package com.ge.fpt.welcomepkg.persistence;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.api.VKCustOrderInfoSpeqT;
import com.ge.fpt.welcomepkg.api.VKSTGReportData;
import com.ge.fpt.welcomepkg.api.ValveKeepPushData;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;
import com.ge.fpt.welcomepkg.util.Constants;
import com.ge.fpt.welcomepkg.util.QueryConstants;

public class ValveKeepDataPersistenceImpl implements IValveKeepDataPersistence {

	@SuppressWarnings("javadoc")
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory.getLogger(ValveKeepDataPersistenceImpl.class);

	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;

	/**
	 * Data source for the JDBC
	 */
	DataSource dataSource;

	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;

	/**
	 * @return the dataSource
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}

	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	/**
	 * 
	 */
	public ValveKeepDataPersistenceImpl() {
		// TODO Auto-generated constructor stub
	}

	@SuppressWarnings("nls")
	@Override
	public StatusInfo uploadValveKeepXMLData(final String createdBy, final String duns, final List<String[]> xmlData) {
		StatusInfo response = new StatusInfo();
		try {

			this.jdbcTemplate.batchUpdate(QueryConstants.VK_CUST_ORDER_INFO_QUERY, new BatchPreparedStatementSetter() {

				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					String[] rowValues = xmlData.get(i);
					ps.setString(1, rowValues[0]);
					ps.setString(2, rowValues[1]);
					ps.setString(3, rowValues[2]);
					ps.setString(4, rowValues[3]);
					ps.setString(5, rowValues[4]);
					ps.setString(6, rowValues[5]);
					ps.setString(7, rowValues[6]);
					ps.setString(8, rowValues[7]);
					ps.setString(9, rowValues[8]);
					ps.setString(10, rowValues[9]);
					ps.setString(11, rowValues[10]);
					ps.setString(12, createdBy);
					ps.setString(13, duns);
				}

				@Override
				public int getBatchSize() {
					return xmlData.size();
				}
			});
			response.setStatusCode(Constants.SUCCESS_STATUS_CODE);
			response.setStatusMessage("File Uploaded Successfully");
		} catch (Exception ex) {
			response.setStatusCode(Constants.FAIL_STATUS_CODE);
			response.setStatusMessage("File Uploaded Fail");
			logger.info("Found Exception when uploading file : " + ex);
		}
		return response;
	}

	@Override
	public StatusInfo getVKSTGReportData(final String loginUserId, final String dunsNumber,
			final List<VKSTGReportData> valveKeepDetails) {
		StatusInfo response = new StatusInfo();
		try {

			for (VKSTGReportData vkstgReportData : valveKeepDetails) {
				this.jdbcTemplate.update(QueryConstants.DELETE_VK_ORDER_INFO_QUERY,
						new Object[] { loginUserId, vkstgReportData.getSalesOrder() });

				this.jdbcTemplate.update(QueryConstants.DELETE_PART_VALVE_INFO_QUERY,
						new Object[] { loginUserId, vkstgReportData.getSalesOrder() });
			}
			
			
			final List<VKSTGReportData> distinctList = removeDuplicateSerialNumbers(valveKeepDetails);

			this.jdbcTemplate.batchUpdate(QueryConstants.VK_ORDER_INFO_QUERY, new BatchPreparedStatementSetter() {

				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					VKSTGReportData rowValues = distinctList.get(i);
					ps.setString(1, rowValues.getSalesOrder());
					ps.setString(2, rowValues.getOrderLineNumber());
					ps.setString(3, rowValues.getEndUserCustName());
					ps.setString(4, rowValues.getCity());
					ps.setString(5, rowValues.getState());
					ps.setString(6, rowValues.getProvince());
					ps.setString(7, rowValues.getPostalCode());
					ps.setString(8, rowValues.getCountry());
					Date date = Date.valueOf(rowValues.getShipDate() != null ? rowValues.getShipDate() : null);
					ps.setDate(9, date);
					ps.setString(10, rowValues.getShipSource());
					ps.setString(11, loginUserId);
					ps.setString(12, dunsNumber);
					ps.setString(13, rowValues.getProductCode());

				}

				@Override
				public int getBatchSize() {
					return distinctList.size();
				}
			});

			this.jdbcTemplate.batchUpdate(QueryConstants.VK_PART_VALVE_INFO_QUERY, new BatchPreparedStatementSetter() {

				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					VKSTGReportData rowValues = valveKeepDetails.get(i);
					ps.setString(1, rowValues.getPartNumber());
					ps.setString(2, rowValues.getPartDescription());
					ps.setString(3, rowValues.getSalesOrder());
					ps.setString(4, rowValues.getOrderLineNumber());
					ps.setString(5, rowValues.getSerialNumber());
					ps.setString(6, rowValues.getTagNumber());
					ps.setString(7, rowValues.getValveDescription());
					ps.setDouble(8, Double.valueOf(rowValues.getQty()));
					ps.setDouble(9, Double.valueOf(rowValues.getListPrice().replace("$", "")));
					ps.setDouble(10, Double.valueOf(rowValues.getLeadTime()));
					ps.setString(11, loginUserId);
					ps.setString(12, dunsNumber);
					ps.setString(13, rowValues.getProductCode());
				}

				@Override
				public int getBatchSize() {
					return valveKeepDetails.size();
				}
			});

			response.setStatusCode(Constants.SUCCESS_STATUS_CODE);
			response.setStatusMessage("Data is Transferred Successfully.");
		} catch (Exception e) {
			response.setStatusCode(Constants.FAIL_STATUS_CODE);
			response.setStatusMessage("Data Transfer is Failed");
			logger.error(
					"Found Exception while transfering data from welcome package to valvekeep stg: " + e.getMessage());
		}
		return response;
	}

	@Override
	public StatusInfo insertvkdocdata(final List<ValveKeepPushData> valveKeepPushData) {

		StatusInfo response = new StatusInfo();

		try {
			this.jdbcTemplate.batchUpdate(QueryConstants.DOCUMENT_SERIAL_NUMBER_PERSIST_QUERY,
					new BatchPreparedStatementSetter() {

						@Override
						public void setValues(PreparedStatement ps, int i) throws SQLException {
							ValveKeepPushData rowValues = valveKeepPushData.get(i);
							ps.setString(1, rowValues.getProjectNumber());
							ps.setString(2, rowValues.getSalesOrderNumber());
							ps.setString(3, rowValues.getSalesOrderLineNumber());
							ps.setString(4, rowValues.getProductionOrderNumber());
							ps.setString(5, rowValues.getSerialNumber());
							ps.setString(6, rowValues.getDocumentDescription());
							ps.setString(7, rowValues.getDocumentType());
							ps.setString(8, rowValues.getFileName());
							ps.setString(9, rowValues.getDocLink());
							ps.setString(10, rowValues.getSiteCode());
							ps.setString(11, rowValues.getTypeFlowProject());
							ps.setString(12, rowValues.getCategoryNuclearCommercial());
							ps.setString(13, rowValues.getDocumentLanguage());
							ps.setString(14, rowValues.getDocumentContentType());
							ps.setString(15, rowValues.getSourceSystem());
						}

						@Override
						public int getBatchSize() {
							return valveKeepPushData.size();
						}
					});
			response.setStatusCode(Constants.SUCCESS_STATUS_CODE);
			response.setStatusMessage("Data is Transferred Successfully.");
		} catch (Exception e) {
			response.setStatusCode(Constants.FAIL_STATUS_CODE);
			response.setStatusMessage("Data Transfer is Failed");
			logger.error(
					"Found Exception while transfering data from welcome package to valvekeep cart: " + e.getMessage());
		}
		return response;

	}

	@Override
	public StatusInfo insertVKSpeqData(final List<VKCustOrderInfoSpeqT> vkCustOrderInfoSpeqData) {

		StatusInfo response = new StatusInfo();
		final List<VKCustOrderInfoSpeqT> vkCustOrderInfoSRVSpeqData = new ArrayList<>();
		final List<VKCustOrderInfoSpeqT> vkCustOrderInfoVALSpeqData = new ArrayList<>();

		try {

			List<VKCustOrderInfoSpeqT> uniqVKCustOrderInfoSpeqTList = removeDuplicateSalesOrders(
					vkCustOrderInfoSpeqData);

			for (VKCustOrderInfoSpeqT vkCustOrderInfoSpeqT : uniqVKCustOrderInfoSpeqTList) {
				if (vkCustOrderInfoSpeqT.getRec_source().equalsIgnoreCase(Constants.SRV_SPEQ)) {
					this.jdbcTemplate.update(QueryConstants.DELETE_VK_SRV_SPEQ_EXISTING_DATA_QUERY,
							new Object[] { vkCustOrderInfoSpeqT.getOrderNumber() });
				} else if (vkCustOrderInfoSpeqT.getRec_source().equalsIgnoreCase(Constants.VAL_SPEQ)) {
					this.jdbcTemplate.update(QueryConstants.DELETE_VK_VAL_SPEQ_EXISTING_DATA_QUERY,
							new Object[] { vkCustOrderInfoSpeqT.getOrderNumber() });
				}
			}

			for (VKCustOrderInfoSpeqT vkCustOrderInfoSpeqT : vkCustOrderInfoSpeqData) {
				if (null != vkCustOrderInfoSpeqT.getRec_source()
						&& vkCustOrderInfoSpeqT.getRec_source().equalsIgnoreCase(Constants.SRV_SPEQ)) {
					vkCustOrderInfoSRVSpeqData.add(vkCustOrderInfoSpeqT);
				} else if (null != vkCustOrderInfoSpeqT.getRec_source()
						&& vkCustOrderInfoSpeqT.getRec_source().equalsIgnoreCase(Constants.VAL_SPEQ)) {
					vkCustOrderInfoVALSpeqData.add(vkCustOrderInfoSpeqT);
				}
			}

			if (vkCustOrderInfoSRVSpeqData.size() > 0) {

				this.jdbcTemplate.batchUpdate(QueryConstants.CUST_ORDER_INFO_SERVSPEQ_PERSIST_QUERY,
						new BatchPreparedStatementSetter() {

							@Override
							public void setValues(PreparedStatement ps, int i) throws SQLException {
								VKCustOrderInfoSpeqT rowValues = vkCustOrderInfoSRVSpeqData.get(i);
								ps.setString(1, rowValues.getAttribute());
								ps.setString(2, rowValues.getField());
								ps.setString(3, rowValues.getValue());
								ps.setString(4, rowValues.getQuoteNumber());
								ps.setString(5, rowValues.getCustomer());
								ps.setString(6, rowValues.getRfqNumber());
								ps.setString(7, rowValues.getCustPoNumber());
								ps.setString(8, rowValues.getProject());
								ps.setString(9, rowValues.getOrderNumber());
								ps.setString(10, rowValues.getGuli());
								ps.setString(11, rowValues.getItemNumber());
								ps.setString(12, rowValues.getTagNumber());
								ps.setString(13, rowValues.getSerialNumber());

							}

							@Override
							public int getBatchSize() {
								return vkCustOrderInfoSRVSpeqData.size();
							}
						});

			} else if (vkCustOrderInfoVALSpeqData.size() > 0) {

				this.jdbcTemplate.batchUpdate(QueryConstants.CUST_ORDER_INFO_VALSPEQ_PERSIST_QUERY,
						new BatchPreparedStatementSetter() {

							@Override
							public void setValues(PreparedStatement ps, int i) throws SQLException {
								VKCustOrderInfoSpeqT rowValues = vkCustOrderInfoVALSpeqData.get(i);
								ps.setString(1, rowValues.getAttribute());
								ps.setString(2, rowValues.getField());
								ps.setString(3, rowValues.getValue());
								ps.setString(4, rowValues.getQuoteNumber());
								ps.setString(5, rowValues.getCustomer());
								ps.setString(6, rowValues.getRfqNumber());
								ps.setString(7, rowValues.getCustPoNumber());
								ps.setString(8, rowValues.getProject());
								ps.setString(9, rowValues.getOrderNumber());
								ps.setString(10, rowValues.getGuli());
								ps.setString(11, rowValues.getItemNumber());
								ps.setString(12, rowValues.getTagNumber());
								ps.setString(13, rowValues.getSerialNumber());

							}

							@Override
							public int getBatchSize() {
								return vkCustOrderInfoVALSpeqData.size();
							}
						});
			}

			response.setStatusCode(Constants.SUCCESS_STATUS_CODE);
			response.setStatusMessage("Data is Transferred Successfully.");

		} catch (Exception e) {
			response.setStatusCode(Constants.FAIL_STATUS_CODE);
			response.setStatusMessage("Data Transfer is Failed");
			logger.error("Found Exception while pushing VK data from Cart: " + e.getMessage());
		}
		return response;
	}
	
	
	private List<VKCustOrderInfoSpeqT> removeDuplicateSalesOrders(List<VKCustOrderInfoSpeqT> vkCustOrderInfoSpeqData) {
		List<VKCustOrderInfoSpeqT> result = new ArrayList<>();
		HashSet<String> set = new HashSet<>();

		for (VKCustOrderInfoSpeqT vkCustOrderInfoSpeqT : vkCustOrderInfoSpeqData) {

			if (!set.contains(vkCustOrderInfoSpeqT.getOrderNumber())) {
				result.add(vkCustOrderInfoSpeqT);
				set.add(vkCustOrderInfoSpeqT.getOrderNumber());
			}
		}
		return result;
	}
	
	private List<VKSTGReportData> removeDuplicateSerialNumbers(List<VKSTGReportData> vKSTGReportData) {
		List<VKSTGReportData> result = new ArrayList<>();
		HashSet<String> set = new HashSet<>();

		for (VKSTGReportData vkSTGReportData : vKSTGReportData) {

			if (!set.contains(vkSTGReportData.getSerialNumber())) {
				result.add(vkSTGReportData);
				set.add(vkSTGReportData.getSerialNumber());
			}
		}
		return result;
	}
}
