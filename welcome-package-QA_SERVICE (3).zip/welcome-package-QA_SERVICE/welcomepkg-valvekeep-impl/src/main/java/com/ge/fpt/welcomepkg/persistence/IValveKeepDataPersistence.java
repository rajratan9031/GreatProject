package com.ge.fpt.welcomepkg.persistence;

import java.util.List;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.api.VKCustOrderInfoSpeqT;
import com.ge.fpt.welcomepkg.api.VKSTGReportData;
import com.ge.fpt.welcomepkg.api.ValveKeepPushData;

public interface IValveKeepDataPersistence {
	@Transactional(propagation=Propagation.REQUIRED)
	StatusInfo uploadValveKeepXMLData(String sso,String duns,List<String[]> xmlData);
	
	@Transactional(propagation=Propagation.REQUIRED)
	StatusInfo getVKSTGReportData(String sso,String duns,List<VKSTGReportData> valveKeepDetails);

	@Transactional(propagation=Propagation.REQUIRED)
	public StatusInfo insertvkdocdata(List<ValveKeepPushData> valveKeepPushData);

	@Transactional(propagation=Propagation.REQUIRED)
	public StatusInfo insertVKSpeqData(List<VKCustOrderInfoSpeqT> vkCustOrderInfoSpeqData);

}