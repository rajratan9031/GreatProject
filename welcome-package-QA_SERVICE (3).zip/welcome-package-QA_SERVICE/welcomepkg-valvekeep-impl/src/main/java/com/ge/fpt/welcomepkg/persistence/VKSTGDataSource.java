/*
 * Copyright (c) 2013 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */
 
package com.ge.fpt.welcomepkg.persistence;

//import javax.sql.DataSource;

import java.util.Map;

import org.apache.commons.dbcp.BasicDataSource;

import com.ge.fpt.welcomepkg.impl.VKSTGConfiguration;
import com.ge.fpt.welcomepkg.impl.VKSTGConfiguration.ConfigConstants;

/**
 * 
 * @author 212414241
 */
public class VKSTGDataSource extends BasicDataSource
{
	private VKSTGConfiguration configuration;

    /**
     * @param configuration configuration bean.
     */
    public void setConfiguration(VKSTGConfiguration configuration)
    {
        this.configuration = configuration;        
    }
    
    @SuppressWarnings("javadoc")
	public VKSTGDataSource ()
    {
    	super();
    }
    
    @SuppressWarnings("javadoc")
    public void init()
    {
        
    	Map<Object, Object> dbConfig = this.configuration.getDbconfig();
    	this.driverClassName = (String) dbConfig.get(ConfigConstants.DB_CONNECTION_DRIVER_NAME);
		this.url = (String) dbConfig.get(ConfigConstants.DB_CONNECTION_URL);
		this.username = (String) dbConfig.get(ConfigConstants.DB_CONNECTION_USER);
		this.password = (String) dbConfig.get(ConfigConstants.DB_CONNECTION_PASSWORD);
		this.initialSize = Integer.valueOf((String)dbConfig.get(ConfigConstants.DB_POOL_INITIALSIZE));
		this.maxIdle = Integer.valueOf((String)dbConfig.get(ConfigConstants.DB_DBCP_MAX_IDEL));
		this.maxActive = Integer.valueOf((String)dbConfig.get(ConfigConstants.DB_DBCP_MAX_ACTIVE));
		this.validationQuery = (String) dbConfig.get(ConfigConstants.DB_DBCP_VALIDATION_QUERY);
    }
  


}
