/*
 * Copyright (c) 2013 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.fpt.welcomepkg.impl;

import java.util.List;

import javax.jws.WebMethod;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;

import org.springframework.web.bind.annotation.RequestBody;

import com.ge.dsp.core.spi.annotation.RestfulServiceAddress;
import com.ge.fpt.welcomepkg.api.IWelcomePkgService;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.api.VKCustOrderInfoSpeqT;
import com.ge.fpt.welcomepkg.api.VKSTGReportData;
import com.ge.fpt.welcomepkg.api.ValveKeepPushData;
import com.ge.fpt.welcomepkg.persistence.IValveKeepDataPersistence;
import com.ge.fpt.welcomepkg.util.Constants;

/**
 * Welcome Pkg service implementation
 * 
 * @author 212414241
 */
@RestfulServiceAddress("welcome-pkg-valvekeep")
public class WelcomePkgServiceImpl implements IWelcomePkgService {

	@SuppressWarnings("javadoc")
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory.getLogger(WelcomePkgServiceImpl.class);

	private IValveKeepDataPersistence valveKeepDataPersistence;

	public IValveKeepDataPersistence getValveKeepDataPersistence() {
		return valveKeepDataPersistence;
	}

	public void setValveKeepDataPersistence(IValveKeepDataPersistence valveKeepDataPersistence) {
		this.valveKeepDataPersistence = valveKeepDataPersistence;
	}

	@Override
	public StatusInfo uploadValveKeepXML(@PathParam(value = "sso") String createdBy, @QueryParam(value = "duns") String dunsNumber,
			@RequestBody List<String[]> xmlData) {
		StatusInfo status = new StatusInfo();
		try {
			status = this.valveKeepDataPersistence.uploadValveKeepXMLData(createdBy, dunsNumber, xmlData);
			status.setStatusCode(Constants.SUCCESS_STATUS_CODE);
			status.setStatusMessage("Upload ValveKeep successful.");
		} catch (Exception e) {
			logger.error("Exception in Valvekeep File Upload service : " + e.getMessage());
			status.setStatusCode(Constants.FAIL_STATUS_CODE);
			status.setStatusMessage("Upload ValveKeep Failed." + e.getMessage());
		}
		return status;
	}

	@Override
	@WebMethod
	public StatusInfo getVKSTGReportData(@PathParam(value = "loginUserId") String loginUserId, @QueryParam(value = "dunsNumber") String dunsNumber,
			@RequestBody List<VKSTGReportData> valveKeepDetails) {
		StatusInfo info = new StatusInfo();
		try {
			info = this.valveKeepDataPersistence.getVKSTGReportData(loginUserId, dunsNumber, valveKeepDetails);
			info.setStatusCode(Constants.SUCCESS_STATUS_CODE);
			info.setStatusMessage("Fetch VK data successful.");
		} catch (Exception e) {
			logger.error("Exception in Valvekeep while fetching VK data : " + e.getMessage());
			info.setStatusCode(Constants.FAIL_STATUS_CODE);
			info.setStatusMessage("Exception while fetching VK data" + e.getMessage());
		}
		return info;
	}

	@Override
	@WebMethod
	public StatusInfo insertvkdocdata(@RequestBody List<ValveKeepPushData> valveKeepPushData) {
		StatusInfo info = new StatusInfo();

		try {
			info = this.valveKeepDataPersistence.insertvkdocdata(valveKeepPushData);
			info.setStatusCode(Constants.SUCCESS_STATUS_CODE);
			info.setStatusMessage("Push VK data successful.");
		} catch (Exception e) {
			logger.error("Exception in Valvekeep while pushing VK data : " + e.getMessage());
			info.setStatusCode(Constants.FAIL_STATUS_CODE);
			info.setStatusMessage("Exception in Valvekeep while pushing VK data : " + e.getMessage());
		}
		return info;
	}

	@Override
	@WebMethod
	public StatusInfo persistVKSpeqData(@RequestBody List<VKCustOrderInfoSpeqT> vkCustOrderInfoSpeqData) {
		StatusInfo info = new StatusInfo();
		try {
			info = this.valveKeepDataPersistence.insertVKSpeqData(vkCustOrderInfoSpeqData);
			info.setStatusCode(Constants.SUCCESS_STATUS_CODE);
			info.setStatusMessage("Update VKC data successful.");
		} catch (Exception e) {
			logger.error("Exception while Update VKC data : " + e.getMessage());
			info.setStatusCode(Constants.FAIL_STATUS_CODE);
			info.setStatusMessage("Exception while Update VKC data " + e.getMessage());
		}
		return info;
	}

}
