package com.ge.fpt.welcomepkg.util;

public class Constants {
	
	  public static final int SUCCESS_STATUS_CODE = 1;
	  public static final int FAIL_STATUS_CODE = 1;
	  public static final String SRV_SPEQ = "SRVSPEQ";
	  public static final String VAL_SPEQ = "VALSPEQ";
}

