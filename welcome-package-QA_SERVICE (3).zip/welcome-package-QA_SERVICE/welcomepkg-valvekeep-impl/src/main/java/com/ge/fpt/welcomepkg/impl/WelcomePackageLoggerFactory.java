/*
 * Copyright (c) 2013 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.fpt.welcomepkg.impl;

import java.util.Properties;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.ge.dsp.core.spi.IServiceManagerService;
import com.ge.dsp.dsi.logging.ILoggerService;
import com.ge.dsp.dsi.logging.LogLevel;
import com.ge.dsp.dsi.logging.LoggerConstants;
import com.ge.dsp.dsi.logging.LoggerException;
import com.ge.dsp.dsi.logging.spi.LoggerType;

/**
 * @author 212414241
 * 
 */
public class WelcomePackageLoggerFactory
{
    @Autowired private IServiceManagerService dspServiceManager;

    private ILoggerService                    loggerService;

    /**
     * @param loggerService the loggerService to set
     */
    public void setLoggerService(ILoggerService loggerService)
    {
        this.loggerService = loggerService;
    }

    private String                  applicationId;

    private Object                  rootCategory;

    private Object                  logLevel;

    private Object                  appenderFilename;

    private Object                  appenderFilePattern;
    private static WelcomePackageLoggerFactory instance;

    /**
     * Instantiates a DSP logger for the given Class.
     * 
     * @param clazz Cateogry of logger
     * @return Logger class
     */
    public static Logger getLogger(Class<?> clazz)
    {
        return (Logger) instance.loggerService.getLogger(clazz, LoggerType.SLF4j);
    }

    /**
     * @param category of logger
     * @param level of logger
     */
    public static void setLevel(String category, String level)
    {
        try
        {
            instance.loggerService.setLevel(category, LogLevel.valueOf(level));
        }
        catch (LoggerException e)
        {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("javadoc")
    public static synchronized WelcomePackageLoggerFactory getInstance()
    {
        return instance;
    }

    /*
     * default constructor
     */
    @SuppressWarnings("javadoc")
    public WelcomePackageLoggerFactory()
    {
        instance = this;
    }

    /**
     * 
     */
    @SuppressWarnings("nls")
    public void init()
    {
        if ( this.loggerService == null )
        {
            throw new RuntimeException("Failed to get loggerService.");
        }

        Logger logger = getLogger(WelcomePackageLoggerFactory.class);

        Properties loggerProps = new Properties();
        loggerProps.put(LoggerConstants.CONFIGURATION_PROPERTY_APPLICATION_ID, this.applicationId);
        loggerProps.put(LoggerConstants.CONFIGURATION_PROPERTY_ROOT_CATEGORY, this.rootCategory);
        loggerProps.put(LoggerConstants.CONFIGURATION_PROPERTY_ROOT_LOG_LEVEL, this.logLevel);
        loggerProps.put(LoggerConstants.CONFIGURATION_PROPERTY_APPENDER_CONSOLE, "" + false);
        loggerProps.put(LoggerConstants.CONFIGURATION_PROPERTY_APPENDER_FILE, "" + true);
        loggerProps.put(LoggerConstants.CONFIGURATION_PROPERTY_APPENDER_FILE_PATTERN, this.appenderFilePattern);
        loggerProps.put(LoggerConstants.CONFIGURATION_PROPERTY_APPENDER_FILE_NAME, this.appenderFilename);
        try
        {
            this.loggerService.configure(loggerProps);
        }
        catch (LoggerException e)
        {
            logger.error("logger configuration error:", e);
        }

        logger.debug("Logger initialized for " + this.applicationId);

    }

    /**
     * @param applicationId for the logger
     */
    public void setApplicationId(String applicationId)
    {
        this.applicationId = applicationId;
    }

    /**
     * @param rootCategory set the root category
     */
    public void setRootCategory(Object rootCategory)
    {
        this.rootCategory = rootCategory;
    }

    /**
     * 
     * @param logLevel the string value of com.ge.dsp.dsi.logging.LogLevel
     */
    public void setLogLevel(String logLevel)
    {
        this.logLevel = logLevel;
    }

    /**
     * @param appenderFilename file name logger uses
     */
    public void setAppenderFilename(Object appenderFilename)
    {
        this.appenderFilename = appenderFilename;
    }

    /**
     * @param appenderFilePattern the pattern of the appender
     */
    public void setAppenderFilePattern(Object appenderFilePattern)
    {
        this.appenderFilePattern = appenderFilePattern;
    }

    /**
     * @return the dspServiceManager
     */
    public IServiceManagerService getDspServiceManager()
    {
        return this.dspServiceManager;
    }

    /**
     * @param dspServiceManager the dspServiceManager to set
     */
    public void setDspServiceManager(IServiceManagerService dspServiceManager)
    {
        this.dspServiceManager = dspServiceManager;
    }
}
