/*


 * 
 * Copyright (c) 2013 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.fpt.welcomepkg.api;

import java.util.List;

import javax.jws.WebService;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.RequestBody;

/**
 * Welcome Pkg service interface
 * 
 * @author 212414241
 */

@Path("/valvekeep/")
@WebService
public interface IWelcomePkgService {

	@POST
	@Path("uploadValveKeepXML/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo uploadValveKeepXML(@PathParam(value = "sso") String sso, @QueryParam(value = "duns") String duns,
			@RequestBody List<String[]> xmlData);

	@POST
	@Path("valveKeepstgreportdata/{loginUserId}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public StatusInfo getVKSTGReportData(@PathParam(value = "loginUserId") String loginUserId, @QueryParam(value = "dunsNumber") String dunsNumber,
			@RequestBody List<VKSTGReportData> valveKeepDetails);

	@POST
	@Path("insertvkdocdata")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public StatusInfo insertvkdocdata(@RequestBody List<ValveKeepPushData> valveKeepPushData);

	@POST
	@Path("valvekeepspeqdata")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public StatusInfo persistVKSpeqData(@RequestBody List<VKCustOrderInfoSpeqT> valveKeepCustOrderInfoSpeqTData);

}
