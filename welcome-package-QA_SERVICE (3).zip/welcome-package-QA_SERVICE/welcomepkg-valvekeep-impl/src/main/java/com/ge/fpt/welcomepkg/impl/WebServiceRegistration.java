/*
 * Copyright (c) 2013 GE Global Research. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Global Research. The software may be used and/or copied only
 * with the written permission of GE Global Research or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.fpt.welcomepkg.impl;

import org.slf4j.Logger;

import com.ge.dsp.core.spi.IServiceManagerService;
import com.ge.fpt.welcomepkg.api.IWelcomePkgService;

/**
 * @author 212414241
 * 
 */
public class WebServiceRegistration
{
    private static Logger       logger;
    private IServiceManagerService serviceManagerService;
    private IWelcomePkgService       welcomePkgService;

    /**
     * @param alarmService the alarmService to set
     */
    public void setWelcomePkgService(IWelcomePkgService welcomePkgService)
    {
        this.welcomePkgService = welcomePkgService;
    }

    /**
     * @param serviceManagerService the serviceManagerService to set
     */
    public void setServiceManagerService(IServiceManagerService serviceManagerService)
    {
        this.serviceManagerService = serviceManagerService;
    }

    /**
    *
    */
    public void registerWebServices()
    {
        this.logger = WelcomePackageLoggerFactory.getLogger(WebServiceRegistration.class);
        
        this.serviceManagerService.createRestWebService(this.welcomePkgService, null);
        logger.info("DONE Welcome Package Service JDBC REST Service Registration"); //$NON-NLS-1$
        this.serviceManagerService.createSoapWebService(this.welcomePkgService, "/welcome-pkg-jdbc-soap"); //$NON-NLS-1$
        logger.info("DONE Welcome Package Service JDBC SOAP Service Registration"); //$NON-NLS-1$
    }

}
