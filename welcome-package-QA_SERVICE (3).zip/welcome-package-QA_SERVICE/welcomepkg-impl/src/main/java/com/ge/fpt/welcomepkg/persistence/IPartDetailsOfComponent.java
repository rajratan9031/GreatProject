package com.ge.fpt.welcomepkg.persistence;

import java.util.List;
import java.util.Map;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ge.fpt.welcomepkg.api.PartDetailsOfComponent;

public interface IPartDetailsOfComponent {
	@Transactional(propagation=Propagation.REQUIRED)
	List<PartDetailsOfComponent> getPartDetailsForComponent(Map componentData);
}
