package com.ge.fpt.welcomepkg.persistence;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ge.fpt.welcomepkg.api.Inventory;
import com.ge.fpt.welcomepkg.api.StatusInfo;

public interface IInventoryPersistence {

	public  List<Inventory> getInventory(Inventory inventory);

	public  StatusInfo uploadInventory(HashMap getCompleteData);
	
	public StatusInfo sendEmail(Map mailDetails,String sso);

}