package com.ge.fpt.welcomepkg.api;

import java.util.ArrayList;
import java.util.List;

public class InstalledBaseWithDuns {
List<InstallBaseLoc> locations;
private String channel;
public List<InstallBaseLoc> getLocations() {
	return locations;
}
public void setLocations(List<InstallBaseLoc> locations) {
	this.locations = locations;
}
public String getChannel() {
	return channel;
}
public void setChannel(String channel) {
	this.channel = channel;
}
public void addLocation(InstallBaseLoc loc){
	if(getLocations()==null){
		locations = new ArrayList<>();
	}
	getLocations().add(loc);
}
}
