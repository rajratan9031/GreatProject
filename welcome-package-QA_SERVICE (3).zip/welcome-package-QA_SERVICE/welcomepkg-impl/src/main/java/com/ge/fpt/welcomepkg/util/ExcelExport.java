package com.ge.fpt.welcomepkg.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;

import com.ge.fpt.welcomepkg.api.Report;
import com.ge.fpt.welcomepkg.api.ReportData;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;
import com.ge.fpt.welcomepkg.impl.WelcomePkgServiceImpl;

public class ExcelExport {

	@SuppressWarnings("javadoc")
	public static final org.slf4j.Logger logger = WelcomePackageLoggerFactory.getLogger(ExcelExport.class);
	
	private static final String SPIR_TEMPLATE = "/WEB-INF/template/SPIR.xls";
	private static final String RSP_TEMPLATE = "/WEB-INF/template/RSPByValveReport.xls";
	private static final String BOM_TEMPLATE = "/WEB-INF/template/BOMByValveReport.xls";
	private static final String QUOTE_TEMPLATE = "/WEB-INF/template/SparePartsQuote.xls";

	public byte[] generateExcel(List<Report> data, ReportData reportParam,String currencySymbol, String sso) {
		boolean isInternal = WelcomePkgServiceImpl.isInternalUser(sso);
		return generateExcelReport(data, reportParam,currencySymbol,isInternal);
	}

	public byte[] generateExcelReport(List<Report> data, ReportData reportParam,String currencySymbol,boolean isInternal) {
		Map<String, Object> headerData = null;
		Map<String, Object> quoteHeaderData = null;

		if (("4").equals(reportParam.getReportType())
				|| ("5").equals(reportParam.getReportType())) {
			headerData = processHeaderData(data);
		}
		try {
			byte[] excelBytes = null;
			if (("4").equals(reportParam.getReportType())) {
				List<Report> processDataList = processSpirData(data);
				excelBytes = generateSpirExcelReport(processDataList,
						headerData);
			}
			if (("5").equals(reportParam.getReportType())){
				List<Report> processDataList = processRspValveData(data);
				excelBytes = generateRspValveExcelReport(processDataList,
						headerData);
			}
			if (("6").equals(reportParam.getReportType())) {
				List<String> factoryist = processBomValveData(data);
				excelBytes = generateBomValveExcelReport(factoryist, data);
			}
			if (("7").equals(reportParam.getReportType())) {
				List<Report> headerDataList = processQuoteData(data,isInternal);
			//	quoteHeaderData = processQuoteHeaderData(data,isInternal);
			//	excelBytes = generateQuoteExcelReport(headerDataList, data,
			//			quoteHeaderData);

				excelBytes = generateQuoteExcelReport(headerDataList, currencySymbol,data);
  		}

			return excelBytes;
		} catch (Exception e) {
			logger.info("Exception in generateExcelReport: " + e);
			return null;
		}

	}

	public byte[] generateRspValveExcelReport(List<Report> processDataList,
			Map<String, Object> headerData) throws IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		InputStream file = null;
		HSSFWorkbook wb = null;
		try {
			file = this.getClass().getResourceAsStream(RSP_TEMPLATE);
			wb = new HSSFWorkbook(file);
			HSSFSheet sheet = wb.getSheetAt(0);
			HSSFCellStyle stylewrap = wb.createCellStyle();
			HSSFFont txtFont = (HSSFFont) wb.createFont();
			txtFont.setFontName("Arial");
			txtFont.setFontHeightInPoints((short) 8);
			stylewrap.setFont(txtFont);
			stylewrap.setWrapText(true);
			stylewrap.setVerticalAlignment(HSSFCellStyle.VERTICAL_TOP);
			HSSFCellStyle center = wb.createCellStyle();
			center.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			center.setVerticalAlignment(HSSFCellStyle.VERTICAL_TOP);
			center.setFont(txtFont);
			HSSFRow row = sheet.getRow(2);
			HSSFCell cell = row.getCell(16);
			Date date = new Date();
			cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
			cell.setCellValue(date);
			row = sheet.getRow(5);
			cell = row.getCell(3);
			cell.setCellValue(headerData.get("salesOrder").toString());
			cell = row.getCell(10);
			cell.setCellValue(headerData.get("customer").toString());
			row = sheet.getRow(6);
			cell = row.getCell(3);
			cell.setCellValue(headerData.get("purchaseOrder").toString());
			row = sheet.getRow(7);
			cell = row.getCell(3);
			cell.setCellValue(headerData.get("factory").toString());
			row = sheet.getRow(8);
			cell = row.getCell(3);
			cell.setCellValue(headerData.get("rep").toString());

			int startRow = 11;
			row = sheet.getRow(startRow - 1);
			row.setHeightInPoints(25);
			cell = row.getCell(16);
			cell.setCellValue("List Price ("
					+ processDataList.get(0).getCurrencyUnit() + ")");

			for (int i = 0; i < processDataList.size(); i++) {
				row = sheet.getRow(startRow);
				row.setHeight((short) 500);
				
				cell = row.getCell(1,Row.CREATE_NULL_AS_BLANK);
				cell.setCellValue(processDataList.get(i).getSalesOrderLine());
				cell.setCellStyle(stylewrap);

				cell = row.getCell(2,Row.CREATE_NULL_AS_BLANK);
				cell.setCellValue(processDataList.get(i).getValveSerialNumber());
				cell.setCellStyle(stylewrap);

				cell = row.getCell(4,Row.CREATE_NULL_AS_BLANK);
				cell.setCellValue(processDataList.get(i).getTagNumber());
				cell.setCellStyle(stylewrap);

				cell = row.getCell(5,Row.CREATE_NULL_AS_BLANK);
				cell.setCellValue(processDataList.get(i).getActualShippedDate()==null?""
						:processDataList.get(i).getActualShippedDate().toString());
				cell.setCellStyle(stylewrap);

				cell = row.getCell(6,Row.CREATE_NULL_AS_BLANK);
				cell.setCellValue(processDataList.get(i)
						.getComponentItemNumber());
				cell.setCellStyle(stylewrap);

				cell = row.getCell(7,Row.CREATE_NULL_AS_BLANK);
				cell.setCellValue(processDataList.get(i)
						.getComponentDescription());
				cell.setCellStyle(stylewrap);

				cell = row.getCell(11,Row.CREATE_NULL_AS_BLANK);
				cell.setCellValue(processDataList.get(i).getLegacyPartNumber());
				cell.setCellStyle(stylewrap);

				cell = row.getCell(13,Row.CREATE_NULL_AS_BLANK);
				cell.setCellValue(processDataList.get(i).getSpareIndicator());
				cell.setCellStyle(stylewrap);

				cell = row.getCell(14,Row.CREATE_NULL_AS_BLANK);
				cell.setCellValue(processDataList.get(i).getStockType());
				cell.setCellStyle(stylewrap);

				cell = row.getCell(15,Row.CREATE_NULL_AS_BLANK);
				cell.setCellValue(processDataList.get(i).getQuantity());
				cell.setCellStyle(center);

				cell = row.getCell(16,Row.CREATE_NULL_AS_BLANK);
				cell.setCellValue(processDataList.get(i).getListPrice());
				cell.setCellStyle(stylewrap);

				cell = row.getCell(17,Row.CREATE_NULL_AS_BLANK);
				cell.setCellValue(processDataList.get(i).getLeadTime());
				cell.setCellStyle(center);

				startRow += 1;
			}

		/*	// set quantity & lead time in center
			int rownum = 11;
			for (int i = 0; i < processDataList.size(); i++) {
				row = sheet.getRow(rownum);
				HSSFCellStyle center = wb.createCellStyle();
				center.setAlignment(HSSFCellStyle.ALIGN_CENTER);
				center.setVerticalAlignment(HSSFCellStyle.VERTICAL_TOP);
				center.setFont(txtFont);
				cell = row.getCell(15);
				cell.setCellStyle(center);
				cell = row.getCell(17);
				cell.setCellStyle(center);
				rownum += 1;
			}*/

			file.close();

			wb.write(baos);
			byte[] excelBytes = baos.toByteArray();
			wb.close();
			file.close();
			baos.close();
			return excelBytes;
		} catch (Exception e) {
			wb.close();
			file.close();
			baos.close();
			logger.info("Exception in generateRspValveExcelReport: " + e);
			return null;

		}
	}

	public byte[] generateSpirExcelReport(List<Report> processDataList,
			Map<String, Object> headerData) throws IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		InputStream file = null;
		HSSFWorkbook wb = null;
		try {
			file = this.getClass().getResourceAsStream(SPIR_TEMPLATE);
			wb = new HSSFWorkbook(file);
			HSSFSheet sheet = wb.getSheetAt(0);
			HSSFCellStyle stylewrap = wb.createCellStyle();
			HSSFFont txtFont = (HSSFFont) wb.createFont();
			txtFont.setFontName("Arial");
			txtFont.setFontHeightInPoints((short) 8);
			stylewrap.setFont(txtFont);
			stylewrap.setWrapText(true);
			stylewrap.setVerticalAlignment(HSSFCellStyle.VERTICAL_TOP);
			
			HSSFCellStyle center = wb.createCellStyle();
			center.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			center.setVerticalAlignment(HSSFCellStyle.VERTICAL_TOP);
			center.setFont(txtFont);
			
			HSSFRow row = sheet.getRow(4);
			HSSFCell cell = row.getCell(12);
			Date date = new Date();
			cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
			cell.setCellValue(date);
			row = sheet.getRow(6);
			cell = row.getCell(2);
			cell.setCellValue(headerData.get("salesOrder").toString());
			cell = row.getCell(8);
			cell.setCellValue(headerData.get("customer").toString());
			row = sheet.getRow(7);
			cell = row.getCell(2);
			cell.setCellValue(headerData.get("purchaseOrder").toString());
			row = sheet.getRow(8);
			cell = row.getCell(2);
			cell.setCellValue(headerData.get("factory").toString());
			row = sheet.getRow(9);
			cell = row.getCell(2);
			cell.setCellValue(headerData.get("rep").toString());

			int startRow = 12;

			// change Price Unit
			row = sheet.getRow(startRow - 1);
			row.setHeightInPoints(25);
			cell = row.getCell(14);
			cell.setCellValue("List Price ("
					+ processDataList.get(0).getCurrencyUnit() + ")");
			cell = row.getCell(15);
			cell.setCellValue("Extended Price ("
					+ processDataList.get(0).getCurrencyUnit() + ")");

			for (int i = 0; i < processDataList.size(); i++) {
				row = sheet.getRow(startRow);
				row.setHeight((short) 700);

				cell = row.getCell(1,Row.CREATE_NULL_AS_BLANK);
				cell.setCellValue(processDataList.get(i)
						.getComponentItemNumber());
				cell.setCellStyle(stylewrap);

				cell = row.getCell(3,Row.CREATE_NULL_AS_BLANK);
				cell.setCellValue(processDataList.get(i)
						.getComponentDescription());
				cell.setCellStyle(stylewrap);

				cell = row.getCell(4,Row.CREATE_NULL_AS_BLANK);
				cell.setCellValue(processDataList.get(i).getSpareCategory());
				cell.setCellStyle(stylewrap);

				cell = row.getCell(7,Row.CREATE_NULL_AS_BLANK);
				cell.setCellValue(processDataList.get(i).getQuantity());
				cell.setCellStyle(center);

				cell = row.getCell(9,Row.CREATE_NULL_AS_BLANK);
				cell.setCellStyle(stylewrap);
				cell.setCellValue(processDataList.get(i).getTagNumber());

				cell = row.getCell(11,Row.CREATE_NULL_AS_BLANK);
				cell.setCellValue(processDataList.get(i).getValveSerialNumber());
				cell.setCellStyle(stylewrap);

				cell = row.getCell(12,Row.CREATE_NULL_AS_BLANK);
				if (processDataList.get(i).getRecommendedQuantity() != 0.0) {
					cell.setCellValue(processDataList.get(i)
							.getRecommendedQuantity());
				} else {
					cell.setCellValue("");
				}
				cell.setCellStyle(center);

				cell = row.getCell(14,Row.CREATE_NULL_AS_BLANK);
				if (processDataList.get(i).getListPrice() != 0.0) {
					cell.setCellValue(processDataList.get(i).getListPrice());
				} else {
					cell.setCellValue("");
				}
				cell.setCellStyle(stylewrap);

				cell = row.getCell(15,Row.CREATE_NULL_AS_BLANK);
				if (processDataList.get(i).getExtendedListPrice() != 0.0) {
					cell.setCellValue(processDataList.get(i)
							.getExtendedListPrice());
				} else {
					cell.setCellValue("");
				}
				cell.setCellStyle(stylewrap);

				startRow += 1;
			}

		/*	// set quantity in center
			int rownum = 12;
			for (int i = 0; i < processDataList.size(); i++) {
				row = sheet.getRow(rownum);
				cell = row.getCell(7);
				HSSFCellStyle center = wb.createCellStyle();
				center.setAlignment(HSSFCellStyle.ALIGN_CENTER);
				center.setVerticalAlignment(HSSFCellStyle.VERTICAL_TOP);
				center.setFont(txtFont);
				cell.setCellStyle(center);
				cell = row.getCell(12);
				cell.setCellStyle(center);
				rownum += 1;
			}*/

			wb.write(baos);
			byte[] excelSpirBytes = baos.toByteArray();
			wb.close();
			file.close();
			baos.close();
			return excelSpirBytes;
		} catch (Exception e) {
			wb.close();
			file.close();
			baos.close();
			logger.info("Exception in generateSpirExcelReport: " + e);
			return null;
		}
	}

	public List<Report> processSpirData(List<Report> data) {
		List<Report> processSpirData = new ArrayList<Report>();

		String componentItemNumber = "";
		for (int i = 0; i < data.size(); i++) {
			Report spirData = new Report();
			spirData.setTagNumber("");
			spirData.setValveSerialNumber("");
			if (!componentItemNumber.equalsIgnoreCase(data.get(i)
					.getComponentItemNumber())) {
				spirData.setComponentItemNumber(data.get(i)
						.getComponentItemNumber());
				spirData.setComponentDescription(data.get(i)
						.getComponentDescription());
				spirData.setSpareCategory(data.get(i).getSpareCategory());
				int quantity = 0;
				for (int k = i; k < data.size(); k++) {
					if (data.get(k)
							.getComponentItemNumber()
							.equalsIgnoreCase(spirData.getComponentItemNumber())) {
						quantity += data.get(k).getQuantity();
					} else {
						break;
					}
				}
				spirData.setQuantity(quantity);
				spirData.setTagNumber("");
				spirData.setValveSerialNumber("");
				/*spirData.setRecommendedQuantity(Math.ceil(spirData
						.getQuantity() * data.get(i).getDefaultPercent()));*/
				spirData.setRecommendedQuantity(data.get(i).getRecomendedQty());
				spirData.setListPrice(data.get(i).getListPrice());
				spirData.setExtendedListPrice(+spirData
						.getRecommendedQuantity() * data.get(i).getListPrice());
				componentItemNumber = data.get(i).getComponentItemNumber();
				spirData.setCurrencyUnit(data.get(i).getCurrencyUnit());
				i = i - 1;

			} else {
				spirData.setComponentItemNumber("");
				spirData.setComponentDescription("");
				spirData.setSpareCategory("");
				spirData.setQuantity(data.get(i).getQuantity());
				spirData.setTagNumber(data.get(i).getTagNumber());
				spirData.setValveSerialNumber(data.get(i)
						.getValveSerialNumber());
				spirData.setCurrencyUnit(data.get(i).getCurrencyUnit());
			}
			processSpirData.add(spirData);
		}
		return processSpirData;
	}

	public List<Report> processRspValveData(List<Report> data) {
		List<Report> processData = new ArrayList<Report>();

		String soLine = "";
		String serialNumber = "";
		String tagNumber = "";
		for (int i = 0; i < data.size(); i++) {
			Report rspValveData = new Report();
			String sqlesOrderLine = data.get(i).getSalesOrderLine()==null?"":data.get(i).getSalesOrderLine();
			String srno = data.get(i).getValveSerialNumber()==null?"":data.get(i).getValveSerialNumber();
			String tagno = data.get(i).getTagNumber()==null?"":data.get(i).getTagNumber();
			if (!sqlesOrderLine.equalsIgnoreCase(soLine)
					|| !srno.equalsIgnoreCase(serialNumber)) {
				rspValveData.setSalesOrderLine(data.get(i).getSalesOrderLine());
				rspValveData.setValveSerialNumber(data.get(i)
						.getValveSerialNumber());
				rspValveData.setTagNumber(data.get(i).getTagNumber());
			} else {
				rspValveData.setSalesOrderLine("");
				rspValveData.setValveSerialNumber("");
				rspValveData.setTagNumber("");
			}
			rspValveData.setActualShippedDate(data.get(i)
					.getActualShippedDate());
			rspValveData.setComponentItemNumber(data.get(i)
					.getComponentItemNumber());
			rspValveData.setComponentDescription(data.get(i)
					.getComponentDescription());
			rspValveData.setLegacyPartNumber(data.get(i).getLegacyPartNumber());
			rspValveData.setSpareIndicator(data.get(i).getSpareIndicator());
			rspValveData.setStockType(data.get(i).getStockType());
			rspValveData.setQuantity(data.get(i).getQuantity());
			rspValveData.setListPrice(data.get(i).getListPrice());
			rspValveData.setLeadTime(data.get(i).getLeadTime());
			rspValveData.setCurrencyUnit(data.get(i).getCurrencyUnit());
			processData.add(rspValveData);

			soLine = data.get(i).getSalesOrderLine();
			serialNumber = data.get(i).getValveSerialNumber();
			tagNumber = data.get(i).getTagNumber();

		}
		return processData;
	}

	public List<String> processBomValveData(List<Report> data) {
		List<String> factoryList = new ArrayList<String>();
		for (int i = 0; i < data.size(); i++) {
			if (!factoryList.contains(data.get(i).getSourceSystem())) {
				factoryList.add(data.get(i).getSourceSystem());
			}
		}
		return factoryList;
	}

	public byte[] generateBomValveExcelReport(List<String> factoryList,
			List<Report> bomDataList) throws IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		InputStream file = null;
		HSSFWorkbook wb = null;
		try {
			file = this.getClass().getResourceAsStream(BOM_TEMPLATE);
			wb = new HSSFWorkbook(file);
			HSSFFont txtFont = (HSSFFont) wb.createFont();
			txtFont.setFontName("Arial");
			txtFont.setFontHeightInPoints((short) 8);
			HSSFCellStyle stylewrap = wb.createCellStyle();
			stylewrap.setFont(txtFont);
			stylewrap.setWrapText(true);
			stylewrap.setVerticalAlignment(HSSFCellStyle.VERTICAL_TOP);
			stylewrap.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			if (factoryList.size() > 1) {
				for (int i = 1; i < factoryList.size(); i++) {
					wb.cloneSheet(0);
					int id = i + 1;
					wb.setSheetName(i, "Sheet" + id);
				}
			}
			
			String serialNumber = "";
			String soLine="";
			String tagNo="";
			String so = "";
			String po = "";
			String repName = "";
			String custName = "";
			for (int i = 0; i < factoryList.size(); i++) {
				HSSFSheet sheet = wb.getSheetAt(i);
				HSSFRow row = sheet.getRow(1);
				HSSFCell cell = row.getCell(17);
				Date date = new Date();
				cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
				cell.setCellValue(date);

				row = sheet.getRow(5);
				cell = row.getCell(2);
				Set<String> salesOrderSet = new HashSet<String>();
				Set<String> purcahseOrderSet = new HashSet<String>();
				Set<String> repNameSet = new HashSet<String>();
				Set<String> custNameSet = new HashSet<String>();


				row = sheet.getRow(5);
				cell = row.getCell(2);
				logger.info("bomDataList  :"+bomDataList.size());
				for (int j = 0; j < bomDataList.size(); j++) {
				if (factoryList.get(i).equalsIgnoreCase(
				bomDataList.get(j).getSourceSystem())) {
				salesOrderSet.add(bomDataList.get(j).getSalesOrder());
				purcahseOrderSet.add(bomDataList.get(j).getPurchaseOrderNumber());
				repNameSet.add(bomDataList.get(j).getRepName());
				String customerName = (bomDataList.get(j).getSoldToCustomerName()==null?"":bomDataList.get(j).getSoldToCustomerName().toString())+" "+
				(bomDataList.get(j).getSoldToCity()==null?"":bomDataList.get(j).getSoldToCity().toString())+" "+
				(bomDataList.get(j).getSoldToState()==null?"":bomDataList.get(j).getSoldToState().toString())+" "+
				(bomDataList.get(j).getEndUserCountry()==null?"":bomDataList.get(j).getEndUserCountry().toString());

				custNameSet.add(customerName);
				}
				}

				if (salesOrderSet.size() != 0) {
				for(String temp : salesOrderSet){
				so = so + temp + ",";
				}
				so = so.substring(0, so.length() - 1);
				}

				if (purcahseOrderSet.size() != 0) {
				for(String temp : purcahseOrderSet){
				po = po + temp + ",";
				}
				po = po.substring(0, po.length() - 1);
				}
				if (repNameSet.size() != 0) {
				for(String temp : repNameSet){
				repName = repName + temp + ",";
				}
				repName = repName.substring(0, repName.length() - 1);
				}
				if (custNameSet.size() != 0) {
				for(String temp : custNameSet){
				custName = custName + temp + ",";
				}
				custName = custName.substring(0, custName.length() - 1);
				}
				cell.setCellValue(so);
				cell = row.getCell(10);
				cell.setCellValue(custName);
				row = sheet.getRow(6);
				cell = row.getCell(2);
				cell.setCellValue(po);
				row = sheet.getRow(7);
				cell = row.getCell(2);
				cell.setCellValue(factoryList.get(i).toString());
				row = sheet.getRow(8);
				cell = row.getCell(2);
				cell.setCellValue(repName);

				int startRow = 11;
				logger.info("bomDataList :"+ bomDataList.size());
				for (int k = 0; k < bomDataList.size(); k++) {
					boolean isFirstRow = false;
					logger.info("k value :"+ k);
					if (bomDataList.get(k).getSourceSystem()
							.equalsIgnoreCase(factoryList.get(i))) {
						System.out.println(bomDataList.get(k).getValveSerialNumber());
						if (!serialNumber.equalsIgnoreCase(bomDataList.get(k).getValveSerialNumber())
								|| !soLine.equalsIgnoreCase(bomDataList.get(k).getSalesOrderLine())
								|| !tagNo.equalsIgnoreCase(bomDataList.get(k).getTagNumber())
								) {
							isFirstRow = true;
							logger.info("inside check condition :"+ isFirstRow);
						}
						if (isFirstRow) {
							logger.info("true");
							txtFont.setBold(true);
							row = sheet.getRow(startRow);
							row.setHeight((short) 700);

							cell = row.getCell(0, Row.CREATE_NULL_AS_BLANK);
							cell.setCellValue(isFirstRow ? bomDataList.get(k)
									.getSalesOrderLine() : "");
							cell.setCellStyle(stylewrap);
							cell.getCellStyle().setFont(txtFont);

							cell = row.getCell(1, Row.CREATE_NULL_AS_BLANK);
							cell.setCellValue(isFirstRow ? bomDataList.get(k)
									.getValveSerialNumber() : "");
							cell.setCellStyle(stylewrap);
							cell.getCellStyle().setFont(txtFont);

							cell = row.getCell(3, Row.CREATE_NULL_AS_BLANK);
							cell.setCellValue(isFirstRow ? bomDataList.get(k)
									.getTagNumber() : "");
							cell.setCellStyle(stylewrap);
							cell.getCellStyle().setFont(txtFont);

							cell = row.getCell(5, Row.CREATE_NULL_AS_BLANK);
							cell.setCellValue(isFirstRow ? bomDataList.get(k)
									.getValvePartNumber() : bomDataList.get(k)
									.getComponentItemNumber());
							cell.setCellStyle(stylewrap);
							cell.getCellStyle().setFont(txtFont);

							cell = row.getCell(7, Row.CREATE_NULL_AS_BLANK);
							cell.setCellStyle(stylewrap);
							cell.setCellValue(isFirstRow ? bomDataList.get(k)
									.getValveDescription() : bomDataList.get(k)
									.getComponentDescription());
							cell.getCellStyle().setFont(txtFont);
							startRow += 1;

						} else {
							txtFont.setBold(false);
						}
			
						row = sheet.getRow(startRow);
						row.setHeight((short) 700);

						/*cell = row.getCell(0, Row.CREATE_NULL_AS_BLANK);
						cell.setCellValue("");
						cell.setCellStyle(stylewrap);
						cell.getCellStyle().setFont(txtFont);

						cell = row.getCell(1, Row.CREATE_NULL_AS_BLANK);
						cell.setCellValue("");
						cell.setCellStyle(stylewrap);
						cell.getCellStyle().setFont(txtFont);

						cell = row.getCell(3, Row.CREATE_NULL_AS_BLANK);
						cell.setCellValue("");
						cell.setCellStyle(stylewrap);
						cell.getCellStyle().setFont(txtFont);*/

						cell = row.getCell(5, Row.CREATE_NULL_AS_BLANK);
						cell.setCellValue(bomDataList.get(k)
								.getComponentItemNumber());
						cell.setCellStyle(stylewrap);
						cell.getCellStyle().setFont(txtFont);

						cell = row.getCell(7, Row.CREATE_NULL_AS_BLANK);
						cell.setCellStyle(stylewrap);
						cell.setCellValue(bomDataList.get(k)
								.getComponentDescription());
						cell.getCellStyle().setFont(txtFont);

						cell = row.getCell(12, Row.CREATE_NULL_AS_BLANK);
						cell.setCellValue(bomDataList.get(k)
								.getLegacyPartNumber());
						cell.setCellStyle(stylewrap);

						cell = row.getCell(14, Row.CREATE_NULL_AS_BLANK);
						cell.setCellValue(bomDataList.get(k)
								.getQuantity());
						cell.setCellStyle(stylewrap);

						cell = row.getCell(17, Row.CREATE_NULL_AS_BLANK);
						cell.setCellValue(bomDataList.get(k)
								.getSpareIndicator());
						cell.setCellStyle(stylewrap);

						cell = row.getCell(19, Row.CREATE_NULL_AS_BLANK);
						cell.setCellValue(bomDataList.get(k)
								.getLeadTime());
						cell.setCellStyle(stylewrap);

						startRow += 1;
						serialNumber = bomDataList.get(k).getValveSerialNumber();
						soLine=bomDataList.get(k).getSalesOrderLine();
						tagNo=bomDataList.get(k).getTagNumber();
					}

				}
			}

			wb.write(baos);
			byte[] excelBytes = baos.toByteArray();
			wb.close();
			file.close();
			baos.close();
			return excelBytes;
		} catch (Exception ex) {
			wb.close();
			file.close();
			baos.close();
			logger.info("Exception in generateBOMExcelReport: " + ex);
			return null;
		}
	}

	public Map<String, Object> processHeaderData(List<Report> data) {
		Set<String> salesOrders = new HashSet<String>();
		Set<String> soldToCustomers = new HashSet<String>();
		Set<String> pos = new HashSet<String>();
		Set<String> factories = new HashSet<String>();
		Set<String> representatives = new HashSet<String>();
		for (Report temp : data) {
			salesOrders.add(temp.getSalesOrder());
			soldToCustomers.add(temp.getSoldToCustomerName() + " ,"
					+ temp.getSoldToCity() + " ," 
					+ temp.getSoldToState()
					+ " ," + temp.getEndUserCountry());
			pos.add(temp.getPurchaseOrderNumber());
			factories.add(temp.getSourceSystem());
			representatives.add(temp.getRepName());
		}

		String salesOrder = "";
		String soldToCustomer = "";
		String po = "";
		String factory = "";
		String representative = "";
		if (salesOrders.size() != 0) {
			for (String temp : salesOrders) {
				salesOrder = salesOrder + temp + ",";
			}
			salesOrder = salesOrder.substring(0, salesOrder.length() - 1);
		}
		if (soldToCustomers.size() != 0) {
			for (String temp : soldToCustomers) {
				soldToCustomer = soldToCustomer + temp + " \n";
			}
		}
		if (pos.size() != 0) {
			for (String temp : pos) {
				po = po + temp + ",";
			}
			po = po.substring(0, po.length() - 1);
		}
		if (factories.size() != 0) {
			for (String temp : factories) {
				factory = factory + temp + ",";
			}
			factory = factory.substring(0, factory.length() - 1);
		}
		if (representatives.size() != 0) {
			for (String temp : representatives) {
				if (temp!=null){
				representative = representative + temp + " \n";
				}
			}
		}
		Map<String, Object> processDataMap = new HashMap<String, Object>();
		processDataMap.put("salesOrder", salesOrder);
		processDataMap.put("purchaseOrder", po);
		processDataMap.put("factory", factory);
		processDataMap.put("rep", representative);
		processDataMap.put("customer", soldToCustomer);

		return processDataMap;
	}

	@SuppressWarnings("deprecation")
	public byte[] generateQuoteExcelReport(List<Report> headerList,String currencySymbol,
			List<Report> dataList)
			throws IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		InputStream file = null;
		HSSFWorkbook wb = null;
		try {
			file = this.getClass().getResourceAsStream(QUOTE_TEMPLATE);
			wb = new HSSFWorkbook(file);
			if (headerList.size() > 2) {
				for (int i = 2; i < headerList.size(); i++) {
					wb.cloneSheet(1);
					int id = i + 1;
					wb.setSheetName(i, "Sheet" + id);

				}
			}
			HSSFSheet sheet = wb.getSheetAt(0);
			CellStyle stylewrap = wb.createCellStyle();

			Font txtFont = (HSSFFont) wb.createFont();
			txtFont.setFontName("Arial");
			txtFont.setFontHeightInPoints((short) 8);
			stylewrap.setFont(txtFont);
			stylewrap.setWrapText(true);
			stylewrap.setVerticalAlignment(CellStyle.VERTICAL_TOP);
			stylewrap.setAlignment(CellStyle.ALIGN_CENTER);
			stylewrap.setBorderBottom(CellStyle.BORDER_THIN);
			stylewrap.setLeftBorderColor(IndexedColors.GREY_25_PERCENT
					.getIndex());
			stylewrap.setBorderTop(CellStyle.BORDER_THIN);
			stylewrap.setTopBorderColor(IndexedColors.GREY_25_PERCENT
					.getIndex());
			stylewrap.setBorderRight(CellStyle.BORDER_THIN);
			stylewrap.setRightBorderColor(IndexedColors.GREY_25_PERCENT
					.getIndex());
			stylewrap.setBorderLeft(CellStyle.BORDER_THIN);
			stylewrap.setBottomBorderColor(IndexedColors.GREY_25_PERCENT
					.getIndex());

			Row row = sheet.getRow(4);
			Cell cell = row.getCell(15);
			Date date = new Date();
			cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
			cell.setCellValue(date);
			
			for (int i = 0; i < headerList.size(); i++) {
				sheet = wb.getSheetAt(i);
				Font font = wb.createFont();
				font.setBoldweight(Font.BOLDWEIGHT_BOLD);
				CellStyle style = wb.createCellStyle();
				style.setFont(font);
			//	row = sheet.getRow(i == 0 ? 15 : 1);
				if(i==0){
					row = sheet.getRow(8);
					cell = row.getCell(6,Row.CREATE_NULL_AS_BLANK);
					cell.setCellValue(headerList.get(i).getChannelPartner()==null? "": headerList.get(i).getChannelPartner());
					row = sheet.getRow(10);
					cell = row.getCell(6,Row.CREATE_NULL_AS_BLANK);
					cell.setCellValue(headerList.get(i).getEndUserName()== null ? "" :headerList.get(i).getEndUserName() );
					row = sheet.getRow(12);
					cell = row.getCell(6,Row.CREATE_NULL_AS_BLANK);
					cell.setCellValue(headerList.get(i).getEndUserLocation()== null? "":headerList.get(i).getEndUserLocation());
					row = sheet.getRow(6);
					cell = row.getCell(15,Row.CREATE_NULL_AS_BLANK);
					cell.setCellValue(headerList.get(i).getSpareQuotes()== null ? "" : headerList.get(i).getSpareQuotes());
				}
				else{
					row = sheet.getRow(0);
					cell = row.getCell(6,Row.CREATE_NULL_AS_BLANK);
					cell.setCellValue(headerList.get(i).getChannelPartner()==null? "": headerList.get(i).getChannelPartner());
					cell.setCellStyle(style);
					row = sheet.getRow(2);
					cell = row.getCell(6,Row.CREATE_NULL_AS_BLANK);
					cell.setCellValue(headerList.get(i).getEndUserName()== null ? "" :headerList.get(i).getEndUserName());
					cell.setCellStyle(style);
					row = sheet.getRow(4);
					cell = row.getCell(6,Row.CREATE_NULL_AS_BLANK);
					cell.setCellValue(headerList.get(i).getEndUserLocation()== null ? "" :headerList.get(i).getEndUserLocation());
					cell.setCellStyle(style);
					row = sheet.getRow(2);
					cell = row.getCell(12,Row.CREATE_NULL_AS_BLANK);
					cell.setCellValue(headerList.get(i).getSpareQuotes()== null ? "" :headerList.get(i).getSpareQuotes());
					cell.setCellStyle(style);

					}
				row = sheet.getRow(i==0? 15 : 7);
				cell = row.getCell(1, Row.CREATE_NULL_AS_BLANK);
				cell.setCellValue(headerList.get(i).getActualShippedDate()==null?""
						:headerList.get(i).getActualShippedDate().toString());
				cell = row.getCell(4, Row.CREATE_NULL_AS_BLANK);
				cell.setCellValue(headerList.get(i).getValveSerialNumber());
				cell = row.getCell(8, Row.CREATE_NULL_AS_BLANK);
				cell.setCellValue(headerList.get(i).getTagNumber());
				cell = row.getCell(9, Row.CREATE_NULL_AS_BLANK);
				cell.setCellValue(headerList.get(i).getSalesOrder());
				cell = row.getCell(10, Row.CREATE_NULL_AS_BLANK);
				cell.setCellValue(headerList.get(i).getValveDescription());

				int rowNum = i == 0 ? 18 : 10;
				double totalPrice = 0.0;
				for (int k = 0; k < dataList.size(); k++) {
					if (headerList.get(i).getValveSerialNumber().equalsIgnoreCase(dataList.get(k).getValveSerialNumber())
					&& headerList.get(i).getTagNumber().equalsIgnoreCase(dataList.get(k).getTagNumber())
					&& headerList.get(i).getSalesOrder().equalsIgnoreCase(dataList.get(k).getSalesOrder())) {

						sheet = wb.getSheetAt(i);
						row = sheet.getRow(rowNum);
						row.setHeight((short) 500);
						cell = row.getCell(1, Row.CREATE_NULL_AS_BLANK);
						cell.setCellValue(dataList.get(k)
								.getComponentItemNumber());
						cell.setCellStyle(stylewrap);

						cell = row.getCell(4, Row.CREATE_NULL_AS_BLANK);
						cell.setCellValue(dataList.get(k)
								.getComponentDescription());
						cell.setCellStyle(stylewrap);

						cell = row.getCell(9, Row.CREATE_NULL_AS_BLANK);
						cell.setCellValue(dataList.get(k).getQuantity());
						cell.setCellStyle(stylewrap);

						cell = row.getCell(10, Row.CREATE_NULL_AS_BLANK);
						if (dataList.get(k).getListPrice() == 0.0) {
						//	totalPrice = -1;
							cell.setCellValue("CF");
						} else {
							cell.setCellValue(new DecimalFormat(currencySymbol+"##.##").format(dataList.get(k).getListPrice()));
						}
						cell.setCellStyle(stylewrap);

						cell = row.getCell(12, Row.CREATE_NULL_AS_BLANK);
						double tp = dataList.get(k).getListPrice()
								* dataList.get(k).getQuantity();
						if (tp == 0.0) {
							cell.setCellValue("CF");
						} else {
							cell.setCellValue(new DecimalFormat(currencySymbol+"##.##").format(tp));
						}
						cell.setCellStyle(stylewrap);

						cell = row.getCell(16, Row.CREATE_NULL_AS_BLANK);
						cell.setCellValue(dataList.get(k).getLeadTime());
						cell.setCellStyle(stylewrap);
						if (totalPrice != -1 ) {
							totalPrice += tp;
						}
						rowNum += 1;
					}
				}
				HSSFSheet sheet1 = wb.getSheetAt(i);
			/*	sheet1.addMergedRegion(new CellRangeAddress(rowNum, rowNum, 1,
						11));*/
				Row row1 = sheet1.getRow(rowNum);
				row1.setHeight((short) 500);
				Cell cell1 = row1.getCell(10, Row.CREATE_NULL_AS_BLANK);
				cell1.setCellValue("Total");
				cell1.setCellStyle(stylewrap);

				cell1 = row1.getCell(12, Row.CREATE_NULL_AS_BLANK);
				if (totalPrice == -1 || totalPrice == 0.0) {
					cell1.setCellValue("CF");
				} else {
					cell1.setCellValue(new DecimalFormat(currencySymbol+"##.##").format(totalPrice));
				}
				cell1.setCellStyle(stylewrap);
				cell1 = row1.getCell(16, Row.CREATE_NULL_AS_BLANK);
				cell1.setCellValue("");
				cell1.setCellStyle(stylewrap);

				if (i == headerList.size() - 1) {
				//	HSSFSheet sheet2 = wb.getSheetAt(i);
					Row row2 = sheet.getRow(rowNum + 3);
					sheet.addMergedRegion(new CellRangeAddress(rowNum + 3,
							rowNum + 9, 1, 16));
					Cell cell2 = row2.getCell(1, Row.CREATE_NULL_AS_BLANK);
					cell2.setCellValue("All information on this quote subject to change; "
							+ "consult GE's iSTORE for List Price information. \n"
							+ "Quote valid for 90 days from issuance. \n\n"
							+ "<b>GE PROPRIETARY AND CONFIDENTIAL INFORMATION.</b> \n"
							+ "<b>© 2016 General Electric Company, All rights reserved.</b>");
				//	cell2.setCellStyle(stylewrap);
				}
			}
			wb.write(baos);
			byte[] excelBytes = baos.toByteArray();
			wb.close();
			file.close();
			baos.close();
			return excelBytes;
		} catch (Exception ex) {
			wb.close();
			file.close();
			baos.close();
			logger.info("Exception in generateQuoteExcelReport: " + ex);
			ex.printStackTrace();
			return null;
		}
	}

	public List<Report> processQuoteData(List<Report> list,boolean isInternal) {
		String serialNumber = "";
		String tagNo="";
		String so="";

		List<Report> headerList = new ArrayList<Report>();
		for (int i = 0; i < list.size(); i++) {
			if (!list.get(i).getValveSerialNumber().equalsIgnoreCase(serialNumber)
					|| !list.get(i).getTagNumber().equalsIgnoreCase(tagNo)
					|| !list.get(i).getSalesOrder().equalsIgnoreCase(so)) {
				Report rpt = new Report();
				if(isInternal){
				rpt.setChannelPartner("GE Oil & Gas");
				}
				else{
				rpt.setChannelPartner(list.get(i).getChannelPartner());	
				}
				rpt.setEndUserName(list.get(i).getEndUserName());
				rpt.setEndUserLocation(list.get(i).getEndUserLocation());
				rpt.setSpareQuotes(list.get(i).getSpareQuotes());
				rpt.setActualShippedDate(list.get(i).getActualShippedDate());
				rpt.setValveSerialNumber(list.get(i).getValveSerialNumber());
				rpt.setTagNumber(list.get(i).getTagNumber());
				rpt.setSalesOrder(list.get(i).getSalesOrder());
				rpt.setValveDescription(list.get(i).getValveDescription());
				headerList.add(rpt);
			}
			serialNumber = list.get(i).getValveSerialNumber();
			tagNo=list.get(i).getTagNumber();
			so=list.get(i).getSalesOrder();
		}
		return headerList;
	}

	public Map<String, Object> processQuoteHeaderData(List<Report> data,boolean isInternal) {
		Set<String> chanelPartner = new HashSet<String>();
		Set<String> endUserName = new HashSet<String>();
		Set<String> endUserLocation = new HashSet<String>();
		Set<String> quoteValues = new HashSet<String>();
		
		for (Report temp : data) {
			if(isInternal){
				chanelPartner.add("GE Oil & Gas");
			}else{
			chanelPartner.add(temp.getChannelPartner());
			}
			endUserName.add(temp.getEndUserName());
			endUserLocation.add(temp.getEndUserLocation());
			quoteValues.add(temp.getSpareQuotes());
		}

		String chanelPartnerVal = "";
		String endUserNameVal = "";
		String endUserLocationVal = "";
		String quoteValue = "";

		if (chanelPartner.size() != 0) {
			for (String temp : chanelPartner) {
				chanelPartnerVal = chanelPartnerVal + temp + ",";
			}
			chanelPartnerVal = chanelPartnerVal.substring(0,
					chanelPartnerVal.length() - 1);
		}

		if (endUserName.size() != 0) {
			for (String temp : endUserName) {
				endUserNameVal = endUserNameVal + temp + ",";
			}
			endUserNameVal = endUserNameVal.substring(0,
					endUserNameVal.length() - 1);
		}

		if (endUserLocation.size() != 0) {
			for (String temp : endUserLocation) {
				endUserLocationVal = endUserLocationVal + temp + ",";
			}
			endUserLocationVal = endUserLocationVal.substring(0,
					endUserLocationVal.length() - 1);
		}

		if (quoteValues.size() != 0) {
			for (String temp : quoteValues) {
				quoteValue = quoteValue + temp + ",";
			}
			quoteValue = quoteValue.substring(0, quoteValue.length() - 1);
		}

		Map<String, Object> processDataMap = new HashMap<String, Object>();
		processDataMap.put("chanelPartnerVal", chanelPartnerVal);
		processDataMap.put("endUserNameVal", endUserNameVal);
		processDataMap.put("endUserLocationVal", endUserLocationVal);
		processDataMap.put("quoteValue", quoteValue);

		return processDataMap;
	}
}
