package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;

public class PartData  implements Serializable{

	private static final long serialVersionUID = -5579175197980496818L;
	
	private String partInfoId;
	private String recSource;
	private String itemNumber;
	private String description;
	private String legacyPartNumber;
	private String spareIndicator;
	private String stockType;
	private String leadTime;
	private String leastPrice;
	private String productLine;
	
	public String getPartInfoId() {
		return partInfoId;
	}
	public void setPartInfoId(String partInfoId) {
		this.partInfoId = partInfoId;
	}
	public String getRecSource() {
		return recSource;
	}
	public void setRecSource(String recSource) {
		this.recSource = recSource;
	}
	public String getItemNumber() {
		return itemNumber;
	}
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getLegacyPartNumber() {
		return legacyPartNumber;
	}
	public void setLegacyPartNumber(String legacyPartNumber) {
		this.legacyPartNumber = legacyPartNumber;
	}
	public String getSpareIndicator() {
		return spareIndicator;
	}
	public void setSpareIndicator(String spareIndicator) {
		this.spareIndicator = spareIndicator;
	}
	public String getStockType() {
		return stockType;
	}
	public void setStockType(String stockType) {
		this.stockType = stockType;
	}
	public String getLeadTime() {
		return leadTime;
	}
	public void setLeadTime(String leadTime) {
		this.leadTime = leadTime;
	}
	public String getLeastPrice() {
		return leastPrice;
	}
	public void setLeastPrice(String leastPrice) {
		this.leastPrice = leastPrice;
	}
	public String getProductLine() {
		return productLine;
	}
	public void setProductLine(String productLine) {
		this.productLine = productLine;
	}
	
	public PartData() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public PartData(String partInfoId, String recSource, String itemNumber, String description,
			String legacyPartNumber, String spareIndicator, String stockType,
			String leadTime, String leastPrice, String productLine) {
		super();
		this.partInfoId = partInfoId;
		this.recSource = recSource;
		this.itemNumber = itemNumber;
		this.description = description;
		this.legacyPartNumber = legacyPartNumber;
		this.spareIndicator = spareIndicator;
		this.stockType = stockType;
		this.leadTime = leadTime;
		this.leastPrice = leastPrice;
		this.productLine = productLine;
	}
}
