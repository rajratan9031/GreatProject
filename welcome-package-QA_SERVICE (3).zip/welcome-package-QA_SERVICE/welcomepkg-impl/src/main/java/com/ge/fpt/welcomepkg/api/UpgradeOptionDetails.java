package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;

public class UpgradeOptionDetails implements Serializable{
	
	private static final long serialVersionUID = -5579178899880989818L;
	private String optionId;
	private String indicator;
	private String partModel;
	private String upgradeId;

	public String getPartModel() {
		return partModel;
	}

	public void setPartModel(String partModel) {
		this.partModel = partModel;
	}

	public String getIndicator() {
		return indicator;
	}

	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}

	public String getOptionId() {
		return optionId;
	}
	
	public void setOptionId(String optionId) {
		this.optionId = optionId;
	}

	
	public String getUpgradeId() {
		return upgradeId;
	}

	public void setUpgradeId(String upgradeId) {
		this.upgradeId = upgradeId;
	}

	@Override
	public String toString() {
		return "UpgradeOptionDetails [optionId=" + optionId + ", indicator=" + indicator + ", partModel=" + partModel
				+ ", upgradeId=" + upgradeId + "]";
	}
	
	
	
}
