package com.ge.fpt.welcomepkg.util;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.PrintSetup;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFClientAnchor;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFPicture;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.ge.fpt.welcomepkg.api.AngolaReportData;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;

public class SPIRAngolaReportUtil {

	public static final org.slf4j.Logger LOGGER = WelcomePackageLoggerFactory
			.getLogger(SPIRAngolaReportUtil.class);

	public static final String LOGO_IMAGE_LINK = "/WEB-INF/images/new-logo.jpg";
	XSSFWorkbook wb;
	XSSFWorkbook wbook;
	Sheet sheet;
	XSSFCellStyle styletmp, styleht, stylehc, stylehn, stylev;
	Row row;
	Cell cell;
	int part123MaxCol = 0;
	int part29MaxColSpan = 0;
	int idefaultColWidth = 1000;
	int partFooterMaxRow = 13;

	public static final int MAX_NUM = 13;
	public static final int MIN_NUM = 3;
	public static final int MID_NUM = 4;

	String[][] label12 = new String[MAX_NUM][MIN_NUM];
	String[][] label14 = new String[MAX_NUM][MIN_NUM];
	String[] label4 = new String[MID_NUM];
	int part29MaxCol = 0;
	int part28AMaxCol = 0;
	int part22MaxCol = 0;

	XSSFCellStyle stylenewt = null;
	XSSFCellStyle stylenewtV = null;
	int brleftn = 0;
	int brrightn = 0;
	int brtopn = 0;
	int brbottomn = 0;
	int ifontt = 0;
	int ifontwt = 0;
	int valignt = 0;
	int alignt = 0;

	Map<String, String> hmHdr = new HashMap<String, String>();
	Map<String, String> hmValue = new HashMap<String, String>();
	String currency;
	Set<Map<String, String>> equipmentInfo = new HashSet<Map<String, String>>();
	List<String> lstEquipNo = new ArrayList<String>();
	List<String> lstMfModel = new ArrayList<String>();
	List<String> lstMfSerial = new ArrayList<String>();
	private static final String SPIR_INSTR_TEMPLATE = "/WEB-INF/template/SPIRInstructions.xls";
	Map<String, Integer> hmMap = new HashMap<String, Integer>();
	Double count1=0.0;
	public void init() {
		InputStream file = null;
		try {
			
			file = this.getClass().getResourceAsStream(SPIR_INSTR_TEMPLATE);
			wb = new XSSFWorkbook(file);
			sheet = wb.createSheet("WIP SPIR");
			wb.setSheetOrder("SPIR Form Instructions", 1);
			wb.setSheetOrder("WIP SPIR", 0);
			getstyle();
		} catch (Exception e) {
			org.apache.commons.io.IOUtils.closeQuietly(file);
			LOGGER.info("inside init " + e.getMessage());
		}
	}

	public byte[] initiateReportPreparation(List<AngolaReportData> allReportData) {
		try {
			init();
			prepareData(allReportData);
			part123();
			part29();
			part28();
			buildtabdata(allReportData);
			PartFooter();
			return cleanupproc();
		} catch (Exception e) {
			LOGGER.info("inside init " + e.getMessage());
			return null;

		}
	}

	public String nullValueHandler(Object value) {
		return value == null ? "" : value.toString();
	}

	public void prepareData(List<AngolaReportData> allReportData) {
		try {
			for (AngolaReportData item : allReportData) {
				Map<String, String> eachEquipment = new HashMap<String, String>();
				eachEquipment.put("lst_equipno", item.getEquipmentNumber());
				eachEquipment.put("lst_mfmodel",
						item.getManufacturerModelNumber());
				eachEquipment.put("lst_mfserial",
						item.getManufacturerSerialNumber());
				equipmentInfo.add(eachEquipment);

				String dataKey = nullValueHandler(item.getEquipmentNumber())
						+ "~"
						+ nullValueHandler(item.getManufacturerModelNumber())
						+ "~"
						+ nullValueHandler(item.getManufacturerSerialNumber())
						+ "~" + nullValueHandler(item.getPartNumber());

				if (hmMap.containsKey(dataKey)) {
					hmMap.put(dataKey, hmMap.get(dataKey) + item.getQuantity());
				} else {
					hmMap.put(dataKey, item.getQuantity());
				}
			}
			for (Map<String, String> value : equipmentInfo) {
				lstEquipNo.add((String) value.get("lst_equipno"));
				lstMfModel.add((String) value.get("lst_mfmodel"));
				lstMfSerial.add((String) value.get("lst_mfserial"));
			}
			currency = allReportData.get(0).getCurrency();
		} catch (Exception e) {
			LOGGER.info("inside prepareData " + e.getMessage());
		}

	}

	public void buildtabdata(List<AngolaReportData> allReportData) {
		try {
			int irowt = 14;
			int icolt = 0;
			int icntrp = 0;
			int irowcntp = 0;
			int isum7b = 0;

			String strCellVal = "";
			String kyStr1 = "";
			String kyStr2 = "";

			Object strcellvalo = null;
			List<String> partInfo = new ArrayList<String>();
			for (AngolaReportData item : allReportData) {
				if (!partInfo.contains(item.getPartNumber())) {
					partInfo.add(item.getPartNumber());
					partFooterMaxRow++;
					irowcntp++;
					isum7b = 0;
					kyStr2 = nullValueHandler(item.getPartNumber());
					row = sheet.createRow(irowt);
					for (icolt = 0; icolt < part123MaxCol; icolt++) {
						strCellVal = "";
						cell = row.createCell(icolt);
						cell.setCellStyle(stylehn);

						if (icolt >= 2) {
							kyStr1 = nullValueHandler(lstEquipNo.get(icolt - 2))
									+ "~"
									+ nullValueHandler(lstMfModel
											.get(icolt - 2))
									+ "~"
									+ nullValueHandler(lstMfSerial
											.get(icolt - 2));

							cell.setCellValue(hmMap.get(kyStr1 + "~" + kyStr2) == null ? 0
									: hmMap.get(kyStr1 + "~" + kyStr2));
							isum7b = isum7b
									+ (hmMap.get(kyStr1 + "~" + kyStr2) == null ? 0
											: hmMap.get(kyStr1 + "~" + kyStr2));

						}
					}
					icntrp = 0;

					int geRecmdForOperation = (int) Math.ceil(((double) isum7b)
							* item.getDefaultPercent());
					int geRecmdForCommissioning = item.getInsuranceOrWear()
							.equals("C") ? geRecmdForOperation : 0;
					int approvedPurchase = geRecmdForOperation
							+ geRecmdForCommissioning;
					for (icolt = part123MaxCol; icolt < (part123MaxCol + 24); icolt++) {
						icntrp++;
						strcellvalo = "";
						if (icolt == part123MaxCol) {
							strcellvalo = irowcntp;
						}
						if (icolt == part123MaxCol + 1) {
							strcellvalo = "Each";
						}
						if (icolt == part123MaxCol + 2) {
							strcellvalo = isum7b;
						}
						if (icolt == part123MaxCol + 3) {
							strcellvalo = nullValueHandler(item
									.getPartDescription());
						}
						if (icolt == part123MaxCol + 4) {
							strcellvalo = "";
						}
						if (icolt == part123MaxCol + 5) {
							strcellvalo = nullValueHandler(item
									.getSectionalDrawingNumber());
						}
						if (icolt == part123MaxCol + 6) {
							strcellvalo = nullValueHandler(item
									.getBubbleCode());
						}
						if (icolt == part123MaxCol + 7) {
							strcellvalo = nullValueHandler(item.getPartNumber());
						}
						if (icolt == part123MaxCol + 8) {
							strcellvalo = "";
						}
						if (icolt == part123MaxCol + 9) {
							strcellvalo = "BHGE";
						}
						if (icolt == part123MaxCol + 10) {
							strcellvalo = nullValueHandler(item
									.getMaterialSpec());
						}
						if (icolt == part123MaxCol + 11) {
							strcellvalo = nullValueHandler(item
									.getInsuranceOrWear());
						}
						if (icolt == part123MaxCol + 12) {
							strcellvalo = nullValueHandler(item.getSalesOrder());
						}
						if (icolt == part123MaxCol + 13) {
							strcellvalo = geRecmdForCommissioning;
						}
						if (icolt == part123MaxCol + 14) {
							strcellvalo = geRecmdForOperation;
						}
						if (icolt == part123MaxCol + 15) {
							strcellvalo = "";
						}
						if (icolt == part123MaxCol + 16) {
							strcellvalo = "";
						}
						if (icolt == part123MaxCol + 17) {
							strcellvalo = approvedPurchase;
						}
						if (icolt == part123MaxCol + 18) {
							strcellvalo = "";
						}
						if (icolt == part123MaxCol + 19) {
							strcellvalo = "";
						}
						if (icolt == part123MaxCol + 20) {
							strcellvalo = nullValueHandler(item
									.getSheepmentInWeeks());
						}
						if (icolt == part123MaxCol + 21) {
							strcellvalo = item.getUnitPriceInUSD();
						}
						if (icolt == part123MaxCol + 22) {
							strcellvalo = approvedPurchase
									* item.getUnitPriceInUSD();
							count1+=(Double)strcellvalo;
							count1 = Math.round(count1*100)/100D; 
						}
						if (icolt == part123MaxCol + 23) {
							strcellvalo = "";
						}
						if (icolt == part123MaxCol + 24) {
							strcellvalo = "";
						}
						cell = row.createCell(icolt);

						if (strcellvalo instanceof String) {
							cell.setCellValue((String) strcellvalo);
							cell.setCellStyle(styleht);
						} else if (strcellvalo instanceof Integer) {
							cell.setCellValue((int) strcellvalo);
							cell.setCellStyle(stylehn);
						} else if (strcellvalo instanceof Double) {
							cell.setCellValue((double) strcellvalo);
							cell.setCellStyle(stylehn);
						}

						if (icntrp == 5 || icntrp == 20) {
							merge(irowt, irowt, icolt - 1, icolt);
						}

					}

					irowt++;
				}
			}

			row = sheet.getRow(14);
			cell = row.getCell(1);
			cell.setCellValue("NO OF PARTS PER UNIT");
			resetstyle();
			ifontt = 11;
			ifontwt = Font.BOLDWEIGHT_BOLD;
			alignt = XSSFCellStyle.ALIGN_CENTER;
			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			stylenewt.setRotation((short) 90);
			cell.setCellStyle(stylenewt);
			merge(14, 14 + irowcntp - 1, 1, 1);

			cell = row.getCell(0);
			cell.setCellValue(5);
			resetstyle();
			alignt = XSSFCellStyle.ALIGN_CENTER;
			valignt = XSSFCellStyle.VERTICAL_CENTER;
			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			cell.setCellStyle(stylenewt);
			merge(14, 14 + irowcntp - 1, 0, 0);

		} catch (Exception e) {
			LOGGER.info("inside buildtabdata--->> " + e.getMessage());

		}

	}

	public void resetstyle() {
		try {
			stylenewt = null;
			brleftn = XSSFCellStyle.BORDER_THIN;
			brrightn = XSSFCellStyle.BORDER_THIN;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			ifontt = 0;
			ifontwt = Font.BOLDWEIGHT_NORMAL;
			valignt = XSSFCellStyle.VERTICAL_CENTER;
			alignt = XSSFCellStyle.ALIGN_CENTER;
		} catch (Exception e) {
			LOGGER.info("inside resetstyle--->> " + e.getMessage());
		}
	}

	public void setcellHdrvalues() {
		try {
			hmHdr.put("28A",
					" OPERATIONAL SPARE PARTS AND INTERCHANGEABILITY REPORT");
			hmValue.put("28A", "");
			hmHdr.put("28B", "");
			hmValue.put("28B", "");
			hmHdr.put("28",
					" Name of Service Company and \nProvider of OEM PARTS for this Project ");
			hmValue.put("28", "");

			hmHdr.put("28Name", "Name:");
			hmValue.put("28Name", "");
			hmHdr.put("28Addr", "Address:");
			hmValue.put("28Addr", "");
			hmHdr.put("28Phone", "Phone:");
			hmValue.put("28Phone", "");

			hmHdr.put("22", "SPARE PART ORDER NO:");
			hmValue.put("22", "");
			hmHdr.put("23", "EQUIPMENT DESCRIPTION:");
			hmValue.put("23", "");
			hmHdr.put("24A", "EQUIPMENT MANUFACTURER:");
			hmValue.put("24A", "");
			hmHdr.put("24B", "VENDOR NAME:");
			hmValue.put("24B", "");
			hmHdr.put("24B2", "VENDOR ADDRESS:");
			hmValue.put("24B2", "");

			hmHdr.put("25", "PREPARED BY:");
			hmValue.put("25", "");
			hmHdr.put("26", "PHONE:");
			hmValue.put("26", "");
			hmHdr.put("27A", "QUOTATION NO:");
			hmValue.put("27A", "");
			hmHdr.put("27B", "QUOTATION NO:");
			hmValue.put("27B", "");

			/*hmHdr.put("14", "Commissioning Spare Parts:");
			hmValue.put("14", "");*/
			hmHdr.put("14A", "Commissioning Spare Parts Recommednded by BHGE");
			hmValue.put("14A", "");

			/*hmHdr.put("15", "Operational Spare parts:");
			hmValue.put("15", "");*/
			hmHdr.put("14B", "Operational Spare parts Recommended by BHGE");
			hmValue.put("14B", "");
			hmHdr.put("15A", "Operational & Commissioning Spares Total Recommended by Proj Mgr");
			hmValue.put("15A", "");
			hmHdr.put("15B", "To be Ordered by Customer:");
			hmValue.put("15B", "");

			hmHdr.put("16", "Final Agreement for Ordering");
			hmValue.put("16", "");

			hmHdr.put("17", "Approved for Purchase:");
			hmValue.put("17", "");
			hmHdr.put("18", "Approved for Purchase:");
			hmValue.put("18", "");
			hmHdr.put("19", "Approved for Purchase:");
			hmValue.put("19", "");
			hmHdr.put("20", "Approved for Purchase:");
			hmValue.put("20", "");

			/*
			 * hm_hdr.put("14", "Commissioning SPARE PARTS:"); hm_hdr.put("14A",
			 * "Recommended by Manufacturer:"); hm_hdr.put("14B",
			 * "Recommended by Contractor:"); hm_hdr.put("15",
			 * "OPERATIONAL SPARE PARTS:"); hm_hdr.put("15A",
			 * "Recommended by Vendor:"); hm_hdr.put("15B",
			 * "Requested by Operations:");
			 */
			hmHdr.put("16", "Total Recommended by BHGE");
			hmHdr.put("17",
					"CLIENT CATALOG NO:\n Customer Spare Part Reference no.");
			hmHdr.put("18", "Shipment in Weeks:");
			hmHdr.put("19", "UNIT PRICE \n (" + currency + ")");
			hmHdr.put("20", "TOTAL PRICE Recommended by BHGE (" + currency
					+ ")");
			hmHdr.put("21", "Total Price\n to be Ordered:\n (" + currency + ")");
		} catch (Exception e) {
			LOGGER.info("inside setcellHdrvalues--->> " + e.getMessage());

		}

	}

	public void part28() {
		try {
			setcellHdrvalues();

			int strown = 0, endrown = 0, stcoln = 0, colwidth = 0, endcoln = 0;
			String strcelvalnt = "";

			resetstyle();
			ifontt = 11;
			ifontwt = Font.BOLDWEIGHT_BOLD;
			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 1;
			endrown = 1;
			stcoln = part123MaxCol;
			colwidth = 15;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get("28A");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);

			part28AMaxCol = endcoln;

			resetstyle();
			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 2;
			endrown = 5;
			stcoln = part123MaxCol;
			colwidth = 15;
			endcoln = part28AMaxCol;
			strcelvalnt = (String) hmHdr.get("28B");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);

			byte[] bytes = IOUtils.toByteArray(this.getClass()
					.getResourceAsStream(LOGO_IMAGE_LINK));
			// Adds a picture to the workbook
			int myPictureId = wb.addPicture(bytes, Workbook.PICTURE_TYPE_PNG);
			XSSFDrawing drawing = (XSSFDrawing) sheet.createDrawingPatriarch();

			XSSFClientAnchor myAnchor = new XSSFClientAnchor();

			myAnchor.setCol1(stcoln);
			myAnchor.setRow1(strown);
			myAnchor.setCol2(stcoln + 3);
			myAnchor.setRow2(strown + 2);

			final CreationHelper helper = wb.getCreationHelper();
			final ClientAnchor anchor = helper.createClientAnchor();
			anchor.setAnchorType(ClientAnchor.MOVE_AND_RESIZE);

			XSSFPicture myPicture = drawing
					.createPicture(myAnchor, myPictureId);
			myPicture.resize();
			strown = 6;
			endrown = 8;
			stcoln = part123MaxCol;
			colwidth = 4;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get("28");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);
			sheet.setColumnWidth(endcoln, (idefaultColWidth * 8));

			int stcol28label = endcoln + 1;

			strown = 6;
			endrown = 6;
			stcoln = endcoln + 1;
			colwidth = 1;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get("28Name");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);
			strown = 6;
			endrown = 6;
			stcoln = endcoln + 1;
			colwidth = 10;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmValue.get("28Name");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);
			int stcol28val = stcoln;

			strown = 7;
			endrown = 7;
			stcoln = stcol28label;
			colwidth = 1;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get("28Addr");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);
			strown = 7;
			endrown = 7;
			stcoln = stcol28val;
			colwidth = 10;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmValue.get("28Addr");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);

			strown = 8;
			endrown = 8;
			stcoln = stcol28label;
			colwidth = 1;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get("28Phone");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);
			strown = 8;
			endrown = 8;
			stcoln = stcol28val;
			colwidth = 10;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmValue.get("28Phone");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);

			part22to27b();

		} catch (Exception e) {
			LOGGER.info("inside part28-->" + e.getMessage());
		}

	}

	public void part22to27b() {
		try {

			int strown = 0, endrown = 0, stcoln = 0, colwidth = 0, endcoln = 0;
			String strcelvalnt = "";

			resetstyle();
			brleftn = XSSFCellStyle.BORDER_MEDIUM;
			brrightn = XSSFCellStyle.BORDER_THIN;
			brtopn = XSSFCellStyle.BORDER_MEDIUM;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 1;
			endrown = 1;
			stcoln = part28AMaxCol + 1;
			colwidth = 4;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get("22");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);

			part22MaxCol = endcoln;

			resetstyle();
			brleftn = XSSFCellStyle.BORDER_THIN;
			brrightn = XSSFCellStyle.BORDER_MEDIUM;
			brtopn = XSSFCellStyle.BORDER_MEDIUM;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 1;
			endrown = 1;
			stcoln = part22MaxCol + 1;
			colwidth = 5;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmValue.get("22");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);

			resetstyle();
			brleftn = XSSFCellStyle.BORDER_MEDIUM;
			brrightn = XSSFCellStyle.BORDER_THIN;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 2;
			endrown = 2;
			stcoln = part28AMaxCol + 1;
			colwidth = 4;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get("23");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);

			resetstyle();
			brleftn = XSSFCellStyle.BORDER_THIN;
			brrightn = XSSFCellStyle.BORDER_MEDIUM;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 2;
			endrown = 2;
			stcoln = part22MaxCol + 1;
			colwidth = 5;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmValue.get("23");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);

			resetstyle();
			brleftn = XSSFCellStyle.BORDER_MEDIUM;
			brrightn = XSSFCellStyle.BORDER_THIN;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 3;
			endrown = 3;
			stcoln = part28AMaxCol + 1;
			colwidth = 4;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get("24A");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);

			resetstyle();
			brleftn = XSSFCellStyle.BORDER_THIN;
			brrightn = XSSFCellStyle.BORDER_MEDIUM;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 3;
			endrown = 3;
			stcoln = part22MaxCol + 1;
			colwidth = 5;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmValue.get("24A");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);

			resetstyle();
			brleftn = XSSFCellStyle.BORDER_MEDIUM;
			brrightn = XSSFCellStyle.BORDER_THIN;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 4;
			endrown = 4;
			stcoln = part28AMaxCol + 1;
			colwidth = 4;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get("24B");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);

			resetstyle();
			brleftn = XSSFCellStyle.BORDER_THIN;
			brrightn = XSSFCellStyle.BORDER_MEDIUM;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 4;
			endrown = 4;
			stcoln = part22MaxCol + 1;
			colwidth = 5;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmValue.get("24B");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);

			resetstyle();
			brleftn = XSSFCellStyle.BORDER_MEDIUM;
			brrightn = XSSFCellStyle.BORDER_THIN;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 5;
			endrown = 6;
			stcoln = part28AMaxCol + 1;
			colwidth = 4;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get("24B2");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);

			resetstyle();
			brleftn = XSSFCellStyle.BORDER_THIN;
			brrightn = XSSFCellStyle.BORDER_MEDIUM;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 5;
			endrown = 6;
			stcoln = part22MaxCol + 1;
			colwidth = 5;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmValue.get("24B2");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);

			resetstyle();
			brleftn = XSSFCellStyle.BORDER_MEDIUM;
			brrightn = XSSFCellStyle.BORDER_THIN;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 7;
			endrown = 7;
			stcoln = part28AMaxCol + 1;
			colwidth = 4;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get("25");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);

			resetstyle();
			brleftn = XSSFCellStyle.BORDER_MEDIUM;
			brrightn = XSSFCellStyle.BORDER_THIN;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_MEDIUM;
			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 8;
			endrown = 8;
			stcoln = part28AMaxCol + 1;
			colwidth = 4;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmValue.get("25");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);

			resetstyle();
			brleftn = XSSFCellStyle.BORDER_THIN;
			brrightn = XSSFCellStyle.BORDER_THIN;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 7;
			endrown = 7;
			stcoln = endcoln + 1;
			colwidth = 1;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get("26");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);

			resetstyle();
			brleftn = XSSFCellStyle.BORDER_THIN;
			brrightn = XSSFCellStyle.BORDER_THIN;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_MEDIUM;
			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 8;
			endrown = 8;
			strcelvalnt = (String) hmValue.get("26");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);

			resetstyle();
			brleftn = XSSFCellStyle.BORDER_THIN;
			brrightn = XSSFCellStyle.BORDER_THIN;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 7;
			endrown = 7;
			stcoln = endcoln + 1;
			colwidth = 2;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get("27A");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);

			resetstyle();
			brleftn = XSSFCellStyle.BORDER_THIN;
			brrightn = XSSFCellStyle.BORDER_THIN;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_MEDIUM;
			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 8;
			endrown = 8;
			strcelvalnt = (String) hmValue.get("27A");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);

			resetstyle();
			brleftn = XSSFCellStyle.BORDER_THIN;
			brrightn = XSSFCellStyle.BORDER_MEDIUM;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 7;
			endrown = 7;
			stcoln = endcoln + 1;
			colwidth = 2;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get("27B");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);

			resetstyle();
			brleftn = XSSFCellStyle.BORDER_THIN;
			brrightn = XSSFCellStyle.BORDER_MEDIUM;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_MEDIUM;
			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 8;
			endrown = 8;
			strcelvalnt = (String) hmValue.get("27B");
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);

			part14to21();

		} catch (Exception e) {
			LOGGER.info("inside part14to21" + e.getMessage());

		}

	}

	public void part14to21() {
		try {

			int strown = 0, endrown = 0, stcoln = 0, colwidth = 0, endcoln = 0;
			String strcelvalnt = "", strlabel = "";

			/*strlabel = "14";
			resetstyle();
			brleftn = XSSFCellStyle.BORDER_THIN;
			brrightn = XSSFCellStyle.BORDER_MEDIUM;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewt = getstyleobjV(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 9;
			endrown = 10;
			stcoln = part29MaxCol + 1;
			colwidth = 1;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get(strlabel);
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);
			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 11;
			endrown = 11;
			stcoln = part29MaxCol + 1;
			colwidth = 1;
			endcoln = stcoln + colwidth - 1;
			createcellbox(strown, endrown, stcoln, endcoln, strlabel, stylenewt);
			sheet.setColumnWidth(stcoln, (idefaultColWidth * 2));*/
			
			strlabel = "14A";
			resetstyle();
			brleftn = XSSFCellStyle.BORDER_THIN;
			brrightn = XSSFCellStyle.BORDER_MEDIUM;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewtV = getstyleobjV(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 9;
			endrown = 12;
			stcoln = part29MaxCol + 1;
			colwidth = 1;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get(strlabel);
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewtV);

			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 13;
			endrown = 13;
			stcoln = part29MaxCol + 1;
			colwidth = 1;
			endcoln = stcoln + colwidth - 1;
			createcellbox(strown, endrown, stcoln, endcoln, strlabel, stylenewt);
			sheet.setColumnWidth(stcoln, (idefaultColWidth * 2));

			/*strlabel = "15";
			resetstyle();
			brleftn = XSSFCellStyle.BORDER_MEDIUM;
			brrightn = XSSFCellStyle.BORDER_THIN;
			brtopn = XSSFCellStyle.BORDER_MEDIUM;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewt = getstyleobjV(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 9;
			endrown = 10;
			stcoln = part29MaxCol + 2;
			colwidth = 3;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get(strlabel);
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);*/

			strlabel = "14B";
			resetstyle();
			brleftn = XSSFCellStyle.BORDER_THIN;
			brrightn = XSSFCellStyle.BORDER_MEDIUM;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewtV = getstyleobjV(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 9;
			endrown = 12;
			stcoln = part29MaxCol + 2;
			colwidth = 1;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get(strlabel);
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewtV);

			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 13;
			endrown = 13;
			stcoln = part29MaxCol + 2;
			colwidth = 1;
			endcoln = stcoln + colwidth - 1;
			createcellbox(strown, endrown, stcoln, endcoln, strlabel, stylenewt);
			sheet.setColumnWidth(stcoln, (idefaultColWidth * 2));

			strlabel = "15A";
			resetstyle();
			brleftn = XSSFCellStyle.BORDER_MEDIUM;
			brrightn = XSSFCellStyle.BORDER_MEDIUM;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewtV = getstyleobjV(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 9;
			endrown = 12;
			stcoln = part29MaxCol + 3;
			colwidth = 1;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get(strlabel);
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewtV);

			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 13;
			endrown = 13;
			stcoln = part29MaxCol + 3;
			colwidth = 1;
			endcoln = stcoln + colwidth - 1;
			createcellbox(strown, endrown, stcoln, endcoln, strlabel, stylenewt);
			sheet.setColumnWidth(stcoln, (idefaultColWidth * 2));

			strlabel = "15B";
			resetstyle();
			brleftn = XSSFCellStyle.BORDER_THIN;
			brrightn = XSSFCellStyle.BORDER_MEDIUM;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewtV = getstyleobjV(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 9;
			endrown = 12;
			stcoln = part29MaxCol + 4;
			colwidth = 1;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get(strlabel);
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewtV);

			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 13;
			endrown = 13;
			stcoln = part29MaxCol + 4;
			colwidth = 1;
			endcoln = stcoln + colwidth - 1;
			createcellbox(strown, endrown, stcoln, endcoln, strlabel, stylenewt);
			sheet.setColumnWidth(stcoln, (idefaultColWidth * 2));

			strlabel = "16";
			resetstyle();
			brleftn = XSSFCellStyle.BORDER_THIN;
			brrightn = XSSFCellStyle.BORDER_MEDIUM;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewtV = getstyleobjV(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 9;
			endrown = 12;
			stcoln = part29MaxCol + 5;
			colwidth = 1;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get(strlabel);
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewtV);

			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 13;
			endrown = 13;
			stcoln = part29MaxCol + 5;
			colwidth = 1;
			endcoln = stcoln + colwidth - 1;
			createcellbox(strown, endrown, stcoln, endcoln, strlabel, stylenewt);
			sheet.setColumnWidth(stcoln, (idefaultColWidth * 2));

			strlabel = "17";
			resetstyle();
			brleftn = XSSFCellStyle.BORDER_MEDIUM;
			brrightn = XSSFCellStyle.BORDER_THIN;
			brtopn = XSSFCellStyle.BORDER_MEDIUM;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 9;
			endrown = 12;
			stcoln = part29MaxCol + 6;
			colwidth = 2;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get(strlabel);
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);

			brtopn = XSSFCellStyle.BORDER_THIN;
			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 13;
			endrown = 13;
			stcoln = part29MaxCol + 6;
			colwidth = 2;
			endcoln = stcoln + colwidth - 1;
			createcellbox(strown, endrown, stcoln, endcoln, strlabel, stylenewt);
			sheet.setColumnWidth(stcoln, (idefaultColWidth * 4));

			/*strlabel = "18";
			resetstyle();
			brleftn = XSSFCellStyle.BORDER_THIN;
			brrightn = XSSFCellStyle.BORDER_THIN;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewtV = getstyleobjV(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 9;
			endrown = 12;
			stcoln = part29MaxCol + 8;
			colwidth = 1;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get(strlabel);
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewtV);

			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 13;
			endrown = 13;
			stcoln = part29MaxCol + 8;
			colwidth = 1;
			endcoln = stcoln + colwidth - 1;
			createcellbox(strown, endrown, stcoln, endcoln, strlabel, stylenewt);
			sheet.setColumnWidth(stcoln, (idefaultColWidth * 2));*/

			strlabel = "19";
			resetstyle();
			brleftn = XSSFCellStyle.BORDER_THIN;
			brrightn = XSSFCellStyle.BORDER_THIN;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 9;
			endrown = 12;
			stcoln = part29MaxCol + 9;
			colwidth = 1;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get(strlabel);
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);

			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 13;
			endrown = 13;
			stcoln = part29MaxCol + 9;
			colwidth = 1;
			endcoln = stcoln + colwidth - 1;
			createcellbox(strown, endrown, stcoln, endcoln, strlabel, stylenewt);
			sheet.setColumnWidth(stcoln, (idefaultColWidth * 3));
			
			strlabel = "18";
			resetstyle();
			brleftn = XSSFCellStyle.BORDER_THIN;
			brrightn = XSSFCellStyle.BORDER_THIN;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewtV = getstyleobjV(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 9;
			endrown = 12;
			stcoln = part29MaxCol + 8;
			colwidth = 1;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get(strlabel);
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewtV);

			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 13;
			endrown = 13;
			stcoln = part29MaxCol + 8;
			colwidth = 1;
			endcoln = stcoln + colwidth - 1;
			createcellbox(strown, endrown, stcoln, endcoln, strlabel, stylenewt);
			sheet.setColumnWidth(stcoln, (idefaultColWidth * 2));
			strlabel = "20";
			resetstyle();
			brleftn = XSSFCellStyle.BORDER_THIN;
			brrightn = XSSFCellStyle.BORDER_THIN;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewt = getstyleobjV(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 9;
			endrown = 12;
			stcoln = part29MaxCol + 10;
			colwidth = 1;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get(strlabel);
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewt);

			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 13;
			endrown = 13;
			stcoln = part29MaxCol + 10;
			colwidth = 1;
			endcoln = stcoln + colwidth - 1;
			createcellbox(strown, endrown, stcoln, endcoln, strlabel, stylenewt);
			sheet.setColumnWidth(stcoln, (idefaultColWidth * 3));

			strlabel = "21";
			resetstyle();
			brleftn = XSSFCellStyle.BORDER_THIN;
			brrightn = XSSFCellStyle.BORDER_THIN;
			brtopn = XSSFCellStyle.BORDER_THIN;
			brbottomn = XSSFCellStyle.BORDER_THIN;
			stylenewtV = getstyleobjV(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 9;
			endrown = 12;
			stcoln = part29MaxCol + 11;
			colwidth = 1;
			endcoln = stcoln + colwidth - 1;
			strcelvalnt = (String) hmHdr.get(strlabel);
			createcellbox(strown, endrown, stcoln, endcoln, strcelvalnt,
					stylenewtV);

			stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn,
					valignt, alignt, ifontt, ifontwt);
			strown = 13;
			endrown = 13;
			stcoln = part29MaxCol + 11;
			colwidth = 1;
			endcoln = stcoln + colwidth - 1;
			createcellbox(strown, endrown, stcoln, endcoln, strlabel, stylenewt);
			sheet.setColumnWidth(stcoln, (idefaultColWidth * 2));

		} catch (Exception e) {
			LOGGER.info("inside part22to27b" + e.getMessage());
		}
	}

	public void createcellbox(int strow, int endrow, int stcol, int endcol,
			Object strcelval, XSSFCellStyle stylenew) {
		try {

			int rowt = 0, colnumt = 0;
			for (rowt = strow; rowt <= endrow; rowt++) {
				if (sheet.getRow(rowt) == null) {
					row = sheet.createRow(rowt);

				} else
					row = sheet.getRow(rowt);

				for (colnumt = stcol; colnumt <= endcol; colnumt++) {
					cell = row.createCell(colnumt);
					cell.setCellStyle(stylenew);
					if (strcelval instanceof String)
						cell.setCellValue((String) strcelval);

				}

			}

			if ((endrow - strow) != 0 || (endcol - stcol) != 0)
				merge(strow, endrow, stcol, endcol);

		} catch (Exception e) {
			LOGGER.info("inside createcellbox" + e.getMessage());
		}

	}

	public void part29() {
		try {
			int rownumt = 9, col_span = 13;
			String part29_label = "29  PARTS REORDER INFORMATION:";
			part29MaxColSpan = col_span;
			int irspanval = 1, colnumt = (part123MaxCol + col_span), colt = 0;
			row = sheet.getRow(rownumt);
			String strcellval = "";
			boolean imergeval = false;
			for (colt = part123MaxCol; colt < colnumt; colt++) {
				if (colt == part123MaxCol)
					strcellval = part29_label;
				else
					strcellval = "";
				CreateCell(rownumt, irspanval, colt, strcellval, styleht,
						imergeval);
			}
			merge(rownumt, rownumt, part123MaxCol, colnumt - 1);

			part29MaxCol = (part123MaxCol + col_span - 1);

		} catch (Exception e) {
			LOGGER.info("inside part29" + e.getMessage());
		}

	}

	public void part123() {
		try {
			String lable1 = "";
			String label2 = "";
			String sqlstr;

			int rownumt = 0;
			int irspanval = 0;
			int rowheight = 0;
			int colnumt = 0;
			int inumcol = 0;

			lable1 = "1";
			label2 = "Equipment No.(Tag Item No.)";
			sqlstr = "1";
			rownumt = 1;
			irspanval = 4;
			rowheight = sheet.getDefaultRowHeight() * 2;
			genpart123(lable1, label2, lstEquipNo, rownumt, irspanval,
					rowheight);

			lable1 = "2";
			label2 = "Manufacturer's Model No.";
			sqlstr = "2";
			rownumt = 5;
			irspanval = 5;
			rowheight = sheet.getDefaultRowHeight() * 3;
			genpart123(lable1, label2, lstMfModel, rownumt, irspanval,
					rowheight);

			lable1 = "3";
			label2 = "Manufacturer's Serial No.";
			sqlstr = "3";
			rownumt = 10;
			irspanval = 3;
			rowheight = sheet.getDefaultRowHeight() * 3;
			genpart123(lable1, label2, lstMfSerial, rownumt, irspanval,
					rowheight);

			int part_type = 13;
			label12[0][0] = "SPIR LINE ITEM NO.";
			label12[0][1] = "V";
			label12[0][2] = "2";
			label12[1][0] = "Units of Measure";
			label12[1][1] = "V";
			label12[1][2] = "2";
			label12[2][0] = "Total No. of Identical Parts on this SPIR";
			label12[2][1] = "V";
			label12[2][2] = "2";

			label12[3][0] = "DESCRIPTION OF PART";
			label12[3][1] = "H";
			label12[3][2] = "2";
			label12[4][0] = "DESCRIPTION OF PART";
			label12[4][1] = "H";
			label12[4][2] = "2";
			label12[5][0] = "SECTIONAL \nDRAWING\nNUMBER\n(Attach to SPIR)";
			label12[5][1] = "H";
			label12[5][2] = "5";
			label12[6][0] = "Part Position (Reference) \n No.\n Balloon Callout #";
			label12[6][1] = "V";
			label12[6][2] = "2";
			label12[7][0] = "BHGE PART NUMBER";
			label12[7][1] = "H";
			label12[7][2] = "5";
			label12[8][0] = "COMPONENT \n SUPPLIERS PART \n NUMBER \n (BUYOUT  PN#)";
			label12[8][1] = "H";
			label12[8][2] = "5";
			label12[9][0] = "COMPONENT \n SUPPLIERS \n NAME \n\n (BHGE or Other)";
			label12[9][1] = "H";
			label12[9][2] = "4";
			label12[10][0] = "MATERIAL SPEC";
			label12[10][1] = "H";
			label12[10][2] = "4";
			label12[11][0] = "C= Consumables, I = Instrument, W = Wear";
			label12[11][1] = "V";
			label12[11][2] = "2";
			label12[12][0] = "Sales Order";
			label12[12][1] = "V";
			label12[12][2] = "2";

			rownumt = 10;
			irspanval = 3;
			colnumt = part123MaxCol;
			inumcol = 12;
			part7to13Hdr(rownumt, irspanval, colnumt, inumcol, rowheight,
					part_type);

			part_type = 14;
			label4[0] = "4";
			label4[1] = "No. of units";
			label4[2] = "1";

			label14[0][0] = "";
			label14[1][0] = "7A";
			label14[2][0] = "7B";

			label14[3][0] = "8";
			label14[4][0] = "8";
			label14[5][0] = "9";
			label14[6][0] = "9A";
			label14[7][0] = "10A";
			label14[8][0] = "10B";
			label14[9][0] = "10C";
			label14[10][0] = "11";
			label14[11][0] = "12";
			label14[12][0] = "13";

			rownumt = 13;
			irspanval = 1;
			colnumt = part123MaxCol;
			inumcol = 12;
			part7to13Hdr(rownumt, irspanval, colnumt, inumcol, rowheight,
					part_type);

			int icolk = 0;
			for (icolk = 0; icolk <= inumcol; icolk++)
				sheet.setColumnWidth((icolk + colnumt),
						(idefaultColWidth * Integer.valueOf(label12[icolk][2])));

		} catch (Exception e) {
			LOGGER.info("inside part123" + e.getMessage());
		}

	}

	public void PartFooter() {
		int icolt = 0;
		int irspan = 1;
		String strcellval = "";

		resetstyle();
		brleftn = XSSFCellStyle.BORDER_THIN;
		brrightn = XSSFCellStyle.BORDER_THIN;
		brtopn = XSSFCellStyle.BORDER_THIN;
		brbottomn = XSSFCellStyle.BORDER_THIN;
		stylenewtV = getstyleobjV(brbottomn, brtopn, brleftn, brrightn,
				valignt, alignt, ifontt, ifontwt);
		stylenewt = getstyleobj(brbottomn, brtopn, brleftn, brrightn, valignt,
				alignt, ifontt, ifontwt);

		System.out.print("partFooterMaxRow == " + partFooterMaxRow);
		partFooterMaxRow = partFooterMaxRow + 1;

		try {
			row = sheet.createRow(partFooterMaxRow + 1);
			row.setHeight((short) 700);
			createcellbox(partFooterMaxRow, partFooterMaxRow, 1, 1,
					"Po. Item no.", stylenewt);

			for (icolt = 2; icolt < part123MaxCol; icolt++) {
				createcellbox(partFooterMaxRow, partFooterMaxRow, icolt, icolt,
						strcellval, stylenewtV);
			}
			createcellbox(partFooterMaxRow, partFooterMaxRow, part123MaxCol,
					part123MaxCol + 23, "", stylenewtV);

			createcellbox(partFooterMaxRow + 1, partFooterMaxRow + 7, 1, 1,
					"Equipment PO & Mfgr's Shop Order", stylenewtV);

			for (icolt = 2; icolt < part123MaxCol; icolt++) {

				createcellbox(partFooterMaxRow + 1, partFooterMaxRow + 7,
						icolt, icolt, strcellval, stylenewtV);
			}

			createcellbox(partFooterMaxRow + 1, partFooterMaxRow + 1,
					part123MaxCol, part123MaxCol + 14, "", stylenewt);
			createcellbox(partFooterMaxRow + 2, partFooterMaxRow + 2,
					part123MaxCol, part123MaxCol + 14, "", stylenewt);
			createcellbox(partFooterMaxRow + 3, partFooterMaxRow + 3,
					part123MaxCol, part123MaxCol + 14, "", stylenewt);
			createcellbox(partFooterMaxRow + 4, partFooterMaxRow + 4,
					part123MaxCol, part123MaxCol + 14, "", stylenewt);
			createcellbox(partFooterMaxRow + 5, partFooterMaxRow + 5,
					part123MaxCol, part123MaxCol + 14, "", stylenewt);
			createcellbox(partFooterMaxRow + 6, partFooterMaxRow + 6,
					part123MaxCol, part123MaxCol + 14, "", stylenewt);
			createcellbox(partFooterMaxRow + 7, partFooterMaxRow + 7,
					part123MaxCol, part123MaxCol + 14, "", stylenewt);

			int secondPartStartColumn = part123MaxCol + 15;

			createcellbox(partFooterMaxRow + 1, partFooterMaxRow + 2,
					secondPartStartColumn, secondPartStartColumn + 6,
					"31. Quantity Approved for purchase by", stylenewt);
			createcellbox(partFooterMaxRow + 3, partFooterMaxRow + 3,
					secondPartStartColumn, secondPartStartColumn + 6,
					"Contact Number", stylenewt);
			createcellbox(partFooterMaxRow + 4, partFooterMaxRow + 5,
					secondPartStartColumn, secondPartStartColumn + 6,
					"Project Description", stylenewt);

			createcellbox(partFooterMaxRow + 6, partFooterMaxRow + 6,
					secondPartStartColumn, secondPartStartColumn,
					"32 Revision", stylenewt);
			createcellbox(partFooterMaxRow + 6, partFooterMaxRow + 6,
					secondPartStartColumn + 1, secondPartStartColumn + 1, "0",
					stylenewt);
			createcellbox(partFooterMaxRow + 6, partFooterMaxRow + 6,
					secondPartStartColumn + 2, secondPartStartColumn + 2, "1",
					stylenewt);
			createcellbox(partFooterMaxRow + 6, partFooterMaxRow + 6,
					secondPartStartColumn + 3, secondPartStartColumn + 3, "2",
					stylenewt);
			createcellbox(partFooterMaxRow + 6, partFooterMaxRow + 6,
					secondPartStartColumn + 4, secondPartStartColumn + 4, "3",
					stylenewt);
			createcellbox(partFooterMaxRow + 6, partFooterMaxRow + 6,
					secondPartStartColumn + 5, secondPartStartColumn + 5, "4",
					stylenewt);
			createcellbox(partFooterMaxRow + 6, partFooterMaxRow + 6,
					secondPartStartColumn + 6, secondPartStartColumn + 6, "5",
					stylenewt);

			createcellbox(partFooterMaxRow + 7, partFooterMaxRow + 7,
					secondPartStartColumn, secondPartStartColumn, "Date",
					stylenewt);
			createcellbox(partFooterMaxRow + 7, partFooterMaxRow + 7,
					secondPartStartColumn + 1, secondPartStartColumn + 1, "",
					stylenewt);
			createcellbox(partFooterMaxRow + 7, partFooterMaxRow + 7,
					secondPartStartColumn + 2, secondPartStartColumn + 2, "",
					stylenewt);
			createcellbox(partFooterMaxRow + 7, partFooterMaxRow + 7,
					secondPartStartColumn + 3, secondPartStartColumn + 3, "",
					stylenewt);
			createcellbox(partFooterMaxRow + 7, partFooterMaxRow + 7,
					secondPartStartColumn + 4, secondPartStartColumn + 4, "",
					stylenewt);
			createcellbox(partFooterMaxRow + 7, partFooterMaxRow + 7,
					secondPartStartColumn + 5, secondPartStartColumn + 5, "",
					stylenewt);
			createcellbox(partFooterMaxRow + 7, partFooterMaxRow + 7,
					secondPartStartColumn + 6, secondPartStartColumn + 6, "",
					stylenewt);

			createcellbox(partFooterMaxRow + 1, partFooterMaxRow + 2,
					secondPartStartColumn + 7, secondPartStartColumn + 7,
					"Sub total this page", stylenewt);
			createcellbox(partFooterMaxRow + 3, partFooterMaxRow + 4,
					secondPartStartColumn + 7, secondPartStartColumn + 7,
					"Grand total", stylenewt);
			createcellbox(partFooterMaxRow + 5, partFooterMaxRow + 5,
					secondPartStartColumn + 7, secondPartStartColumn + 7,
					"Checked By", stylenewt);
			createcellbox(partFooterMaxRow + 6, partFooterMaxRow + 6,
					secondPartStartColumn + 7, secondPartStartColumn + 7,
					"Sheet no.", stylenewt);
			createcellbox(partFooterMaxRow + 7, partFooterMaxRow + 7,
					secondPartStartColumn + 7, secondPartStartColumn + 7,
					"SPIR No.", stylenewt);

			createcellbox(partFooterMaxRow + 1, partFooterMaxRow + 2,
					secondPartStartColumn + 8, secondPartStartColumn + 8, count1.toString(),
					stylenewt);
			createcellbox(partFooterMaxRow + 3, partFooterMaxRow + 4,
					secondPartStartColumn + 8, secondPartStartColumn + 8, count1.toString(),
					stylenewt);
			createcellbox(partFooterMaxRow + 5, partFooterMaxRow + 5,
					secondPartStartColumn + 8, secondPartStartColumn + 8, "",
					stylenewt);
			createcellbox(partFooterMaxRow + 6, partFooterMaxRow + 6,
					secondPartStartColumn + 8, secondPartStartColumn + 8,
					"1 of 1", stylenewt);
			createcellbox(partFooterMaxRow + 7, partFooterMaxRow + 7,
					secondPartStartColumn + 8, secondPartStartColumn + 8,
					"0001", stylenewt);

		} catch (Exception e) {
			LOGGER.info("inside PartFooter" + e.getMessage());
		}
	}

	public void part7to13Hdr(int rownumt_in, int irspanval_in, int colnumt_in,
			int inumcolt_in, int rowheight_in, int part_type_in) {
		try {

			int rowt = 0, colnumt = 0, rownumt = (rownumt_in + irspanval_in - 1), icolwidth = 1, icntr = 0;
			boolean imergeval = false;
			String strcellval = "";

			for (rowt = rownumt_in; rowt <= rownumt; rowt++) {
				if (sheet.getRow(rowt) == null) {
					row = sheet.createRow(rowt);
					row.setHeight((short) (rowheight_in));
				} else
					row = sheet.getRow(rowt);

				if (part_type_in == 14) {
					for (colnumt = 0; colnumt < part123MaxCol; colnumt++) {
						if (colnumt == 0)
							CreateCell(rownumt_in, irspanval_in, colnumt,
									label4[0], stylehc, imergeval);
						else if (colnumt == 1)
							CreateCell(rownumt_in, irspanval_in, colnumt,
									label4[1], stylehc, imergeval);
						else
							CreateCell(rownumt_in, irspanval_in, colnumt,
									label4[2], stylehc, imergeval);
					}

				}

				icntr = 0;
				for (colnumt = colnumt_in; colnumt <= (colnumt_in + inumcolt_in); colnumt++) {
					if (part_type_in == 13) {
						icolwidth = Integer.valueOf(label12[icntr][2]);
						strcellval = label12[icntr][0];
						if (label12[icntr][1] == "H")
							styletmp = stylehc;
						else
							styletmp = stylev;
					} else if (part_type_in == 14) {
						strcellval = label14[icntr][0];
						styletmp = stylehc;
					}
					CreateCell(rownumt_in, irspanval_in, colnumt, strcellval,
							styletmp, imergeval);
					if (colnumt == colnumt_in + 3) {
						colnumt++;
						icntr++;
						strcellval = "";
						CreateCell(rownumt_in, irspanval_in, colnumt,
								strcellval, styletmp, imergeval);
					}

					if (rowt == rownumt && part_type_in == 13)
						sheet.setColumnWidth(colnumt,
								(idefaultColWidth * icolwidth));

					if (rowt == rownumt) {
						if ((colnumt - colnumt_in) == 4)
							merge(rownumt_in, rownumt, colnumt_in + 3,
									colnumt_in + 4);
						else if (part_type_in == 13)
							merge(rownumt_in, rownumt, colnumt, colnumt);

					}

					icntr++;

				}

			}

		} catch (Exception e) {
			LOGGER.info("inside part7to13Hdr" + e.getMessage());
		}
	}

	public void genpart123(String lable1_in, String label2_in,
			List<String> list_in, int rownumt_in, int irspanval_in,
			int rowheight_in) {
		try {

			String lable1 = lable1_in, label2 = label2_in;

			int rownumt = rownumt_in, irspanval = irspanval_in, colnumt = 0, rowt = 0;
			String strcellval = "";
			boolean imergeval = false;

			for (rowt = rownumt; rowt < (rownumt + irspanval); rowt++) {
				row = sheet.createRow(rowt);
				row.setHeight((short) (rowheight_in));
				colnumt = 0;

				Iterator itr = list_in.iterator();
				while (itr.hasNext()) {
					strcellval = (String) itr.next();
					if (rowt == (rownumt + irspanval - 1))
						imergeval = true;

					if (colnumt == 0) {
						CreateCell(rownumt, irspanval, colnumt, lable1,
								stylehc, imergeval);
						if (rowt == rownumt)
							sheet.autoSizeColumn(colnumt);
						colnumt++;

						CreateCell(rownumt, irspanval, colnumt, label2, stylev,
								imergeval);
						colnumt++;
					}

					CreateCell(rownumt, irspanval, colnumt, strcellval, stylev,
							imergeval);
					if (rowt == rownumt)
						sheet.autoSizeColumn(colnumt);
					colnumt++;
				}

				if (part123MaxCol == 0 && rownumt_in == 1)
					part123MaxCol = colnumt;
			}
		} catch (Exception e) {
			LOGGER.info("inside genpart123" + e.getMessage());
		}
	}

	public void CreateCell(int startrownum, int irspan, int colt,
			Object objval, XSSFCellStyle stylein, boolean imerge) {
		try {
			cell = row.createCell(colt);
			cell.setCellStyle(stylein);
			if (objval instanceof String)
				cell.setCellValue((String) objval);

			if (imerge)
				merge(startrownum, (irspan + startrownum - 1), colt, colt);
		} catch (Exception e) {
			LOGGER.info("inside CreateCell" + e.getMessage());
		}

	}

	public XSSFCellStyle getstyleobj(int bbot, int btop, int bleft, int bright,
			int valign, int align, int ifont, int ifontw) {
		XSSFCellStyle stylehtmp = null;

		try {

			stylehtmp = (XSSFCellStyle) wb.createCellStyle();
			stylehtmp.setBorderBottom((short) bbot);
			stylehtmp.setBorderTop((short) btop);
			stylehtmp.setBorderRight((short) bright);
			stylehtmp.setBorderLeft((short) bleft);
			stylehtmp.setVerticalAlignment((short) valign);
			stylehtmp.setAlignment((short) align);
			stylehtmp.setWrapText(true);
			if (ifont != 0 || ifontw != 0) {
				XSSFFont txtFont = (XSSFFont) wb.createFont();
				
				if (ifont != 0)
					txtFont.setFontHeightInPoints((short) ifont);
				if (ifontw != 0)
					txtFont.setBoldweight((short) ifontw);
				stylehtmp.setFont(txtFont);
			}
			return stylehtmp;
		} catch (Exception e) {
			LOGGER.info("inside CreateCell" + e.getMessage());
			return null;
		}

	}

	public XSSFCellStyle getstyleobjV(int bbot, int btop, int bleft,
			int bright, int valign, int align, int ifont, int ifontw) {
		XSSFCellStyle stylehtmp = null;

		try {

			stylehtmp = (XSSFCellStyle) wb.createCellStyle();
			stylehtmp.setBorderBottom((short) bbot);
			stylehtmp.setBorderTop((short) btop);
			stylehtmp.setBorderRight((short) bright);
			stylehtmp.setBorderLeft((short) bleft);
			stylehtmp.setVerticalAlignment((short) valign);
			stylehtmp.setAlignment((short) align);
			stylehtmp.setRotation((short) 90);
			stylehtmp.setWrapText(true);
			if (ifont != 0 || ifontw != 0) {
				XSSFFont txtFont = (XSSFFont) wb.createFont();
				if (ifont != 0)
					txtFont.setFontHeightInPoints((short) ifont);
				if (ifontw != 0)
					txtFont.setBoldweight((short) ifontw);
				stylehtmp.setFont(txtFont);
			}
			return stylehtmp;
		} catch (Exception e) {
			LOGGER.info("inside getstyleobjV" + e.getMessage());
			return null;
		}

	}

	public void getstyle() {
		try {
			stylehn = (XSSFCellStyle) wb.createCellStyle();
			
			stylehn.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			stylehn.setBorderTop(XSSFCellStyle.BORDER_THIN);
			stylehn.setBorderRight(XSSFCellStyle.BORDER_THIN);
			stylehn.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			stylehn.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			stylehn.setWrapText(true);

			styleht = (XSSFCellStyle) wb.createCellStyle();
			styleht.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			styleht.setBorderTop(XSSFCellStyle.BORDER_THIN);
			styleht.setBorderRight(XSSFCellStyle.BORDER_THIN);
			styleht.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			styleht.setVerticalAlignment(XSSFCellStyle.VERTICAL_BOTTOM);
			styleht.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			styleht.setWrapText(true);

			stylehc = (XSSFCellStyle) wb.createCellStyle();
			stylehc.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			stylehc.setBorderTop(XSSFCellStyle.BORDER_THIN);
			stylehc.setBorderRight(XSSFCellStyle.BORDER_THIN);
			stylehc.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			stylehc.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
			stylehc.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			stylehc.setWrapText(true);

			stylev = (XSSFCellStyle) wb.createCellStyle();
			stylev.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			stylev.setBorderTop(XSSFCellStyle.BORDER_THIN);
			stylev.setBorderRight(XSSFCellStyle.BORDER_THIN);
			stylev.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			stylev.setVerticalAlignment(XSSFCellStyle.VERTICAL_BOTTOM);
			stylev.setRotation((short) 90);
			stylev.setWrapText(true);

			// turn off gridlines
			sheet.setDisplayGridlines(false);
			sheet.setPrintGridlines(false);
			sheet.setFitToPage(true);
			sheet.setHorizontallyCenter(true);
			PrintSetup printSetup = sheet.getPrintSetup();
			printSetup.setLandscape(true);

		} catch (Exception e) {
			LOGGER.info("inside getstyle" + e.getMessage());
		}
	}

	public void merge(int frow, int lrow, int fcol, int lcol) {
		try {
			sheet.addMergedRegion(new CellRangeAddress(frow, // first row
																// (0-based)
					lrow, // last row (0-based)
					fcol, // first column (0-based)
					lcol // last column (0-based)
			));
		} catch (Exception e) {
			LOGGER.info("inside merge" + e.getMessage());
		}

	}

	public byte[] cleanupproc() {
		try {
			return writefile();
		} catch (Exception e) {
			LOGGER.info("inside cleanupproc" + e.getMessage());
			return null;
		}

	}

	public byte[] writefile() {
		byte[] excelBytes = null;
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		try {
			wb.write(baos);
			excelBytes = baos.toByteArray();
			baos.close();
			wb.close();
			return excelBytes;
		} catch (Exception e) {
			LOGGER.info("inside writefile" + e.getMessage());
			return null;
		}
	}

}
