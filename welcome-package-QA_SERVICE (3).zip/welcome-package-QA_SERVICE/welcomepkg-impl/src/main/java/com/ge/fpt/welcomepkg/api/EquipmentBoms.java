/*
 * Copyright (c) 2013 GE Global Research. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Global Research. The software may be used and/or copied only
 * with the written permission of GE Global Research or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author 212414241
 * 
 */

@XmlRootElement
public class EquipmentBoms implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String recSource;
	private String salesOrder;
	private String salesOrderLine;
	private String customerPo;
	private String soldToCustomerName;
	private String soldToCountry;
	private String soldToState;
	private String soldToProvince;
	private String soldToCity;
	private String repName;
	private String orderedItemNumber;
	private Long quantityShipped;
	private Double unitSellingPrice;
	private Date actualShipDate;
	private String serialNumber;
	private String valvePartNumber;
	private String valveDescription;
	private String tagNumber;
	private String componentItemNumber;
	private String componentDescription;
	private String legacyPartNumber;
	private String sparesIndicator;
	private String stockType;
	private int quantity;
	private String listPrice;
	private Long leadTime;
	private String sourceSystem;
	private String listPriceLP;
	private String updatedBy;
	private Date updatedDate;
	private String colorValue;
	private String subAssemItem;
	private String crossRefData;
	private String endUserIndustry;
	private String productCode;
	
	

	/**
	 * 
	 */
	public EquipmentBoms() {
		super();
	}

	/**
	 * @param recSource
	 * @param salesOrder
	 * @param salesOrderLine
	 * @param customerPo
	 * @param soldToCustomerName
	 * @param soldToCountry
	 * @param soldToState
	 * @param soldToProvince
	 * @param soldToCity
	 * @param repName
	 * @param orderedItemNumber
	 * @param quantityShipped
	 * @param unitSellingPrice
	 * @param actualShipDate
	 * @param serialNumber
	 * @param valvePartNumber
	 * @param valveDescription
	 * @param tagNumber
	 * @param componentItemNumber
	 * @param componentDescription
	 * @param legacyPartNumber
	 * @param sparesIndicator
	 * @param stockType
	 * @param quantity
	 * @param listPrice
	 * @param leadTime
	 * @param sourceSystem
	 */
	public EquipmentBoms(String recSource, String salesOrder, String salesOrderLine, String customerPo,
			String soldToCustomerName, String soldToCountry, String soldToState, String soldToProvince,
			String soldToCity, String repName, String orderedItemNumber, Long quantityShipped, Double unitSellingPrice,
			Date actualShipDate, String serialNumber, String valvePartNumber, String valveDescription, String tagNumber,
			String componentItemNumber, String componentDescription, String legacyPartNumber, String sparesIndicator,
			String stockType, int quantity, String listPrice, Long leadTime, String sourceSystem,String updatedBy,Date updatedDate,
			String  colorValue,String subAssemItem,String crossRefData,String endUserIndustry,String productCode){
		super();
		this.recSource = recSource;
		this.salesOrder = salesOrder;
		this.salesOrderLine = salesOrderLine;
		this.customerPo = customerPo;
		this.soldToCustomerName = soldToCustomerName;
		this.soldToCountry = soldToCountry;
		this.soldToState = soldToState;
		this.soldToProvince = soldToProvince;
		this.soldToCity = soldToCity;
		this.repName = repName;
		this.orderedItemNumber = orderedItemNumber;
		this.quantityShipped = quantityShipped;
		this.unitSellingPrice = unitSellingPrice;
		this.actualShipDate = actualShipDate;
		this.serialNumber = serialNumber;
		this.valvePartNumber = valvePartNumber;
		this.valveDescription = valveDescription;
		this.tagNumber = tagNumber;
		this.componentItemNumber = componentItemNumber;
		this.componentDescription = componentDescription;
		this.legacyPartNumber = legacyPartNumber;
		this.sparesIndicator = sparesIndicator;
		this.stockType = stockType;
		this.quantity = quantity;
		this.listPrice = listPrice;
		this.leadTime = leadTime;
		this.sourceSystem = sourceSystem;
		this.updatedBy=updatedBy;
		this.updatedDate=updatedDate;
		this.colorValue=colorValue;
		this.subAssemItem=subAssemItem;
		this.crossRefData=crossRefData;
		this.endUserIndustry =endUserIndustry;
		this.productCode=productCode;
	}

	
	public String getCrossRefData() {
		return crossRefData;
	}

	public void setCrossRefData(String crossRefData) {
		this.crossRefData = crossRefData;
	}

	public String getColorValue() {
		return colorValue;
	}

	public void setColorValue(String colorValue) {
		this.colorValue = colorValue;
	}
	/**
	 * @return the recSource
	 */
	public String getRecSource() {
		return recSource;
	}

	/**
	 * @param recSource
	 *            the recSource to set
	 */
	public void setRecSource(String recSource) {
		this.recSource = recSource;
	}

	/**
	 * @return the salesOrder
	 */
	public String getSalesOrder() {
		return salesOrder;
	}

	/**
	 * @param salesOrder
	 *            the salesOrder to set
	 */
	public void setSalesOrder(String salesOrder) {
		this.salesOrder = salesOrder;
	}

	/**
	 * @return the salesOrderLine
	 */
	public String getSalesOrderLine() {
		return salesOrderLine;
	}

	/**
	 * @param salesOrderLine
	 *            the salesOrderLine to set
	 */
	public void setSalesOrderLine(String salesOrderLine) {
		this.salesOrderLine = salesOrderLine;
	}

	/**
	 * @return the customerPo
	 */
	public String getCustomerPo() {
		return customerPo;
	}

	/**
	 * @param customerPo
	 *            the customerPo to set
	 */
	public void setCustomerPo(String customerPo) {
		this.customerPo = customerPo;
	}

	/**
	 * @return the soldToCustomerName
	 */
	public String getSoldToCustomerName() {
		return soldToCustomerName;
	}

	/**
	 * @param soldToCustomerName
	 *            the soldToCustomerName to set
	 */
	public void setSoldToCustomerName(String soldToCustomerName) {
		this.soldToCustomerName = soldToCustomerName;
	}

	/**
	 * @return the soldToCountry
	 */
	public String getSoldToCountry() {
		return soldToCountry;
	}

	/**
	 * @param soldToCountry
	 *            the soldToCountry to set
	 */
	public void setSoldToCountry(String soldToCountry) {
		this.soldToCountry = soldToCountry;
	}

	/**
	 * @return the soldToState
	 */
	public String getSoldToState() {
		return soldToState;
	}

	/**
	 * @param soldToState
	 *            the soldToState to set
	 */
	public void setSoldToState(String soldToState) {
		this.soldToState = soldToState;
	}

	/**
	 * @return the soldToProvince
	 */
	public String getSoldToProvince() {
		return soldToProvince;
	}

	/**
	 * @param soldToProvince
	 *            the soldToProvince to set
	 */
	public void setSoldToProvince(String soldToProvince) {
		this.soldToProvince = soldToProvince;
	}

	/**
	 * @return the soldToCity
	 */
	public String getSoldToCity() {
		return soldToCity;
	}

	/**
	 * @param soldToCity
	 *            the soldToCity to set
	 */
	public void setSoldToCity(String soldToCity) {
		this.soldToCity = soldToCity;
	}

	/**
	 * @return the repName
	 */
	public String getRepName() {
		return repName;
	}

	/**
	 * @param repName
	 *            the repName to set
	 */
	public void setRepName(String repName) {
		this.repName = repName;
	}

	/**
	 * @return the orderedItemNumber
	 */
	public String getOrderedItemNumber() {
		return orderedItemNumber;
	}

	/**
	 * @param orderedItemNumber
	 *            the orderedItemNumber to set
	 */
	public void setOrderedItemNumber(String orderedItemNumber) {
		this.orderedItemNumber = orderedItemNumber;
	}

	/**
	 * @return the quantityShipped
	 */
	public Long getQuantityShipped() {
		return quantityShipped;
	}

	/**
	 * @param quantityShipped
	 *            the quantityShipped to set
	 */
	public void setQuantityShipped(Long quantityShipped) {
		this.quantityShipped = quantityShipped;
	}

	/**
	 * @return the unitSellingPrice
	 */
	public Double getUnitSellingPrice() {
		return unitSellingPrice;
	}

	/**
	 * @param unitSellingPrice
	 *            the unitSellingPrice to set
	 */
	public void setUnitSellingPrice(Double unitSellingPrice) {
		this.unitSellingPrice = unitSellingPrice;
	}

	/**
	 * @return the actualShipDate
	 */
	public Date getActualShipDate() {
		return actualShipDate;
	}

	/**
	 * @param actualShipDate
	 *            the actualShipDate to set
	 */
	public void setActualShipDate(Date actualShipDate) {
		this.actualShipDate = actualShipDate;
	}

	/**
	 * @return the serialNumber
	 */
	public String getSerialNumber() {
		return serialNumber;
	}

	/**
	 * @param serialNumber
	 *            the serialNumber to set
	 */
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	/**
	 * @return the valvePartNumber
	 */
	public String getValvePartNumber() {
		return valvePartNumber;
	}

	/**
	 * @param valvePartNumber
	 *            the valvePartNumber to set
	 */
	public void setValvePartNumber(String valvePartNumber) {
		this.valvePartNumber = valvePartNumber;
	}

	/**
	 * @return the valveDescription
	 */
	public String getValveDescription() {
		return valveDescription;
	}

	/**
	 * @param valveDescription
	 *            the valveDescription to set
	 */
	public void setValveDescription(String valveDescription) {
		this.valveDescription = valveDescription;
	}

	/**
	 * @return the tagNumber
	 */
	public String getTagNumber() {
		return tagNumber;
	}

	/**
	 * @param tagNumber
	 *            the tagNumber to set
	 */
	public void setTagNumber(String tagNumber) {
		this.tagNumber = tagNumber;
	}

	/**
	 * @return the componentItemNumber
	 */
	public String getComponentItemNumber() {
		return componentItemNumber;
	}

	/**
	 * @param componentItemNumber
	 *            the componentItemNumber to set
	 */
	public void setComponentItemNumber(String componentItemNumber) {
		this.componentItemNumber = componentItemNumber;
	}

	/**
	 * @return the componentDescription
	 */
	public String getComponentDescription() {
		return componentDescription;
	}

	/**
	 * @param componentDescription
	 *            the componentDescription to set
	 */
	public void setComponentDescription(String componentDescription) {
		this.componentDescription = componentDescription;
	}

	/**
	 * @return the legacyPartNumber
	 */
	public String getLegacyPartNumber() {
		return legacyPartNumber;
	}

	/**
	 * @param legacyPartNumber
	 *            the legacyPartNumber to set
	 */
	public void setLegacyPartNumber(String legacyPartNumber) {
		this.legacyPartNumber = legacyPartNumber;
	}

	/**
	 * @return the sparesIndicator
	 */
	public String getSparesIndicator() {
		return sparesIndicator;
	}

	/**
	 * @param sparesIndicator
	 *            the sparesIndicator to set
	 */
	public void setSparesIndicator(String sparesIndicator) {
		this.sparesIndicator = sparesIndicator;
	}

	/**
	 * @return the stockType
	 */
	public String getStockType() {
		return stockType;
	}

	/**
	 * @param stockType
	 *            the stockType to set
	 */
	public void setStockType(String stockType) {
		this.stockType = stockType;
	}

	/**
	 * @return the quantity
	 */
	public int getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity
	 *            the quantity to set
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	/**
	 * @return the listPrice
	 */
	public String getListPrice() {
		return listPrice;
	}

	/**
	 * @param listPrice
	 *            the listPrice to set
	 */
	public void setListPrice(String listPrice) {
		this.listPrice = listPrice;
	}

	/**
	 * @return the leadTime
	 */
	public Long getLeadTime() {
		return leadTime;
	}

	/**
	 * @param leadTime
	 *            the leadTime to set
	 */
	public void setLeadTime(Long leadTime) {
		this.leadTime = leadTime;
	}

	/**
	 * @return the sourceSystem
	 */
	public String getSourceSystem() {
		return sourceSystem;
	}

	/**
	 * @param sourceSystem
	 *            the sourceSystem to set
	 */
	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	/**
	 * @return the listPriceLP
	 */
	public String getListPriceLP() {
		return listPriceLP;
	}

	/**
	 * @param listPriceLP the listPriceLP to set
	 */
	public void setListPriceLP(String listPriceLP) {
		this.listPriceLP = listPriceLP;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getSubAssemItem() {
		return subAssemItem;
	}

	public void setSubAssemItem(String subAssemItem) {
		this.subAssemItem = subAssemItem;
	}
	public String getEndUserIndustry() {
		return endUserIndustry;
	}

	public void setEndUserIndustry(String endUserIndustry) {
		this.endUserIndustry = endUserIndustry;
	}
	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
}
