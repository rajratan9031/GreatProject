package com.ge.fpt.welcomepkg.api;

public class CustomerInfo {
	private String serialNumber;
	private String lastupdateDate;
	private String linkcustomerName;
	private String customerId;
	private String updatedBy;
	private String dunsNumber;
	private String euIndustry;
	private String euCountry;
	private String euState;
	private String euCity;
	private String euPostalCode;
	private String euCustomerName;
	private String isActive;


	
	
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	public String getEuIndustry() {
		return euIndustry;
	}
	public void setEuIndustry(String euIndustry) {
		this.euIndustry = euIndustry;
	}
	public String getEuCountry() {
		return euCountry;
	}
	public void setEuCountry(String euCountry) {
		this.euCountry = euCountry;
	}
	public String getEuState() {
		return euState;
	}
	public void setEuState(String euState) {
		this.euState = euState;
	}
	public String getEuCity() {
		return euCity;
	}
	public void setEuCity(String euCity) {
		this.euCity = euCity;
	}
	public String getEuPostalCode() {
		return euPostalCode;
	}
	public void setEuPostalCode(String euPostalCode) {
		this.euPostalCode = euPostalCode;
	}
	public String getEuCustomerName() {
		return euCustomerName;
	}
	public void setEuCustomerName(String euCustomerName) {
		this.euCustomerName = euCustomerName;
	}
	public String getDunsNumber() {
		return dunsNumber;
	}
	public void setDunsNumber(String dunsNumber) {
		this.dunsNumber = dunsNumber;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getLastupdateDate() {
		return lastupdateDate;
	}
	public void setLastupdateDate(String lastupdateDate) {
		this.lastupdateDate = lastupdateDate;
	}
	public String getLinkcustomerName() {
		return linkcustomerName;
	}
	public void setLinkcustomerName(String linkcustomerName) {
		this.linkcustomerName = linkcustomerName;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	
	public CustomerInfo(String serialNumber, String lastupdateDate, String linkcustomerName, String customerId,
			String updatedBy, String dunsNumber, String euIndustry, String euCountry, String euState, String euCity,
			String euPostalCode, String euCustomerName) {
		super();
		this.serialNumber = serialNumber;
		this.lastupdateDate = lastupdateDate;
		this.linkcustomerName = linkcustomerName;
		this.customerId = customerId;
		this.updatedBy = updatedBy;
		this.dunsNumber = dunsNumber;
		this.euIndustry = euIndustry;
		this.euCountry = euCountry;
		this.euState = euState;
		this.euCity = euCity;
		this.euPostalCode = euPostalCode;
		this.euCustomerName = euCustomerName;
	}
	
	public CustomerInfo() {
		super();
	}
	@Override
	public String toString() {
		return "CustomerInfo [serialNumber=" + serialNumber + ", lastupdateDate=" + lastupdateDate
				+ ", linkcustomerName=" + linkcustomerName + ", customerId=" + customerId + ", updatedBy=" + updatedBy
				+ ", dunsNumber=" + dunsNumber + ", euIndustry=" + euIndustry + ", euCountry=" + euCountry
				+ ", euState=" + euState + ", euCity=" + euCity + ", euPostalCode=" + euPostalCode + ", euCustomerName="
				+ euCustomerName + ", isActive=" + isActive + "]";
	}

	

}
