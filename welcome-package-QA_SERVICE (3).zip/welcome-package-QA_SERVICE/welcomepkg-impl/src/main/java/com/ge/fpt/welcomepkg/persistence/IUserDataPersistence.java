/**
 * 
 */
package com.ge.fpt.welcomepkg.persistence;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.api.UserData;
import com.ge.fpt.welcomepkg.api.UserSettings;

/**
 * @author 204060632
 *
 */
public interface IUserDataPersistence {

	@Transactional(propagation=Propagation.REQUIRED)
	UserSettings loadUserSettings(String sso);
	
	@Transactional(propagation=Propagation.REQUIRED)
	StatusInfo saveUserSettings(String sso, UserSettings saveData);
	
	@Transactional(propagation=Propagation.REQUIRED)
	boolean getValidAdminUser(String sso);
	
	@Transactional(propagation=Propagation.REQUIRED)
	boolean getValidPriceToolUser(String sso);
	
	@Transactional(propagation=Propagation.REQUIRED)
	UserData getUserData(String sso);
	
	@Transactional(propagation=Propagation.REQUIRED)
	boolean getValidEnggAdminUser(String sso);
	
	@Transactional(propagation=Propagation.REQUIRED)
	boolean getValidInventoryUser(String sso);

	@Transactional(propagation=Propagation.REQUIRED)
	boolean getValidUpgradeMgmtUser(String sso);
	
	@Transactional(propagation=Propagation.REQUIRED)
	boolean getValidRCAccountMgmtUser(String sso);
	
	@Transactional(propagation=Propagation.REQUIRED)
	boolean getValidRCCustomerMgmtUser(String sso);
	
	@Transactional(propagation=Propagation.REQUIRED)
	boolean getValidRCProductMgmtUser(String sso);
/*
	@Transactional(propagation=Propagation.REQUIRED)
	boolean getRcUser(String sso);*/

}
