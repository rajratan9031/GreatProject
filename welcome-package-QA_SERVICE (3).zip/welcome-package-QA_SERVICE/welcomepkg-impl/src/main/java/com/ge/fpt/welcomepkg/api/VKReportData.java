/**
 * 
 */
package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author 204060632
 *
 */
@XmlRootElement	
public class VKReportData implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3187207681893707788L;
	
	private String salesOrder;
	private String endUserCustName;
	private String endUserCustAddress;
	private String city;
	private String state;
	private String province;
	private String postalCode;
	private String country;
	private String shipDate;
	private String shipSource;
	private String serialNumber;
	private String valveDescription;
	private String tagNumber;
	private String partNumber;
	private String partDescription;
	private String sparesCode;
	private String qty;
	//private String listPrice;
	private String leadTime;

	/**
	 * 
	 */
	public VKReportData() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the salesOrder
	 */
	public String getSalesOrder() {
		return salesOrder;
	}

	/**
	 * @param salesOrder the salesOrder to set
	 */
	public void setSalesOrder(String salesOrder) {
		this.salesOrder = salesOrder;
	}

	/**
	 * @return the endUserCustName
	 */
	public String getEndUserCustName() {
		return endUserCustName;
	}

	/**
	 * @param endUserCustName the endUserCustName to set
	 */
	public void setEndUserCustName(String endUserCustName) {
		this.endUserCustName = endUserCustName;
	}

	/**
	 * @return the endUserCustAddress
	 */
	public String getEndUserCustAddress() {
		return endUserCustAddress;
	}

	/**
	 * @param endUserCustAddress the endUserCustAddress to set
	 */
	public void setEndUserCustAddress(String endUserCustAddress) {
		this.endUserCustAddress = endUserCustAddress;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the province
	 */
	public String getProvince() {
		return province;
	}

	/**
	 * @param province the province to set
	 */
	public void setProvince(String province) {
		this.province = province;
	}

	/**
	 * @return the postalCode
	 */
	public String getPostalCode() {
		return postalCode;
	}

	/**
	 * @param postalCode the postalCode to set
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the shipDate
	 */
	public String getShipDate() {
		return shipDate;
	}

	/**
	 * @param shipDate the shipDate to set
	 */
	public void setShipDate(String shipDate) {
		this.shipDate = shipDate;
	}

	/**
	 * @return the shipSource
	 */
	public String getShipSource() {
		return shipSource;
	}

	/**
	 * @param shipSource the shipSource to set
	 */
	public void setShipSource(String shipSource) {
		this.shipSource = shipSource;
	}

	/**
	 * @return the serialNumber
	 */
	public String getSerialNumber() {
		return serialNumber;
	}

	/**
	 * @param serialNumber the serialNumber to set
	 */
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	/**
	 * @return the valveDescription
	 */
	public String getValveDescription() {
		return valveDescription;
	}

	/**
	 * @param valveDescription the valveDescription to set
	 */
	public void setValveDescription(String valveDescription) {
		this.valveDescription = valveDescription;
	}

	/**
	 * @return the tagNumber
	 */
	public String getTagNumber() {
		return tagNumber;
	}

	/**
	 * @param tagNumber the tagNumber to set
	 */
	public void setTagNumber(String tagNumber) {
		this.tagNumber = tagNumber;
	}

	/**
	 * @return the partNumber
	 */
	public String getPartNumber() {
		return partNumber;
	}

	/**
	 * @param partNumber the partNumber to set
	 */
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	/**
	 * @return the partDescription
	 */
	public String getPartDescription() {
		return partDescription;
	}

	/**
	 * @param partDescription the partDescription to set
	 */
	public void setPartDescription(String partDescription) {
		this.partDescription = partDescription;
	}

	/**
	 * @return the sparesCode
	 */
	public String getSparesCode() {
		return sparesCode;
	}

	/**
	 * @param sparesCode the sparesCode to set
	 */
	public void setSparesCode(String sparesCode) {
		this.sparesCode = sparesCode;
	}

	/**
	 * @return the qty
	 */
	public String getQty() {
		return qty;
	}

	/**
	 * @param qty the qty to set
	 */
	public void setQty(String qty) {
		this.qty = qty;
	}

//	/**
//	 * @return the listPrice
//	 */
//	public String getListPrice() {
//		return listPrice;
//	}
//
//	/**
//	 * @param listPrice the listPrice to set
//	 */
//	public void setListPrice(String listPrice) {
//		this.listPrice = listPrice;
//	}

	/**
	 * @return the leadTime
	 */
	public String getLeadTime() {
		return leadTime;
	}

	/**
	 * @param leadTime the leadTime to set
	 */
	public void setLeadTime(String leadTime) {
		this.leadTime = leadTime;
	}

}
