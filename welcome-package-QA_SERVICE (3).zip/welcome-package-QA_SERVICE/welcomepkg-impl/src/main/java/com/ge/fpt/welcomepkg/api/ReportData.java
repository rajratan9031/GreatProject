package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class ReportData implements Serializable{
	private static final long serialVersionUID = -5579175197980496818L;
	
	private boolean wipSpir;
	private String reportType;
	private String region;
	private String currency;
	private List<Map<String,String>> data;
	
	
	public ReportData() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public ReportData(boolean wipSpir, String reportType, String region, 
			String currency,List<Map<String,String>> data) {
		super();
		this.reportType = reportType;
		this.region = region;
		this.currency = currency;
		this.wipSpir = wipSpir;
		this.data = data;
	}

	public boolean isWipSpir() {
		return wipSpir;
	}

	public void setWipSpir(boolean wipSpir) {
		this.wipSpir = wipSpir;
	}

	public String getReportType() {
		return reportType;
	}

	public void setReportType(String reportType) {
		this.reportType = reportType;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public List<Map<String, String>> getData() {
		return data;
	}

	public void setData(List<Map<String, String>> data) {
		this.data = data;
	}
	
	
	
}
