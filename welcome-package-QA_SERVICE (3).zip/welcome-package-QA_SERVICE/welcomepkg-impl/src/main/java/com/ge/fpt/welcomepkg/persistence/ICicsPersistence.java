package com.ge.fpt.welcomepkg.persistence;

import java.util.List;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ge.fpt.welcomepkg.api.BomWhereusedData;
import com.ge.fpt.welcomepkg.api.PartMasterData;
import com.ge.fpt.welcomepkg.api.PartMasterData1;


public interface ICicsPersistence {
	
	
	@Transactional(propagation=Propagation.REQUIRED)
	List<PartMasterData> getPartNumberData(String searchBy, String partNo, Integer startPartIndex, Integer endPartIndex);

	
	
	@Transactional(propagation=Propagation.REQUIRED)
	List<PartMasterData> getSubPartNumberData(String searchBy, String partNo, String subPartNo, Integer startPartIndex, Integer endPartIndex);
	
	@Transactional(propagation=Propagation.REQUIRED)
	List<PartMasterData1> getPartDataOnClick(String partNo);


	@Transactional(propagation=Propagation.REQUIRED)
	List<BomWhereusedData> getWhereusedData(String partNo, Integer startIndex, Integer endIndex);


	@Transactional(propagation=Propagation.REQUIRED)
	List<BomWhereusedData> getBOMData(String partNo, Integer startIndex, Integer endIndex);

}
