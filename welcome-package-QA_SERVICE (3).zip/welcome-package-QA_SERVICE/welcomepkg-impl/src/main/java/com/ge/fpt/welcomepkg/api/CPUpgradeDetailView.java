package com.ge.fpt.welcomepkg.api;

import java.util.List;

public class CPUpgradeDetailView {
	
	private int upgradeId;
	private String upgradeName;
	private double amount;
	private double discount;
	private String couponCode;
	private String description;
	private int noOfParts;
	private int noOfCustomers;
	private double savings;
	private double revenue;
	List<CPUpgradeDocument> upgradeDocuments;
	List<CPUpgradePackage> upgradePackages;
	public int getUpgradeId() {
		return upgradeId;
	}
	public void setUpgradeId(int upgradeId) {
		this.upgradeId = upgradeId;
	}
	public String getUpgradeName() {
		return upgradeName;
	}
	public void setUpgradeName(String upgradeName) {
		this.upgradeName = upgradeName;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getNoOfParts() {
		return noOfParts;
	}
	public void setNoOfParts(int noOfParts) {
		this.noOfParts = noOfParts;
	}
	public int getNoOfCustomers() {
		return noOfCustomers;
	}
	public void setNoOfCustomers(int noOfCustomers) {
		this.noOfCustomers = noOfCustomers;
	}
	public double getSavings() {
		return savings;
	}
	public void setSavings(double savings) {
		this.savings = savings;
	}
	public double getRevenue() {
		return revenue;
	}
	public void setRevenue(double revenue) {
		this.revenue = revenue;
	}
	public List<CPUpgradeDocument> getUpgradeDocuments() {
		return upgradeDocuments;
	}
	public void setUpgradeDocuments(List<CPUpgradeDocument> upgradeDocuments) {
		this.upgradeDocuments = upgradeDocuments;
	}
	public List<CPUpgradePackage> getUpgradePackages() {
		return upgradePackages;
	}
	public void setUpgradePackages(List<CPUpgradePackage> upgradePackages) {
		this.upgradePackages = upgradePackages;
	}
	public String getCouponCode() {
		return couponCode;
	}
	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}
	@Override
	public String toString() {
		return "CPUpgradeDetailView [upgradeId=" + upgradeId + ", upgradeName=" + upgradeName + ", amount=" + amount
				+ ", discount=" + discount + ", couponCode=" + couponCode + ", description=" + description
				+ ", noOfParts=" + noOfParts + ", noOfCustomers=" + noOfCustomers + ", savings=" + savings
				+ ", revenue=" + revenue + ", upgradeDocuments=" + upgradeDocuments + ", upgradePackages="
				+ upgradePackages + "]";
	}
	
	
	
	
	
	
	

}
