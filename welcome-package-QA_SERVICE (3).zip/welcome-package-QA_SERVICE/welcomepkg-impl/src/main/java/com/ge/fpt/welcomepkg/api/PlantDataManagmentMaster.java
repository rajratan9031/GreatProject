package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.Date;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
@JsonIgnoreProperties(ignoreUnknown = true)
public class PlantDataManagmentMaster implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String customerId;
	//private String customerName;
	private String plantId="";
	private String plantLocation;
	/*private String plantArea;
	private String plantAccount;
	private String plantUniversal;*/
	private String contact; // To store CUSTOMER_CONTACT_NAME
	private String maintaenaceInternal;
	private String country;
	//private String region;
	private String isActive;
	private String dunsNumber;
	private Date createdDate;
	private Date updatedDate;
	private String updatedBy;
	private String createdBy;
	private String plantName;
	private String city;
	private String state;
	private String postalCode;
	private String customerEmail;
	private String valveLocation;
	
	public PlantDataManagmentMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getPlantId() {
		return plantId;
	}

	public void setPlantId(String plantId) {
		this.plantId = plantId;
	}

	public String getPlantLocation() {
		return plantLocation;
	}

	public void setPlantLocation(String plantLocation) {
		this.plantLocation = plantLocation;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getMaintaenaceInternal() {
		return maintaenaceInternal;
	}

	public void setMaintaenaceInternal(String maintaenaceInternal) {
		this.maintaenaceInternal = maintaenaceInternal;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getDunsNumber() {
		return dunsNumber;
	}

	public void setDunsNumber(String dunsNumber) {
		this.dunsNumber = dunsNumber;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getPlantName() {
		return plantName;
	}

	public void setPlantName(String plantName) {
		this.plantName = plantName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public String getValveLocation() {
		return valveLocation;
	}

	public void setValveLocation(String valveLocation) {
		this.valveLocation = valveLocation;
	}

	public PlantDataManagmentMaster(String customerId, String plantId, String plantLocation, String contact,
			String maintaenaceInternal, String country, String isActive, String dunsNumber, Date createdDate,
			Date updatedDate, String updatedBy, String createdBy, String plantName, String city, String state,
			String postalCode, String customerEmail, String valveLocation) {
		super();
		this.customerId = customerId;
		this.plantId = plantId;
		this.plantLocation = plantLocation;
		this.contact = contact;
		this.maintaenaceInternal = maintaenaceInternal;
		this.country = country;
		this.isActive = isActive;
		this.dunsNumber = dunsNumber;
		this.createdDate = createdDate;
		this.updatedDate = updatedDate;
		this.updatedBy = updatedBy;
		this.createdBy = createdBy;
		this.plantName = plantName;
		this.city = city;
		this.state = state;
		this.postalCode = postalCode;
		this.customerEmail = customerEmail;
		this.valveLocation = valveLocation;
	}

	@Override
	public String toString() {
		return "PlantDataManagmentMaster [customerId=" + customerId + ", plantId=" + plantId + ", plantLocation="
				+ plantLocation + ", contact=" + contact + ", maintaenaceInternal=" + maintaenaceInternal + ", country="
				+ country + ", isActive=" + isActive + ", dunsNumber=" + dunsNumber + ", createdDate=" + createdDate
				+ ", updatedDate=" + updatedDate + ", updatedBy=" + updatedBy + ", createdBy=" + createdBy
				+ ", plantName=" + plantName + ", city=" + city + ", state=" + state + ", postalCode=" + postalCode
				+ ", customerEmail=" + customerEmail + ", valveLocation=" + valveLocation + "]";
	}

	
	
}
