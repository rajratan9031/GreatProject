/*
 * Copyright (c) 2013 GE Global Research. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Global Research. The software may be used and/or copied only
 * with the written permission of GE Global Research or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.fpt.welcomepkg.persistence;

import java.util.List;
import java.util.Map;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ge.fpt.welcomepkg.api.BomConfigurator;
import com.ge.fpt.welcomepkg.api.EquipmentBoms;
import com.ge.fpt.welcomepkg.api.StatusInfo;

/**
 * @author 212414241
 * 
 */
public interface IBomsPersistence {

	/**
	 * Get Bom by Serial Number and Rec Source
	 * 
	 * @param serialNumber
	 *            euipment serial number
	 * @param recSource
	 *            record source
	 * @return list of boms, filtered by serial number and record source
	 */
	@Transactional(propagation = Propagation.REQUIRED)
	List<EquipmentBoms> getBomBySerialNumberAndRecSource(String serialNumber, String recSource, String region, String currency);
	
	@Transactional(propagation = Propagation.REQUIRED)
	List<String>getPartNo(String recsource,String serialno,String partNo);
	
	@Transactional(propagation = Propagation.REQUIRED)
	List<String> getPartDesc(String recsource,String partNo);
	
	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo deletePartHeader( String sso,EquipmentBoms equipmentBoms) ;
	
	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo savePartHeader(String serialNumber,String recSource,String sso,EquipmentBoms[] equipmentBoms);
	
	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo saveBomConfigurator( String sso,BomConfigurator bomConfigurator);
	
	@Transactional(propagation = Propagation.REQUIRED)
	List<BomConfigurator> getBomConfigurator( String serialNumber,String recSource);
}
