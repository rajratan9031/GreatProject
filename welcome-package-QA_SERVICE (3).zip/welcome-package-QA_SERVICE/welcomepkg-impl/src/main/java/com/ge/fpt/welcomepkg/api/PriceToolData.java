package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class PriceToolData implements Serializable {
	private static final long serialVersionUID = 1L;
	private String partNumber;
	private String productLine;
	private String type;
	private String priceListname;
	private String currency;
	private String listPrice;
	private String cost;
	private Date dateOfCost;
	private String location;
	private String region;
	private Date dateOfPrice;
	private String locationOfcost;
	private String description;

	public PriceToolData() {
	}

	public PriceToolData(String priceListname, String partNumber,
			String listPrice, Date dateOfPrice, String region, String cost,
			Date dateOfCost, String locationOfcost, String productLine,
			String currency, String location, String type,String description) {
		this.priceListname = priceListname;
		this.partNumber = partNumber;
		this.listPrice = listPrice;
		this.dateOfPrice = dateOfPrice;
		this.region = region;
		this.cost = cost;
		this.dateOfCost = dateOfCost;
		this.locationOfcost = locationOfcost;
		this.productLine = productLine;
		this.currency = currency;
		this.location = location;
		this.type = type;
		this.description=description;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getPriceListname() {
		return this.priceListname;
	}

	public void setPriceListname(String priceListname) {
		this.priceListname = priceListname;
	}

	public String getPartNumber() {
		return this.partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public String getListPrice() {
		return this.listPrice;
	}

	public void setListPrice(String listPrice) {
		this.listPrice = listPrice;
	}

	public Date getDateOfPrice() {
		return this.dateOfPrice;
	}

	public void setDateOfPrice(Date dateOfPrice) {
		this.dateOfPrice = dateOfPrice;
	}

	public String getRegion() {
		return this.region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getCost() {
		return this.cost;
	}

	public void setCost(String cost) {
		this.cost = cost;
	}

	public Date getDateOfCost() {
		return this.dateOfCost;
	}

	public void setDateOfCost(Date dateOfCost) {
		this.dateOfCost = dateOfCost;
	}

	public String getLocationOfcost() {
		return this.locationOfcost;
	}

	public void setLocationOfcost(String locationOfcost) {
		this.locationOfcost = locationOfcost;
	}

	public String getProductLine() {
		return this.productLine;
	}

	public void setProductLine(String productLine) {
		this.productLine = productLine;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getLocation() {
		return this.location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
}
