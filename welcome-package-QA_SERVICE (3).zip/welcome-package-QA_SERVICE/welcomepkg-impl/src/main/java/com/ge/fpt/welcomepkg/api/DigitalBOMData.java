package com.ge.fpt.welcomepkg.api;

public class DigitalBOMData {
	
	private String componentItemNumber;
	private String componentDescription;
	private String quantity;
	private String valveInfoId;
	
	public DigitalBOMData(){
		super();
	}
	
	public String getValveInfoId() {
		return valveInfoId;
	}

	public void setValveInfoId(String valveInfoId) {
		this.valveInfoId = valveInfoId;
	}

	public String getComponentItemNumber() {
		return componentItemNumber;
	}

	public void setComponentItemNumber(String componentItemNumber) {
		this.componentItemNumber = componentItemNumber;
	}

	public String getComponentDescription() {
		return componentDescription;
	}

	public void setComponentDescription(String componentDescription) {
		this.componentDescription = componentDescription;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public DigitalBOMData(String componentItemNumber, String componentDescription, String quantity,
			String valveInfoId) {
		super();
		this.componentItemNumber = componentItemNumber;
		this.componentDescription = componentDescription;
		this.quantity = quantity;
		this.valveInfoId = valveInfoId;
	}

	@Override
	public String toString() {
		return "DigitalBOMData [componentItemNumber=" + componentItemNumber + ", componentDescription="
				+ componentDescription + ", quantity=" + quantity + ", valveInfoId=" + valveInfoId + "]";
	}

	
	
}
