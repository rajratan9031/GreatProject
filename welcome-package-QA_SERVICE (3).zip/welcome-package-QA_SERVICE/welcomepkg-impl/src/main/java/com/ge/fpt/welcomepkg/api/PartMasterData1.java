package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.Date;

public class PartMasterData1 implements Serializable {

	private static final long serialVersionUID = -5579278977980989818L; 
	
	
	private String pmtPartNumber;                  
	private String pmtConsignedAccount ;             
	private String pmtRespCode ;                     
	private String pmtDrawingNumber ;               
	private String pmtAccountNumber ;                 
	private Date pmtDateLastActive ;      
	private Date pmtDateOfLastRecpt ;       
	private Date pmtLastPhyInvDate ;        
	private String pmtDescription ;
	private String pmtLeadTime ;
	private Long pmtEconomicOq ;
	private String pmtVendorPrimary ;
	private Long pmtYtdUseProduction ;
	private Long pmtLastYearsUsage ;
	private String pmtStatusCode ;
	private Date pmtDateCreated ;                 
	private Double pmtTpoCostMaterial ;
	private Double pmtTpoCostLabor ;
	private Double pmtTpoStdLabHours ;
	private Double pmtRplCostMtl ;
	private Double pmtRplCostLab ;
	private Double pmtRplCostOvhd ;
	private String pmtPriceFactorCode ;
	private Long pmtStandardOq ;
	private Double pmtSvcListPrice ;
	private String pmtPartRevalueFlag ;
	private String pmtCompRevalueFlag ;
	private String pmtSvcNotAvailCode ;
	private String pmtPartsClassCode ;
	private String pmtPartsCatalogCode ;
	private Double pmtLyrCostMtl ;
	private Double pmtLyrCostLab ;
	private Long pmtActNoOfPieces ;
	private String pmtSize ;
	private Double pmtStdCostMaterial ;
	private Double pmtStdCostLabor ;
	private Double pmtStdLaborHours ;
	private String pmtStdCostNoValue ;
	private Long pmtStartExtMtlAmt ;
	private Long pmtStartExtLabAmt ;
	private String pmtProdComm ;
	private String pmtUnitMeasureStock ;
	private String pmtUnitMeasurePurch ;
	private Date pmtDateOfCost ;            
	private String pmtHtsCat ;
	private String pmtEccnCode ;
	private String pmtMaterialDescCd ;
	private String pmtLowLevelCode ;
	private String pmtCountryOfOrigin1 ;
	private String pmtCountryOfOrigin2 ;
	private String pmtMstrRtgNum ;
	private String pmtEngrChangeNumber1 ;
	private String pmtMaterialChangeNo ;
	private String pmtEngrChangeNumber2 ;
	private String pmtEngrChangeNumber3 ;
	private Date pmtEngrChangeDate1 ;           
	private Date pmtEngrChangeDate2 ;           
	private Date pmtEngrChangeDate3 ;           
	private String pmtEngrChangeInit1 ;
	private String pmtEngrChangeInit2 ;
	private String pmtEngrChangeInit3 ;
	private String pmtStatusCategory ;
	private String pmtEngrChgDisp ;
	private String pmtCadDrawing ;
	private Long pmtAssyRecCount ;
	private Long pmtWhereuseRecCount ;
	private Long pmtRoutingRecCount ;
	private String pmtOrdPolicyCode ;
	private String mdscGeneral ;
	private String specific ;
	
	
	
	public String getPmtPartNumber() {
		return pmtPartNumber;
	}
	public void setPmtPartNumber(String pmtPartNumber) {
		this.pmtPartNumber = pmtPartNumber;
	}
	public String getPmtConsignedAccount() {
		return pmtConsignedAccount;
	}
	public void setPmtConsignedAccount(String pmtConsignedAccount) {
		this.pmtConsignedAccount = pmtConsignedAccount;
	}
	public String getPmtRespCode() {
		return pmtRespCode;
	}
	public void setPmtRespCode(String pmtRespCode) {
		this.pmtRespCode = pmtRespCode;
	}
	public String getPmtDrawingNumber() {
		return pmtDrawingNumber;
	}
	public void setPmtDrawingNumber(String pmtDrawingNumber) {
		this.pmtDrawingNumber = pmtDrawingNumber;
	}
	public String getPmtAccountNumber() {
		return pmtAccountNumber;
	}
	public void setPmtAccountNumber(String pmtAccountNumber) {
		this.pmtAccountNumber = pmtAccountNumber;
	}
	public Date getPmtDateLastActive() {
		return pmtDateLastActive;
	}
	public void setPmtDateLastActive(Date pmtDateLastActive) {
		this.pmtDateLastActive = pmtDateLastActive;
	}
	public Date getPmtDateOfLastRecpt() {
		return pmtDateOfLastRecpt;
	}
	public void setPmtDateOfLastRecpt(Date pmtDateOfLastRecpt) {
		this.pmtDateOfLastRecpt = pmtDateOfLastRecpt;
	}
	public Date getPmtLastPhyInvDate() {
		return pmtLastPhyInvDate;
	}
	public void setPmtLastPhyInvDate(Date pmtLastPhyInvDate) {
		this.pmtLastPhyInvDate = pmtLastPhyInvDate;
	}
	public String getPmtDescription() {
		return pmtDescription;
	}
	public void setPmtDescription(String pmtDescription) {
		this.pmtDescription = pmtDescription;
	}
	public String getPmtLeadTime() {
		return pmtLeadTime;
	}
	public void setPmtLeadTime(String pmtLeadTime) {
		this.pmtLeadTime = pmtLeadTime;
	}
	public Long getPmtEconomicOq() {
		return pmtEconomicOq;
	}
	public void setPmtEconomicOq(Long pmtEconomicOq) {
		this.pmtEconomicOq = pmtEconomicOq;
	}
	public String getPmtVendorPrimary() {
		return pmtVendorPrimary;
	}
	public void setPmtVendorPrimary(String pmtVendorPrimary) {
		this.pmtVendorPrimary = pmtVendorPrimary;
	}
	public Long getPmtYtdUseProduction() {
		return pmtYtdUseProduction;
	}
	public void setPmtYtdUseProduction(Long pmtYtdUseProduction) {
		this.pmtYtdUseProduction = pmtYtdUseProduction;
	}
	public Long getPmtLastYearsUsage() {
		return pmtLastYearsUsage;
	}
	public void setPmtLastYearsUsage(Long pmtLastYearsUsage) {
		this.pmtLastYearsUsage = pmtLastYearsUsage;
	}
	public String getPmtStatusCode() {
		return pmtStatusCode;
	}
	public void setPmtStatusCode(String pmtStatusCode) {
		this.pmtStatusCode = pmtStatusCode;
	}
	public Date getPmtDateCreated() {
		return pmtDateCreated;
	}
	public void setPmtDateCreated(Date pmtDateCreated) {
		this.pmtDateCreated = pmtDateCreated;
	}
	public Double getPmtTpoCostMaterial() {
		return pmtTpoCostMaterial;
	}
	public void setPmtTpoCostMaterial(Double pmtTpoCostMaterial) {
		this.pmtTpoCostMaterial = pmtTpoCostMaterial;
	}
	public Double getPmtTpoCostLabor() {
		return pmtTpoCostLabor;
	}
	public void setPmtTpoCostLabor(Double pmtTpoCostLabor) {
		this.pmtTpoCostLabor = pmtTpoCostLabor;
	}
	public Double getPmtTpoStdLabHours() {
		return pmtTpoStdLabHours;
	}
	public void setPmtTpoStdLabHours(Double pmtTpoStdLabHours) {
		this.pmtTpoStdLabHours = pmtTpoStdLabHours;
	}
	public Double getPmtRplCostMtl() {
		return pmtRplCostMtl;
	}
	public void setPmtRplCostMtl(Double pmtRplCostMtl) {
		this.pmtRplCostMtl = pmtRplCostMtl;
	}
	public Double getPmtRplCostLab() {
		return pmtRplCostLab;
	}
	public void setPmtRplCostLab(Double pmtRplCostLab) {
		this.pmtRplCostLab = pmtRplCostLab;
	}
	public Double getPmtRplCostOvhd() {
		return pmtRplCostOvhd;
	}
	public void setPmtRplCostOvhd(Double pmtRplCostOvhd) {
		this.pmtRplCostOvhd = pmtRplCostOvhd;
	}
	public String getPmtPriceFactorCode() {
		return pmtPriceFactorCode;
	}
	public void setPmtPriceFactorCode(String pmtPriceFactorCode) {
		this.pmtPriceFactorCode = pmtPriceFactorCode;
	}
	public Long getPmtStandardOq() {
		return pmtStandardOq;
	}
	public void setPmtStandardOq(Long pmtStandardOq) {
		this.pmtStandardOq = pmtStandardOq;
	}
	public Double getPmtSvcListPrice() {
		return pmtSvcListPrice;
	}
	public void setPmtSvcListPrice(Double pmtSvcListPrice) {
		this.pmtSvcListPrice = pmtSvcListPrice;
	}
	public String getPmtPartRevalueFlag() {
		return pmtPartRevalueFlag;
	}
	public void setPmtPartRevalueFlag(String pmtPartRevalueFlag) {
		this.pmtPartRevalueFlag = pmtPartRevalueFlag;
	}
	public String getPmtCompRevalueFlag() {
		return pmtCompRevalueFlag;
	}
	public void setPmtCompRevalueFlag(String pmtCompRevalueFlag) {
		this.pmtCompRevalueFlag = pmtCompRevalueFlag;
	}
	public String getPmtSvcNotAvailCode() {
		return pmtSvcNotAvailCode;
	}
	public void setPmtSvcNotAvailCode(String pmtSvcNotAvailCode) {
		this.pmtSvcNotAvailCode = pmtSvcNotAvailCode;
	}
	public String getPmtPartsClassCode() {
		return pmtPartsClassCode;
	}
	public void setPmtPartsClassCode(String pmtPartsClassCode) {
		this.pmtPartsClassCode = pmtPartsClassCode;
	}
	public String getPmtPartsCatalogCode() {
		return pmtPartsCatalogCode;
	}
	public void setPmtPartsCatalogCode(String pmtPartsCatalogCode) {
		this.pmtPartsCatalogCode = pmtPartsCatalogCode;
	}
	public Double getPmtLyrCostMtl() {
		return pmtLyrCostMtl;
	}
	public void setPmtLyrCostMtl(Double pmtLyrCostMtl) {
		this.pmtLyrCostMtl = pmtLyrCostMtl;
	}
	public Double getPmtLyrCostLab() {
		return pmtLyrCostLab;
	}
	public void setPmtLyrCostLab(Double pmtLyrCostLab) {
		this.pmtLyrCostLab = pmtLyrCostLab;
	}
	public Long getPmtActNoOfPieces() {
		return pmtActNoOfPieces;
	}
	public void setPmtActNoOfPieces(Long pmtActNoOfPieces) {
		this.pmtActNoOfPieces = pmtActNoOfPieces;
	}
	public String getPmtSize() {
		return pmtSize;
	}
	public void setPmtSize(String pmtSize) {
		this.pmtSize = pmtSize;
	}
	public Double getPmtStdCostMaterial() {
		return pmtStdCostMaterial;
	}
	public void setPmtStdCostMaterial(Double pmtStdCostMaterial) {
		this.pmtStdCostMaterial = pmtStdCostMaterial;
	}
	public Double getPmtStdCostLabor() {
		return pmtStdCostLabor;
	}
	public void setPmtStdCostLabor(Double pmtStdCostLabor) {
		this.pmtStdCostLabor = pmtStdCostLabor;
	}
	public Double getPmtStdLaborHours() {
		return pmtStdLaborHours;
	}
	public void setPmtStdLaborHours(Double pmtStdLaborHours) {
		this.pmtStdLaborHours = pmtStdLaborHours;
	}
	public String getPmtStdCostNoValue() {
		return pmtStdCostNoValue;
	}
	public void setPmtStdCostNoValue(String pmtStdCostNoValue) {
		this.pmtStdCostNoValue = pmtStdCostNoValue;
	}
	public Long getPmtStartExtMtlAmt() {
		return pmtStartExtMtlAmt;
	}
	public void setPmtStartExtMtlAmt(Long pmtStartExtMtlAmt) {
		this.pmtStartExtMtlAmt = pmtStartExtMtlAmt;
	}
	public Long getPmtStartExtLabAmt() {
		return pmtStartExtLabAmt;
	}
	public void setPmtStartExtLabAmt(Long pmtStartExtLabAmt) {
		this.pmtStartExtLabAmt = pmtStartExtLabAmt;
	}
	public String getPmtProdComm() {
		return pmtProdComm;
	}
	public void setPmtProdComm(String pmtProdComm) {
		this.pmtProdComm = pmtProdComm;
	}
	public String getPmtUnitMeasureStock() {
		return pmtUnitMeasureStock;
	}
	public void setPmtUnitMeasureStock(String pmtUnitMeasureStock) {
		this.pmtUnitMeasureStock = pmtUnitMeasureStock;
	}
	public String getPmtUnitMeasurePurch() {
		return pmtUnitMeasurePurch;
	}
	public void setPmtUnitMeasurePurch(String pmtUnitMeasurePurch) {
		this.pmtUnitMeasurePurch = pmtUnitMeasurePurch;
	}
	public Date getPmtDateOfCost() {
		return pmtDateOfCost;
	}
	public void setPmtDateOfCost(Date pmtDateOfCost) {
		this.pmtDateOfCost = pmtDateOfCost;
	}
	public String getPmtHtsCat() {
		return pmtHtsCat;
	}
	public void setPmtHtsCat(String pmtHtsCat) {
		this.pmtHtsCat = pmtHtsCat;
	}
	public String getPmtEccnCode() {
		return pmtEccnCode;
	}
	public void setPmtEccnCode(String pmtEccnCode) {
		this.pmtEccnCode = pmtEccnCode;
	}
	public String getPmtMaterialDescCd() {
		return pmtMaterialDescCd;
	}
	public void setPmtMaterialDescCd(String pmtMaterialDescCd) {
		this.pmtMaterialDescCd = pmtMaterialDescCd;
	}
	public String getPmtLowLevelCode() {
		return pmtLowLevelCode;
	}
	public void setPmtLowLevelCode(String pmtLowLevelCode) {
		this.pmtLowLevelCode = pmtLowLevelCode;
	}
	public String getPmtCountryOfOrigin1() {
		return pmtCountryOfOrigin1;
	}
	public void setPmtCountryOfOrigin1(String pmtCountryOfOrigin1) {
		this.pmtCountryOfOrigin1 = pmtCountryOfOrigin1;
	}
	public String getPmtCountryOfOrigin2() {
		return pmtCountryOfOrigin2;
	}
	public void setPmtCountryOfOrigin2(String pmtCountryOfOrigin2) {
		this.pmtCountryOfOrigin2 = pmtCountryOfOrigin2;
	}
	public String getPmtMstrRtgNum() {
		return pmtMstrRtgNum;
	}
	public void setPmtMstrRtgNum(String pmtMstrRtgNum) {
		this.pmtMstrRtgNum = pmtMstrRtgNum;
	}
	public String getPmtEngrChangeNumber1() {
		return pmtEngrChangeNumber1;
	}
	public void setPmtEngrChangeNumber1(String pmtEngrChangeNumber1) {
		this.pmtEngrChangeNumber1 = pmtEngrChangeNumber1;
	}
	public String getPmtMaterialChangeNo() {
		return pmtMaterialChangeNo;
	}
	public void setPmtMaterialChangeNo(String pmtMaterialChangeNo) {
		this.pmtMaterialChangeNo = pmtMaterialChangeNo;
	}
	public String getPmtEngrChangeNumber2() {
		return pmtEngrChangeNumber2;
	}
	public void setPmtEngrChangeNumber2(String pmtEngrChangeNumber2) {
		this.pmtEngrChangeNumber2 = pmtEngrChangeNumber2;
	}
	public String getPmtEngrChangeNumber3() {
		return pmtEngrChangeNumber3;
	}
	public void setPmtEngrChangeNumber3(String pmtEngrChangeNumber3) {
		this.pmtEngrChangeNumber3 = pmtEngrChangeNumber3;
	}
	public Date getPmtEngrChangeDate1() {
		return pmtEngrChangeDate1;
	}
	public void setPmtEngrChangeDate1(Date pmtEngrChangeDate1) {
		this.pmtEngrChangeDate1 = pmtEngrChangeDate1;
	}
	public Date getPmtEngrChangeDate2() {
		return pmtEngrChangeDate2;
	}
	public void setPmtEngrChangeDate2(Date pmtEngrChangeDate2) {
		this.pmtEngrChangeDate2 = pmtEngrChangeDate2;
	}
	public Date getPmtEngrChangeDate3() {
		return pmtEngrChangeDate3;
	}
	public void setPmtEngrChangeDate3(Date pmtEngrChangeDate3) {
		this.pmtEngrChangeDate3 = pmtEngrChangeDate3;
	}
	public String getPmtEngrChangeInit1() {
		return pmtEngrChangeInit1;
	}
	public void setPmtEngrChangeInit1(String pmtEngrChangeInit1) {
		this.pmtEngrChangeInit1 = pmtEngrChangeInit1;
	}
	public String getPmtEngrChangeInit2() {
		return pmtEngrChangeInit2;
	}
	public void setPmtEngrChangeInit2(String pmtEngrChangeInit2) {
		this.pmtEngrChangeInit2 = pmtEngrChangeInit2;
	}
	public String getPmtEngrChangeInit3() {
		return pmtEngrChangeInit3;
	}
	public void setPmtEngrChangeInit3(String pmtEngrChangeInit3) {
		this.pmtEngrChangeInit3 = pmtEngrChangeInit3;
	}
	public String getPmtStatusCategory() {
		return pmtStatusCategory;
	}
	public void setPmtStatusCategory(String pmtStatusCategory) {
		this.pmtStatusCategory = pmtStatusCategory;
	}
	public String getPmtEngrChgDisp() {
		return pmtEngrChgDisp;
	}
	public void setPmtEngrChgDisp(String pmtEngrChgDisp) {
		this.pmtEngrChgDisp = pmtEngrChgDisp;
	}
	public String getPmtCadDrawing() {
		return pmtCadDrawing;
	}
	public void setPmtCadDrawing(String pmtCadDrawing) {
		this.pmtCadDrawing = pmtCadDrawing;
	}
	public Long getPmtAssyRecCount() {
		return pmtAssyRecCount;
	}
	public void setPmtAssyRecCount(Long pmtAssyRecCount) {
		this.pmtAssyRecCount = pmtAssyRecCount;
	}
	public Long getPmtWhereuseRecCount() {
		return pmtWhereuseRecCount;
	}
	public void setPmtWhereuseRecCount(Long pmtWhereuseRecCount) {
		this.pmtWhereuseRecCount = pmtWhereuseRecCount;
	}
	public Long getPmtRoutingRecCount() {
		return pmtRoutingRecCount;
	}
	public void setPmtRoutingRecCount(Long pmtRoutingRecCount) {
		this.pmtRoutingRecCount = pmtRoutingRecCount;
	}
	public String getPmtOrdPolicyCode() {
		return pmtOrdPolicyCode;
	}
	public void setPmtOrdPolicyCode(String pmtOrdPolicyCode) {
		this.pmtOrdPolicyCode = pmtOrdPolicyCode;
	}
	public String getMdscGeneral() {
		return mdscGeneral;
	}
	public void setMdscGeneral(String mdscGeneral) {
		this.mdscGeneral = mdscGeneral;
	}
	public String getSpecific() {
		return specific;
	}
	public void setSpecific(String specific) {
		this.specific = specific;
	}
	
	
	@Override
	public String toString() {
		return "PartMasterData1 [pmtPartNumber=" + pmtPartNumber + ", pmtConsignedAccount=" + pmtConsignedAccount
				+ ", pmtRespCode=" + pmtRespCode + ", pmtDrawingNumber=" + pmtDrawingNumber + ", pmtAccountNumber="
				+ pmtAccountNumber + ", pmtDateLastActive=" + pmtDateLastActive + ", pmtDateOfLastRecpt="
				+ pmtDateOfLastRecpt + ", pmtLastPhyInvDate=" + pmtLastPhyInvDate + ", pmtDescription=" + pmtDescription
				+ ", pmtLeadTime=" + pmtLeadTime + ", pmtEconomicOq=" + pmtEconomicOq + ", pmtVendorPrimary="
				+ pmtVendorPrimary + ", pmtYtdUseProduction=" + pmtYtdUseProduction + ", pmtLastYearsUsage="
				+ pmtLastYearsUsage + ", pmtStatusCode=" + pmtStatusCode + ", pmtDateCreated=" + pmtDateCreated
				+ ", pmtTpoCostMaterial=" + pmtTpoCostMaterial + ", pmtTpoCostLabor=" + pmtTpoCostLabor
				+ ", pmtTpoStdLabHours=" + pmtTpoStdLabHours + ", pmtRplCostMtl=" + pmtRplCostMtl + ", pmtRplCostLab="
				+ pmtRplCostLab + ", pmtRplCostOvhd=" + pmtRplCostOvhd + ", pmtPriceFactorCode=" + pmtPriceFactorCode
				+ ", pmtStandardOq=" + pmtStandardOq + ", pmtSvcListPrice=" + pmtSvcListPrice + ", pmtPartRevalueFlag="
				+ pmtPartRevalueFlag + ", pmtCompRevalueFlag=" + pmtCompRevalueFlag + ", pmtSvcNotAvailCode="
				+ pmtSvcNotAvailCode + ", pmtPartsClassCode=" + pmtPartsClassCode + ", pmtPartsCatalogCode="
				+ pmtPartsCatalogCode + ", pmtLyrCostMtl=" + pmtLyrCostMtl + ", pmtLyrCostLab=" + pmtLyrCostLab
				+ ", pmtActNoOfPieces=" + pmtActNoOfPieces + ", pmtSize=" + pmtSize + ", pmtStdCostMaterial="
				+ pmtStdCostMaterial + ", pmtStdCostLabor=" + pmtStdCostLabor + ", pmtStdLaborHours=" + pmtStdLaborHours
				+ ", pmtStdCostNoValue=" + pmtStdCostNoValue + ", pmtStartExtMtlAmt=" + pmtStartExtMtlAmt
				+ ", pmtStartExtLabAmt=" + pmtStartExtLabAmt + ", pmtProdComm=" + pmtProdComm + ", pmtUnitMeasureStock="
				+ pmtUnitMeasureStock + ", pmtUnitMeasurePurch=" + pmtUnitMeasurePurch + ", pmtDateOfCost="
				+ pmtDateOfCost + ", pmtHtsCat=" + pmtHtsCat + ", pmtEccnCode=" + pmtEccnCode + ", pmtMaterialDescCd="
				+ pmtMaterialDescCd + ", pmtLowLevelCode=" + pmtLowLevelCode + ", pmtCountryOfOrigin1="
				+ pmtCountryOfOrigin1 + ", pmtCountryOfOrigin2=" + pmtCountryOfOrigin2 + ", pmtMstrRtgNum="
				+ pmtMstrRtgNum + ", pmtEngrChangeNumber1=" + pmtEngrChangeNumber1 + ", pmtMaterialChangeNo="
				+ pmtMaterialChangeNo + ", pmtEngrChangeNumber2=" + pmtEngrChangeNumber2 + ", pmtEngrChangeNumber3="
				+ pmtEngrChangeNumber3 + ", pmtEngrChangeDate1=" + pmtEngrChangeDate1 + ", pmtEngrChangeDate2="
				+ pmtEngrChangeDate2 + ", pmtEngrChangeDate3=" + pmtEngrChangeDate3 + ", pmtEngrChangeInit1="
				+ pmtEngrChangeInit1 + ", pmtEngrChangeInit2=" + pmtEngrChangeInit2 + ", pmtEngrChangeInit3="
				+ pmtEngrChangeInit3 + ", pmtStatusCategory=" + pmtStatusCategory + ", pmtEngrChgDisp=" + pmtEngrChgDisp
				+ ", pmtCadDrawing=" + pmtCadDrawing + ", pmtAssyRecCount=" + pmtAssyRecCount + ", pmtWhereuseRecCount="
				+ pmtWhereuseRecCount + ", pmtRoutingRecCount=" + pmtRoutingRecCount + ", pmtOrdPolicyCode="
				+ pmtOrdPolicyCode + ", mdscGeneral=" + mdscGeneral + ", specific=" + specific + "]";
	}
	
	
	
	
	
	

	

 }
