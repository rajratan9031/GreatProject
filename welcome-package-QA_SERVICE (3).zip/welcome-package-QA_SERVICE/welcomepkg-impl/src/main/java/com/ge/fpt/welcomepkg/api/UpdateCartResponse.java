/**
 * 
 */
package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author 204060632
 *
 */
@XmlRootElement
public class UpdateCartResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7834542015060808647L;

	/**
	 * 
	 */
	public UpdateCartResponse() {
		// TODO Auto-generated constructor stub
	}
	
	private int totalCartCount;
	private int updateCount;
	
	private List<RSPCartData> addedItems;
	
	private String message;

	/**
	 * @return the totalCartCount
	 */
	public int getTotalCartCount() {
		return totalCartCount;
	}

	/**
	 * @param totalCartCount the totalCartCount to set
	 */
	public void setTotalCartCount(int totalCartCount) {
		this.totalCartCount = totalCartCount;
	}

	/**
	 * @return the updateCount
	 */
	public int getUpdateCount() {
		return updateCount;
	}

	/**
	 * @param updateCount the updateCount to set
	 */
	public void setUpdateCount(int updateCount) {
		this.updateCount = updateCount;
	}

	/**
	 * @return the addedItems
	 */
	public List<RSPCartData> getAddedItems() {
		return addedItems;
	}

	/**
	 * @param addedItems the addedItems to set
	 */
	public void setAddedItems(List<RSPCartData> addedItems) {
		this.addedItems = addedItems;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

}
