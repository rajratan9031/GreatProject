package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;

public class PlantData implements Serializable {

	private static final long serialVersionUID = -5579178977980989818L;
	
	private String plantId;
	private String plantName;
	private String plantLocation;
	private String cPDunsId;	
	private String region;
	private String state;
	private String country;
	private String plantPhone;
	private String plantEmail;
	private String plantPrevOutageDate;
	private String plantNextOutageDate;
	private String plantZip;
	private String plantFax;
	
	public String getPlantZip() {
		return plantZip;
	}
	public void setPlantZip(String plantZip) {
		this.plantZip = plantZip;
	}
	public String getPlantFax() {
		return plantFax;
	}
	public void setPlantFax(String plantFax) {
		this.plantFax = plantFax;
	}
	
	public String getcPDunsId() {
		return cPDunsId;
	}
	public void setcPDunsId(String cPDunsId) {
		this.cPDunsId = cPDunsId;
	}
	public String getPlantPhone() {
		return plantPhone;
	}
	public void setPlantPhone(String plantPhone) {
		this.plantPhone = plantPhone;
	}
	public String getPlantEmail() {
		return plantEmail;
	}
	public void setPlantEmail(String plantEmail) {
		this.plantEmail = plantEmail;
	}

	
	public String getPlantId() {
		return plantId;
	}
	public void setPlantId(String plantId) {
		this.plantId = plantId;
	}
	public String getPlantName() {
		return plantName;
	}
	public void setPlantName(String plantName) {
		this.plantName = plantName;
	}
	public String getPlantLocation() {
		return plantLocation;
	}
	public void setPlantLocation(String plantLocation) {
		this.plantLocation = plantLocation;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getPlantPrevOutageDate() {
		return plantPrevOutageDate;
	}
	public void setPlantPrevOutageDate(String plantPrevOutageDate) {
		this.plantPrevOutageDate = plantPrevOutageDate;
	}
	public String getPlantNextOutageDate() {
		return plantNextOutageDate;
	}
	public void setPlantNextOutageDate(String plantNextOutageDate) {
		this.plantNextOutageDate = plantNextOutageDate;
	}
/*	
	public PlantData(String plantId,String plantName,String plantLocation,String cPDunsId,String region,String state,String country,
			String plantPhone,String plantEmail,String plantPrevOutageDate,String plantNextOutageDate){
		this.plantId=plantId;
		this.plantName=plantName;
		this.plantLocation=plantLocation;
		this.cPDunsId=cPDunsId;
		this.region=region;
		this.state=state;
		this.country=country;
		this.plantEmail=plantEmail;
		this.plantPhone=plantPhone;
		this.plantPrevOutageDate=plantPrevOutageDate;
		this.plantNextOutageDate=plantNextOutageDate;
	}*/
	@Override
	public String toString() {
		return "PlantData [plantId=" + plantId + ", plantName=" + plantName + ", plantLocation=" + plantLocation
				+ ", CPDunsId=" + cPDunsId + ", region=" + region + ", state=" + state + ", country=" + country
				+ ", plantPhone=" + plantPhone + ", plantEmail=" + plantEmail + ", plantPrevOutageDate="
				+ plantPrevOutageDate + ", plantNextOutageDate=" + plantNextOutageDate + "]";
	}	

}
