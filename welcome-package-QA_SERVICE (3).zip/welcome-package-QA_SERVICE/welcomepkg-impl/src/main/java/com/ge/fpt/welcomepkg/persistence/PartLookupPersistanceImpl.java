package com.ge.fpt.welcomepkg.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.fpt.welcomepkg.api.ChannelData;
import com.ge.fpt.welcomepkg.api.Inventory;
import com.ge.fpt.welcomepkg.api.PartLookupData;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;

public class PartLookupPersistanceImpl implements IPartLookupPersistance{
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory
			.getLogger(PartLookupPersistanceImpl.class);
	
	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;

	/**
	 * Data source for the JDBC
	 */
	DataSource dataSource;

	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;

	NamedParameterJdbcTemplate namedParamTemplate;

	/**
	 * @return the dataSource
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}

	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate = new NamedParameterJdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}
	
	public  List<PartLookupData> getPartCrossRefData(PartLookupData part){
		String partNumber = part.getPartNumber();
		String sql = "select a.item_number as PART_NUMBER,b.description PART_DESCRIPTION from "+
					"(select crossref item_number from ddsafm.ODS_SQT_CROSS_REF_MV where segment1 = ? "+  
					"union select segment1 item_number from ddsafm.ODS_SQT_CROSS_REF_MV where crossref = ? "+  
					"union select a.crossref item_number from ddsafm.ODS_SQT_CROSS_REF_MV a "+
					"inner join ddsafm.ODS_SQT_CROSS_REF_MV b on a.segment1 = b.segment1 and b.crossref = ? "+
					"where a.crossref != ?) a "+
					"left outer join "+
					"(select * from(select item_number,description,row_number() "+ 
					"over(partition by item_number order by item_number) rownumber from fptods.sqt_part_info_t_master) "+
					"where rownumber = 1) b on a.item_number = b.item_number";
		
		List<PartLookupData> partData=this.jdbcTemplate.query(sql, new Object[] { partNumber,partNumber,partNumber,partNumber},
				new PartLookupMapper());
		
		return partData;
	}
	
	private static final class PartLookupMapper implements RowMapper<PartLookupData> {
		public PartLookupMapper() {
		}

		@Override
		public PartLookupData mapRow(ResultSet rs, int rowNum) throws SQLException {
			PartLookupData result = new PartLookupData();
			result.setPartNumber(rs.getString("PART_NUMBER"));
			result.setPartDescription(rs.getString("PART_DESCRIPTION"));
			return result;

		}
	}
}
