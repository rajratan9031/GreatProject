package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;

public class CustomerLinkMasterModel implements Serializable {
	private static final long serialVersionUID = 1L;

	
	private String linkCustomerName;  //Added by sujeet
	private String custId;
	
	
	
	public CustomerLinkMasterModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	public CustomerLinkMasterModel(String linkCustomerName, String custId) {
		super();
		this.linkCustomerName = linkCustomerName;
		this.custId = custId;
	}



	public String getLinkCustomerName() {
		return linkCustomerName;
	}
	public void setLinkCustomerName(String linkCustomerName) {
		this.linkCustomerName = linkCustomerName;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	@Override
	public String toString() {
		return "CustomerLinkMasterModel [linkCustomerName=" + linkCustomerName + ", custId=" + custId + "]";
	} 
	
	

}
