package com.ge.fpt.welcomepkg.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.fpt.welcomepkg.api.PartDataComponents;
import com.ge.fpt.welcomepkg.api.PartDetailsOfComponent;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;

public class PartDetailsOfComponentImpl implements IPartDetailsOfComponent{
	@SuppressWarnings("javadoc")
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory.getLogger(BomsPersistenceImpl.class);
	
	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;

	/**
	 * Data source for the JDBC
	 */
	DataSource dataSource;

	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;
	
	NamedParameterJdbcTemplate namedParamTemplate;

	/**
	 * @return the dataSource
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}

	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate = new NamedParameterJdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}
	
	public List<PartDetailsOfComponent> getPartDetailsForComponent(Map componentData){
		//change sqt_part_info_t to sqt_part_info_t_master
		String sql= "select max(b.description) as description, a.parent_item_number part_number, "+
				"a.component_item_number component_item_number , (select max(description) from fptods.sqt_part_info_t_master where item_number = ?) as component_description from DDSAFM.ods_subassembly_bom_t a inner join fptods.sqt_part_info_t_master b "+
				"on parent_item_number =item_number where component_item_number = ? "+
				"group by a.parent_item_number,a.component_item_number";
		List<PartDetailsOfComponent> partDetailsOfComponent=this.jdbcTemplate.query(sql, new Object[] {componentData.get("componentNumber"),componentData.get("componentNumber")},
				new PartDetailsOfComponentMapper());
		return partDetailsOfComponent;
	}
	
	private static final class PartDetailsOfComponentMapper implements RowMapper<PartDetailsOfComponent> {
		public PartDetailsOfComponentMapper() {
		}

		@Override
		public PartDetailsOfComponent mapRow(ResultSet rs, int rowNum) throws SQLException {
			PartDetailsOfComponent result = new PartDetailsOfComponent();
			result.setPartId(rs.getString("part_number"));
			result.setPartDesc(rs.getString("description"));
			result.setComponentId(rs.getString("component_item_number"));
			result.setComponentDescription(rs.getString("component_description"));
			return result;
		}
	}
}
