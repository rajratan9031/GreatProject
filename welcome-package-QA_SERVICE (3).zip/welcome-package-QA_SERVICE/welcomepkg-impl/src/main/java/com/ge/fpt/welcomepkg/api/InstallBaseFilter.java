package com.ge.fpt.welcomepkg.api;

public class InstallBaseFilter {
private String productModel;
private String channel;
private String productCode;
private String country;
private String state;
public String getProductModel() {
	return productModel;
}
public void setProductModel(String productModel) {
	this.productModel = productModel;
}
public String getChannel() {
	return channel;
}
public void setChannel(String channel) {
	this.channel = channel;
}
public String getProductCode() {
	return productCode;
}
public void setProductCode(String productCode) {
	this.productCode = productCode;
}
public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country = country;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
@Override
public String toString() {
	return "InstallBaseFilter [productModel=" + productModel + ", channel=" + channel + ", productCode=" + productCode
			+ ", country=" + country + ", state=" + state + "]";
}

}
