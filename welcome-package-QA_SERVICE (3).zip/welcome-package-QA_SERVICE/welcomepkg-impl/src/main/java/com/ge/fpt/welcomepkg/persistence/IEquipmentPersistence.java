/*
 * Copyright (c) 2013 GE Global Research. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Global Research. The software may be used and/or copied only
 * with the written permission of GE Global Research or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.fpt.welcomepkg.persistence;

import java.util.List;
import java.util.Map;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ge.fpt.welcomepkg.api.CPPromotionalCart;
import com.ge.fpt.welcomepkg.api.CustomerDataManagmentMaster;
import com.ge.fpt.welcomepkg.api.DigitalBOMData;
import com.ge.fpt.welcomepkg.api.DigitalEquipmentData;
import com.ge.fpt.welcomepkg.api.EquipLookupData;
import com.ge.fpt.welcomepkg.api.OrderEquipment;
import com.ge.fpt.welcomepkg.api.PromotionalCart;
import com.ge.fpt.welcomepkg.api.RSPCartData;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.api.UpdateCartResponse;
import com.ge.fpt.welcomepkg.api.VKReportData;

/**
 * @author 212414241
 * 
 */
public interface IEquipmentPersistence {

	/**
	 * Get Equipment by Sales Order Number and Rec Source
	 * 
	 * @param salesOrder
	 *            sales order number
	 * @param recSource
	 *            record source
	 * @return list of equipment, filtered by order and record source
	 */
	@Transactional(propagation = Propagation.REQUIRED)
	List<OrderEquipment> getEquipmentBySalesOrderAndRecSource(String salesOrder, String recSource, String engineeredValve,String dunsNumber);
	
	@Transactional(propagation = Propagation.REQUIRED)
	List<OrderEquipment> getEquipmentBySalesOrderSerialNumberAndRecSource(EquipLookupData[] lookupData);
	
	/**
	 * Save equipment data to RSP cart
	 * 
	 * @param sso SSO of the cart owner
	 * @param saveData the equipment data to save
	 * @return total count of items in cart
	 */

	@Transactional(propagation = Propagation.REQUIRED)
	UpdateCartResponse saveToRSPCart(String sso, OrderEquipment[] saveData);
	
	@Transactional(propagation = Propagation.REQUIRED)
	int getCartCount(String sso);
	
	@Transactional(propagation = Propagation.REQUIRED)
	UpdateCartResponse deleteFromRSPCart(String sso, Long[] valveInfoIds);
	
	@Transactional(propagation = Propagation.REQUIRED)
	List<RSPCartData> getCurrentRSPCart(String sso);
	
	@Transactional(propagation = Propagation.REQUIRED)
	int checkCartExists(String sso, String cartName);
	
	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo saveCart(String sso, String cartName);
	
	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo loadCart(String sso, String cartName);
	
	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo deleteSavedCart(String sso, String cartName);
	
	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo deleteAllFromRSPCart(String sso);
	
	@Transactional(propagation = Propagation.REQUIRED)
	List<String> getSavedCarts(String sso);
	
	@Transactional(propagation = Propagation.REQUIRED)
	List<OrderEquipment> getEquipmentBySn(EquipLookupData lookupData);
	
	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo updateEquipment( String sso,OrderEquipment orderEquipment);
	
	@Transactional(propagation = Propagation.REQUIRED)
	List<VKReportData> getVKReportData(String sso, String region, String currency);
	
	@Transactional(propagation = Propagation.REQUIRED)
	List<OrderEquipment> getBlanketEquipment(String col, String val,String dunsNumber);

	@Transactional(propagation = Propagation.REQUIRED)
	UpdateCartResponse addToPromotionalCart(String sso, PromotionalCart saveData);
	
	@Transactional(propagation = Propagation.REQUIRED)
	boolean checkUpgradeExist(String sso, PromotionalCart saveData);
	
	@Transactional(propagation = Propagation.REQUIRED)
	 StatusInfo saveCartStatus(String sso, Map<String,String> data);
	
	@Transactional(propagation = Propagation.REQUIRED)
	 List<String> getCartStatus(String sso, Map<String,String> data);
	
	@Transactional(propagation = Propagation.REQUIRED)
	 int getCartPC(String sso, Map<String,String> data);
	
	@Transactional(propagation = Propagation.REQUIRED)
	String saveEquipmentDigital(DigitalEquipmentData digitalEquipmentData);

	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo saveBomDigital(String valveInfoId, List<DigitalBOMData> digitalBomData);
	
	//added by sujeet
	@Transactional(propagation = Propagation.REQUIRED)
	List<OrderEquipment> getCustomerDataManagement(String customerId);
	
	@Transactional(propagation = Propagation.REQUIRED)
	List<OrderEquipment> getCustomerForSerial();
	//end by sujeet
	
	//Channel Partner - Add to promotional Cart - Neha
	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo addToPromotionalCartCP(String sso, String promotionalCartLevel, CPPromotionalCart data);
	
	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo addToPromotionalCartSMI(String sso, CPPromotionalCart data);
	
}
