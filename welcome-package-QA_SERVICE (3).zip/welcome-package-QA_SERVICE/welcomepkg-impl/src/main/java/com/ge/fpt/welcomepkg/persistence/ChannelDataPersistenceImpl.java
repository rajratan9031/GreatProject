package com.ge.fpt.welcomepkg.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.fpt.welcomepkg.api.ChannelData;
import com.ge.fpt.welcomepkg.api.CpLocationInfo;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;


public class ChannelDataPersistenceImpl implements IChannelDataPersistence {
	
	@SuppressWarnings("javadoc")
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory.getLogger(ChannelDataPersistenceImpl.class);
	
	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;

	/**
	 * Data source for the JDBC
	 */
	DataSource dataSource;

	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;
	
	NamedParameterJdbcTemplate namedParamTemplate;

	/**
	 * @return the dataSource
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}

	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate = new NamedParameterJdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}
	
	public String getFilterClause(ChannelData channelData){
		String filter="";
		List<String> conditions = new ArrayList<String>();
		if(channelData!=null){
			if(channelData.getUserName()!=null && !channelData.getUserName().isEmpty()){
				conditions.add(" UPPER(USER_NAME) LIKE '%' || :userName || '%'");
				}
			if(channelData.getEmail()!=null && !channelData.getEmail().isEmpty()){
				conditions.add(" UPPER(EMAIL) LIKE '%' || :email || '%'");
			}
			if(channelData.getSso()!=null && !channelData.getSso().isEmpty()){
				conditions.add(" UPPER(SSO_ID) LIKE '%' || :sso || '%'");
			}
			if(channelData.getPhone()!=null && !channelData.getPhone().isEmpty()){
				conditions.add(" UPPER(PHONE) LIKE '%' || :phone || '%'");
			}
			if(channelData.getCompany()!=null && !channelData.getCompany().isEmpty()){
				conditions.add(" UPPER(COMPANY) LIKE '%' || :company || '%'");
			}
			if(channelData.getCompanyOwner()!=null && !channelData.getCompanyOwner().isEmpty()){
				conditions.add(" UPPER(COMPANY_OWNERS) LIKE '%' || :companyOwner || '%'");
			}
			if(channelData.getGeBusiness()!=null && !channelData.getGeBusiness().isEmpty()){
				conditions.add(" UPPER(GE_BUSINESS) LIKE '%' || :geBusiness || '%'");
			}
			if(channelData.getRegion()!=null && !channelData.getRegion().isEmpty()){
				conditions.add(" UPPER(REGION) LIKE '%' || :region || '%'");
			}
			if(channelData.getCountry()!=null && !channelData.getCountry().isEmpty()){
				conditions.add(" UPPER(COUNTRY) LIKE '%' || :country || '%'");
			}
			if(channelData.getState()!=null && !channelData.getState().isEmpty()){
				conditions.add(" UPPER(STATE) LIKE '%' || :state || '%'");
			}
			if(channelData.getProductLine()!=null && !channelData.getProductLine().isEmpty()){
				conditions.add(" UPPER(PRODUCT_LINES) LIKE '%' || :productLine || '%'");
			}
			if(channelData.getDuns()!=null && !channelData.getDuns().isEmpty()){
				conditions.add(" UPPER(DUNS_NUMBER) LIKE '%' || :duns || '%'");
			}
		}
		if (conditions.size() > 0) {
			String condStr = "";
			
			for (int i = 0; i < conditions.size(); i++) {
				condStr += ( " AND " + conditions.get(i));
			}
			
			filter = condStr;
		}
		return filter;
	}
	
	public  Map<String, String> setFilterParams(ChannelData channelData){
		Map<String, String> result = new HashMap<String, String>();
		result.put("userName", channelData.getUserName() == null ? "" : channelData.getUserName().toUpperCase());
		result.put("email", channelData.getEmail() == null ? "" : channelData.getEmail().toUpperCase());
		result.put("sso", channelData.getSso() == null ? "" : channelData.getSso().toUpperCase());
		result.put("phone", channelData.getPhone() == null ? "" : channelData.getPhone().toUpperCase());
		result.put("company", channelData.getCompany() == null ? "" : channelData.getCompany().toUpperCase());
		result.put("companyOwner", channelData.getCompanyOwner() == null ? "" : channelData.getCompanyOwner().toUpperCase());
		result.put("geBusiness", channelData.getGeBusiness() == null ? "" : channelData.getGeBusiness().toUpperCase());
		result.put("region", channelData.getRegion() == null ? "" : channelData.getRegion().toUpperCase());
		result.put("country", channelData.getCountry() == null ? "" : channelData.getCountry().toUpperCase());
		result.put("state", channelData.getState() == null ? "" : channelData.getState().toUpperCase());
		result.put("productLine", channelData.getProductLine() == null ? "" : channelData.getProductLine().toUpperCase());
		result.put("duns", channelData.getDuns() == null ? "" : channelData.getDuns().toUpperCase());
		
		return result;
	}
	
	public  int getChannelDataCount(ChannelData channelData){
		String sql="select count(*) from ddsafm.sqt_channel_sso a where 1=1 ";
		MapSqlParameterSource parameters = new MapSqlParameterSource(setFilterParams(channelData));
		if(channelData!=null){
			String filter=getFilterClause(channelData);
			
			sql=sql+filter;
			
		}
		return this.namedParamTemplate.queryForInt(sql, parameters);
	}
	public List<ChannelData> getChannelData(int pageNo,int rowsPerPage,ChannelData channelData){
		String sql= "select * from (select rownum as rnum, a.* from ddsafm.sqt_channel_sso a where 1=1";
		MapSqlParameterSource parameters = new MapSqlParameterSource(setFilterParams(channelData));
		
		if(channelData!=null){
			String filter=getFilterClause(channelData);
			sql=sql+filter;
		}
		sql+=")";
		if (rowsPerPage > 0) {
			int lowerLimit = rowsPerPage * pageNo;
			int upperLimit = lowerLimit + rowsPerPage;
			
			String pageLimitClause= " where rnum >:lowerLimit AND rnum <=:upperLimit";
			parameters.addValue("lowerLimit", lowerLimit);
			parameters.addValue("upperLimit", upperLimit);
			sql+=pageLimitClause;
		}
		
		List<ChannelData> result=this.namedParamTemplate.query(sql, parameters,
				new ChannelMapper());
		return result;
	}
	
	
	public List<ChannelData> channelDataBySso(String sso){
		logger.info("SSO in channelDataBySso---->>>"+sso.trim());
		String upperCaseSSO = sso.toUpperCase();
		logger.info("sso id in upper case :"+ upperCaseSSO);
		String sql= "select * from ddsafm.sqt_channel_sso where UPPER(sso_id)=? ";
		logger.info("SSO in upper case:"+upperCaseSSO);
		List<ChannelData> channelData=this.jdbcTemplate.query(sql, new Object[] { upperCaseSSO},
				new ChannelMapper());
		for (ChannelData channelData2 : channelData) {
			logger.info("Duns_Number --- "+channelData2.getDuns());
			}
		String output=channelData.isEmpty()?"no Data":"haveData"  ;
		logger.info("Duns_Number --- " +output );
		return channelData;
	}

	public StatusInfo saveChannelData(ChannelData channelData){
		StatusInfo statusinfo= new StatusInfo();
		String sql= "select count(sso_id) from ddsafm.sqt_channel_sso where UPPER(sso_id)= ?";
		String saveSql="";
		int count=this.jdbcTemplate.queryForInt(sql, new Object[]{channelData.getSso().toUpperCase()});
		if(count>0){
			 saveSql="update ddsafm.sqt_channel_sso set Email=?,phone=?,company=?,company_owners=?,ge_business=?, "+
					" region= ?,country=?, state=?,product_lines=?,duns_number=? where UPPER(user_name)=? and UPPER(sso_id)=? "	;	
		  Object[] param={channelData.getEmail(),
				  		  channelData.getPhone(),
				  		  channelData.getCompany(),
				  		  channelData.getCompanyOwner(),
				  		  channelData.getGeBusiness(),
				  		  channelData.getRegion(),
				  		  channelData.getCountry(),
				  		  channelData.getState(),
				  		  channelData.getProductLine(),
				  		  channelData.getDuns(),
				  		  channelData.getUserName().toUpperCase(),
				  		  channelData.getSso().toUpperCase()
				 };
		  this.jdbcTemplate.update(saveSql, param);
		}else{
			saveSql= "insert into ddsafm.sqt_channel_sso values (?,?,?,?,?,?,?,?,?,?,?,?,?)";
			Object[] param={
						channelData.getUserName(),
						channelData.getEmail(),
						channelData.getSso(),
						channelData.getPhone(),
			  		  	channelData.getCompany(),
			  		  	channelData.getCompanyOwner(),
			  		  	channelData.getGeBusiness(),
			  		  	channelData.getRegion(),
			  		  	channelData.getCountryState(),
			  		  	channelData.getProductLine(),
			  		  	channelData.getDuns(),
			  		  	channelData.getCountry(),
			  		  	channelData.getState()
			   };
			this.jdbcTemplate.update(saveSql, param);
		}
		
			
		 statusinfo.setStatusCode(1);
		 statusinfo.setStatusMessage("Data saved Successfully");
		 return statusinfo;
	}
	
	public List getCompanyFromDuns(String duns){
		String sql="select distinct Company_name from fptods.SQT_REGION_DUNS where duns_code like :duns" ;
		MapSqlParameterSource paramMap=new MapSqlParameterSource();
		paramMap.addValue("duns", "%"+duns+"%");
		return this.namedParamTemplate.queryForList(sql, paramMap);
	}
	
	public List<CpLocationInfo> getLocationData(int pageNo, int rowsPerpage, CpLocationInfo cpLocationInfo){
		logger.info("inside getLocationDataFromDuns() for duns:"+cpLocationInfo);
		if(!cpLocationInfo.getIsAdmin()){
			if(null==cpLocationInfo.getDuns() || ("").equals(cpLocationInfo.getDuns()))
				return null;
		}
			String sql ="select * from (select rownum as rnum, a.* from FPTODS.CP_LOCATION_DETAILS a where 1=1" ;
		List<CpLocationInfo> result = null;
		try{
		MapSqlParameterSource parameters = new MapSqlParameterSource(setFilterLocationParams(cpLocationInfo));
		if(cpLocationInfo!=null){
			String filter=getFilterClauseLocation(cpLocationInfo);
			sql=sql+filter;
		}
		sql+=")";
		if (rowsPerpage > 0) {
			int lowerLimit = rowsPerpage * pageNo;
			int upperLimit = lowerLimit + rowsPerpage;
			
			String pageLimitClause= " where rnum >:lowerLimit AND rnum <=:upperLimit";
			parameters.addValue("lowerLimit", lowerLimit);
			parameters.addValue("upperLimit", upperLimit);
			sql+=pageLimitClause;
		}
		result =this.namedParamTemplate.query(sql, parameters,
				new CpLocationMapper());
		logger.info("got the CP location objects"+result.toString());
		}catch(Exception e){
			logger.error("unable to fetch the locations"+e.getLocalizedMessage());
		}
		return result;
	}
	
	private static final class ChannelMapper implements RowMapper<ChannelData> {
		public ChannelMapper() {
		}

		@Override
		public ChannelData mapRow(ResultSet rs, int rowNum) throws SQLException {
			ChannelData result = new ChannelData();
			result.setUserName(rs.getString("USER_NAME"));
			result.setSso(rs.getString("SSO_ID"));
			result.setEmail(rs.getString("EMAIL"));
			result.setPhone(rs.getString("PHONE"));
			result.setCompany(rs.getString("COMPANY"));
			result.setCompanyOwner(rs.getString("COMPANY_OWNERS"));
			result.setGeBusiness(rs.getString("GE_BUSINESS"));
			result.setRegion(rs.getString("REGION"));
			result.setCountryState(rs.getString("COUNTRY_STATE"));
			result.setProductLine(rs.getString("PRODUCT_LINES"));
			result.setDuns(rs.getString("DUNS_NUMBER"));
			result.setCountry(rs.getString("COUNTRY"));
			result.setState(rs.getString("STATE"));
			return result;
		}
	}

	private static final class CpLocationMapper implements RowMapper<CpLocationInfo> {
		public CpLocationMapper() {
		}

		@Override
		public CpLocationInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
			CpLocationInfo result = new CpLocationInfo();
			result.setEmail(rs.getString("CP_EMAIL"));
			result.setPhoneNumber(rs.getString("CP_PHONE"));
			result.setDuns(rs.getString("DUNS_NUMBER"));
			result.setLocation(rs.getString("CP_LOCATION"));
			result.setCpId(rs.getLong("CP_LOC_ID"));
			result.setFax(rs.getString("CP_FAX"));
			return result;
		}
	}
	@Override
	public StatusInfo savecpLocationData(CpLocationInfo cpLocationInfo) {
		StatusInfo statusinfo= new StatusInfo();
			String saveSql="";
			logger.info("saving the CP location:"+cpLocationInfo);
			    try{
				if(null!=cpLocationInfo.getCpId()&& 0!=cpLocationInfo.getCpId()){
					Object[] param={cpLocationInfo.getEmail(),
					  		  cpLocationInfo.getPhoneNumber(),
					  		  cpLocationInfo.getLocation(),
					  		cpLocationInfo.getFax(),
					  		cpLocationInfo.getCpId()
					 };
					logger.info("updating the location details"+cpLocationInfo);
					if(!checkIsLocationexists(cpLocationInfo)){
					 saveSql="update FPTODS.CP_LOCATION_DETAILS set cp_email=?,cp_phone=?,cp_location=?, cp_fax=? where cp_loc_id=?"	;
					 this.jdbcTemplate.update(saveSql, param);
					}else{
						logger.info("Location"+cpLocationInfo.getLocation().toUpperCase()+ "is already exists");
						statusinfo.setStatusMessage("Location  "+cpLocationInfo.getLocation().toUpperCase()+"  is already exists");
						return statusinfo;
					}
				}else{
					Object[] param={
							cpLocationInfo.getDuns(),
							 cpLocationInfo.getLocation(),
							cpLocationInfo.getEmail(),
					  		  cpLocationInfo.getPhoneNumber(),
					  		cpLocationInfo.getFax()
					 };
					if(!checkIsLocationexists(cpLocationInfo)){
						logger.info("inserting new location"+cpLocationInfo);
					saveSql= "insert into FPTODS.CP_LOCATION_DETAILS (DUNS_NUMBER,CP_LOCATION,CP_EMAIL,CP_PHONE,CP_FAX) values (?,?,?,?,?)";
					this.jdbcTemplate.update(saveSql, param);
					}else{
						logger.info("Location"+cpLocationInfo.getLocation().toUpperCase()+ "is already exists");
						statusinfo.setStatusMessage("Location  "+cpLocationInfo.getLocation().toUpperCase()+"  is already exists");
						return statusinfo;
					}
				}
				 statusinfo.setStatusCode(1);
				 logger.info("Data saved successfully");
				 statusinfo.setStatusMessage("Data saved Successfully");
				 }catch(Exception e){
			logger.error("Unable to saved the Channel partner location"+e.getLocalizedMessage());
			statusinfo.setStatusCode(500);
			statusinfo.setStatusMessage("Failed to save the Location");
		}
				 return statusinfo;
		}

	@Override
	public int getCpLocationDataCount(CpLocationInfo cpLocationInfo) {
		logger.info("inside getCpLocationDataCount():"+cpLocationInfo);
		if(!cpLocationInfo.getIsAdmin()){
			if(null==cpLocationInfo.getDuns() || ("").equals(cpLocationInfo.getDuns()))
				return 0;
		}
		String sql="select count(*) from fptods.cp_location_details a where 1=1 ";
		MapSqlParameterSource parameters = new MapSqlParameterSource(setFilterLocationParams(cpLocationInfo));
		if(cpLocationInfo!=null){
			String filter=getFilterClauseLocation(cpLocationInfo);
			sql=sql+filter;
		}
		return this.namedParamTemplate.queryForInt(sql, parameters);
	}

	private Map<String, String> setFilterLocationParams(CpLocationInfo cpLocationInfo) {
		Map<String, String> result = new HashMap<String, String>();
		result.put("email", cpLocationInfo.getEmail() == null ? "" : cpLocationInfo.getEmail().toUpperCase());
		result.put("phoneNumber", cpLocationInfo.getPhoneNumber() == null ? "" : cpLocationInfo.getPhoneNumber().toUpperCase());
		result.put("location", cpLocationInfo.getLocation() == null ? "" : cpLocationInfo.getLocation().toUpperCase());
		result.put("fax", cpLocationInfo.getFax() == null ? "" : cpLocationInfo.getFax().toUpperCase());
		result.put("duns", cpLocationInfo.getDuns()== null ? "" : cpLocationInfo.getDuns().toUpperCase());
		return result;
	}

	private String getFilterClauseLocation(CpLocationInfo cpLocationInfo) {

		String filter="";
		List<String> conditions = new ArrayList<String>();
		if(cpLocationInfo!=null){
			if(cpLocationInfo.getEmail()!=null && !cpLocationInfo.getEmail().isEmpty()){
				conditions.add(" UPPER(CP_EMAIL) LIKE '%' || :email || '%'");
			}
			if(cpLocationInfo.getPhoneNumber()!=null && !cpLocationInfo.getPhoneNumber().isEmpty()){
				conditions.add(" UPPER(CP_PHONE) LIKE '%' || :phoneNumber || '%'");
			}
		if(cpLocationInfo.getLocation()!=null && !cpLocationInfo.getLocation().isEmpty()){
				conditions.add(" UPPER(CP_LOCATION) LIKE '%' || :location || '%'");
			}
		if(cpLocationInfo.getFax()!=null && !cpLocationInfo.getFax().isEmpty()){
			conditions.add(" UPPER(CP_FAX) LIKE '%' || :fax || '%'");
		}
		if(cpLocationInfo.getDuns()!=null && !cpLocationInfo.getDuns().isEmpty()){
			conditions.add(" UPPER(duns_number) LIKE '%' || :duns || '%'");
		}
		
		}
		if (conditions.size() > 0) {
			String condStr = "";
			
			for (int i = 0; i < conditions.size(); i++) {
				condStr += ( " AND " + conditions.get(i));
			}
			
			filter = condStr;
		}
		return filter;
	
	}

/*delete functionality TBD*/
	@Override
	public StatusInfo deleteCpLocation(CpLocationInfo cpLocationInfo) {
		logger.info("inside location delete:"+cpLocationInfo);
		StatusInfo result= new StatusInfo();
		String sql = "delete from FPTODS.CP_LOCATION_DETAILS where cp_loc_id=?";
		this.jdbcTemplate.update(sql, new Object[] { cpLocationInfo.getCpId()});
		result.setStatusCode(1);
		result.setStatusMessage("location deleted successfully");
		return result;
	}
	
	private boolean checkIsLocationexists(CpLocationInfo cpLocationInfo){
		boolean result = false;
		String sql = "select * from FPTODS.CP_LOCATION_DETAILS where cp_location=? and duns_number=? and CP_EMAIL=? and CP_PHONE=? and CP_FAX=? ";
		List<CpLocationInfo> cpLocInfoList = new ArrayList<>();
	 cpLocInfoList= this.jdbcTemplate.query(sql, new Object[]{cpLocationInfo.getLocation(),
			 cpLocationInfo.getDuns(),
			 cpLocationInfo.getEmail(),
			 cpLocationInfo.getPhoneNumber(),
			 cpLocationInfo.getFax()
			 }, new CpLocationMapper());
	if(cpLocInfoList.size()!=0)
		result = true; 
		return result;
		
	}
}
