/*
 * Copyright (c) 2013 GE Global Research. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Global Research. The software may be used and/or copied only
 * with the written permission of GE Global Research or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.fpt.welcomepkg.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.fpt.welcomepkg.api.BomConfigurator;
import com.ge.fpt.welcomepkg.api.EquipmentBoms;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;

/**
 * @author 212414241
 * 
 */
public class BomsPersistenceImpl implements IBomsPersistence {
	@SuppressWarnings("javadoc")
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory.getLogger(BomsPersistenceImpl.class);
	
	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;

	/**
	 * Data source for the JDBC
	 */
	DataSource dataSource;

	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;
	
	NamedParameterJdbcTemplate namedParamTemplate;

	/**
	 * @return the dataSource
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}

	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate = new NamedParameterJdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	/*
	 * Propagation.REQUIRED is used. (non-Javadoc)
	 * 
	 * @see com.ge.ast.platform.dsp.jpa.AstPersistence#getpatientById(java.lang.
	 * String)
	 */
	@SuppressWarnings("nls")
	@Override
	public List<EquipmentBoms> getBomBySerialNumberAndRecSource(String serialNumber, String recSource, String region, String currency) {
		try {
			// Revised query per Ravi
			/*String sql = "select a.*, " +
					     "(select List_price from ddsafm.ods_sqt_price_look_up b " +
					     "where (b.to_currency = ? or b.to_currency is null) " +
					     "and (b.region = ? or b.region is null) " +
					     "and a.COMPONENT_ITEM_NUMBER = b.part_number " +
					     "and a.spares_indicator in ('C','W', 'I', '1', '2') ) LP " +
					     "from ddsafm.ODS_SQT_BY_SALES_ORDER_V a " +
					     "where  SERIAL_NUMBER = ?";*/	
			/*String sql="select a.*, b.List_price as LP, c.lead_time as LT,c.ORG_RANK,c.org_name "+
						"from ddsafm.ODS_SQT_BY_SALES_ORDER_V a "+
						"left outer join ddsafm.ods_sqt_price_look_up b "+
						"on a.COMPONENT_ITEM_NUMBER = b.part_number and a.spares_indicator in ('C','W', 'I', '1', '2') "+
						"left outer join ddsafm.LEAD_TIME_LOOKUP c "+
						"on a.COMPONENT_ITEM_NUMBER = c.item_number "+
						"where a.rec_source = ? "+
						"and a.SERIAL_NUMBER = ? "+
						"and (b.to_currency = ? or b.to_currency is null) "+
						"and (b.region = ? or b.region is null) "+
						"and (c.region = ? or c.region is null)";*/
			
			/*String sql="select distinct a.*, b.List_price as LP, c.lead_time as LT, c.ORG_RANK, c.org_name "+
					   "from ddsafm.ODS_SQT_BY_SALES_ORDER_V a "+
			           "left outer join ddsafm.ods_sqt_price_look_up_MV b "+
			           "on a.COMPONENT_ITEM_NUMBER = b.part_number "+
			           "and a.spares_indicator in ('C', 'W', 'I', '1', '2') "+
			           "left outer join ddsafm.LEAD_TIME_LOOKUP_MV c "+
			           "on a.COMPONENT_ITEM_NUMBER = c.item_number "+
			    	"where a.SERIAL_NUMBER = ? "+
					"and (b.to_currency = ? or b.to_currency is null) "+
					"and (b.region = ? or b.region is null) "+
					"and (c.region = ? or c.region is null) ";*/
			//updated query for cross ref part data
			String sql = "select m.*,n.crossref cross_ref from "+
					"(select distinct a.*, b.List_price as LP, c.lead_time as LT, c.ORG_RANK, c.org_name "+ 
					"from ddsafm.ODS_SQT_BY_SALES_ORDER_V a left outer join "+
					"ddsafm.ods_sqt_price_look_up_MV b on a.COMPONENT_ITEM_NUMBER = b.part_number "+ 
					"and a.spares_indicator in ('C', 'W', 'I', '1', '2') left outer join ddsafm.LEAD_TIME_LOOKUP_MV c "+ 
					"on a.COMPONENT_ITEM_NUMBER = c.item_number where a.SERIAL_NUMBER = ? "+
					"and (b.to_currency = ? or b.to_currency is null) and (b.region = ? or b.region is null) "+ 
					"and (c.region = ? or c.region is null) and rec_source= ?) m left outer join "+
					"( "+
					"select part_no,LISTAGG(cross_ref_part, ' , ')  WITHIN GROUP (ORDER BY cross_ref_part) as crossref from( "+ 
					"select segment1 part_no,crossref cross_ref_part from ddsafm.ODS_SQT_CROSS_REF_MV where crossref is not null "+  
					"union "+
					"select crossref part_no,segment1 cross_ref_part from ddsafm.ODS_SQT_CROSS_REF_MV where crossref is not null "+  
					"union "+
					"select b.crossref part_no,a.crossref cross_ref_part from ddsafm.ODS_SQT_CROSS_REF_MV a "+ 
					"inner join ddsafm.ODS_SQT_CROSS_REF_MV b on a.segment1 = b.segment1 "+
					"where a.crossref != b.crossref and a.crossref is not null and b.crossref is not null "+
					") group by part_no)n on m.component_item_number = n.part_no ";
			

			
			logger.info("BOMS query start: " + new Date().toString());
			List<EquipmentBoms> boms = this.jdbcTemplate.query(sql, new Object[] { serialNumber,currency,region,region,recSource },
					new BomsMapper());
			logger.info("BOMS query finish: " + new Date().toString());
			return boms;
		} catch (Exception ex) {
			logger.error("Get BOMS By SSO error:", ex);
		}
		return null;
	}

	
	public List<String>getPartNo(String recSource,String serialNo,String partNo){
		 List<String> result=new ArrayList<String>();
		String sql="select distinct item_number from sqt_part_info_t "
				+ "where upper(item_number) like upper('%"+partNo+"%') and rec_source= ?  and "
				+" item_number not in(select item_number from ods_serial_updates_t where source=? and serial_number=?)";
		List<Map<String, Object>> rows=this.jdbcTemplate.queryForList(sql,new Object[] {recSource,recSource,serialNo});
		for(Map<String, Object> row : rows){
			result.add((String) row.get("ITEM_NUMBER"));
		}
		
		 
		return result;
	}
	
	public List<String> getPartDesc(String recsource,String partNo){
		List<String> result= new ArrayList<String>();
		List<Map<String,Object>> resultList=null;
		String sqlPartDesc="";
		 sqlPartDesc="select Max(distinct description) as description from fptods.sqt_part_info_t_master"
				+ " where item_number =? ";
		resultList=this.jdbcTemplate.queryForList(sqlPartDesc,new Object[] {partNo});
		for(Map<String, Object>  item : resultList){
			result.add((String) item.get("DESCRIPTION"));
		}
		
		return result;
	}
	
	
	public StatusInfo deletePartHeader( String sso,EquipmentBoms equipmentBoms) {
		  StatusInfo result= new StatusInfo();
		String cntSql="select count(*) from ddsafm.ods_serial_updates_t where 1=1 "+
					  "and serial_number=? and  source=? and item_number=? ";
		int cnt=this.jdbcTemplate.queryForInt(cntSql,new Object[] {equipmentBoms.getSerialNumber(),equipmentBoms.getRecSource(),equipmentBoms.getComponentItemNumber()});
		logger.info("part count while delete: " + cnt);
		 String insertSql= "insert into ddsafm.ods_serial_updates_t "
					+ "(SERIAL_UPD_ID,SERIAL_NUMBER,SOURCE,ITEM_NUMBER,QUANTITY,SOURCE_SYSTEM,LOAD_DATE,CHANGED,BOM_CHANGES_ID,ITEM_DESC,UPDATED_BY,UPDATED_DATE) values"
					+ "((select Max(SERIAL_UPD_ID) from ddsafm.ods_serial_updates_t)+1,?,?,?,?,?,sysdate,?,?,?,?,sysdate)";
			 Object[] params = {
					 equipmentBoms.getSerialNumber(),
					 equipmentBoms.getRecSource(),
					 equipmentBoms.getComponentItemNumber(),
					 "-"+equipmentBoms.getQuantity(),
					 equipmentBoms.getSourceSystem(),
					 "Y",
					 "",
					 equipmentBoms.getComponentDescription(),
					 sso	
				};
			 this.jdbcTemplate.update(insertSql,params);	 
		
		  result.setStatusCode(0);
			 result.setStatusMessage("Part Deleted successfully.");
			  
			  return result;
		
	}
	
	public StatusInfo savePartHeader(String serialNumber, String recSource,String sso,EquipmentBoms[] equipmentBoms) {
		  StatusInfo result= new StatusInfo();
		  String insertSql= "insert into ddsafm.ods_serial_updates_t  "
				+"(serial_upd_id,serial_number,source,item_number,quantity,source_system,load_date, "
				+ "changed,bom_changes_id,updated_by,updated_date,item_desc) values" 
		  		+ "((SELECT MAX( serial_upd_id ) FROM ddsafm.ods_serial_updates_t C) +1,?,?,?,?,?,sysdate,?,?,?,sysdate,?)";
		  String insertPartsql=" insert into ddsafm.sqt_part_info_t "
				+ "(part_info_id,rec_source,item_number,description,legacy_part_number,spares_indicator,stock_type,lead_time,list_price,creation_date,last_update_date,product_line,updated_by) "  
		  		+ "values ((SELECT MAX( part_info_id ) FROM ddsafm.sqt_part_info_t C) +1,?,?,?,?,?,?,0,0,sysdate,sysdate,'',? )";
		  String insertLegacyPartNoSql="select CASE when exists (select 1 "+
                           "from fptods.sqt_part_info_t_master "+
                          "where item_number = ?) Then "+
                          "(select Max(legacy_part_number) "+
                          "from fptods.sqt_part_info_t_master "+
                          "where item_number = ?) else '' end from dual";
		  String insertSpareIndicatorSql="select CASE when exists (select 1 "+
                  "from fptods.sqt_part_info_t_master "+
                 "where item_number = ?) Then "+
                 "(select Max(Spares_indicator) "+
                 "from fptods.sqt_part_info_t_master "+
                 "where item_number = ?) else 'C' end from dual";
		  String insertStockTypeSql="select CASE when exists (select 1 "+
                  "from fptods.sqt_part_info_t_master "+
                 "where item_number = ?) Then "+
                 "(select Max(Stock_type) "+
                 "from fptods.sqt_part_info_t_master "+
                 "where item_number = ?) else 'PARTS' end from dual";
		  
		  String partCountsql="select count(item_number)  from ddsafm.sqt_part_info_t where item_number=? and rec_source=?   ";
		  String serialCountSql="select count(serial_number)  from ddsafm.ods_serial_updates_t where serial_number=? and  source=?  and item_number=?";
		  String updateSql="update ddsafm.ods_serial_updates_t set quantity=?, updated_by=? ,updated_Date=sysdate "+
					" where serial_number=? and  source=? and item_number=? "; 
		  for(int i=0;i<equipmentBoms.length;i++) {
			  Object[] params = {
					  serialNumber,
					  recSource,
					  equipmentBoms[i].getComponentItemNumber(),
					  equipmentBoms[i].getQuantity(),
					  equipmentBoms[i].getSourceSystem(),
					  "Y",
					  "",
					  sso,
					  equipmentBoms[i].getComponentDescription()
			  };
			  this.jdbcTemplate.update(insertSql,params);	 
			String legacyPartNumber = this.jdbcTemplate.queryForObject(
					insertLegacyPartNoSql,
					new Object[] { equipmentBoms[i].getComponentItemNumber(),
							equipmentBoms[i].getComponentItemNumber() },
					String.class);
			String spareIndicator = this.jdbcTemplate.queryForObject(
					insertSpareIndicatorSql,
					new Object[] { equipmentBoms[i].getComponentItemNumber(),
							equipmentBoms[i].getComponentItemNumber() },
					String.class);
			String stockType = this.jdbcTemplate.queryForObject(
					insertStockTypeSql,
					new Object[] { equipmentBoms[i].getComponentItemNumber(),
							equipmentBoms[i].getComponentItemNumber() },
					String.class);
  Object[] paramsPart= {
					  recSource,
					  equipmentBoms[i].getComponentItemNumber(),
					  equipmentBoms[i].getComponentDescription(),
					  legacyPartNumber,
					  spareIndicator,
					  stockType,
					  sso
			  };
			  int count=this.jdbcTemplate.queryForInt(partCountsql,new Object[]{equipmentBoms[i].getComponentItemNumber(),recSource});
				 if(count==0){
			  this.jdbcTemplate.update(insertPartsql,paramsPart);
				 }
		  }
		  result.setStatusCode(0);
			 result.setStatusMessage("Part inserted successfully.");
			  
			  return result;
	}
	
	public StatusInfo saveBomConfigurator( String sso,BomConfigurator bomConfigurator){
		logger.info("BOM Configurator"+bomConfigurator);
		StatusInfo result =new StatusInfo();
		String countSqt="select count(*)from ddsafm.ods_bom_changes_t where serial_number=? and source=?";
		int count=this.jdbcTemplate.queryForInt(countSqt,new Object[]{bomConfigurator.getSerialNumber(),bomConfigurator.getSource()});
		if(count>0){
			String updatesql="update ddsafm.ods_bom_changes_t set"
					+ " modified_user=?,modified_date=sysdate,short_reason=?,reason_remarks=?,"
					+ " finished_model_number=?,tag_number=?,temperature=?,capacity=?,asme_code_stamp=?,"
					+ " cdtp=?,back_pressure=?,service=?,spring_number_range=?,valve_type=?,modified_org=?"
					+ " where serial_number=? and source=? ";
			this.jdbcTemplate.update(updatesql, new Object[]{
					sso,
					bomConfigurator.getReason(),
					bomConfigurator.getRemark(),
					bomConfigurator.getFinishModelNumber(),
					bomConfigurator.getTagNumber(),
					bomConfigurator.getTemperature(),
					bomConfigurator.getCapacity(),
					bomConfigurator.getAsmeCodeStamp(),
					bomConfigurator.getCdtp(),
					bomConfigurator.getBackPressure(),
					bomConfigurator.getService(),
					bomConfigurator.getSpringNumberRange(),
					bomConfigurator.getValveType(),
					bomConfigurator.getModifiedOrg(),
					bomConfigurator.getSerialNumber(),
					bomConfigurator.getSource()
			});
			}else{
				
				String sql="select max(bom_changes_id)+1 from ddsafm.ods_bom_changes_t ";
				int countID =this.jdbcTemplate.queryForInt(sql);
				String insertSql="insert into ddsafm.ods_bom_changes_t"
						+ " (modified_user,modified_date,short_reason,reason_remarks,"
						+ " finished_model_number,tag_number,temperature,capacity,asme_code_stamp,"
						+ " cdtp,back_pressure,service,spring_number_range,valve_type,"
						+ " serial_number, source,bom_changes_id,modified_org) values (?,sysdate,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				this.jdbcTemplate.update(insertSql, new Object[]{
						sso,
						bomConfigurator.getReason(),
						bomConfigurator.getRemark(),
						bomConfigurator.getFinishModelNumber(),
						bomConfigurator.getTagNumber(),
						bomConfigurator.getTemperature(),
						bomConfigurator.getCapacity(),
						bomConfigurator.getAsmeCodeStamp(),
						bomConfigurator.getCdtp(),
						bomConfigurator.getBackPressure(),
						bomConfigurator.getService(),
						bomConfigurator.getSpringNumberRange(),
						bomConfigurator.getValveType(),
						bomConfigurator.getSerialNumber(),
						bomConfigurator.getSource(),
						countID,
						bomConfigurator.getModifiedOrg(),
				});
			}
		String updateModel="update ddsafm.sqt_valve_info_t set product_code=?,product_model=?,tag_number=?,description=? where"
				+ " serial_number=? and rec_source=?";
		this.jdbcTemplate.update(updateModel,new Object[]{
				bomConfigurator.getValveType(),
				bomConfigurator.getFinishModelNumber(),
				bomConfigurator.getTagNumber(),
				bomConfigurator.getValveDesc(),
				bomConfigurator.getSerialNumber(),
				bomConfigurator.getSource()
		});
		result.setStatusCode(0);
		 result.setStatusMessage("Data saved successfully.");
		  
		  return result;
	}
	
	public List<BomConfigurator> getBomConfigurator( String serialNumber,String recSource){
		String sql="select * from ddsafm.ods_bom_changes_t where serial_number=? and source=?";
		List<BomConfigurator> bomsConfig = this.jdbcTemplate.query(sql, new Object[] { serialNumber,recSource },
				new BomsConfigMapper());
		return bomsConfig;
	}
	
		
	private static final class BomsMapper implements RowMapper<EquipmentBoms> {
		public BomsMapper() {
		}

		@Override
		public EquipmentBoms mapRow(ResultSet rs, int rowNum) throws SQLException {
			EquipmentBoms result = new EquipmentBoms();

			result.setRecSource(rs.getString("REC_SOURCE")); //$NON-NLS-1$
			result.setSalesOrder(rs.getString("SALES_ORDER"));
			result.setSalesOrderLine(rs.getString("SALES_ORDER_LINE"));
			result.setCustomerPo(rs.getString("CUSTOMER_PO"));
			result.setSoldToCustomerName(rs.getString("SOLD_TO_CUSTOMER_NAME"));
			result.setSoldToCountry(rs.getString("SOLD_TO_COUNTRY"));
			result.setSoldToState(rs.getString("SOLD_TO_STATE"));
			result.setSoldToProvince(rs.getString("SOLD_TO_PROVINCE"));
			result.setSoldToCity(rs.getString("SOLD_TO_CITY"));
			result.setRepName(rs.getString("REP_NAME"));
			result.setOrderedItemNumber(rs.getString("ORDERED_ITEM_NUMBER"));
			result.setQuantityShipped(rs.getLong("QUANTITY_SHIPPED"));
			result.setUnitSellingPrice(rs.getDouble("UNIT_SELLING_PRICE"));
			result.setSerialNumber(rs.getString("SERIAL_NUMBER"));
			result.setValvePartNumber(rs.getString("VALVE_PART_NUMBER"));
			result.setValveDescription(rs.getString("VALVE_DESCRIPTION"));
			result.setTagNumber(rs.getString("TAG_NUMBER"));
			result.setSourceSystem(rs.getString("SOURCE_SYSTEM"));
			result.setComponentItemNumber(rs.getString("COMPONENT_ITEM_NUMBER"));
			result.setComponentDescription(rs.getString("COMPONENT_DESCRIPTION"));
			result.setLegacyPartNumber(rs.getString("LEGACY_PART_NUMBER"));
			result.setSparesIndicator(rs.getString("SPARES_INDICATOR"));
			result.setStockType(rs.getString("STOCK_TYPE"));
			result.setQuantity(rs.getInt("QUANTITY"));
			result.setListPrice(rs.getString("LP"));
			result.setLeadTime(rs.getLong("LT"));
			result.setSourceSystem(rs.getString("SOURCE_SYSTEM"));
			result.setListPriceLP(rs.getString("LP"));
			result.setActualShipDate(rs.getDate("ACTUAL_SHIP_DATE"));
			result.setUpdatedBy(rs.getString("UPDATED_BY"));
			result.setUpdatedDate(rs.getDate("UPDATED_DATE"));
			long qty = rs.getLong("QUANTITY");
			String desc = rs.getString("COMPONENT_DESCRIPTION");
			if(desc!=null){
			int descLength = rs.getString("COMPONENT_DESCRIPTION").length();
			if(descLength > 3){
			String first3char = desc.substring(0, 3);
			if(first3char.equals("(+)") && qty > 0){
			result.setColorValue("blue");
			}else if(first3char.equals("(+)") && qty < 0){
			result.setColorValue("red");
			}else{
			result.setColorValue("black");
			}
			}
			}else{
				result.setColorValue("black");	
			}
			result.setSubAssemItem(rs.getString("SUBASSM_TYPE"));
			result.setCrossRefData(rs.getString("CROSS_REF"));
						
			
//			try {
//				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //$NON-NLS-1$
//				Date actualShipDate = formatter.parse(rs.getString("ACTUAL_SHIP_DATE")); //$NON-NLS-1$
//				result.setActualShipDate(actualShipDate);
//
//			} catch (Exception e) {
//				logger.error("Boms Mapper: ", e); //$NON-NLS-1$
//			}
			return result;
		}
	}
	
	
	private static final class BomsConfigMapper implements RowMapper<BomConfigurator> {
		public BomsConfigMapper() {
		}

		@Override
		public BomConfigurator mapRow(ResultSet rs, int rowNum) throws SQLException {
			BomConfigurator result = new BomConfigurator();
			result.setSerialNumber(rs.getString("SERIAL_NUMBER"));
			result.setSource(rs.getString("SOURCE"));
			result.setModifiedUser(rs.getString("MODIFIED_USER"));
			result.setModifiedDate(rs.getDate("MODIFIED_DATE"));
			result.setReason(rs.getString("SHORT_REASON"));
			result.setRemark(rs.getString("REASON_REMARKS"));
			result.setFinishModelNumber(rs.getString("FINISHED_MODEL_NUMBER"));
			result.setTagNumber(rs.getString("TAG_NUMBER"));
			result.setTemperature(rs.getString("TEMPERATURE"));
			result.setCapacity(rs.getString("CAPACITY"));
			result.setAsmeCodeStamp(rs.getString("ASME_CODE_STAMP"));
			result.setCdtp(rs.getString("CDTP"));
			result.setBackPressure(rs.getString("BACK_PRESSURE"));
			result.setService(rs.getString("SERVICE"));
			result.setSpringNumberRange(rs.getString("SPRING_NUMBER_RANGE"));
			result.setValveType(rs.getString("VALVE_TYPE"));
			return result;
		}
	}
}
