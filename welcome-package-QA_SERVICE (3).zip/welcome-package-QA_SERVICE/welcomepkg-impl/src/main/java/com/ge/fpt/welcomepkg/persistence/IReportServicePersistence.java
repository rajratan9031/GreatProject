package com.ge.fpt.welcomepkg.persistence;

import java.util.List;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ge.fpt.welcomepkg.api.Report;
import com.ge.fpt.welcomepkg.api.ReportData;

public interface IReportServicePersistence {

	@Transactional(propagation = Propagation.REQUIRED)
	List<Report> getReportData(ReportData reportData,String sso);

	@Transactional(propagation = Propagation.REQUIRED)
	byte[] generateExcel(ReportData reportData,String sso);

	@Transactional(propagation = Propagation.REQUIRED)
	byte[] generatePdf(ReportData reportData,String sso);

}
