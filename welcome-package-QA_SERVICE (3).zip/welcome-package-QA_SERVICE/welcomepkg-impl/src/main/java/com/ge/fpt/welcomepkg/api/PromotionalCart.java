package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class PromotionalCart implements Serializable {

	private static final long serialVersionUID = 9031948384674999876L;
	
	public PromotionalCart() {
		
	}
	
	private String sso;
	private String upgradeId;
	private String upgradeName;
	private String optionId;
	private String optionName;
	private String optionDescription;
	private String couponCode;
	private List<UpgradeOptionDetails> partModel;
	private String partModelDescription;
	private String quantity;
	
	public String getPartModelDescription() {
		return partModelDescription;
	}
	public void setPartModelDescription(String partModelDescription) {
		this.partModelDescription = partModelDescription;
	}

	public List<UpgradeOptionDetails> getPartModel() {
		return partModel;
	}
	public void setPartModel(List<UpgradeOptionDetails> partModel) {
		this.partModel = partModel;
	}
	
	public String getSso() {
		return sso;
	}
	public void setSso(String sso) {
		this.sso = sso;
	}
	public String getUpgradeId() {
		return upgradeId;
	}
	public void setUpgradeId(String upgradeId) {
		this.upgradeId = upgradeId;
	}
	public String getUpgradeName() {
		return upgradeName;
	}
	public void setUpgradeName(String upgradeName) {
		this.upgradeName = upgradeName;
	}
	public String getOptionId() {
		return optionId;
	}
	public void setOptionId(String optionId) {
		this.optionId = optionId;
	}
	public String getOptionName() {
		return optionName;
	}
	public void setOptionName(String optionName) {
		this.optionName = optionName;
	}
	public String getOptionDescription() {
		return optionDescription;
	}
	public void setOptionDescription(String optionDescription) {
		this.optionDescription = optionDescription;
	}
	public String getCouponCode() {
		return couponCode;
	}
	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "PromotionalCart [sso=" + sso + ", upgradeId=" + upgradeId + ", upgradeName=" + upgradeName
				+ ", optionId=" + optionId + ", optionName=" + optionName + ", optionDescription=" + optionDescription
				+ ", couponCode=" + couponCode + ", partModel=" + partModel + ", quantity=" + quantity + "]";
	}
	
	
	
}
