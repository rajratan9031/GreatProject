package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;

public class ChannelData implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5579175197980496818L;
	
	
	private String userName;
	private String email;
	private String sso;
	private String phone;
	private String company;
	private String companyOwner;
	private String geBusiness;
	private String region;
	private String countryState;
	private String productLine;
	private String duns;
	private String country;
	private String state;
	
	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSso() {
		return sso;
	}

	public void setSso(String sso) {
		this.sso = sso;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getCompanyOwner() {
		return companyOwner;
	}

	public void setCompanyOwner(String companyOwner) {
		this.companyOwner = companyOwner;
	}

	public String getGeBusiness() {
		return geBusiness;
	}

	public void setGeBusiness(String geBusiness) {
		this.geBusiness = geBusiness;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getCountryState() {
		return countryState;
	}

	public void setCountryState(String countryState) {
		this.countryState = countryState;
	}

	public String getProductLine() {
		return productLine;
	}

	public void setProductLine(String productLine) {
		this.productLine = productLine;
	}

	public String getDuns() {
		return duns;
	}

	public void setDuns(String duns) {
		this.duns = duns;
	}

	public ChannelData() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ChannelData(String userName, String email, String sso, String phone,
			String company, String companyOwner, String geBusiness,
			String region, String countryState, String productLine, String duns,String country,String state ) {
		super();
		this.userName = userName;
		this.email = email;
		this.sso = sso;
		this.phone = phone;
		this.company = company;
		this.companyOwner = companyOwner;
		this.geBusiness = geBusiness;
		this.region = region;
		this.countryState = countryState;
		this.productLine = productLine;
		this.duns = duns;
		this.country=country;
		this.state=state;
	}
	
	

}
