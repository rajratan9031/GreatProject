package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;

public class Country implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String country_code;
	private String country;
	private String states;
	private String region;
	
	public Country() {
		super();
	}
	/**
	 * @param country_code
	 * @param country
	 * @param states
	 * @param region
	 */
	public Country(String country_code, String country, String states, String region) {
		super();
		this.country_code = country_code;
		this.country = country;
		this.states = states;
		this.region = region;
	}
	/**
	 * @return the country_code
	 */
	public String getCountry_code() {
		return country_code;
	}
	/**
	 * @param country_code the country_code to set
	 */
	public void setCountry_code(String country_code) {
		this.country_code = country_code;
	}
	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}
	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}
	/**
	 * @return the states
	 */
	public String getStates() {
		return states;
	}
	/**
	 * @param states the states to set
	 */
	public void setStates(String states) {
		this.states = states;
	}
	/**
	 * @return the region
	 */
	public String getRegion() {
		return region;
	}
	/**
	 * @param region the region to set
	 */
	public void setRegion(String region) {
		this.region = region;
	}
	
	
	
}
