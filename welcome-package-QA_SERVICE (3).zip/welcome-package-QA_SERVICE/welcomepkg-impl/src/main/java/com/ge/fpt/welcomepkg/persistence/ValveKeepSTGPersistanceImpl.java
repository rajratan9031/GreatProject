package com.ge.fpt.welcomepkg.persistence;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.fpt.welcomepkg.api.CartData;
import com.ge.fpt.welcomepkg.api.OrderInfo;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.api.VKCustOrderInfoSpeqT;
import com.ge.fpt.welcomepkg.api.VKOrderDocument;
import com.ge.fpt.welcomepkg.api.VKSTGReportData;
import com.ge.fpt.welcomepkg.api.ValveKeepPushData;
import com.ge.fpt.welcomepkg.api.ValvekeepUploadData;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;
import com.ge.fpt.welcomepkg.util.Constants;
import com.ge.fpt.welcomepkg.util.QueryConstants;

public class ValveKeepSTGPersistanceImpl implements IValveKeepSTGPersistance {
	@SuppressWarnings("javadoc")
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory.getLogger(ValveKeepSTGPersistanceImpl.class);

	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;

	/**
	 * Data source for the JDBC
	 */
	DataSource dataSource;

	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;

	NamedParameterJdbcTemplate namedParamTemplate;

	/**
	 * @return the dataSource
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}

	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate = new NamedParameterJdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	public List<VKSTGReportData> getVKSTGReportData(Map param) {

		try {
			List<CartData> cartData = new ArrayList<>();
			List<VKSTGReportData> result = new ArrayList<>();

			MapSqlParameterSource params = new MapSqlParameterSource();
			params.addValue("sso", param.get("loginUserId"));

			cartData = this.namedParamTemplate.query(QueryConstants.CART_DATA_QUERY, params,
					new SSOCartDocumentMapper());

			List<String> serialNumberList = new ArrayList<String>();
			List<String> salesOrderList = new ArrayList<String>();
			if (!cartData.isEmpty()) {
				for (int i = 0; i < cartData.size(); i++) {
					serialNumberList.add(cartData.get(i).getSerialNumber());
					salesOrderList.add(cartData.get(i).getSalesOrder());
				}
			}

			MapSqlParameterSource paramMap = new MapSqlParameterSource();
			paramMap.addValue("currency", param.get("currency"));
			paramMap.addValue("region", param.get("region"));
			paramMap.addValue("serialNumberList", serialNumberList);
			paramMap.addValue("salesOrderList", salesOrderList);

			try {
				result = this.namedParamTemplate.query(QueryConstants.CART_DETAILS_QUERY, paramMap,
						new VKReportDataMapper());
			} catch (Exception e) {
				logger.error("Exception when fetching VK data : " + e.getMessage());
			}
			return result;
		} catch (Exception ex) {
			logger.error("getVKReportData Query Error: SSO = '" + param.get("sso") + "';\n" + ex);
			return null;
		}
	}

	private static final class VKReportDataMapper implements RowMapper<VKSTGReportData> {
		public VKReportDataMapper() {
		}

		@Override
		public VKSTGReportData mapRow(ResultSet rs, int rowNum) throws SQLException {
			VKSTGReportData result = new VKSTGReportData();

			try {
				result.setSalesOrder(rs.getString("SALES_ORDER"));
				result.setOrderLineNumber(rs.getString("ORDER_LINE_NUMBER"));
				result.setEndUserCustName(rs.getString("END_USER_CUST_NAME"));
				result.setEndUserCustAddress(rs.getString("END_USER_CUST_ADDRESS"));
				result.setCity(rs.getString("CITY"));
				result.setState(rs.getString("STATE"));
				result.setProvince(rs.getString("PROVINCE"));
				result.setPostalCode(rs.getString("POSTAL_CODE"));
				result.setCountry(rs.getString("COUNTRY"));
				result.setShipSource(rs.getString("SHIP_SOURCE"));
				result.setSerialNumber(rs.getString("SERIAL_NUMBER"));
				result.setValveDescription(rs.getString("VALVE_DESCRIPTION"));
				result.setTagNumber(rs.getString("TAG_NUMBER"));
				result.setPartNumber(rs.getString("PART_NUMBER"));
				result.setPartDescription(rs.getString("PART_DESCRIPTION"));
				result.setSparesCode(rs.getString("SPARES_CODE"));
				result.setQty(rs.getString("QTY"));
				result.setListPrice(rs.getString("LIST_PRICE"));
				result.setLeadTime(rs.getString("LEAD_TIME"));
				result.setProductCode(rs.getString("PRODUCT_CODE"));

				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); //$NON-NLS-1$
				result.setShipDate(formatter.format(rs.getDate("SHIP_DATE")));

			} catch (Exception ex) {
				logger.error("VKReportDataMapper Mapper error: ", ex);
			}
			return result;
		}
	}

	@Override
	public StatusInfo valveKeepXMLDataSync(final List<String[]> xmlData) {
		StatusInfo response = new StatusInfo();
		try {
			this.jdbcTemplate.batchUpdate(QueryConstants.CUST_ORDER_INFO_QUERY, new BatchPreparedStatementSetter() {

				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					String[] rowValues = xmlData.get(i);
					ps.setString(1, rowValues[0]);
					ps.setString(2, rowValues[1]);
					ps.setString(3, rowValues[2]);
					ps.setString(4, rowValues[3]);
					ps.setString(5, rowValues[4]);
					ps.setString(6, rowValues[5]);
					ps.setString(7, rowValues[6]);
					ps.setString(8, rowValues[7]);
					ps.setString(9, rowValues[8]);
					ps.setString(10, rowValues[9]);
					ps.setString(11, rowValues[10]);
					ps.setString(12, rowValues[11]);
					ps.setString(13, rowValues[12]);
					ps.setString(14, rowValues[13]);
					ps.setString(15, rowValues[14]);
				}

				@Override
				public int getBatchSize() {
					return xmlData.size();
				}
			});
			response.setStatusCode(Constants.SUCCESS_STATUS_CODE);
			response.setStatusMessage("Valve-Keep Data Sync Successful.");
		} catch (Exception ex) {
			response.setStatusCode(Constants.FAIL_STATUS_CODE);
			response.setStatusMessage("Valve-Keep Data Sync Fail" + ex.getMessage());
			logger.error("Found Exception while Valve-Keep Data Sync : " + ex.getMessage());
		}
		return response;
	}

	@Override
	public StatusInfo saveFilePathValvekeep(ValvekeepUploadData vkUploadData) {

		StatusInfo statusinfo = new StatusInfo();
		try {

			Object[] param = { vkUploadData.getOrderNumber(), vkUploadData.getFileName(),
					vkUploadData.getProjectNumber(), vkUploadData.getBrand(), vkUploadData.getSso(),
					vkUploadData.getSso() };
			this.jdbcTemplate.update(QueryConstants.UPLOAD_FILE_VALVEKEEP_QUERY, param);
			statusinfo.setStatusCode(Constants.SUCCESS_STATUS_CODE);
			statusinfo.setStatusMessage("Data saved Successfully...");
		} catch (Exception e) {
			statusinfo.setStatusCode(Constants.FAIL_STATUS_CODE);
			statusinfo.setStatusMessage("Error while saving file info - Valvekeep...");
			logger.error("Error while saving file info - Valvekeep..." + e.getMessage());
		}
		return statusinfo;
	}

	@Override
	public List<ValveKeepPushData> getDocData(List<CartData> cartData) {

		List<ValveKeepPushData> vkData = new ArrayList<>();
		List<ValveKeepPushData> vkDataList = new ArrayList<>();

		for (CartData cartInfo : cartData) {
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("serialNumber", cartInfo.getSerialNumber());
			parameters.addValue("sourceSystem", QueryConstants.VK_PUSH_SOURCE_SYSTEM);
			vkData = this.namedParamTemplate.query(QueryConstants.ALFRESCO_SERIAL_NUMBER_DATA_QUERY, parameters,
					new DocumentMapper());
			vkDataList.addAll(vkData);
		}

		return vkDataList;

	}

	private static final class DocumentMapper implements RowMapper<ValveKeepPushData> {
		public DocumentMapper() {
		}

		@Override
		public ValveKeepPushData mapRow(ResultSet rs, int rowNum) throws SQLException {
			ValveKeepPushData result = new ValveKeepPushData();
			result.setSiteCode(rs.getString("SITE_CODE"));
			result.setTypeFlowProject(rs.getString("TYPE_FLOW_PROJECT"));
			result.setCategoryNuclearCommercial(rs.getString("CATEGORY_NUCLEAR_COMMERCIAL"));
			result.setSalesOrderNumber(rs.getString("SALES_ORDER_NUMBER"));
			result.setSalesOrderLineNumber(rs.getString("SALES_ORDER_LINE_NUMBER"));
			result.setProductionOrderNumber(rs.getString("PRODUCTION_ORDER_NUMBER"));
			result.setSerialNumber(rs.getString("SERIAL_NUMBER_SAP"));
			result.setDocumentType(rs.getString("DOCUMENT_TYPE"));
			result.setDocumentDescription(rs.getString("DOCUMENT_DESCRIPTION"));
			result.setFileName(rs.getString("FILE_NAME"));
			result.setDocLink(rs.getString("FILE_LINK"));
			result.setProjectNumber(rs.getString("PROJECT_NUMBER"));
			result.setDocumentLanguage(rs.getString("DOCUMENT_LANGUAGE"));
			result.setDocumentContentType(rs.getString("DOCUMENT_CONTENT_TYPE"));
			result.setSourceSystem(rs.getString("SOURCE_SYSTEM"));

			return result;

		}
	}

/*	@Override
	public List<VKOrderDocument> getVkOrderDocument(List<CartData> cartData) {
		List<VKOrderDocument> vkOrderDocumentList = new ArrayList<>();
		List<VKOrderDocument> vkOrderDocumentLst = new ArrayList<>();

		for (CartData cartInfo : cartData) {
			MapSqlParameterSource params = new MapSqlParameterSource();
			params.addValue("orderNumber", cartInfo.getSalesOrder());
			vkOrderDocumentLst = this.namedParamTemplate.query(QueryConstants.ORDER_DOCUMENT_DATA_QUERY, params,
					new vkOrderDocumentMapper());
			vkOrderDocumentList.addAll(vkOrderDocumentLst);
		}

		return vkOrderDocumentList;

	}*/

	private static final class vkOrderDocumentMapper implements RowMapper<VKOrderDocument> {
		public vkOrderDocumentMapper() {
		}

		@Override
		public VKOrderDocument mapRow(ResultSet rs, int rowNum) throws SQLException {
			VKOrderDocument result = new VKOrderDocument();
			result.setOrderNumber(rs.getString("ORDER_NUMBER"));
			result.setBrand(rs.getString("BRAND"));
			result.setCreatedBy(rs.getString("CREATED_BY"));
			result.setCreatedDate(rs.getString("CREATED_DATE"));
			result.setDocumentName(rs.getString("DOCUMENT_NAME"));
			result.setProjectNumber(rs.getString("PROJECT_NUMBER"));
			result.setUpdatedBy(rs.getString("UPDATED_BY"));
			result.setUpdatedDate(rs.getString("UPDATED_DATE"));

			return result;

		}
	}

	@Override
	public List<VKCustOrderInfoSpeqT> getVkCustOrderInfoSpeqT(List<CartData> vkCartData) {
		List<VKCustOrderInfoSpeqT> vkCustOrderInfoSpeqTList = new ArrayList<>();

		for (CartData valveKeepCartData : vkCartData) {
//			String orderNumber = valveKeepPushData.getSalesOrderNumber();
			MapSqlParameterSource param = new MapSqlParameterSource();
//			param.addValue("documentName", valveKeepPushData.getFileName());
			param.addValue("orderNumber", valveKeepCartData.getSalesOrder());
			List<VKCustOrderInfoSpeqT> vkCustOrderInfoSpeqTLst = this.namedParamTemplate
					.query(QueryConstants.CUST_ORDER_INFO_SPEQ_T_DATA_QUERY, param, new vkCustOrderInfoSpeqTMapper());
			/*
			 * for (VKCustOrderInfoSpeqT vKCustOrderInfoSpeqT : vkCustOrderInfoSpeqTLst) {
			 * vKCustOrderInfoSpeqT.setOrderNumber(orderNumber); }
			 */
			vkCustOrderInfoSpeqTList.addAll(vkCustOrderInfoSpeqTLst);
		}
		return vkCustOrderInfoSpeqTList;

	}

	private static final class vkCustOrderInfoSpeqTMapper implements RowMapper<VKCustOrderInfoSpeqT> {
		public vkCustOrderInfoSpeqTMapper() {
		}

		@Override
		public VKCustOrderInfoSpeqT mapRow(ResultSet rs, int rowNum) throws SQLException {
			VKCustOrderInfoSpeqT result = new VKCustOrderInfoSpeqT();
			result.setAttribute(rs.getString("ATTRIBUTE"));
			result.setCreatedBy(rs.getString("CREATED_BY"));
			result.setCreatedTime(rs.getTimestamp("CREATED_TIME"));
			result.setDocumentName(rs.getString("DOCUMENT_NAME"));
			result.setCustomer(rs.getString("CUSTOMER"));
			result.setCustPoNumber(rs.getString("CUST_PO_NUMBER"));
			result.setDunsNumber(rs.getString("DUNS_NUMBER"));
			result.setField(rs.getString("FIELD"));
			result.setGuli(rs.getString("GULI"));
			result.setOrderNumber(rs.getString("ORDER_NUMBER"));
			result.setProject(rs.getString("PROJECT"));
			result.setQuoteNumber(rs.getString("QUOTE_NUMBER"));
			result.setRec_source(rs.getString("REC_SOURCE"));
			result.setRfqNumber(rs.getString("RFQ_NUMBER"));
			result.setTagNumber(rs.getString("TAG_NUMBER"));
			result.setTransferredBy(rs.getString("TRANSFERRED_BY"));
			result.setTransferredDateTime(rs.getTimestamp("TRANSFERRED_DATETIME"));
			result.setValue(rs.getString("VALUE"));
			result.setValveTransferredUniqueKey(rs.getString("VALVETRANSERRED_UNIQUEKEY"));
			result.setXferd(rs.getString("XFERD"));
			result.setItemNumber(rs.getString("ITEM_NUMBER"));
			return result;

		}
	}

	@Override
	public List<CartData> getcartData(Map postData) {
		List<CartData> cartData = new ArrayList<>();

		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("sso", postData.get("loginUserId"));
		cartData = this.namedParamTemplate.query(QueryConstants.CART_INFO_QUERY, params, new SSOCartDocumentMapper());
		return cartData;
	}

	@Override
	public String getDocName(String documentName) {
		String docName = (String) jdbcTemplate.queryForObject(QueryConstants.GET_SO_FOR_DOC_VK_QUERY,
				new Object[] { documentName }, String.class);
		return docName;
	}
	
	@Override
	public String getDocmntName(String documentName) {
		String docName = (String) jdbcTemplate.queryForObject(QueryConstants.GET_SN_FOR_DOC_VK_QUERY,
				new Object[] { documentName }, String.class);
		return docName;
	}

	private static final class SSOCartDocumentMapper implements RowMapper<CartData> {
		public SSOCartDocumentMapper() {
		}

		@Override
		public CartData mapRow(ResultSet rs, int rowNum) throws SQLException {
			CartData result = new CartData();
			result.setSalesOrder(rs.getString("ORDER_NUMBER"));
			result.setRecSource(rs.getString("REC_SOURCE"));
			result.setSerialNumber(rs.getString("SERIAL_NUMBER"));
			result.setSso(rs.getString("SSO"));

			return result;

		}
	}

	@Override
	public StatusInfo removeDuplicateSOValveKeep(String orderNumber) {

		StatusInfo statusinfo = new StatusInfo();
		try {
			Object[] param = { orderNumber };
			this.jdbcTemplate.update(QueryConstants.DELETE_CUST_ORDER_INFO_SPEQT_QUERY, param);
			statusinfo.setStatusCode(Constants.SUCCESS_STATUS_CODE);
		} catch (Exception e) {
			statusinfo.setStatusCode(Constants.FAIL_STATUS_CODE);
			statusinfo.setStatusMessage("Error while removing duplicate SO - Valvekeep...");
			logger.error("Error while removing duplicate SO - Valvekeep..." + e.getMessage());
		}
		return statusinfo;

	}

	@Override
	public List<OrderInfo> validateSO(String orderNumber) {
		List<OrderInfo> orderInfo = new ArrayList<>();
		try {
			MapSqlParameterSource params = new MapSqlParameterSource();
			params.addValue("orderNumber", orderNumber);
			orderInfo = this.namedParamTemplate.query(QueryConstants.VALIDATE_SO_QUERY, params,
					new OrderInfoDocumentMapper());
		} catch (Exception e) {
			logger.error("Exception while validating SO - " + e.getMessage());
		}
		return orderInfo;
	}

	private static final class OrderInfoDocumentMapper implements RowMapper<OrderInfo> {
		public OrderInfoDocumentMapper() {
		}

		@Override
		public OrderInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
			OrderInfo result = new OrderInfo();
			result.setSalesOrder(rs.getString("SALES_ORDER"));
			return result;

		}
	}

}
