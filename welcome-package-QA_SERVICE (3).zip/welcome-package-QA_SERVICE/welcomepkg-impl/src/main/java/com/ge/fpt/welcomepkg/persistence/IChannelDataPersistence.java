package com.ge.fpt.welcomepkg.persistence;

import java.util.List;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ge.fpt.welcomepkg.api.ChannelData;
import com.ge.fpt.welcomepkg.api.CpLocationInfo;
import com.ge.fpt.welcomepkg.api.StatusInfo;

public interface IChannelDataPersistence {

	@Transactional(propagation=Propagation.REQUIRED)
	List<ChannelData> channelDataBySso(String sso);
	
	@Transactional(propagation=Propagation.REQUIRED)
	StatusInfo saveChannelData(ChannelData channelData);
	
	@Transactional(propagation=Propagation.REQUIRED)
	List<ChannelData> getChannelData(int pageNo,int rowperpage,ChannelData channelData);

	@Transactional(propagation=Propagation.REQUIRED)
	int getChannelDataCount(ChannelData channelData);
	
	@Transactional(propagation=Propagation.REQUIRED)
	List getCompanyFromDuns(String duns);
	
	@Transactional(propagation=Propagation.REQUIRED)
	List<CpLocationInfo> getLocationData(int pageNo,int rowperpage,CpLocationInfo locationInfo );
	
	@Transactional(propagation=Propagation.REQUIRED)
	StatusInfo savecpLocationData(CpLocationInfo cpLocationInfo);
	
	@Transactional(propagation=Propagation.REQUIRED)
	int getCpLocationDataCount(CpLocationInfo cpLocationInfo);
	
	@Transactional(propagation=Propagation.REQUIRED)
	StatusInfo deleteCpLocation(CpLocationInfo cpLocationInfo);
	
	

}