package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;

public class PartMasterData implements Serializable {

	private static final long serialVersionUID = -5579178977980989818L; 
	
	
	private String partNumber;
	private String pmtDescription;
	private String pmtDrawingNumber;
	private long rowNumber;
	
	
	
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	
	public String getPartNumber() {
		return partNumber;
	}
	
	public String getPmtDescription() {
		return pmtDescription;
	}
	public void setPmtDescription(String pmtDescription) {
		this.pmtDescription = pmtDescription;
	}
	public String getPmtDrawingNumber() {
		return pmtDrawingNumber;
	}
	public void setPmtDrawingNumber(String pmtDrawingNumber) {
		this.pmtDrawingNumber = pmtDrawingNumber;
	}
	public long getRowNumber() {
		return rowNumber;
	}
	public void setRowNumber(long rowNumber) {
		this.rowNumber = rowNumber;
	}
	@Override
	public String toString() {
		return "PartMasterData [partNumber=" + partNumber + ", pmtDescription=" + pmtDescription + ", pmtDrawingNumber="
				+ pmtDrawingNumber + ", rowNumber=" + rowNumber + "]";
	}
	
	
	

}
