package com.ge.fpt.welcomepkg.persistence;

import java.util.List;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ge.fpt.welcomepkg.api.AccountData;
import com.ge.fpt.welcomepkg.api.CustomerData;
import com.ge.fpt.welcomepkg.api.EquipmentBoms;
import com.ge.fpt.welcomepkg.api.ProductData;
import com.ge.fpt.welcomepkg.api.RecipData;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.api.TurboChargerDetail;

public interface IRCManagementPersistence {

	@Transactional(propagation = Propagation.REQUIRED)
	List<AccountData> getAccountData(int pageNo, int rowperpage, String sortCol, String sortOrder, AccountData accountData);

	@Transactional(propagation = Propagation.REQUIRED)
	int getAccountdatacount(AccountData accountData);

	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo saveAccountData(AccountData accountData);

	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo deleteAccountdata(AccountData accountData);

	@Transactional(propagation = Propagation.REQUIRED)
	List<CustomerData> getCustomerdata(int pageNo, int rowperpage, String sortCol, String sortOrder, CustomerData customerData);

	@Transactional(propagation = Propagation.REQUIRED)
	int getCustomerdatacount(CustomerData customerData);

	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo saveCustomerdata(CustomerData customerData);

	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo deleteCustomerdata(CustomerData customerData);	
	
	@Transactional(propagation = Propagation.REQUIRED)
	List<ProductData> getProductdata(int pageNo, int rowperpage, String sortCol, String sortOrder, ProductData productData);

	@Transactional(propagation = Propagation.REQUIRED)
	int getProductdatacount(ProductData productData);

	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo saveProductdata(ProductData productData);

	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo deleteProductdata(ProductData productData);

	@Transactional(propagation = Propagation.REQUIRED)
	List<RecipData> getRecipdata(int pageNo, int rowperpage, String sortCol, String sortOrder,String globalSearch,RecipData recipData);

	@Transactional(propagation = Propagation.REQUIRED)
	int getRecipDataCount(String globalSearch,RecipData recipData);
	
	@Transactional(propagation = Propagation.REQUIRED)
	List<EquipmentBoms> getRecipPartData(int pageNo, int rowperpage, RecipData recipData);

	@Transactional(propagation = Propagation.REQUIRED)
	int getRecipPartsDataCount(RecipData recipData);

	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo updateRecipdata(RecipData recipData);
	
	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo addRecipdata(RecipData recipData);

	@Transactional(propagation = Propagation.REQUIRED)
	List<String> getCustomerName(String customerName);

	@Transactional(propagation = Propagation.REQUIRED)
	List<String> getAccountManagerName(String accountManagerName);

	@Transactional(propagation = Propagation.REQUIRED)
	List<String> getProductName(String productName);	
	
	List<TurboChargerDetail> getTurboChargerValues();
//	@Transactional(propagation = Propagation.REQUIRED)
//	List<RecipData> getRecordsBySerialNumber(String sso, String serialNumber ) ;
//	
//	@Transactional(propagation = Propagation.REQUIRED)
//	StatusInfo UpdateRecipData(String sso,RecipData recipdata);
}
