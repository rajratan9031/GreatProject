/**
 * 
 */
package com.ge.fpt.welcomepkg.persistence;

import java.io.InputStream;
import java.util.List;

import javax.ws.rs.core.HttpHeaders;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ge.fpt.welcomepkg.api.DocumentDetails;
import com.ge.fpt.welcomepkg.api.OtherDocumentDetails;
import com.ge.fpt.welcomepkg.api.StatusInfo;

/**
 * @author 212670449
 *
 */
public interface IDocumentPersistence {

	List<DocumentDetails> getAllDocDetails(String serialNumber);

	List<OtherDocumentDetails> getAllDocDownloadDetails(String serialNumber);

	List<DocumentDetails> getDocumentsBySerialNumber(String serialNumber, List<String> docName);

	// code for Document Upload functionality
	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo documentFileUpload(InputStream file, HttpHeaders httpHeaders);

	
	StatusInfo saveFileForDataBook(String serialNumber, String docType, String documentDescription, String fileName,
			String fileLINK, String language);

	StatusInfo saveFileForOthers(String serialNumber, String docType, String documentDescription, String fileName,
			String fileLINK, String language);

	// other doc start
	List<OtherDocumentDetails> getAllOtherDocDetails(String serialNumber, List<String> docName, String docType);
	// other doc start

	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo uploadUpgradeDocument(InputStream file, HttpHeaders httpHeaders);

	StatusInfo saveUpgradeFile(String upgradeId, String optionId, String docContentType, String docType,
			String FileName, String fileLINK, String language, String sso);

	@Transactional(propagation = Propagation.REQUIRED)
	public List<DocumentDetails> getDocuments(String sourceSystem, String docType, String updatedDate);
}
