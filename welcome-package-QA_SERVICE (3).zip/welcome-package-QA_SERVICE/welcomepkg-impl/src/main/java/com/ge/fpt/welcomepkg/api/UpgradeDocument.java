package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;

public class UpgradeDocument implements Serializable{ 
	
	private static final long serialVersionUID = 1L;

	String documentId;
	String upgradeId;
	String optionId;
	String documentName;
	String documentType;
	String language;
	String documentUploadPath;
	
	public String getDocumentUploadPath() {
		return documentUploadPath;
	}
	public void setDocumentUploadPath(String documentUploadPath) {
		this.documentUploadPath = documentUploadPath;
	}
	public String getDocumentId() {
		return documentId;
	}
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}
	public String getUpgradeId() {
		return upgradeId;
	}
	public void setUpgradeId(String upgradeId) {
		this.upgradeId = upgradeId;
	}
	public String getOptionId() {
		return optionId;
	}
	public void setOptionId(String optionId) {
		this.optionId = optionId;
	}
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	
	
	
	public UpgradeDocument(String documentId, String upgradeId, String optionId, String documentName,
			String documentType, String language, String documentUploadPath) {
		super();
		this.documentId = documentId;
		this.upgradeId = upgradeId;
		this.optionId = optionId;
		this.documentName = documentName;
		this.documentType = documentType;
		this.language = language;
		this.documentUploadPath = documentUploadPath;
	}
	public UpgradeDocument(){
		super();
	}
	@Override
	public String toString() {
		return "UpgradeDocument [documentId=" + documentId + ", upgradeId=" + upgradeId + ", optionId=" + optionId
				+ ", documentName=" + documentName + ", documentType=" + documentType + ", language=" + language
				+ ", documentUploadPath=" + documentUploadPath + "]";
	}
	
	
}
