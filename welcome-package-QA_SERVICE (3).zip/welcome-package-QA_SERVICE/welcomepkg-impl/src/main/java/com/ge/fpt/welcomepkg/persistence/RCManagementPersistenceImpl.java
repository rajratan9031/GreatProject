package com.ge.fpt.welcomepkg.persistence;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.fpt.welcomepkg.api.AccountData;
import com.ge.fpt.welcomepkg.api.CustomerData;
import com.ge.fpt.welcomepkg.api.EquipmentBoms;
import com.ge.fpt.welcomepkg.api.PartData;
import com.ge.fpt.welcomepkg.api.ProductData;
import com.ge.fpt.welcomepkg.api.RecipData;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.api.TurboChargerDetail;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;

public class RCManagementPersistenceImpl implements IRCManagementPersistence{


	@SuppressWarnings("javadoc")
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory.getLogger(RCManagementPersistenceImpl.class);

	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;

	/**
	 * Data source for the JDBC
	 */
	DataSource dataSource;

	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;

	NamedParameterJdbcTemplate namedParamTemplate;

	/**
	 * @return the dataSource
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}

	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate = new NamedParameterJdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	public String getFilterClause(AccountData accountData){
		String filter="";
		List<String> conditions = new ArrayList<String>();
		if(accountData!=null){
			if(accountData.getAccountName()!=null && !accountData.getAccountName().isEmpty()){
				conditions.add(" UPPER(NAME) LIKE '%' || :accountName || '%'");
			}
		}
		if (conditions.size() > 0) {
			String condStr = "";

			for (int i = 0; i < conditions.size(); i++) {
				condStr += ( " AND " + conditions.get(i));
			}

			filter = condStr;
		}
		return filter;
	}

	public  Map<String, String> setFilterParams(AccountData accountData){
		Map<String, String> result = new HashMap<String, String>();
		result.put("accountId", accountData.getAccountId() == null ? "" : accountData.getAccountId().toUpperCase());
		result.put("accountName", accountData.getAccountName() == null ? "" : accountData.getAccountName().toUpperCase());
		return result;
	}

	public  Map<String, String> setCustomerFilterParams(CustomerData customerData){
		Map<String, String> result = new HashMap<String, String>();
		result.put("customerKey", customerData.getCustomerKey() == null ? "" : customerData.getCustomerKey().toUpperCase());
		result.put("customerName", customerData.getCustomerName() == null ? "" :  customerData.getCustomerName().toUpperCase());
		result.put("endUserName", customerData.getEndUserName() == null ? "" : customerData.getEndUserName().toUpperCase());
		result.put("stationLocation", customerData.getStationLocation() == null ? "" :  customerData.getStationLocation().toUpperCase());
		result.put("geLocation", customerData.getGeLocation() == null ? "" : customerData.getGeLocation().toUpperCase());
		result.put("country", customerData.getCountry() == null ? "" :  customerData.getCountry().toUpperCase());
		result.put("stateName", customerData.getStateName() == null ? "" : customerData.getStateName().toUpperCase());	
		return result;
	}

	public  Map<String, String> setProductFilterParams(ProductData productData){
		Map<String, String> result = new HashMap<String, String>();
		result.put("productKey", productData.getProductKey() == null ? "" : productData.getProductKey().toUpperCase());
		result.put("productName", productData.getProductName() == null ? "" :  productData.getProductName().toUpperCase());
		result.put("unitType", productData.getUnitType() == null ? "" : productData.getUnitType().toUpperCase());
		result.put("model", productData.getModel() == null ? "" :  productData.getModel().toUpperCase());
		return result;
	}


	public  Map<String, String> setRecipFilterParams(String globalSearch,RecipData recipData){
		Map<String, String> result = new HashMap<String, String>();
		result.put("globalSearch", globalSearch == null ? "" : globalSearch.toUpperCase());
		result.put("customerKey", recipData.getCustomerKey() == null ? "" : recipData.getCustomerKey().toUpperCase());
		result.put("productKey", recipData.getProductKey() == null ? "" : recipData.getProductKey().toUpperCase());
		result.put("managerKey", recipData.getManagerKey() == null ? "" : recipData.getManagerKey().toUpperCase());
		result.put("recordId", recipData.getRecordId() == null ? "" : recipData.getRecordId().toUpperCase());
		result.put("serialNumber", recipData.getSerialNumber() == null ? "" : recipData.getSerialNumber().toUpperCase());
		result.put("status", recipData.getStatus() == null ? "" : recipData.getStatus().toUpperCase());
		result.put("lastOverHaulDT", recipData.getLastOverHaulDT() == null ? "" : recipData.getLastOverHaulDT().toUpperCase());
		result.put("hrsAtLastOverHaul", recipData.getHrsAtLastOverHaul() == null ? "" : recipData.getHrsAtLastOverHaul().toUpperCase());
		result.put("nextOverHaulDT", recipData.getNextOverHaulDT() == null ? "" : recipData.getNextOverHaulDT().toUpperCase());
		result.put("partsProvider", recipData.getPartsProvider() == null ? "" : recipData.getPartsProvider().toUpperCase());
		result.put("fieldServiceProvider", recipData.getFieldServiceProvider() == null ? "" : recipData.getFieldServiceProvider().toUpperCase());
		result.put("marketSegment", recipData.getMarketSegment() == null ? "" : recipData.getMarketSegment().toUpperCase());
		result.put("noOfCyclinders", recipData.getNoOfCyclinders() == null ? "" : recipData.getNoOfCyclinders().toUpperCase());
		result.put("ratedBhp", recipData.getRatedBhp() == null ? "" : recipData.getRatedBhp().toUpperCase());
		result.put("turboCharged", recipData.getTurboCharged() == null ? "" : recipData.getTurboCharged().toUpperCase());
		result.put("serviceManager", recipData.getServiceManager() == null ? "" : recipData.getServiceManager().toUpperCase());
		result.put("thirdPartyPartsProvides", recipData.getThirdPartyPartsProvides() == null ? "" : recipData.getThirdPartyPartsProvides().toUpperCase());	
		result.put("thirdPartyFldServProvider", recipData.getThirdPartyFldServProvider() == null ? "" : recipData.getThirdPartyFldServProvider().toUpperCase());	
		result.put("thirdPartyRepairsProvides", recipData.getThirdPartyRepairsProvides() == null ? "" : recipData.getThirdPartyRepairsProvides().toUpperCase());
		result.put("notesFuturePlans", recipData.getNotesFuturePlans() == null ? "" : recipData.getNotesFuturePlans().toUpperCase());result.put("noOfActvComprsrThrows", recipData.getNoOfActvComprsrThrows() == null ? "" : recipData.getNoOfActvComprsrThrows().toUpperCase());
		result.put("turbochargerServiceProvider", recipData.getTurbochargerServiceProvider() == null ? "" : recipData.getTurbochargerServiceProvider().toUpperCase());
		result.put("plansToRepairReplace", recipData.getPlansToRepairReplace() == null ? "" : recipData.getPlansToRepairReplace().toUpperCase());
		result.put("retireDt", recipData.getRetireDt() == null ? "" : recipData.getRetireDt().toUpperCase());
		result.put("utilization2016HST", recipData.getUtilization2016HST() == null ? "" : recipData.getUtilization2016HST().toUpperCase());
		result.put("utilization2015HST", recipData.getUtilization2015HST() == null ? "" : recipData.getUtilization2015HST().toUpperCase());
		result.put("maintenancePratice", recipData.getMaintenancePratice() == null ? "" : recipData.getMaintenancePratice().toUpperCase());
		result.put("directInderct", recipData.getDirectInderct() == null ? "" : recipData.getDirectInderct().toUpperCase());
		result.put("accountManagerName", recipData.getAccountManagerName() == null ? "" : recipData.getAccountManagerName().toUpperCase());
		result.put("productName", recipData.getProductName() == null ? "" : recipData.getProductName().toUpperCase());
		result.put("unitType", recipData.getUnitType() == null ? "" : recipData.getUnitType().toUpperCase());
		result.put("productModel", recipData.getProductModel() == null ? "" : recipData.getProductModel().toUpperCase());
		result.put("customerName", recipData.getCustomerName() == null ? "" : recipData.getCustomerName().toUpperCase());
		result.put("endUserName", recipData.getEndUserName() == null ? "" : recipData.getEndUserName().toUpperCase());
		result.put("geRegion", recipData.getGeRegion() == null ? "" : recipData.getGeRegion().toUpperCase());
		result.put("country", recipData.getCountry() == null ? "" : recipData.getCountry().toUpperCase());
		result.put("stationLocation", recipData.getStationLocation() == null ? "" : recipData.getStationLocation().toUpperCase());
		result.put("usaStateName", recipData.getUsaStateName() == null ? "" : recipData.getUsaStateName().toUpperCase());
		result.put("utilization2017Current", recipData.getUtilization2017Current() == null ? "" : recipData.getUtilization2017Current().toUpperCase());
		result.put("utilization2018Projected", recipData.getUtilization2018Projected() == null ? "" : recipData.getUtilization2018Projected().toUpperCase());
		result.put("repairsProvider", recipData.getRepairsProvider() == null ? "" : recipData.getRepairsProvider().toUpperCase());
		result.put("county", recipData.getCounty() == null ? "" : recipData.getCounty().toUpperCase());
		result.put("lastUpdateDate", recipData.getLastUpdateDate() == null ? "" : recipData.getLastUpdateDate().toUpperCase());
		result.put("turbochargerMake", recipData.getTurbochargerMake() == null ? "" : recipData.getTurbochargerMake().toUpperCase());
		result.put("turbochargerModel", recipData.getTurbochargerModel() == null ? "" : recipData.getTurbochargerModel().toUpperCase());	
		result.put("designCode", recipData.getDesignCode() == null ? "" : recipData.getDesignCode().toUpperCase());
		return result;
	}


	private String getGlobalFilterClause() {
		String filter = "";
		filter = " ((UPPER(SERIAL_NUMBER) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(STATUS) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(CUSTOMER_KEY) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(PRODUCT_KEY) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(MANAGER_KEY) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(RECORD_ID) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(SERIAL_NUMBER) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(STATUS) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(LAST_OVERHAUL_DT) LIKE '%' || :globalSearch || '%')" +	
				" OR (UPPER(HRS_AT_LAST_OVERHAUL) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(NEXT_OVERHAUL_DT) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(PARTS_PROVIDER) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(FIELD_SERVICE_PROVIDER) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(MARKET_SEGMENT) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(NO_OF_CYLINDERS) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(RATED_BHP) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(TURBO_CHARGED) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(SERVICE_MANAGER) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(THIRDPARTY_PARTS_PROVIDER) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(THIRDPARTY_FLD_SERV_PROVIDER) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(THIRDPARTY_REPAIRS_PROVIDER) LIKE '%' || :globalSearch || '%')" +
			    " OR (UPPER(NOTES_FUTURE_PLANS) LIKE '%' || :globalSearch || '%')" +
			    " OR (UPPER(NO_OF_ACTV_COMPRSR_THROWS) LIKE '%' || :globalSearch ||'%')" +
				" OR (UPPER(TURBOCHARGER_SERVICE_PROVIDER) LIKE '%' || :globalSearch || '%')" +
			    " OR (UPPER(PLANS_TO_REPAIR_REPLACE) LIKE '%' || :globalSearch || '%')" +
			    " OR (UPPER(RETIRE_DT) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(UTILIZATION_2016_HIST) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(UTILIZATION_2015_HIST) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(MAINTENANCE_PRACTICE) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(DIRECT_INDERCT) LIKE '%' || :globalSearch || '%')" +
			    " OR (UPPER(ACCOUNT_MANAGER_NAME) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(PRODUCT_NAME) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(UNIT_TYPE) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(PRODUCT_MODEL) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(CUSTOMER_NAME) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(END_USER_NAME) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(GE_REGION) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(COUNTRY) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(STATION_LOCATION) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(USA_STATE_NAME) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(COUNTY) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(UTILIZATION_2017_CURRENT) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(UTILIZATION_2018_PROJECTED) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(REPAIRS_PROVIDER) LIKE '%' || :globalSearch || '%')" +
			    " OR (UPPER(TURBOCHARGER_MAKE) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(TURBOCHARGER_MODEL) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(DESIGN_CODE) LIKE '%' || :globalSearch || '%'))" ;
		return filter;
	}


	public String getRecipFilterClause(RecipData recipData){
		String filter="";
		List<String> conditions = new ArrayList<String>();
		if(recipData!=null){
			if(recipData.getCustomerKey()!=null && !recipData.getCustomerKey().isEmpty()){
				conditions.add(" UPPER(CUSTOMER_KEY) LIKE '%' || :customerKey || '%'");
			}
			if(recipData.getProductKey()!=null && !recipData.getProductKey().isEmpty()){
				conditions.add(" UPPER(PRODUCT_KEY) LIKE '%' || :productKey || '%'");
			}
			if(recipData.getManagerKey()!=null && !recipData.getManagerKey().isEmpty()){
				conditions.add(" UPPER(MANAGER_KEY) LIKE '%' || :managerKey || '%'");
			}
			if(recipData.getRecordId()!=null && !recipData.getRecordId().isEmpty()){
				conditions.add(" UPPER(RECORD_ID) LIKE '%' || :recordId || '%'");
			}
			if(recipData.getSerialNumber()!=null && !recipData.getSerialNumber().isEmpty()){
				conditions.add(" UPPER(SERIAL_NUMBER) LIKE '%' || :serialNumber || '%'");
			}
			if(recipData.getStatus()!=null && !recipData.getStatus().isEmpty()){
				conditions.add(" UPPER(STATUS) LIKE '%' || :status || '%'");
			}	
			if(recipData.getLastOverHaulDT()!=null && !recipData.getLastOverHaulDT().isEmpty()){
				conditions.add(" UPPER(LAST_OVERHAUL_DT) LIKE '%' || :lastOverHaulDT || '%'");
			}
			if(recipData.getHrsAtLastOverHaul()!=null && !recipData.getHrsAtLastOverHaul().isEmpty()){
				conditions.add(" UPPER(HRS_AT_LAST_OVERHAUL) LIKE '%' || :hrsAtLastOverHaul || '%'");
			}
			if(recipData.getNextOverHaulDT()!=null && !recipData.getNextOverHaulDT().isEmpty()){
				conditions.add(" UPPER(NEXT_OVERHAUL_DT) LIKE '%' || :nextOverHaulDT || '%'");
			}
			if(recipData.getPartsProvider()!=null && !recipData.getPartsProvider().isEmpty()){
				conditions.add(" UPPER(PARTS_PROVIDER) LIKE '%' || :partsProvider || '%'");
			}
			if(recipData.getFieldServiceProvider()!=null && !recipData.getFieldServiceProvider().isEmpty()){
				conditions.add(" UPPER(FIELD_SERVICE_PROVIDER) LIKE '%' || :fieldServiceProvider || '%'");
			}
			if(recipData.getMarketSegment()!=null && !recipData.getMarketSegment().isEmpty()){
				conditions.add(" UPPER(MARKET_SEGMENT) LIKE '%' || :marketSegment || '%'");
			}		
			if(recipData.getNoOfCyclinders()!=null && !recipData.getNoOfCyclinders().isEmpty()){
				conditions.add(" UPPER(NO_OF_CYLINDERS) LIKE '%' || :noOfCyclinders || '%'");
			}
			
			if(recipData.getRatedBhp()!=null && !recipData.getRatedBhp().isEmpty()){
				conditions.add(" UPPER(RATED_BHP) LIKE '%' || :ratedBhp || '%'");
			}
			if(recipData.getTurboCharged()!=null && !recipData.getTurboCharged().isEmpty()){
				conditions.add(" UPPER(TURBO_CHARGED) LIKE '%' || :turboCharged || '%'");
			}
			if(recipData.getServiceManager()!=null && !recipData.getServiceManager().isEmpty()){
				conditions.add(" UPPER(SERVICE_MANAGER) LIKE '%' || :serviceManager || '%'");
			}
			if(recipData.getThirdPartyPartsProvides()!=null && !recipData.getThirdPartyPartsProvides().isEmpty()){
				conditions.add(" UPPER(THIRDPARTY_PARTS_PROVIDER) LIKE '%' || :thirdPartyPartsProvides || '%'");
			}	
			if(recipData.getThirdPartyFldServProvider()!=null && !recipData.getThirdPartyFldServProvider().isEmpty()){
				conditions.add(" UPPER(THIRDPARTY_FLD_SERV_PROVIDER) LIKE '%' || :thirdPartyFldServProvider || '%'");
			}
			if(recipData.getThirdPartyRepairsProvides()!=null && !recipData.getThirdPartyRepairsProvides().isEmpty()){
				conditions.add(" UPPER(THIRDPARTY_REPAIRS_PROVIDER) LIKE '%' || :thirdPartyRepairsProvides || '%'");
			}
			
			if(recipData.getNotesFuturePlans()!=null && !recipData.getNotesFuturePlans().isEmpty()){
				conditions.add(" UPPER(NOTES_FUTURE_PLANS) LIKE '%' || :notesFuturePlans || '%'");
			}
			
			if(recipData.getNoOfActvComprsrThrows()!=null && !recipData.getNoOfActvComprsrThrows().isEmpty()){
				conditions.add(" UPPER(NO_OF_ACTV_COMPRSR_THROWS) LIKE '%' || :noOfActvComprsrThrows || '%'");
			}	
			if(recipData.getTurbochargerServiceProvider()!=null && !recipData.getTurbochargerServiceProvider().isEmpty()){
				conditions.add(" UPPER(TURBOCHARGER_SERVICE_PROVIDER) LIKE '%' || :turbochargerServiceProvider || '%'");
			}
			
			if(recipData.getPlansToRepairReplace()!=null && !recipData.getPlansToRepairReplace().isEmpty()){
				conditions.add(" UPPER(PLANS_TO_REPAIR_REPLACE) LIKE '%' || :plansToRepairReplace || '%'");
			}
			
			if(recipData.getRetireDt()!=null && !recipData.getRetireDt().isEmpty()){
				conditions.add(" UPPER(RETIRE_DT) LIKE '%' || :retireDt || '%'");
			}
			if(recipData.getUtilization2016HST()!=null && !recipData.getUtilization2016HST().isEmpty()){
				conditions.add(" UPPER(UTILIZATION_2016_HIST) LIKE '%' || :utilization2016HST || '%'");
			}
			if(recipData.getUtilization2015HST()!=null && !recipData.getUtilization2015HST().isEmpty()){
				conditions.add(" UPPER(UTILIZATION_2015_HIST) LIKE '%' || :utilization2015HST || '%'");
			}
			if(recipData.getMaintenancePratice()!=null && !recipData.getMaintenancePratice().isEmpty()){
				conditions.add(" UPPER(MAINTENANCE_PRACTICE) LIKE '%' || :maintenancePratice || '%'");
			}
			
			if(recipData.getDirectInderct()!=null && !recipData.getDirectInderct().isEmpty()){
				conditions.add(" UPPER(DIRECT_INDERCT) LIKE '%' || :directInderct || '%'");
			}
			
			if(recipData.getAccountManagerName()!=null && !recipData.getAccountManagerName().isEmpty()){
				conditions.add(" UPPER(ACCOUNT_MANAGER_NAME) LIKE '%' || :accountManagerName || '%'");
			}
			if(recipData.getProductName()!=null && !recipData.getProductName().isEmpty()){
				conditions.add(" UPPER(PRODUCT_NAME) LIKE '%' || :productName || '%'");
			}
			if(recipData.getUnitType()!=null && !recipData.getUnitType().isEmpty()){
				conditions.add(" UPPER(UNIT_TYPE) LIKE '%' || :unitType || '%'");
			}
			if(recipData.getProductModel()!=null && !recipData.getProductModel().isEmpty()){
				conditions.add(" UPPER(PRODUCT_MODEL) LIKE '%' || :productModel || '%'");
			}
			if(recipData.getCustomerName()!=null && !recipData.getCustomerName().isEmpty()){
				conditions.add(" UPPER(CUSTOMER_NAME) LIKE '%' || :customerName || '%'");
			}
			if(recipData.getEndUserName()!=null && !recipData.getEndUserName().isEmpty()){
				conditions.add(" UPPER(END_USER_NAME) LIKE '%' || :endUserName || '%'");
			}
			if(recipData.getGeRegion()!=null && !recipData.getGeRegion().isEmpty()){
				conditions.add(" UPPER(GE_REGION) LIKE '%' || :geRegion || '%'");
			}
			if(recipData.getCountry()!=null && !recipData.getCountry().isEmpty()){
				conditions.add(" UPPER(COUNTRY) LIKE '%' || :country || '%'");
			}
			if(recipData.getStationLocation()!=null && !recipData.getStationLocation().isEmpty()){
				conditions.add(" UPPER(STATION_LOCATION) LIKE '%' || :stationLocation || '%'");
			}
			if(recipData.getUsaStateName()!=null && !recipData.getUsaStateName().isEmpty()){
				conditions.add(" UPPER(USA_STATE_NAME) LIKE '%' || :usaStateName || '%'");
			}	

			// new 

			/*	if(recipData.getCustomerDunsNo()!=null && !recipData.getCustomerDunsNo().isEmpty()){
				conditions.add(" UPPER(CUSTOMER_DUNS_NO) LIKE '%' || :customerDunsNo || '%'");
			}*/

			if(recipData.getCounty()!=null && !recipData.getCounty().isEmpty()){
				conditions.add(" UPPER(COUNTY) LIKE '%' || :county || '%'");
			}
			if(recipData.getUtilization2017Current()!=null && !recipData.getUtilization2017Current().isEmpty()){
				conditions.add(" UPPER(UTILIZATION_2017_CURRENT) LIKE '%' || :utilization2017Current || '%'");
			}
			if(recipData.getUtilization2018Projected()!=null && !recipData.getUtilization2018Projected().isEmpty()){
				conditions.add(" UPPER(UTILIZATION_2018_PROJECTED) LIKE '%' || :utilization2018Projected || '%'");
			}
			if(recipData.getRepairsProvider()!=null && !recipData.getRepairsProvider().isEmpty()){
				conditions.add(" UPPER(REPAIRS_PROVIDER) LIKE '%' || :repairsProvider || '%'");
			}
			
			if(recipData.getLastUpdateDate()!=null && !recipData.getLastUpdateDate().isEmpty()){
				conditions.add(" UPPER(LAST_UPDATE_DATE) LIKE '%' || :lastUpdateDate || '%'");
			}	
			// New Fields
			if(recipData.getTurbochargerMake()!=null && !recipData.getTurbochargerMake().isEmpty()){
				conditions.add(" UPPER(TURBOCHARGER_MAKE) LIKE '%' || :turbochargerMake || '%'");
			}
			if(recipData.getTurbochargerModel()!=null && !recipData.getTurbochargerModel().isEmpty()){
				conditions.add(" UPPER(TURBOCHARGER_MODEL) LIKE '%' || :turbochargerModel || '%'");
			}	
			if(recipData.getDesignCode()!=null && !recipData.getDesignCode().isEmpty()){
				conditions.add(" UPPER(DESIGN_CODE) LIKE '%' || :designCode || '%'");
			}					
		}
		if (conditions.size() > 0) {
			String condStr = "";

			for (int i = 0; i < conditions.size(); i++) {
				condStr += ( " AND " + conditions.get(i));
			}

			filter = condStr;
		}
		return filter;
	}

	public String getCustomerFilterClause(CustomerData customerData){
		String filter="";
		List<String> conditions = new ArrayList<String>();
		if(customerData!=null){
			if(customerData.getCustomerName()!=null && !customerData.getCustomerName().isEmpty()){
				conditions.add(" UPPER(CUSTOMER_NAME) LIKE '%' || :customerName || '%'");
			}
			if(customerData.getEndUserName()!=null && !customerData.getEndUserName().isEmpty()){
				conditions.add(" UPPER(END_USER_NAME) LIKE '%' || :endUserName || '%'");
			}
			if(customerData.getStationLocation()!=null && !customerData.getStationLocation().isEmpty()){
				conditions.add(" UPPER(STATION_LOCATION) LIKE '%' || :stationLocation || '%'");
			}
			if(customerData.getGeLocation()!=null && !customerData.getGeLocation().isEmpty()){
				conditions.add(" UPPER(GE_REGION) LIKE '%' || :geLocation || '%'");
			}
			if(customerData.getCountry()!=null && !customerData.getCountry().isEmpty()){
				conditions.add(" UPPER(COUNTRY) LIKE '%' || :country || '%'");
			}
			if(customerData.getStateName()!=null && !customerData.getStateName().isEmpty()){
				conditions.add(" UPPER(USA_STATE_NAME) LIKE '%' || :stateName || '%'");
			}	
		}
		if (conditions.size() > 0) {
			String condStr = "";

			for (int i = 0; i < conditions.size(); i++) {
				condStr += ( " AND " + conditions.get(i));
			}

			filter = condStr;
		}
		return filter;
	}

	public String getProductFilterClause(ProductData productData){
		String filter="";
		List<String> conditions = new ArrayList<String>();
		if(productData!=null){
			if(productData.getProductName()!=null && !productData.getProductName().isEmpty()){
				conditions.add(" UPPER(PRODUCT_NAME) LIKE '%' || :productName || '%'");
			}
			if(productData.getUnitType()!=null && !productData.getUnitType().isEmpty()){
				conditions.add(" UPPER(UNIT_TYPE) LIKE '%' || :unitType || '%'");
			}
			if(productData.getModel()!=null && !productData.getModel().isEmpty()){
				conditions.add(" UPPER(MODEL) LIKE '%' || :model || '%'");

			}
			if (conditions.size() > 0) {
				String condStr = "";

				for (int i = 0; i < conditions.size(); i++) {
					condStr += ( " AND " + conditions.get(i));
				}

				filter = condStr;
			}

		}
		return filter;
	}
	public  int getAccountdatacount(AccountData accountData){
		String sql="select count(*) from ddsafm.rc_account_manager a where 1=1 ";
		MapSqlParameterSource parameters = new MapSqlParameterSource(setFilterParams(accountData));
		if(accountData!=null){
			String filter=getFilterClause(accountData);
			sql=sql+filter;
		}
		return this.namedParamTemplate.queryForInt(sql, parameters);
	}

	public List<AccountData> getAccountData(int pageNo,int rowsPerPage,String sortCol, String sortOrder,AccountData accountData){
		List<AccountData> result = null;
		try{
			String sql= "select manager_key, name " +
					" from (select rownum as rnum, a.* from ddsafm.rc_account_manager a where 1=1";
			MapSqlParameterSource parameters = new MapSqlParameterSource(setFilterParams(accountData));
			if(accountData!=null){
				String filter=getFilterClause(accountData);
				sql=sql+filter;
			}
			if(sortCol!=null && !sortCol.equalsIgnoreCase("")){
				sql+="order by "+sortCol;
			}
			if(sortOrder!=null && !sortOrder.equalsIgnoreCase("")){
				sql+=" "+sortOrder;
			}	
			sql+=")";
			if (rowsPerPage > 0) {

				int lowerLimit = rowsPerPage * pageNo;
				int upperLimit = lowerLimit + rowsPerPage;

				String pageLimitClause= " where rnum >:lowerLimit AND rnum <=:upperLimit";
				parameters.addValue("lowerLimit", lowerLimit);
				parameters.addValue("upperLimit", upperLimit);
				sql+=pageLimitClause;

			}
			result=this.namedParamTemplate.query(sql, parameters,
					new AccountMapper());

		}catch(Exception e){
			logger.info("found Exception :: "+e);
		}
		return result;
	}



	public StatusInfo saveAccountData(AccountData accountData){
		StatusInfo statusinfo= new StatusInfo();
		try {		
			String sql= "select count(manager_key) from ddsafm.rc_account_manager where manager_key= ?";
			String saveSql="";
			int count=this.jdbcTemplate.queryForInt(sql, new Object[]{accountData.getAccountId()});
			if(count>0){
				saveSql="update ddsafm.rc_account_manager set name=? where manager_key=?"	;	
				Object[] param={
						accountData.getAccountName(),
						accountData.getAccountId()	 		  		  
				};
				this.jdbcTemplate.update(saveSql, param);
			}else{
				sql="Select max(manager_key)+1 from ddsafm.rc_account_manager";
				int cnt=this.jdbcTemplate.queryForInt(sql);

				saveSql= "insert into ddsafm.rc_account_manager(manager_key,name) "+
						"values (?,?)";
				Object[] param={
						cnt,
						accountData.getAccountName()	
				};
				this.jdbcTemplate.update(saveSql, param);
			}
			statusinfo.setStatusCode(1);
			statusinfo.setStatusMessage("Data saved Successfully"); 
		} catch(Exception ex){
			logger.info("Error occured during saving the Data :: "+ex);
			statusinfo.setStatusCode(-1);
			statusinfo.setStatusMessage(ex.getMessage());
		}
		return statusinfo;
	}


	@Override
	public StatusInfo deleteAccountdata(AccountData accountData) {
		StatusInfo statusinfo= new StatusInfo();
		try{
			int accountDataValue=Integer.valueOf(accountData.getAccountId());		
			String sql= "delete from ddsafm.rc_account_manager where manager_key= ?";
			this.jdbcTemplate.update(sql,accountDataValue);
			statusinfo.setStatusCode(1);
			statusinfo.setStatusMessage("Data deleted Successfully");
		} catch(Exception e){
			statusinfo.setStatusCode(500);
			statusinfo.setStatusMessage("Data deletion failed"+e.getLocalizedMessage());
		}
		return statusinfo;
	}	



	@Override
	public List<CustomerData> getCustomerdata(int pageNo, int rowperpage,String sortCol, String sortOrder,  CustomerData customerData) {
		List<CustomerData> result = null;
		try{
			String sql= "select customer_key, customer_name , end_user_name , station_location , ge_region , country , usa_state_name " +
					" from (select rownum as rnum, a.* from ddsafm.rc_customer a where 1=1";

			MapSqlParameterSource parameters = new MapSqlParameterSource(setCustomerFilterParams(customerData));
			if(customerData!=null){
				String filter=getCustomerFilterClause(customerData);
				sql=sql+filter;
			}

			if(sortCol!=null && !sortCol.equalsIgnoreCase("")){
				sql+="order by "+sortCol;
			}
			if(sortOrder!=null && !sortOrder.equalsIgnoreCase("")){
				sql+=" "+sortOrder;
			}

			sql+=")";
			if (rowperpage > 0) {
				int lowerLimit = rowperpage * pageNo;
				int upperLimit = lowerLimit + rowperpage;

				String pageLimitClause= " where rnum >:lowerLimit AND rnum <=:upperLimit";
				parameters.addValue("lowerLimit", lowerLimit);
				parameters.addValue("upperLimit", upperLimit);
				sql+=pageLimitClause;
			}
			result=this.namedParamTemplate.query(sql, parameters,new CustomerMapper());

		}catch(Exception e){
			logger.info("found Exception :: "+e);
		}
		return result;
	}

	@Override
	public int getCustomerdatacount(CustomerData customerData) {
		String sql="select count(*) from ddsafm.rc_customer a where 1=1 ";
		MapSqlParameterSource parameters = new MapSqlParameterSource(setCustomerFilterParams(customerData));
		if(customerData!=null){
			String filter=getCustomerFilterClause(customerData);
			sql=sql+filter;
		}
		return this.namedParamTemplate.queryForInt(sql, parameters);
	}

	@Override
	public StatusInfo saveCustomerdata(CustomerData customerData) {
		StatusInfo statusinfo= new StatusInfo();
		try {		
			String sql= "select count(customer_key) from  ddsafm.rc_customer where customer_key= ?";
			String saveSql="";
			int count=this.jdbcTemplate.queryForInt(sql, new Object[]{customerData.getCustomerKey()});
			if(count>0){
				saveSql="update ddsafm.rc_customer set customer_name=? ,end_user_name=?, station_location=?, ge_region=?, country=?, usa_state_name=? where customer_key= ?"	;	
				Object[] param={
						customerData.getCustomerName(),
						customerData.getEndUserName(),
						customerData.getStationLocation(),
						customerData.getGeLocation(),
						customerData.getCountry(),
						customerData.getStateName(),
						customerData.getCustomerKey()
				};
				this.jdbcTemplate.update(saveSql, param);
			}else{
				sql="Select max(customer_key)+1 from ddsafm.rc_customer";
				int cnt=this.jdbcTemplate.queryForInt(sql);

				saveSql= "insert into ddsafm.rc_customer(customer_key,customer_name,end_user_name,station_location,ge_region,country,usa_state_name) "+
						"values (?,?,?,?,?,?,?)";
				Object[] param={
						cnt,
						customerData.getCustomerName(),
						customerData.getEndUserName(),
						customerData.getStationLocation(),
						customerData.getGeLocation(),
						customerData.getCountry(),
						customerData.getStateName()	
				};
				this.jdbcTemplate.update(saveSql, param);
			}
			statusinfo.setStatusCode(1);
			statusinfo.setStatusMessage("Data saved Successfully"); 
		} catch(Exception ex){
			logger.info("Error occured during saving the Data :: "+ex);
			statusinfo.setStatusCode(-1);
			statusinfo.setStatusMessage(ex.getMessage());
		}
		return statusinfo;
	}

	@Override
	public StatusInfo deleteCustomerdata(CustomerData customerData) {
		StatusInfo statusinfo= new StatusInfo();
		try{
			int customerDataValue=Integer.valueOf(customerData.getCustomerKey());		
			String sql= "delete from ddsafm.rc_customer where customer_key= ?";
			this.jdbcTemplate.update(sql,customerDataValue);
			statusinfo.setStatusCode(1);
			statusinfo.setStatusMessage("Data deleted Successfully");
		} catch(Exception e){
			statusinfo.setStatusCode(500);
			statusinfo.setStatusMessage("Data deletion failed"+e.getLocalizedMessage());
		}
		return statusinfo;
	}


	@Override
	public List<String> getCustomerName(String customerName) {
		List<String> custDataConcat= new ArrayList<String>();		
		String customerNameCheck[]=customerName.split(",");
		String customer=customerNameCheck[0];
		if(customerNameCheck.length == 1){
			logger.error("Only one customer Name"+customerNameCheck[0].trim());
			try{
				String sql = "select * from ddsafm.rc_customer where UPPER(customer_name) LIKE '%'||UPPER(:customerName)||'%'";
				MapSqlParameterSource parameters=new MapSqlParameterSource();
				parameters.addValue("customerName",customer);
				logger.error("inside getCustomerName()");	
				logger.error("Query :: "+sql);
				List<CustomerData> custData=this.namedParamTemplate.query(sql, parameters,new CustomerMapper());		
				for(CustomerData c:custData){
					String data = c.getCustomerName() + "--" + c.getEndUserName() + "--" +  c.getStationLocation() + "--" + c.getGeLocation() + "--" + c.getCountry() + "--" + c.getStateName() + "--" + c.getCustomerKey();
					logger.error("getCustomerName()"+data);
					custDataConcat.add(data);
				}
			}catch(Exception e){
				logger.error("found Exception getCustomerName :: "+e);
			}
		}  else {
			logger.error("more than one customer Name"+customerNameCheck[1].trim());
			String secondaryCheck=customerNameCheck[1].trim();
			try{
				String sql = "select * from ddsafm.rc_customer where (UPPER(customer_name) LIKE '%'||UPPER(:customerName)||'%') AND ((UPPER(end_user_name) like '%'||UPPER(:secondaryCheck)||'%') OR (UPPER(station_location) like '%'||UPPER(:secondaryCheck)||'%') OR (UPPER(ge_region) like '%'||UPPER(:secondaryCheck)||'%') OR (UPPER(country) like '%'||UPPER(:secondaryCheck)||'%') OR  (UPPER(usa_state_name) like '%'||UPPER(:secondaryCheck)||'%'))";
				MapSqlParameterSource parameters=new MapSqlParameterSource();
				parameters.addValue("customerName",customer);
				parameters.addValue("secondaryCheck",secondaryCheck);
				logger.error("inside getCustomerName()");		
				logger.error("Query :: "+sql);
				List<CustomerData> custData=this.namedParamTemplate.query(sql, parameters,new CustomerMapper());		
				for(CustomerData c:custData){
					String data = c.getCustomerName() + "--" + c.getEndUserName() + "--" +  c.getStationLocation() + "--" + c.getGeLocation() + "--" + c.getCountry() + "--" + c.getStateName() + "--" + c.getCustomerKey();
					logger.error("getCustomerName()"+data);
					custDataConcat.add(data);
				}
			}catch(Exception e){
				logger.error("found Exception getCustomerName :: "+e);
			}
		}
		return custDataConcat;	
	}


	@Override
	public List<String> getAccountManagerName(String accountManagerName) {
		List<String> accDataConcat= new ArrayList<String>();
		try{
			String sql = "select * from ddsafm.rc_account_manager where UPPER(name) LIKE '%'||UPPER(:accountManagerName)||'%'";
			MapSqlParameterSource parameters=new MapSqlParameterSource();
			parameters.addValue("accountManagerName",accountManagerName);
			logger.error("inside getAccountManagerName()");		
			List<AccountData> accData=this.namedParamTemplate.query(sql, parameters,new AccountMapper());
			for(AccountData c:accData){
				String data = c.getAccountName() + "--" + c.getAccountId();
				logger.error("getAccountManagerName()"+data);
				accDataConcat.add(data);
			}

		}catch(Exception e){
			logger.error("found Exception getAccountManagerName :: "+e);
		}
		return accDataConcat;
	}

	@Override
	public List<String> getProductName(String productName) {
		List<String> prodDataConcat= new ArrayList<String>();
		String productNameCheck[]=productName.split(",");
		String product=productNameCheck[0];
		if(productNameCheck.length == 1){
			try{
				String sql = "select * from ddsafm.rc_product where UPPER(product_name) LIKE '%'||UPPER(:productName)||'%'";
				MapSqlParameterSource parameters=new MapSqlParameterSource();
				parameters.addValue("productName",product);
				logger.error("inside getProductName()");		
				List<ProductData> prodData=this.namedParamTemplate.query(sql, parameters,new ProductMapper());
				for(ProductData c:prodData){
					String data = c.getProductName() + "--" + c.getUnitType() + "--" + c.getModel() + "--" + c.getProductKey() ;
					logger.error("getProductName()"+data);
					prodDataConcat.add(data);
				}	
			}catch(Exception e){
				logger.error("found Exception getAccountManagerName :: "+e);
			}		
		} else {
			String secondaryCheck=productNameCheck[1].trim();
			try{
				String sql = "select * from ddsafm.rc_product where (UPPER(product_name) LIKE '%'||UPPER(:productName)||'%') AND ((UPPER(unit_type) like '%'||UPPER(:secondaryCheck)||'%') OR (UPPER(model) like '%'||UPPER(:secondaryCheck)||'%')) ";
				MapSqlParameterSource parameters=new MapSqlParameterSource();
				parameters.addValue("productName",product);
				parameters.addValue("secondaryCheck",secondaryCheck);
				logger.error("inside getProductName()");		
				List<ProductData> prodData=this.namedParamTemplate.query(sql, parameters,new ProductMapper());
				for(ProductData c:prodData){
					String data = c.getProductName() + "--" + c.getUnitType() + "--" + c.getModel() + "--" + c.getProductKey() ;
					logger.error("getProductName()"+data);
					prodDataConcat.add(data);
				}	
			}catch(Exception e){
				logger.error("found Exception getAccountManagerName :: "+e);
			}
		}
		return prodDataConcat;
	}

	@Override
	public List<ProductData> getProductdata(int pageNo, int rowperpage,String sortCol, String sortOrder,  ProductData productData) {
		List<ProductData> result = null;
		try{
			String sql= "select product_key, product_name, unit_type , model" +
					" from (select rownum as rnum, a.* from ddsafm.rc_product a where 1=1";
			MapSqlParameterSource parameters = new MapSqlParameterSource(setProductFilterParams(productData));
			if(productData!=null){
				String filter=getProductFilterClause(productData);
				sql=sql+filter;
			}
			if(sortCol!=null && !sortCol.equalsIgnoreCase("")){
				sql+="order by "+sortCol;
			}
			if(sortOrder!=null && !sortOrder.equalsIgnoreCase("")){
				sql+=" "+sortOrder;
			}
			sql+=")";
			if (rowperpage > 0) {
				int lowerLimit = rowperpage * pageNo;
				int upperLimit = lowerLimit + rowperpage;

				String pageLimitClause= " where rnum >:lowerLimit AND rnum <=:upperLimit";
				parameters.addValue("lowerLimit", lowerLimit);
				parameters.addValue("upperLimit", upperLimit);
				sql+=pageLimitClause;
			}
			result=this.namedParamTemplate.query(sql, parameters,new ProductMapper());

		}catch(Exception e){
			logger.info("found Exception :: "+e);
		}
		return result;
	}

	@Override
	public int getProductdatacount(ProductData productData) {
		String sql="select count(*) from ddsafm.rc_product a where 1=1 ";
		MapSqlParameterSource parameters = new MapSqlParameterSource(setProductFilterParams(productData));
		if(productData!=null){
			String filter=getProductFilterClause(productData);
			sql=sql+filter;
		}
		return this.namedParamTemplate.queryForInt(sql, parameters);
	}

	@Override
	public StatusInfo saveProductdata(ProductData productData) {
		StatusInfo statusinfo= new StatusInfo();
		try {		
			String sql= "select count(product_key) from  ddsafm.rc_product where product_key= ?";
			String saveSql="";
			int count=this.jdbcTemplate.queryForInt(sql, new Object[]{productData.getProductKey()});
			if(count>0){
				saveSql="update ddsafm.rc_product set product_name=?, unit_type=? , model=? where product_key= ?"	;	
				Object[] param={
						productData.getProductName(),
						productData.getUnitType(),
						productData.getModel(),
						productData.getProductKey()
				};
				this.jdbcTemplate.update(saveSql, param);
			}else{
				sql="Select max(product_key)+1 from ddsafm.rc_product";
				int cnt=this.jdbcTemplate.queryForInt(sql);

				saveSql= "insert into ddsafm.rc_product(product_key,product_name,unit_type,model) "+
						"values (?,?,?,?)";
				Object[] param={
						cnt,
						productData.getProductName(),
						productData.getUnitType(),
						productData.getModel(),
				};
				this.jdbcTemplate.update(saveSql, param);
			}
			statusinfo.setStatusCode(1);
			statusinfo.setStatusMessage("Data saved Successfully"); 
		} catch(Exception ex){
			logger.info("Error occured during saving the Data :: "+ex);
			statusinfo.setStatusCode(-1);
			statusinfo.setStatusMessage(ex.getMessage());
		}
		return statusinfo;
	}

	@Override
	public StatusInfo deleteProductdata(ProductData productData) {
		StatusInfo statusinfo= new StatusInfo();
		try{
			int productDataValue=Integer.valueOf(productData.getProductKey());		
			String sql= "delete from ddsafm.rc_product where product_key= ?";
			this.jdbcTemplate.update(sql,productDataValue);
			statusinfo.setStatusCode(1);
			statusinfo.setStatusMessage("Data deleted Successfully");
		} catch(Exception e){
			statusinfo.setStatusCode(500);
			statusinfo.setStatusMessage("Data deletion failed"+e.getLocalizedMessage());
		}
		return statusinfo;
	}


	@Override
	public List<RecipData> getRecipdata(int pageNo, int rowperpage, String globalSearch,String sortCol, String sortOrder, RecipData recipData){
		List<RecipData> result = null;
		try{
			String sql= "";
			if(sortOrder!=null && !sortOrder.equalsIgnoreCase("")){
				sql= "select * " +
						" from (select ROW_NUMBER() over(order by "+sortCol+" "+sortOrder+") as rnum, a.* from ddsafm.rc_ib_equipemnt_data_mv a where 1=1";	
			} else {
				sql= "select * " +
						" from (select rownum as rnum, a.* from ddsafm.rc_ib_equipemnt_data_mv a where 1=1";
			}



			MapSqlParameterSource parameters = new MapSqlParameterSource(setRecipFilterParams(globalSearch,recipData));
			if(recipData!=null){
				String filter=getRecipFilterClause(recipData);
				sql=sql+filter;
			}	
			if(sortCol!=null && !sortCol.equalsIgnoreCase("")){
				sql+=" order by "+sortCol;
			}
			if(sortOrder!=null && !sortOrder.equalsIgnoreCase("")){
				sql+=" "+sortOrder;
			}		
			sql+=")";
			if (rowperpage > 0) {
				int lowerLimit = rowperpage * pageNo;
				int upperLimit = lowerLimit + rowperpage;

				String pageLimitClause= " where rnum >:lowerLimit AND rnum <=:upperLimit";
				parameters.addValue("lowerLimit", lowerLimit);
				parameters.addValue("upperLimit", upperLimit);
				sql+=pageLimitClause;
			}

			if (null !=globalSearch && !globalSearch.trim().isEmpty()) {
				String globalFilterClause = getGlobalFilterClause();			
				sql += " AND " + globalFilterClause;
			}
			logger.info("Recip Data SQL is :: "+sql);
			result=this.namedParamTemplate.query(sql, parameters,new RecipDataMapper());
			logger.info("Recip Data result is :: "+result);
		}catch(Exception e){
			logger.info("found Exception :: "+e);
		}
		return result;
	}

	@Override
	public int getRecipDataCount(String globalSearch,RecipData recipData){
		try{
			String sql="select count(*) from ddsafm.rc_ib_equipemnt_data_mv a where 1=1 ";
			MapSqlParameterSource parameters = new MapSqlParameterSource(setRecipFilterParams(globalSearch,recipData));
			if(recipData!=null){
				String filter=getRecipFilterClause(recipData);
				sql=sql+filter;
			}	
			if (null !=globalSearch && !globalSearch.trim().isEmpty()) {
				String globalFilterClause = getGlobalFilterClause();			
				sql += " AND " + globalFilterClause;
			}	
			return this.namedParamTemplate.queryForInt(sql, parameters); 
			//logger.error("SQL QUERY COUNT"+sql);
		}catch(Exception e){
			logger.info("found Exception :: "+e);
		}
		return 0;

	}

	/*
	public StatusInfo saveRecipData(RecipData recipData) {
		StatusInfo statusinfo= new StatusInfo();
		try {		
			String sql= "select count(record_id) from ddsafm.rc_ib_equipemnt_data_mv where record_id= ?";
			String saveSql="";
			int count=this.jdbcTemplate.queryForInt(sql, new Object[]{recipData.getRecordId()});
			if(count>0){
				saveSql="update ddsafm.rc_ib_equipemnt_data set staus=?, unit_type=? , model=? where product_key= ?"	;	
				Object[] param={
						recipData.getProductName(),
						productData.getUnitType(),
						productData.getModel(),
						productData.getProductKey()
				};
				this.jdbcTemplate.update(saveSql, param);
			}else{
				sql="Select max(product_key)+1 from ddsafm.rc_product";
				int cnt=this.jdbcTemplate.queryForInt(sql);

				saveSql= "insert into ddsafm.rc_product(product_key,product_name,unit_type,model) "+
						"values (?,?,?,?)";
				Object[] param={
						cnt,
						productData.getProductName(),
						productData.getUnitType(),
						productData.getModel(),
				};
				this.jdbcTemplate.update(saveSql, param);
			}
			statusinfo.setStatusCode(1);
			statusinfo.setStatusMessage("Data saved Successfully"); 
		} catch(Exception ex){
			logger.info("Error occured during saving the Data :: "+ex);
			statusinfo.setStatusCode(-1);
			statusinfo.setStatusMessage(ex.getMessage());
		}
		return statusinfo;
	}	
	 */

	private static final class AccountMapper implements RowMapper<AccountData> {
		public AccountMapper() {
		}
		@Override
		public AccountData mapRow(ResultSet rs, int rowNum) throws SQLException {
			AccountData result = new AccountData();
			int accountId=rs.getInt("manager_key");
			result.setAccountId(null!=String.valueOf(accountId)?String.valueOf(accountId):"");
			result.setAccountName(rs.getString("name"));
			return result;
		}
	}

	private static final class CustomerMapper implements RowMapper<CustomerData> {
		public CustomerMapper() {
		}
		@Override
		public CustomerData mapRow(ResultSet rs, int rowNum) throws SQLException {
			CustomerData result = new CustomerData();
			int customerId=rs.getInt("customer_key");
			result.setCustomerKey(null!=String.valueOf(customerId)?String.valueOf(customerId):"");
			result.setCustomerName(rs.getString("customer_name"));
			result.setEndUserName(rs.getString("end_user_name"));
			result.setStationLocation(rs.getString("station_location"));
			result.setGeLocation(rs.getString("ge_region"));
			result.setCountry(rs.getString("country"));
			result.setStateName(rs.getString("usa_state_name"));

			return result;
		}
	}

	private static final class ProductMapper implements RowMapper<ProductData> {
		public ProductMapper() {
		}
		@Override
		public ProductData mapRow(ResultSet rs, int rowNum) throws SQLException {
			ProductData result = new ProductData();
			int productId=rs.getInt("product_key");
			result.setProductKey(null!=String.valueOf(productId)?String.valueOf(productId):"");
			result.setProductName(rs.getString("product_name"));
			result.setUnitType(rs.getString("unit_type"));
			result.setModel(rs.getString("model"));

			return result;
		}
	}

	private static final class RecipDataMapper implements RowMapper<RecipData> {
		public RecipDataMapper() {
		}
		@Override
		public RecipData mapRow(ResultSet rs, int rowNum) throws SQLException {
			RecipData result = new RecipData();

			try {
				Long customerKey=rs.getLong("CUSTOMER_KEY");
				result.setCustomerKey(null!=String.valueOf(customerKey)?String.valueOf(customerKey):"");
				Long productKey=rs.getLong("PRODUCT_KEY");
				result.setProductKey(null!=String.valueOf(productKey)?String.valueOf(productKey):"");
				Long managerKey=rs.getLong("MANAGER_KEY");
				result.setManagerKey(null!=String.valueOf(managerKey)?String.valueOf(managerKey):"");
				Long recordId=rs.getLong("RECORD_ID");
				result.setRecordId(null!=String.valueOf(recordId)?String.valueOf(recordId):"");
				result.setSerialNumber(rs.getString("SERIAL_NUMBER"));
				result.setStatus(rs.getString("STATUS"));
				result.setLastOverHaulDT(rs.getString("LAST_OVERHAUL_DT"));
				result.setHrsAtLastOverHaul(rs.getString("HRS_AT_LAST_OVERHAUL"));
				result.setNextOverHaulDT(rs.getString("NEXT_OVERHAUL_DT"));
				result.setPartsProvider(rs.getString("PARTS_PROVIDER"));
				result.setFieldServiceProvider(rs.getString("FIELD_SERVICE_PROVIDER"));
				result.setMarketSegment(rs.getString("MARKET_SEGMENT"));
				result.setNoOfCyclinders(rs.getString("NO_OF_CYLINDERS"));
				Long ratedBhp=rs.getLong("RATED_BHP");
				result.setRatedBhp(null!=String.valueOf(ratedBhp)?String.valueOf(ratedBhp):"");
				result.setTurboCharged(rs.getString("TURBO_CHARGED"));
				result.setServiceManager(rs.getString("SERVICE_MANAGER"));
				result.setThirdPartyPartsProvides(rs.getString("THIRDPARTY_PARTS_PROVIDER"));
				result.setThirdPartyFldServProvider(rs.getString("THIRDPARTY_FLD_SERV_PROVIDER"));
				result.setThirdPartyRepairsProvides(rs.getString("THIRDPARTY_REPAIRS_PROVIDER"));
				result.setNotesFuturePlans(rs.getString("NOTES_FUTURE_PLANS"));
				String shortNotes=rs.getString("NOTES_FUTURE_PLANS");
				String shortNotesValue="";
				if(null!=shortNotes && !shortNotes.equals("") ){
					String shortNotesArray[]=shortNotes.trim().split("\\s+");
					if(shortNotesArray.length>4){
						shortNotesValue=shortNotesArray[0]+" "+shortNotesArray[1]+" "+shortNotesArray[2]+" "+shortNotesArray[3]+".....";
						result.setShortNotesFuturePlans(shortNotesValue);
					} else {
						result.setShortNotesFuturePlans(shortNotes);
					}	
				}
				Long noOfActvComprsrThrows=rs.getLong("NO_OF_ACTV_COMPRSR_THROWS");
				result.setNoOfActvComprsrThrows(null!=String.valueOf(noOfActvComprsrThrows)?String.valueOf(noOfActvComprsrThrows):"");
				result.setTurbochargerServiceProvider(rs.getString("TURBOCHARGER_SERVICE_PROVIDER"));
				result.setRetireDt(rs.getString("RETIRE_DT"));
				result.setUtilization2016HST(rs.getString("UTILIZATION_2016_HIST"));
				result.setUtilization2015HST(rs.getString("UTILIZATION_2015_HIST"));
				result.setMaintenancePratice(rs.getString("MAINTENANCE_PRACTICE"));
				result.setDirectInderct(rs.getString("DIRECT_INDERCT"));
			    result.setAccountManagerName(rs.getString("ACCOUNT_MANAGER_NAME"));
				result.setProductName(rs.getString("PRODUCT_NAME"));		
				result.setUnitType(rs.getString("UNIT_TYPE"));
				result.setProductModel(rs.getString("PRODUCT_MODEL"));
				result.setCustomerName(rs.getString("CUSTOMER_NAME"));
				String shortCustomer=rs.getString("CUSTOMER_NAME");
				String shortCustomerValue="";
				if(null!=shortCustomer && !shortCustomer.equals("") ){
					String shortCustomerArray[]=shortCustomer.trim().split("\\s+");
					if(shortCustomerArray.length>3){
						shortCustomerValue=shortCustomerArray[0]+" "+shortCustomerArray[1]+" "+shortCustomerArray[2]+".....";
						result.setShortCustomerName(shortCustomerValue);
					} else {
						result.setShortCustomerName(shortCustomer);
					}	
				}
				result.setEndUserName(rs.getString("END_USER_NAME"));			
				String shortEndUser=rs.getString("END_USER_NAME");
				String shortEndUserValue="";
				if(null!=shortEndUser && !shortEndUser.equals("") ){
					String shortEndUserArray[]=shortEndUser.trim().split("\\s+");
					if(shortEndUserArray.length>3){
						shortEndUserValue=shortEndUserArray[0]+" "+shortEndUserArray[1]+" "+shortEndUserArray[2]+".....";
						result.setShortEndUser(shortEndUserValue);
					} else {
						result.setShortEndUser(shortEndUser);
					}	
				}
				result.setGeRegion(rs.getString("GE_REGION"));
				result.setCountry(rs.getString("COUNTRY"));
				result.setStationLocation(rs.getString("STATION_LOCATION"));
				String shortStationLocation=rs.getString("STATION_LOCATION");
				String shortStationLocationValue="";
				if(null!=shortStationLocation && !shortStationLocation.equals("") ){
					String shortStationLocationArray[]=shortStationLocation.trim().split("\\s+");
					if(shortStationLocationArray.length>3){
						shortStationLocationValue=shortStationLocationArray[0]+" "+shortStationLocationArray[1]+" "+shortStationLocationArray[2]+".....";
						result.setShortStationLocation(shortStationLocationValue);
					} else {
						result.setShortStationLocation(shortStationLocation);
					}	
				}
				result.setUsaStateName(rs.getString("USA_STATE_NAME"));
				// new fields
				//result.setCustomerDunsNo(rs.getString("CUSTOMER_DUNS_NO"));
				result.setCounty(rs.getString("COUNTY"));
				result.setUtilization2017Current(rs.getString("UTILIZATION_2017_CURRENT"));
				result.setUtilization2018Projected(rs.getString("UTILIZATION_2018_PROJECTED"));
				result.setRepairsProvider(rs.getString("REPAIRS_PROVIDER"));
				result.setLastUpdateDate(null!=rs.getDate("LAST_UPDATE_DATE")?String.valueOf(rs.getDate("LAST_UPDATE_DATE")):"");
				result.setTurbochargerMake(rs.getString("TURBOCHARGER_MAKE"));
				result.setTurbochargerModel(rs.getString("TURBOCHARGER_MODEL"));
				result.setDesignCode(rs.getString("DESIGN_CODE"));
			} catch(Exception e){
				logger.info("found Exception :: "+e);
			}

			return result;
		}
	}

	@Override
	public List<EquipmentBoms> getRecipPartData(int pageNo, int rowperpage, RecipData recipData) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getRecipPartsDataCount(RecipData recipData) {
		// TODO Auto-generated method stub
		return 0;
	}


	public String findOutSerialNumbers(RecipData recipData){

		String query="";
		int ratedBhp = 0;
		int noOfActvCompsr = 0;
		//int serviceCaloriesUSD = 0;

		
		if(null != recipData.getRatedBhp() && !recipData.getRatedBhp().equals("")){
			ratedBhp = Integer.valueOf(recipData.getRatedBhp());				
		}
		if(null != recipData.getNoOfActvComprsrThrows() && !recipData.getNoOfActvComprsrThrows().equals("")){
			noOfActvCompsr = Integer.valueOf(recipData.getNoOfActvComprsrThrows());			
		}

		List<String> conditions = new ArrayList<String>();		
		if(recipData.getStatus()!=null && !recipData.getStatus().isEmpty()){
			conditions.add("STATUS ="+"'"+recipData.getStatus()+"'");
		}
		if(recipData.getLastOverHaulDT()!=null && !recipData.getLastOverHaulDT().isEmpty()){
			conditions.add("LAST_OVERHAUL_DT ="+"'"+recipData.getLastOverHaulDT()+"'");
		}
		if(recipData.getHrsAtLastOverHaul()!=null && !recipData.getHrsAtLastOverHaul().isEmpty()){
			conditions.add("HRS_AT_LAST_OVERHAUL ="+"'"+recipData.getHrsAtLastOverHaul()+"'");
		}
		if(recipData.getNextOverHaulDT()!=null && !recipData.getNextOverHaulDT().isEmpty()){
			conditions.add("NEXT_OVERHAUL_DT ="+"'"+recipData.getNextOverHaulDT()+"'");
		}	
		if(recipData.getCustomerKey()!=null && !recipData.getCustomerKey().isEmpty()){
			conditions.add("CUSTOMER_KEY ="+"'"+recipData.getCustomerKey()+"'");
		}
		if(recipData.getProductKey()!=null && !recipData.getProductKey().isEmpty()){
			conditions.add("PRODUCT_KEY ="+"'"+recipData.getProductKey()+"'");
		}
		if(recipData.getManagerKey()!=null && !recipData.getManagerKey().isEmpty()){
			conditions.add("MANAGER_KEY ="+"'"+recipData.getManagerKey()+"'");
		}
		if(recipData.getPartsProvider()!=null && !recipData.getPartsProvider().isEmpty()){
			conditions.add("PARTS_PROVIDER = "+"'"+recipData.getPartsProvider()+"'");
		}
		if(recipData.getFieldServiceProvider()!=null && !recipData.getFieldServiceProvider().isEmpty()){
			conditions.add("FIELD_SERVICE_PROVIDER ="+"'"+recipData.getFieldServiceProvider()+"'");
		}
		if(recipData.getMarketSegment()!=null && !recipData.getMarketSegment().isEmpty()){
			conditions.add("MARKET_SEGMENT="+"'"+recipData.getMarketSegment()+"'");
		}		
		if(recipData.getNoOfCyclinders()!=null && !recipData.getNoOfCyclinders().isEmpty()){
			conditions.add("NO_OF_CYLINDERS="+"'"+recipData.getNoOfCyclinders()+"'");
		}
	
		if(recipData.getRatedBhp()!=null && !recipData.getRatedBhp().isEmpty()){
			conditions.add("RATED_BHP="+ratedBhp);
		}
		if(recipData.getTurboCharged()!=null && !recipData.getTurboCharged().isEmpty()){
			conditions.add("TURBO_CHARGED ="+"'"+recipData.getTurboCharged()+"'");
		}
		if(recipData.getServiceManager()!=null && !recipData.getServiceManager().isEmpty()){
			conditions.add("SERVICE_MANAGER="+"'"+recipData.getServiceManager()+"'");
		}
		if(recipData.getThirdPartyPartsProvides()!=null && !recipData.getThirdPartyPartsProvides().isEmpty()){
			conditions.add("THIRDPARTY_PARTS_PROVIDER="+"'"+recipData.getThirdPartyPartsProvides()+"'");
		}	
		if(recipData.getThirdPartyFldServProvider()!=null && !recipData.getThirdPartyFldServProvider().isEmpty()){
			conditions.add("THIRDPARTY_FLD_SERV_PROVIDER ="+"'"+recipData.getThirdPartyFldServProvider()+"'");
		}
		if(recipData.getThirdPartyRepairsProvides()!=null && !recipData.getThirdPartyRepairsProvides().isEmpty()){
			conditions.add("THIRDPARTY_REPAIRS_PROVIDER ="+"'"+recipData.getThirdPartyRepairsProvides()+"'");
		}
		
		if(recipData.getNotesFuturePlans()!=null && !recipData.getNotesFuturePlans().isEmpty()){
			conditions.add("NOTES_FUTURE_PLANS="+"'"+recipData.getNotesFuturePlans()+"'");
		}
		
		
		if(recipData.getNoOfActvComprsrThrows()!=null && !recipData.getNoOfActvComprsrThrows().isEmpty()){
			conditions.add("NO_OF_ACTV_COMPRSR_THROWS="+noOfActvCompsr);
		}	
		if(recipData.getTurbochargerServiceProvider()!=null && !recipData.getTurbochargerServiceProvider().isEmpty()){
			conditions.add("TURBOCHARGER_SERVICE_PROVIDER="+"'"+recipData.getTurbochargerServiceProvider()+"'");
		}
		
		if(recipData.getPlansToRepairReplace()!=null && !recipData.getPlansToRepairReplace().isEmpty()){
			conditions.add("PLANS_TO_REPAIR_REPLACE="+"'"+recipData.getPlansToRepairReplace()+"'");
		}
		
		if(recipData.getRetireDt()!=null && !recipData.getRetireDt().isEmpty()){
			conditions.add("RETIRE_DT="+"'"+recipData.getRetireDt()+"'");
		}
		if(recipData.getUtilization2016HST()!=null && !recipData.getUtilization2016HST().isEmpty()){
			conditions.add("UTILIZATION_2016_HIST="+"'"+recipData.getUtilization2016HST()+"'");
		}
		if(recipData.getUtilization2015HST()!=null && !recipData.getUtilization2015HST().isEmpty()){
			conditions.add("UTILIZATION_2015_HIST="+"'"+recipData.getUtilization2015HST()+"'");
		}
		if(recipData.getMaintenancePratice()!=null && !recipData.getMaintenancePratice().isEmpty()){
			conditions.add("MAINTENANCE_PRACTICE="+"'"+recipData.getMaintenancePratice()+"'");
		}
		
		if(recipData.getDirectInderct()!=null && !recipData.getDirectInderct().isEmpty()){
			conditions.add("DIRECT_INDERCT="+"'"+recipData.getDirectInderct()+"'");
		}
		
		
		if(recipData.getCounty()!=null && !recipData.getCounty().isEmpty()){
			conditions.add("COUNTY="+"'"+recipData.getCounty()+"'");
		}
		if(recipData.getUtilization2017Current()!=null && !recipData.getUtilization2017Current().isEmpty()){
			conditions.add("UTILIZATION_2017_CURRENT="+"'"+recipData.getUtilization2017Current()+"'");
		}
		if(recipData.getUtilization2018Projected()!=null && !recipData.getUtilization2018Projected().isEmpty()){
			conditions.add("UTILIZATION_2018_PROJECTED="+"'"+recipData.getUtilization2018Projected()+"'");
		}
		if(recipData.getRepairsProvider()!=null && !recipData.getRepairsProvider().isEmpty()){
			conditions.add("REPAIRS_PROVIDER="+"'"+recipData.getRepairsProvider()+"'");
		}
		
		Calendar currenttime = Calendar.getInstance();
		Date sqldate = new Date((currenttime.getTime()).getTime());
		//conditions.add("UPGRADE_DATE="+sqldate);		
		

	
			conditions.add("TURBOCHARGER_MAKE="+"'"+recipData.getTurbochargerMake()+"'");

			conditions.add("TURBOCHARGER_MODEL="+"'"+recipData.getTurbochargerModel()+"'");

			conditions.add("DESIGN_CODE="+"'"+recipData.getDesignCode()+"'");

		logger.error("Size of condition" + conditions.size() );

		for(String ce:conditions){
			logger.error("Size of condition" + ce.toString() );
		}

		if (conditions.size() > 0) {
			String condStr = "";
			condStr+=conditions.get(0);
			for (int i = 1; i < conditions.size(); i++) {
				condStr += ","+ conditions.get(i);
			}

			query = condStr;
		}

		return query;

	}



@Override
public StatusInfo updateRecipdata(RecipData recipData) {	
	StatusInfo statusinfo= new StatusInfo();
	String[] allSerialNumbers = recipData.getSerialNumber().split(",");
	for(String i:allSerialNumbers){
		logger.error("Serial Number"+i);
	}
	logger.error("The length of serial Numbers" + allSerialNumbers.length);
	if(allSerialNumbers.length > 1)
	{
		for(int s=0; s<allSerialNumbers.length;s++){
			try {		
				String saveSqlFirst="update ddsafm.rc_ib_equipemnt_data set";
				String saveSqlSecond=findOutSerialNumbers(recipData);				
				String saveSqlThird=" where SERIAL_NUMBER = ? ";
				String finalSql= saveSqlFirst + " " + saveSqlSecond + " " +  saveSqlThird;
				Object[] param={	
						allSerialNumbers[s].trim()
				};

				//logger.error("Final SQL" + s + "  " +finalSql);
				this.jdbcTemplate.update(finalSql, param);
				logger.error("Saving the Recip data in Mass Update");
				statusinfo.setStatusCode(1);
				statusinfo.setStatusMessage("Data saved Successfully"); 
			} catch(Exception ex){
				logger.error("Error occured during saving recip data in Mass Update :: "+ex);
				statusinfo.setStatusCode(-1);
				statusinfo.setStatusMessage(ex.getMessage());
			}	

		}			
	} else {
		try {		
			/*String saveSql="update ddsafm.rc_ib_equipemnt_data set STATUS = ? , LAST_OVERHAUL_DT = ? , HRS_AT_LAST_OVERHAUL = ? , NEXT_OVERHAUL_DT = ? , "
					+ " PARTS_PROVIDER = ? , FIELD_SERVICE_PROVIDER = ? , MARKET_SEGMENT = ? , NO_OF_CYLINDERS = ? , NO_OF_COMPRESSOR_THROWS = ? , RATED_BHP = ? , "
					+ " TURBO_CHARGED = ? , SERVICE_MANAGER = ? , THIRDPARTY_PARTS_PROVIDER = ? , THIRDPARTY_FLD_SERV_PROVIDER = ? , THIRDPARTY_REPAIRS_PROVIDER = ? , "
					+ " CONTRACT_NUMBER = ? , NOTES_FUTURE_PLANS = ? , REGULATED_EMISSIONS = ? , OTHER_MARKET_SEGMENT = ? , NO_OF_ACTV_COMPRSR_THROWS = ? , TURBOCHARGER_SERVICE_PROVIDER = ? , "
					+ " UPGRADED_FLAG = ? , PLANS_TO_REPAIR_REPLACE = ? , REPLACE_DT = ? , RETIRE_DT = ? , UTILIZATION_2016_HIST = ? , UTILIZATION_2015_HIST = ? , "
					+ " MAINTENANCE_PRACTICE = ? , OTHER_MAINTENANCE_PRACTICE = ? , DIRECT_INDERCT = ? , CHANNEL_PARTNER = ?, DIRECT_CHANNEL_PARTNER = ? , "
					+ " EQPMENT_PACKGR = ? , COUNTY = ?, UTILIZATION_2017_CURRENT=? , UTILIZATION_2018_PROJECTED = ? , REPAIRS_PROVIDER = ?,"
					+ " SERVICE_CALORIES_USD = ? , UPGRADED_BY = ? , CUSTOMER_KEY = ? , PRODUCT_KEY = ? , MANAGER_KEY = ? , LAST_UPDATE_DATE=? where SERIAL_NUMBER = ? ";
			int ratedBhp = 0;
			int noOfActvCompsr = 0;
			int serviceCaloriesUSD = 0;
			Calendar currenttime = Calendar.getInstance();
			Date sqldate = new Date((currenttime.getTime()).getTime()); 
				java.util.Date date=null;
			java.sql.Date sqlDateSaveNew=null;	
			if(null!=recipData.getUpgradeDate() && !("".equals(recipData.getUpgradeDate())) ){
				date = new SimpleDateFormat("yyyy-MM-dd").parse(recipData.getUpgradeDate());
				sqlDateSaveNew = new java.sql.Date(date.getTime());
			}
			if(null != recipData.getServiceCaloriesUSD() && !recipData.getServiceCaloriesUSD().equals("")){
				serviceCaloriesUSD = Integer.valueOf(recipData.getServiceCaloriesUSD());				
			}
			if(null != recipData.getRatedBhp() && !recipData.getRatedBhp().equals("")){
				ratedBhp = Integer.valueOf(recipData.getRatedBhp());				
			}
			if(null != recipData.getNoOfActvComprsrThrows() && !recipData.getNoOfActvComprsrThrows().equals("")){
				noOfActvCompsr = Integer.valueOf(recipData.getNoOfActvComprsrThrows());			
			}
			Object[] param={	
					recipData.getStatus(),
					recipData.getLastOverHaulDT(),
					recipData.getHrsAtLastOverHaul(),
					recipData.getNextOverHaulDT(),
					recipData.getPartsProvider(),
					recipData.getFieldServiceProvider(),
					recipData.getMarketSegment(),
					recipData.getNoOfCyclinders(),
					recipData.getNoOfCompressorThrows(),
					ratedBhp,
					recipData.getTurboCharged(),
					recipData.getServiceManager(),
					recipData.getThirdPartyPartsProvides(),
					recipData.getThirdPartyFldServProvider(),
					recipData.getThirdPartyRepairsProvides(),
					recipData.getContractNumber(),
					recipData.getNotesFuturePlans(),
					recipData.getRegulatedEmissions(),
					recipData.getOtherMarketSegment(),
					noOfActvCompsr,
					recipData.getTurbochargerServiceProvider(),
					recipData.getUpgradeFlag(),
					recipData.getPlansToRepairReplace(),
					recipData.getReplaceDt(),
					recipData.getRetireDt(),
					recipData.getUtilization2016HST(),
					recipData.getUtilization2015HST(),
					recipData.getMaintenancePratice(),
					recipData.getOtherMaintenancePratice(),
					recipData.getDirectInderct(),
					recipData.getChannelPartner(),
					recipData.getDirectChannelPartner(),
					recipData.getEqpmentPackgr(),
					//new 
					recipData.getCounty(),
					recipData.getUtilization2017Current(),
					recipData.getUtilization2018Projected(),
					recipData.getRepairsProvider(),
					serviceCaloriesUSD,
					sqlDateSaveNew,
					recipData.getUpgradedBy(),
					recipData.getCustomerKey(),
					recipData.getProductKey(),
					recipData.getManagerKey(),
					sqldate,
					recipData.getSerialNumber()	
			};
			this.jdbcTemplate.update(saveSql, param);*/	
			String saveSqlFirst="update ddsafm.rc_ib_equipemnt_data set";
			String saveSqlSecond=findOutSerialNumbers(recipData);				
			String saveSqlThird=" where SERIAL_NUMBER = ? ";
			String finalSql= saveSqlFirst + " " + saveSqlSecond + " " +  saveSqlThird;
			Object[] param={	
					recipData.getSerialNumber().trim()
			};

			//logger.error("Final SQL" + s + "  " +finalSql);
			this.jdbcTemplate.update(finalSql, param);

			logger.error("saving the Data recip data");
			statusinfo.setStatusCode(1);
			statusinfo.setStatusMessage("Data saved Successfully"); 
		} catch(Exception ex){
			logger.error("Error occured during saving the Data :: "+ex);
			statusinfo.setStatusCode(-1);
			statusinfo.setStatusMessage(ex.getMessage());
		}		
	}

	return statusinfo;
}


	@Override
	public StatusInfo addRecipdata(RecipData recipData) {	
		StatusInfo statusinfo= new StatusInfo();
		try{			
			//  check whether the Serial Number exist		
			String sqlCheck="select count(*) from ddsafm.rc_ib_equipemnt_data a where serial_number = ?";
			int countRecip = this.jdbcTemplate.queryForInt(sqlCheck, new Object[]{recipData.getSerialNumber()});
			if(countRecip>0){
				statusinfo.setStatusCode(2);
				statusinfo.setStatusMessage("The record already exist");
				logger.error("After checking the duplicacy");
				return statusinfo;
			}	
			String saveSql="insert into ddsafm.rc_ib_equipemnt_data(SERIAL_NUMBER,STATUS,LAST_OVERHAUL_DT,HRS_AT_LAST_OVERHAUL,NEXT_OVERHAUL_DT,"
					+ " PARTS_PROVIDER,FIELD_SERVICE_PROVIDER,MARKET_SEGMENT,NO_OF_CYLINDERS,RATED_BHP,"
					+ " TURBO_CHARGED,SERVICE_MANAGER,THIRDPARTY_PARTS_PROVIDER,THIRDPARTY_FLD_SERV_PROVIDER,THIRDPARTY_REPAIRS_PROVIDER,"
					+ " NOTES_FUTURE_PLANS,NO_OF_ACTV_COMPRSR_THROWS,TURBOCHARGER_SERVICE_PROVIDER,"
					+ " PLANS_TO_REPAIR_REPLACE,RETIRE_DT,UTILIZATION_2016_HIST,UTILIZATION_2015_HIST,"
					+ " MAINTENANCE_PRACTICE,DIRECT_INDERCT,"
					+ " COUNTY,UTILIZATION_2017_CURRENT,UTILIZATION_2018_PROJECTED,REPAIRS_PROVIDER,"
					+ " CUSTOMER_KEY,PRODUCT_KEY,MANAGER_KEY,LAST_UPDATE_DATE,TURBOCHARGER_MAKE,TURBOCHARGER_MODEL,DESIGN_CODE) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,"
					+ "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			int ratedBhp = 0;
			int noOfActvCompsr = 0;
			//int serviceCaloriesUSD = 0;
			Calendar currenttime = Calendar.getInstance();
			Date sqldate = new Date((currenttime.getTime()).getTime()); 
			/*if(null != recipData.getServiceCaloriesUSD() && !recipData.getServiceCaloriesUSD().equals("")){
				serviceCaloriesUSD = Integer.valueOf(recipData.getServiceCaloriesUSD());				
			}*/
			if(null != recipData.getRatedBhp() && !recipData.getRatedBhp().equals("")){
				ratedBhp = Integer.valueOf(recipData.getRatedBhp());				
			}
			if(null != recipData.getNoOfActvComprsrThrows() && !recipData.getNoOfActvComprsrThrows().equals("")){
				noOfActvCompsr = Integer.valueOf(recipData.getNoOfActvComprsrThrows());			
			}
			Object[] param={	
					recipData.getSerialNumber(),
					recipData.getStatus(),
					recipData.getLastOverHaulDT(),
					recipData.getHrsAtLastOverHaul(),
					recipData.getNextOverHaulDT(),
					recipData.getPartsProvider(),
					recipData.getFieldServiceProvider(),
					recipData.getMarketSegment(),
					recipData.getNoOfCyclinders(),
					ratedBhp,
					recipData.getTurboCharged(),
					recipData.getServiceManager(),
					recipData.getThirdPartyPartsProvides(),
					recipData.getThirdPartyFldServProvider(),
					recipData.getThirdPartyRepairsProvides(),
					recipData.getNotesFuturePlans(),
					noOfActvCompsr,
					recipData.getTurbochargerServiceProvider(),
			        recipData.getPlansToRepairReplace(),
				    recipData.getRetireDt(),
					recipData.getUtilization2016HST(),
					recipData.getUtilization2015HST(),
					recipData.getMaintenancePratice(),
                    recipData.getDirectInderct(),
			
					//new 
					recipData.getCounty(),
					recipData.getUtilization2017Current(),
					recipData.getUtilization2018Projected(),
					recipData.getRepairsProvider(),
					
					/*sqlDateSaveNew,*/
			
					recipData.getCustomerKey(),
					recipData.getProductKey(),
					recipData.getManagerKey(),
					sqldate,
					recipData.getTurbochargerMake(),
					recipData.getTurbochargerModel(),
					recipData.getDesignCode()
			};
			this.jdbcTemplate.update(saveSql, param);
			logger.error("adding recip data");
			statusinfo.setStatusCode(1);
			statusinfo.setStatusMessage("Data saved Successfully"); 
		} catch(Exception ex){
			logger.error("Error occured during Adding recip data :: "+ex);
			statusinfo.setStatusCode(-1);
			statusinfo.setStatusMessage(ex.getMessage());
		}	
		return statusinfo;
	}

	@Override
	public List<TurboChargerDetail> getTurboChargerValues() {
	//	String query = "select TURBOCHARGER_MAKE,TURBOCHARGER_MODEL from DDSAFM.RC_TURBOCHARGER group by TURBOCHARGER_MAKE,TURBOCHARGER_MODEL";
		String query = "select * from DDSAFM.RC_TURBOCHARGER";
		List<TurboChargerDetail> turboDetails = new ArrayList<>();
		try{
			logger.info("inside getTurboChargerValues");
			turboDetails = jdbcTemplate.query(query, new TurboChargerMapper());
		}catch(Exception ex){
		  logger.error("error occured in turboCharger :"+ex);	
		}
		return turboDetails;
	}


	private static final class TurboChargerMapper implements RowMapper<TurboChargerDetail> {
		public TurboChargerMapper() {
		}
		@Override
		public TurboChargerDetail mapRow(ResultSet rs, int rowNum) throws SQLException {
			TurboChargerDetail result = new TurboChargerDetail();
			result.setTurbochargerMake(rs.getString("TURBOCHARGER_MAKE"));
			result.setTurbochargerModel(rs.getString("TURBOCHARGER_MODEL"));
			return result;
		}
	}



}
