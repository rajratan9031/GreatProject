package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;

public class DropDownItem implements Serializable {
	private static final long serialVersionUID = 4253745981939637720L;
	private String text;
	private String value;

	public String getText() {
		return this.text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
