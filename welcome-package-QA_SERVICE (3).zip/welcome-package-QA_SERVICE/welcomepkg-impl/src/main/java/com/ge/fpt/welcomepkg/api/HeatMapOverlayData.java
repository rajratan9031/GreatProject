package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class HeatMapOverlayData implements Serializable{
/**
	 * 
	 */
	private static final long serialVersionUID = 8053810140725851039L;
private List<GeoMapping> geoMappingList;
private Map<String,List<Map<String,List<InstallBaseLoc>>>> locWithDuns;
private Map<String,List<Map<String,List<InstallBaseLoc>>>> countyMap;

public Map<String, List<Map<String, List<InstallBaseLoc>>>> getCountyMap() {
	return countyMap;
}
public void setCountyMap(Map<String, List<Map<String, List<InstallBaseLoc>>>> countyMap) {
	this.countyMap = countyMap;
}
private Map<String,List<County>> channels;
//private Map<String,List<GeoMapping>> heatMapData;
private List<GeoMapping> heatMapData;

public List<GeoMapping> getHeatMapData() {
	return heatMapData;
}
public void setHeatMapData(List<GeoMapping> heatMapData) {
	this.heatMapData = heatMapData;
}
/*public Map<String, List<GeoMapping>> getHeatMapData() {
	return heatMapData;
}
public void setHeatMapData(Map<String, List<GeoMapping>> heatMapData) {
	this.heatMapData = heatMapData;
}*/
public Map<String, List<County>> getChannels() {
	return channels;
}
public void setChannels(Map<String, List<County>> channels) {
	this.channels = channels;
}

public List<GeoMapping> getGeoMappingList() {
	return geoMappingList;
}
public void setGeoMappingList(List<GeoMapping> geoMappingList) {
	this.geoMappingList = geoMappingList;
}
public Map<String,List<Map<String,List<InstallBaseLoc>>>> getLocWithDuns() {
	return locWithDuns;
}
public void setLocWithDuns(Map<String,List<Map<String,List<InstallBaseLoc>>>> locWithDuns) {
	this.locWithDuns = locWithDuns;
}

}
