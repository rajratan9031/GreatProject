package com.ge.fpt.welcomepkg.persistence;

import java.util.List;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ge.fpt.welcomepkg.api.CountryDTO;
import com.ge.fpt.welcomepkg.api.CustomerSqtLinkT;
import com.ge.fpt.welcomepkg.api.CustomerMgmtMaster;
import com.ge.fpt.welcomepkg.api.LinkingMasterTO;
import com.ge.fpt.welcomepkg.api.PlantDataMaster;
import com.ge.fpt.welcomepkg.api.Region_Data;

public interface ICustomermgmtMasterPersistence {
	@Transactional(propagation=Propagation.REQUIRED)
	public List<CustomerMgmtMaster> getcustomermgmt();

	public CustomerMgmtMaster getCustomerById(int custId);

	public CustomerSqtLinkT getcustomersqtbySerialNo(String serialNo);
	
	public List<Region_Data> getRegionCoutryStatesDetails(); 

	public List<CountryDTO> getCoutryList(); 

}
