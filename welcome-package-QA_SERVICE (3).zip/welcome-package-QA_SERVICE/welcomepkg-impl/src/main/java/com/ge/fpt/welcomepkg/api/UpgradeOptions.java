package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.List;

public class UpgradeOptions implements Serializable{
	
	private static final long serialVersionUID = -5579178899880989818L;
	private String optionId;
	private String optionName;
	private String optionValue;
	private String upgradeId;
	private String optionDescription;
	private List<UpgradeOptionDetails> upgradeOptionDetails;
	private List<UpgradePromotions> upgradePromotions;
	private List<UpgradeDocument> upgradeDocument;
	private String kitNumber;
	private String docCount;
	private String discountedAmount;
	
	
	

	public String getDiscountedAmount() {
		return discountedAmount;
	}
	public void setDiscountedAmount(String discountedAmount) {
		this.discountedAmount = discountedAmount;
	}
	public String getDocCount() {
		return docCount;
	}
	public void setDocCount(String docCount) {
		this.docCount = docCount;
	}
	public String getOptionId() {
		return optionId;
	}
	public void setOptionId(String optionId) {
		this.optionId = optionId;
	}
	public String getOptionName() {
		return optionName;
	}
	public void setOptionName(String optionName) {
		this.optionName = optionName;
	}
	public String getOptionValue() {
		return optionValue;
	}
	public void setOptionValue(String optionValue) {
		this.optionValue = optionValue;
	}
	public String getUpgradeId() {
		return upgradeId;
	}
	public void setUpgradeId(String upgradeId) {
		this.upgradeId = upgradeId;
	}
	public String getOptionDescription() {
		return optionDescription;
	}
	public void setOptionDescription(String optionDescription) {
		this.optionDescription = optionDescription;
	}
	public List<UpgradeOptionDetails> getUpgradeOptionDetails() {
		return upgradeOptionDetails;
	}
	public void setUpgradeOptionDetails(List<UpgradeOptionDetails> upgradeOptionDetails) {
		this.upgradeOptionDetails = upgradeOptionDetails;
	}

	public String getKitNumber() {
		return kitNumber;
	}
	public void setKitNumber(String kitNumber) {
		this.kitNumber = kitNumber;
	}
/*	public String getDocCount() {
		return docCount;
	}
	public void setDocCount(String docCount) {
		this.docCount = docCount;
	}*/
	
	
	public List<UpgradePromotions> getUpgradePromotions() {
		return upgradePromotions;
	}
	public void setUpgradePromotions(List<UpgradePromotions> upgradePromotions) {
		this.upgradePromotions = upgradePromotions;
	}
	public List<UpgradeDocument> getUpgradeDocument() {
		return upgradeDocument;
	}
	public void setUpgradeDocument(List<UpgradeDocument> upgradeDocument) {
		this.upgradeDocument = upgradeDocument;
	}
	@Override
	public String toString() {
		return "UpgradeOptions [optionId=" + optionId + ", optionName=" + optionName + ", optionValue=" + optionValue
				+ ", upgradeId=" + upgradeId + ", optionDescription=" + optionDescription + ", upgradeOptionDetails="
				+ upgradeOptionDetails + ", upgradePromotions=" + upgradePromotions + ", upgradeDocument="
				+ upgradeDocument + ", kitNumber=" + kitNumber + "]";
	}
	
	
	

}
