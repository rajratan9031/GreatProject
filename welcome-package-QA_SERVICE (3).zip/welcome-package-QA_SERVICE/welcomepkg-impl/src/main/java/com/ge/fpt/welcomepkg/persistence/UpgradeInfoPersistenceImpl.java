package com.ge.fpt.welcomepkg.persistence;

import java.io.ByteArrayOutputStream;
import java.nio.charset.Charset;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.activation.CommandMap;
import javax.activation.DataHandler;
import javax.activation.MailcapCommandMap;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.sql.DataSource;

import org.apache.commons.io.IOUtils;
import org.apache.openjpa.lib.util.Bytes;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.ge.fpt.welcomepkg.api.CPPromotionalCartData;
import com.ge.fpt.welcomepkg.api.CPUpgradeDetailSMIView;
import com.ge.fpt.welcomepkg.api.CPUpgradeDetailView;
import com.ge.fpt.welcomepkg.api.CPUpgradeDocument;
import com.ge.fpt.welcomepkg.api.CPUpgradeInfo;
import com.ge.fpt.welcomepkg.api.CPUpgradePackage;
import com.ge.fpt.welcomepkg.api.CPUpgradeParts;
import com.ge.fpt.welcomepkg.api.DropDownItem;
import com.ge.fpt.welcomepkg.api.EmailNotification;
import com.ge.fpt.welcomepkg.api.EquipmentBoms;
import com.ge.fpt.welcomepkg.api.PromotionalCart;
import com.ge.fpt.welcomepkg.api.PromotionalCartViewData;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.api.UpgradeDocument;
import com.ge.fpt.welcomepkg.api.UpgradeInfo;
import com.ge.fpt.welcomepkg.api.UpgradeInfoNew;
import com.ge.fpt.welcomepkg.api.UpgradeInfoNewDTO;
import com.ge.fpt.welcomepkg.api.UpgradeOptionDetails;
import com.ge.fpt.welcomepkg.api.UpgradeOptionListDTO;
import com.ge.fpt.welcomepkg.api.UpgradeOptions;
import com.ge.fpt.welcomepkg.api.UpgradePartModel;
import com.ge.fpt.welcomepkg.api.UpgradePromotions;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;
import com.ge.fpt.welcomepkg.impl.WelcomePkgServiceImpl;
import com.ge.fpt.welcomepkg.util.QueryConstants;
import com.sun.istack.ByteArrayDataSource;

public class UpgradeInfoPersistenceImpl implements IUpgradeInfoPersistence {
	public static final String LOGO_IMAGE_LINK = "/WEB-INF/images/email.png";
	public static final String EMAIL_FOOTER = "/WEB-INF/images/emailfooter.png";
	@SuppressWarnings("javadoc")
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory.getLogger(UpgradeInfoPersistenceImpl.class);
	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;
	/**
	 * Data source for the JDBC
	 */
	javax.sql.DataSource dataSource;
	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;
	NamedParameterJdbcTemplate namedParamTemplate;

	/**
	 * @return the dataSource
	 */
	public javax.sql.DataSource getDataSource() {
		return this.dataSource;
	}

	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate = new NamedParameterJdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	public String getFilterUpgradeInfoClause(UpgradeInfo upgradeInfo) {
		String filter = "";
		List<String> conditions = new ArrayList<String>();
		if (upgradeInfo != null) {
			if (upgradeInfo.getUpgradeName() != null && !upgradeInfo.getUpgradeName().isEmpty()) {
				conditions.add(" UPPER(UPGRADE_ID) LIKE '%' || :upgradeId || '%'");
			}
			if (upgradeInfo.getUpgradeName() != null && !upgradeInfo.getUpgradeName().isEmpty()) {
				conditions.add(" UPPER(UPGRADE_NAME) LIKE '%' || :upgradeName || '%'");
			}
			if (upgradeInfo.getUpgradeBrand() != null && !upgradeInfo.getUpgradeBrand().isEmpty()) {
				conditions.add(" UPPER(BRAND) LIKE '%' || :upgradeBrand || '%'");
			}
			if (upgradeInfo.getUpgradeDescription() != null && !upgradeInfo.getUpgradeDescription().isEmpty()) {
				conditions.add(" UPPER(DESCRIPTION) LIKE '%' || :upgradeDescription || '%'");
			}
			if (upgradeInfo.getUpgradeModel() != null && !upgradeInfo.getUpgradeModel().isEmpty()) {
				conditions.add(" UPPER(MODEL) LIKE '%' || :upgradeModel || '%'");
			}
			if (upgradeInfo.getUpgradePart() != null && !upgradeInfo.getUpgradePart().isEmpty()) {
				conditions.add(" UPPER(PART_ID) LIKE '%' || :upgradePart || '%'");
			}
			if (upgradeInfo.getCouponCode() != null && !upgradeInfo.getCouponCode().isEmpty()) {
				conditions.add(" UPPER(COUPON_CODE) LIKE '%' || :couponCode || '%'");
			}
			if (upgradeInfo.getRegion() != null && !upgradeInfo.getRegion().isEmpty()) {
				conditions.add(" UPPER(REGION) LIKE '%' || :region || '%'");
			}
		}
		if (conditions.size() > 0) {
			String condStr = "";

			for (int i = 0; i < conditions.size(); i++) {
				condStr += (" AND " + conditions.get(i));
			}

			filter = condStr;
		}
		return filter;
	}

	public String getFilterUpgradeOptionsClause(UpgradeOptions upgradeOptions) {
		String filter = "";
		List<String> conditions = new ArrayList<String>();
		if (upgradeOptions != null) {
			if (upgradeOptions.getOptionName() != null && !upgradeOptions.getOptionName().isEmpty()) {
				conditions.add(" UPPER(NAME) LIKE '%' || :optionName || '%'");
			}
			if (upgradeOptions.getOptionValue() != null && !upgradeOptions.getOptionValue().isEmpty()) {
				conditions.add(" UPPER(VALUE) LIKE '%' || :optionValue || '%'");
			}
			if (upgradeOptions.getOptionDescription() != null && !upgradeOptions.getOptionDescription().isEmpty()) {
				conditions.add(" UPPER(DESCRIPTION) LIKE '%' || :optionDescription || '%'");
			}
			if (upgradeOptions.getUpgradeId() != null && !upgradeOptions.getUpgradeId().isEmpty()) {
				conditions.add(" UPGRADE_ID = " + upgradeOptions.getUpgradeId());
			}
		}
		if (conditions.size() > 0) {
			String condStr = "";

			for (int i = 0; i < conditions.size(); i++) {
				condStr += (" AND " + conditions.get(i));
			}

			filter = condStr;
		}
		return filter;
	}

	public Map<String, String> setFilterUpgradeInfoParams(UpgradeInfo upgradeInfo) {
		Map<String, String> result = new HashMap<String, String>();
		result.put("upgradeId", upgradeInfo.getUpgradeId() == null ? "" : upgradeInfo.getUpgradeId().toUpperCase());
		result.put("upgradeName",
				upgradeInfo.getUpgradeName() == null ? "" : upgradeInfo.getUpgradeName().toUpperCase());
		result.put("upgradeBrand",
				upgradeInfo.getUpgradeBrand() == null ? "" : upgradeInfo.getUpgradeBrand().toUpperCase());
		result.put("upgradeDescription",
				upgradeInfo.getUpgradeDescription() == null ? "" : upgradeInfo.getUpgradeDescription().toUpperCase());
		result.put("upgradeModel",
				upgradeInfo.getUpgradeModel() == null ? "" : upgradeInfo.getUpgradeModel().toUpperCase());
		result.put("upgradePart",
				upgradeInfo.getUpgradePart() == null ? "" : upgradeInfo.getUpgradePart().toUpperCase());
		result.put("couponCode", upgradeInfo.getCouponCode() == null ? "" : upgradeInfo.getCouponCode().toUpperCase());
		result.put("region", upgradeInfo.getRegion() == null ? "" : upgradeInfo.getRegion().toUpperCase());
		return result;
	}

	public Map<String, String> setFilterUpgradeOptionsParams(UpgradeOptions upgradeOptions) {
		Map<String, String> result = new HashMap<String, String>();
		result.put("optionId", upgradeOptions.getOptionId() == null ? "" : upgradeOptions.getOptionId().toUpperCase());
		result.put("upgradeId",
				upgradeOptions.getUpgradeId() == null ? "" : upgradeOptions.getUpgradeId().toUpperCase());
		result.put("optionName",
				upgradeOptions.getOptionName() == null ? "" : upgradeOptions.getOptionName().toUpperCase());
		result.put("optionValue",
				upgradeOptions.getOptionValue() == null ? "" : upgradeOptions.getOptionValue().toUpperCase());
		result.put("optionDescription", upgradeOptions.getOptionDescription() == null ? ""
				: upgradeOptions.getOptionDescription().toUpperCase());
		return result;
	}

	/*
	 * @Override public Boolean getModelData(String model) { try{ if(null!=model
	 * && !model.equals("")){ String sql=
	 * "select count(*) from ddsafm.sqt_valve_info_t where product_model=?"; int
	 * count=this.jdbcTemplate.queryForInt(sql,new Object[]{model});
	 * if(count!=0){ return true; } else { return false; } } } catch (Exception
	 * e) { logger.error("Exception in getModelData"+e.getLocalizedMessage()); }
	 * return false; }
	 */

	@Override
	public Boolean getPartOrModelData(Object partModel) {
		UpgradePartModel upgradePartModel = null;
		UpgradeOptionDetails optionDetails = null;
		try {
			if (partModel instanceof UpgradePartModel) {
				upgradePartModel = (UpgradePartModel) partModel;
			} else if (partModel instanceof UpgradeOptionDetails) {
				optionDetails = (UpgradeOptionDetails) partModel;
			}
			if (null != upgradePartModel) {
				return ValidatePartOrModelNew(upgradePartModel.getPartModel(), upgradePartModel.getIndicator());
			} else if (null != optionDetails) {
				return ValidatePartOrModelNew(optionDetails.getPartModel(), optionDetails.getIndicator());
			}

		} catch (Exception e) {
			logger.error("Exception in getPartData" + e.getLocalizedMessage());
		}
		return false;
	}

	private Boolean ValidatePartOrModel(String partModel, String indicator) {
		if (null != partModel && !("").equalsIgnoreCase(partModel)) {
			String sql = null;
			if ("Model".equalsIgnoreCase(indicator))
				sql = "select count(*) from ddsafm.sqt_valve_info_t where product_model=?";
			else if ("Part".equalsIgnoreCase(indicator))
				sql = "select count(*) from ddsafm.sqt_part_info_t where item_number=?";
			int count = this.jdbcTemplate.queryForInt(sql, new Object[] { partModel.trim() });
			if (count != 0) {
				return true;
			} else {
				return false;
			}
		}
		return false;
	}

	@Override
	public int getUpgradeDetailsCount(UpgradeInfo upgradeInfo) {
		int result = 0;
		try {
			String sql = "select count(*) from ddsafm.sqt_upgrade_info a where 1=1";
			MapSqlParameterSource parameters = new MapSqlParameterSource(setFilterUpgradeInfoParams(upgradeInfo));
			if (upgradeInfo != null) {
				String filter = getFilterUpgradeInfoClause(upgradeInfo);
				sql = sql + filter;
			}
			result = this.namedParamTemplate.queryForInt(sql, parameters);
		} catch (Exception e) {
			logger.error("Exception in getUpgradeDetailsCount" + e.getLocalizedMessage());
		}
		return result;
	}

	@Override
	public List<UpgradeInfo> getUpgradeDetailsData(int pageNo, int rowsPerPage, UpgradeInfo upgradeInfo) {
		List<UpgradeInfo> result = new ArrayList<UpgradeInfo>();
		List<UpgradeInfo> finalResults = new ArrayList<UpgradeInfo>();
		try {
			/*
			 * String sql=
			 * "select upgrade_id,upgrade_name,brand,description,model,part_id,coupon_code,region,validity_from,validity_to "
			 * +
			 * "from (select rownum as rnum, a.* from ddsafm.sqt_upgrade_info a where 1=1"
			 * ;
			 */
			String sql = "select * " + "from (select rownum as rnum, a.* from ddsafm.sqt_upgrade_info a where 1=1";

			MapSqlParameterSource parameters = new MapSqlParameterSource(setFilterUpgradeInfoParams(upgradeInfo));
			if (upgradeInfo != null) {
				String filter = getFilterUpgradeInfoClause(upgradeInfo);
				sql = sql + filter;
			}
			sql += ")";
			if (rowsPerPage > 0) {

				int lowerLimit = rowsPerPage * pageNo;
				int upperLimit = lowerLimit + rowsPerPage;

				String pageLimitClause = " where rnum >:lowerLimit AND rnum <=:upperLimit";
				parameters.addValue("lowerLimit", lowerLimit);
				parameters.addValue("upperLimit", upperLimit);
				sql += pageLimitClause;

			}
			result = this.namedParamTemplate.query(sql, parameters, new UpgradeInfoMapper());
			for (UpgradeInfo upgradeInfoItems : result) {
				String sqlForUpgradePartModel = "select * from ddsafm.sqt_upgrade_legacy_pn_model where upgrade_id=:upgradeId";
				MapSqlParameterSource paramMap = new MapSqlParameterSource();
				paramMap.addValue("upgradeId", upgradeInfoItems.getUpgradeId());
				List<UpgradePartModel> upgradeOptionDetailsResult = this.namedParamTemplate
						.query(sqlForUpgradePartModel, paramMap, new UpgradeOptionsPartModelMapper());
				upgradeInfoItems.setUpgradePartModel(upgradeOptionDetailsResult);
				finalResults.add(upgradeInfoItems);
			}

		} catch (Exception e) {
			logger.error("Exception in getUpgradeDetailsData" + e.getLocalizedMessage());
		}
		return finalResults;
	}

	@Override
	public StatusInfo saveUpgradeDetails(UpgradeInfo upgradeInfo) {
		TransactionDefinition transDef = new DefaultTransactionDefinition();
		TransactionStatus saveUpgradeDetailsTM = txManager.getTransaction(transDef);
		StatusInfo statusinfo = new StatusInfo();
		try {
			String sql = "select count(upgrade_id) from ddsafm.sqt_upgrade_info where upgrade_id=?";
			String saveSql = "";
			int count = this.jdbcTemplate.queryForInt(sql, new Object[] { upgradeInfo.getUpgradeId() });
			List<String> invalidEntries = new ArrayList<String>();
			if (count > 0) {
				/*
				 * byte[] promoFileDecoded=
				 * Base64.decodeBase64(upgradeInfo.getPromo_file());
				 */
				saveSql = "update ddsafm.sqt_upgrade_info set brand=?,description=?,model=?,part_id=?,coupon_code=?,region=?,validity_from=?,validity_to=?,promo_file=?,promo_name=? "
						+ "where upgrade_id=?";
				Object[] param = { upgradeInfo.getUpgradeBrand(), upgradeInfo.getUpgradeDescription(),
						upgradeInfo.getUpgradeModel(), upgradeInfo.getUpgradePart(), upgradeInfo.getCouponCode(),
						upgradeInfo.getRegion(), upgradeInfo.getValidityFrom(), upgradeInfo.getValidityTo(),
						upgradeInfo.getPromo_file(), upgradeInfo.getPromo_name(), upgradeInfo.getUpgradeId() };
				this.jdbcTemplate.update(saveSql, param);
				String sqlDelete = "delete from ddsafm.sqt_upgrade_legacy_pn_model where upgrade_id=?";
				int upgradeIdInt = Integer.parseInt(upgradeInfo.getUpgradeId());
				this.jdbcTemplate.update(sqlDelete, upgradeIdInt);
				logger.error("Value in SQL DELETE" + upgradeIdInt);

				List<UpgradePartModel> upgradePartModels = upgradeInfo.getUpgradePartModel();

				for (UpgradePartModel upgradePartModel : upgradePartModels) {
					if (!getPartOrModelData(upgradePartModel)) {
						invalidEntries.add(upgradePartModel.getPartModel());
						continue;
					}
					String savePartModel = "insert into ddsafm.sqt_upgrade_legacy_pn_model(upgrade_id,part_model,indicator) values(?,?,?)";
					Object[] paramPartModel = { upgradeIdInt, upgradePartModel.getPartModel(),
							upgradePartModel.getIndicator() };
					this.jdbcTemplate.update(savePartModel, paramPartModel);
				}
			} else {
				/*
				 * byte[] promoFileDecoded=
				 * Base64.decodeBase64(upgradeInfo.getPromo_file());
				 */
				saveSql = "insert into ddsafm.sqt_upgrade_info(upgrade_id,upgrade_name,brand,description,part_id,model,coupon_code,region,validity_from,validity_to,promo_file,promo_name) "
						+ "values (?,?,?,?,?,?,?,?,?,?,?,?)";
				Object[] param = { "", upgradeInfo.getUpgradeName(), upgradeInfo.getUpgradeBrand(),
						upgradeInfo.getUpgradeDescription(), upgradeInfo.getUpgradePart(),
						upgradeInfo.getUpgradeModel(), upgradeInfo.getCouponCode(), upgradeInfo.getRegion(),
						upgradeInfo.getValidityFrom(), upgradeInfo.getValidityTo(), upgradeInfo.getPromo_file(),
						upgradeInfo.getPromo_name() };
				this.jdbcTemplate.update(saveSql, param);
				/*
				 * ,new
				 * int[]{Types.INTEGER,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR
				 * ,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,
				 * Types.DATE,Types.DATE, Types.BLOB,Types.VARCHAR}
				 */
				String sqlMax = "select max(upgrade_id) from ddsafm.sqt_upgrade_info";
				int cntAfterInsert = this.jdbcTemplate.queryForInt(sqlMax);
				List<UpgradePartModel> upgradePartModels = upgradeInfo.getUpgradePartModel();
				for (UpgradePartModel upgradePartModel : upgradePartModels) {
					if (!getPartOrModelData(upgradePartModel)) {
						invalidEntries.add(upgradePartModel.getPartModel());
						continue;
					}
					String savePartModel = "insert into ddsafm.sqt_upgrade_legacy_pn_model(upgrade_id,part_model,indicator) values(?,?,?)";
					Object[] paramPartModel = { cntAfterInsert, upgradePartModel.getPartModel(),
							upgradePartModel.getIndicator() };
					this.jdbcTemplate.update(savePartModel, paramPartModel);
				}

				txManager.commit(saveUpgradeDetailsTM);

			}
			statusinfo.setStatusCode(1);
			if (invalidEntries.size() > 0)
				statusinfo.setStatusMessage("Partial Data saved and excluding invalid parts/Models" + invalidEntries);
			else {
				statusinfo.setStatusMessage("Data saved Successfully");
			}
		} catch (Exception e) {
			statusinfo.setStatusCode(500);
			statusinfo.setStatusMessage("Issue in saving data");
			logger.error("Exception in Upgrade Info" + e.getLocalizedMessage());
			txManager.rollback(saveUpgradeDetailsTM);
		}
		return statusinfo;
	}
	
	
	private Boolean ValidatePartOrModelNew(String partModel, String indicator) {
		if (null != partModel && !("").equalsIgnoreCase(partModel)) {
			String sql = null;
			if ("Model".equalsIgnoreCase(indicator))
				sql = "select count(*) from FPTODS.sqt_valve_info_t where product_model=?";
			else if ("Part".equalsIgnoreCase(indicator))
				sql = "select count(*) from FPTODS.sqt_part_info_t where item_number=?";
			int count = this.jdbcTemplate.queryForInt(sql, new Object[] { partModel.trim() });
			if (count != 0) {
				return true;
			} else {
				return false;
			}
		}
		return false;
	}

	// Siddhesh & RAJ
	@Override
	public StatusInfo saveUpgradeNewDetails(String sso,UpgradeInfo upgradeInfo) {
		StatusInfo statusinfo = new StatusInfo();
		logger.info("size="+upgradeInfo.getPromo_file().getBytes(Charset.forName("UTF-8")));
		TransactionDefinition transDef = new DefaultTransactionDefinition();
		TransactionStatus saveUpgradeDetailsTM = txManager.getTransaction(transDef);
		
		try {
			String sql = "select count(upgrade_id) from FPTODS.SQT_UPGRADE_INFO where upgrade_id=?";
			String saveSql = "";
			String saveSqlSMI = "";
			String str = upgradeInfo.getPromo_file();
			long maxlength = 1377911l;
			long n = str.getBytes().length;
			int count = this.jdbcTemplate.queryForInt(sql, new Object[] { upgradeInfo.getUpgradeId() });
			List<String> invalidEntries = new ArrayList<String>();
			if (count > 0) {
				
				Calendar currenttime = Calendar.getInstance();
				Date sqldate = new Date((currenttime.getTime()).getTime());
				
				//Checking for Image Size
				if(n<=maxlength){

				if(upgradeInfo.getCategory().equalsIgnoreCase("SMI")){
					
					saveSqlSMI = QueryConstants.UPGRADE_SAVE_FOR_SMI;
					
					Object[] paramSMI = { upgradeInfo.getUpgradeName(), upgradeInfo.getUpgradeBrand(), upgradeInfo.getUpgradeDescription(),upgradeInfo.getValidityFrom(), upgradeInfo.getValidityTo(),
							upgradeInfo.getRegion(), upgradeInfo.getCategory(),upgradeInfo.getFeaturedUpgrade(),upgradeInfo.getDisplayOnDashBoard(),sso,sqldate ,upgradeInfo.getPromo_name(),upgradeInfo.getPromo_file(),upgradeInfo.getUpgradeId()};
					
					this.jdbcTemplate.update(saveSqlSMI, paramSMI);
					
				} else if(upgradeInfo.getCategory().equalsIgnoreCase("Part")){
				saveSql = QueryConstants.UPGRADE_SAVE_FOR_PART;
				
				Object[] param = { upgradeInfo.getUpgradeName(), upgradeInfo.getUpgradeBrand(), upgradeInfo.getUpgradeDescription(),upgradeInfo.getValidityFrom(), upgradeInfo.getValidityTo(),
						upgradeInfo.getRegion(), upgradeInfo.getCategory(),upgradeInfo.getUpgradePart(),upgradeInfo.getFeaturedUpgrade(),upgradeInfo.getAmount(),
						upgradeInfo.getDiscount(), upgradeInfo.getCouponCode(),upgradeInfo.getDisplayOnDashBoard(),sso,sqldate ,upgradeInfo.getPromo_name(),upgradeInfo.getPromo_file(),upgradeInfo.getUpgradeId()};
				
				this.jdbcTemplate.update(saveSql, param);
				}else{
					saveSql = QueryConstants.UPGRADE_SAVE_FOR_MODEL;
					
					Object[] param = { upgradeInfo.getUpgradeName(), upgradeInfo.getUpgradeBrand(), upgradeInfo.getUpgradeDescription(),upgradeInfo.getValidityFrom(), upgradeInfo.getValidityTo(),
							upgradeInfo.getRegion(), upgradeInfo.getCategory(),upgradeInfo.getUpgradePart(),upgradeInfo.getFeaturedUpgrade(),upgradeInfo.getAmount(),
							upgradeInfo.getDiscount(), upgradeInfo.getCouponCode(),upgradeInfo.getDisplayOnDashBoard(),sso,sqldate ,upgradeInfo.getPromo_name(),upgradeInfo.getPromo_file(),upgradeInfo.getUpgradeId()};
					
					this.jdbcTemplate.update(saveSql, param);
					}
				String sqlDelete = "delete from FPTODS.SQT_UPGRADE_LEGACY_PN_MODEL where upgrade_id=?";
				int upgradeIdInt = Integer.parseInt(upgradeInfo.getUpgradeId());
				this.jdbcTemplate.update(sqlDelete, upgradeIdInt);
				List<UpgradePartModel> upgradePartModels = upgradeInfo.getUpgradePartModel();
				logger.error("Part Model" + upgradePartModels);
				for (UpgradePartModel upgradePartModel : upgradePartModels) {
					if (!getPartOrModelData(upgradePartModel)) {
						invalidEntries.add(upgradePartModel.getPartModel());
						continue;
					}
					//Changes the Table to new table
					String savePartModel = "insert into FPTODS.SQT_UPGRADE_LEGACY_PN_MODEL(upgrade_id,part_model,indicator,discount_price) values(?,?,?,?)";
					Object[] paramPartModel = { upgradeIdInt, upgradePartModel.getPartModel(),
							upgradePartModel.getIndicator(), upgradePartModel.getDiscountPrice() };
					this.jdbcTemplate.update(savePartModel, paramPartModel);
				}
				}else{
					statusinfo.setStatusCode(4);
					statusinfo.setStatusMessage("Image size is too big");
				return 	statusinfo;
				}
			} else {
			
				Calendar currenttime = Calendar.getInstance();
				Date sqldate = new Date((currenttime.getTime()).getTime()); 
				if(n<=maxlength){
				if(upgradeInfo.getCategory().equalsIgnoreCase("SMI")){
					
					saveSqlSMI = QueryConstants.UPGRADE_EDIT_FOR_SMI;
							
					
					Object[] paramSMI = { upgradeInfo.getUpgradeName(), upgradeInfo.getUpgradeBrand(), upgradeInfo.getUpgradeDescription(),upgradeInfo.getValidityFrom(), upgradeInfo.getValidityTo(),
							upgradeInfo.getRegion(), upgradeInfo.getCategory(),upgradeInfo.getFeaturedUpgrade(),
							upgradeInfo.getDisplayOnDashBoard(),sso,sqldate ,upgradeInfo.getPromo_name(),upgradeInfo.getPromo_file()};
					
					this.jdbcTemplate.update(saveSqlSMI, paramSMI);
					
				} else if(upgradeInfo.getCategory().equalsIgnoreCase("Part")){
				
					saveSql =QueryConstants.UPGRADE_EDIT_FOR_PART;
						
				Object[] param = { upgradeInfo.getUpgradeName(),upgradeInfo.getUpgradeBrand(), upgradeInfo.getUpgradeDescription(),upgradeInfo.getValidityFrom(), upgradeInfo.getValidityTo(),
						upgradeInfo.getRegion(), upgradeInfo.getCategory(),upgradeInfo.getUpgradePart(),upgradeInfo.getFeaturedUpgrade(),upgradeInfo.getAmount(),
						upgradeInfo.getDiscount(), upgradeInfo.getCouponCode(),upgradeInfo.getDisplayOnDashBoard(),sso,sqldate,upgradeInfo.getPromo_name(),upgradeInfo.getPromo_file()};
				this.jdbcTemplate.update(saveSql, param);
				}else{
				
					saveSql =QueryConstants.UPGRADE_EDIT_FOR_MODEL;
						
				Object[] param = { upgradeInfo.getUpgradeName(),upgradeInfo.getUpgradeBrand(), upgradeInfo.getUpgradeDescription(),upgradeInfo.getValidityFrom(), upgradeInfo.getValidityTo(),
						upgradeInfo.getRegion(), upgradeInfo.getCategory(),upgradeInfo.getUpgradePart(),upgradeInfo.getFeaturedUpgrade(),upgradeInfo.getAmount(),
						upgradeInfo.getDiscount(), upgradeInfo.getCouponCode(),upgradeInfo.getDisplayOnDashBoard(),sso,sqldate,upgradeInfo.getPromo_name(),upgradeInfo.getPromo_file()};
				this.jdbcTemplate.update(saveSql, param);
				}
				
				String sqlMax = "select max(upgrade_id) from FPTODS.SQT_UPGRADE_INFO";
				int cntAfterInsert = this.jdbcTemplate.queryForInt(sqlMax);
				List<UpgradePartModel> upgradePartModels = upgradeInfo.getUpgradePartModel();
				for (UpgradePartModel upgradePartModel : upgradePartModels) {
					if (!getPartOrModelData(upgradePartModel)) {
						invalidEntries.add(upgradePartModel.getPartModel());
						continue;
						
					}
				String savePartModel = "insert into FPTODS.SQT_UPGRADE_LEGACY_PN_MODEL (upgrade_id,part_model,indicator,discount_price) values(?,?,?,?)";
				Object[] paramPartModel = { cntAfterInsert, upgradePartModel.getPartModel(),
							upgradePartModel.getIndicator(),upgradePartModel.getDiscountPrice()};
					this.jdbcTemplate.update(savePartModel, paramPartModel);
				}

				txManager.commit(saveUpgradeDetailsTM);

			}else{
				statusinfo.setStatusCode(4);
				statusinfo.setStatusMessage("Image size is too big");
			
				return statusinfo;
			}
			}
			statusinfo.setStatusCode(1);
			if (invalidEntries.size() > 0)
				statusinfo.setStatusMessage("Partial Data saved and excluding invalid parts/Models" + invalidEntries);
			else {
				statusinfo.setStatusMessage("Data saved Successfully");
			}
		} catch (Exception e) {
			statusinfo.setStatusCode(500);
			statusinfo.setStatusMessage("Issue in saving data");
			logger.error("Exception in Upgrade Info" + e.getLocalizedMessage());
			txManager.rollback(saveUpgradeDetailsTM);
		}
		return statusinfo;
	}	
	
	@Override
	public int getUpgradeOptionsCount(UpgradeOptions upgradeOptions) {
		int result = 0;
		try {
			String sql = "select count(*) from ddsafm.sqt_upgrade_options a where 1=1";
			MapSqlParameterSource parameters = new MapSqlParameterSource(setFilterUpgradeOptionsParams(upgradeOptions));
			if (upgradeOptions != null) {
				String filter = getFilterUpgradeOptionsClause(upgradeOptions);
				sql = sql + filter;
			}
			result = this.namedParamTemplate.queryForInt(sql, parameters);
		} catch (Exception e) {
			logger.error("Exception in getUpgradeOptionsCount" + e.getLocalizedMessage());
		}
		return result;
	}

	@Override
	public List<UpgradeOptions> getUpgradeOptionsData(int pageNo, int rowsPerPage, UpgradeOptions upgradeOptions) {
		List<UpgradeOptions> result = new ArrayList<UpgradeOptions>();
		List<UpgradeOptions> finalResults = new ArrayList<UpgradeOptions>();
		try {
			String sql = "select option_id,name,value,upgrade_id,description "
					+ "from (select rownum as rnum, a.* from ddsafm.sqt_upgrade_options a where 1=1";
			MapSqlParameterSource parameters = new MapSqlParameterSource(setFilterUpgradeOptionsParams(upgradeOptions));
			if (upgradeOptions != null) {
				String filter = getFilterUpgradeOptionsClause(upgradeOptions);
				sql = sql + filter;
			}
			sql += ")";
			if (rowsPerPage > 0) {

				int lowerLimit = rowsPerPage * pageNo;
				int upperLimit = lowerLimit + rowsPerPage;

				String pageLimitClause = " where rnum >:lowerLimit AND rnum <=:upperLimit";
				parameters.addValue("lowerLimit", lowerLimit);
				parameters.addValue("upperLimit", upperLimit);
				sql += pageLimitClause;

			}
			result = this.namedParamTemplate.query(sql, parameters, new UpgradeOptionsMapper());
			for (UpgradeOptions upgradeOption : result) {
				String sqlForUpgradeOptions = "select * from ddsafm.sqt_upgrade_option_details where option_id=:optionId";
				MapSqlParameterSource paramMap = new MapSqlParameterSource();
				paramMap.addValue("optionId", upgradeOption.getOptionId());
				List<UpgradeOptionDetails> upgradeOptionDetailsResult = this.namedParamTemplate
						.query(sqlForUpgradeOptions, paramMap, new UpgradeOptionsDetailsMapper());
				upgradeOption.setUpgradeOptionDetails(upgradeOptionDetailsResult);
				finalResults.add(upgradeOption);
			}
		} catch (Exception e) {
			logger.info("Found Exception while getUpgradeOptionsData :" + e.getLocalizedMessage());
		}
		return finalResults;
	}

	@Override
	public StatusInfo saveUpgradeOptions(UpgradeOptions upgradeOptions) {
		StatusInfo statusinfo = new StatusInfo();
		TransactionDefinition transDef = new DefaultTransactionDefinition();
		TransactionStatus saveUpgradeDetailsTM = txManager.getTransaction(transDef);
		try {
			String sql = "select count(option_id) from ddsafm.sqt_upgrade_options where option_id= ?";
			String saveSql = "";
			int count = this.jdbcTemplate.queryForInt(sql, new Object[] { upgradeOptions.getOptionId() });
			List<String> invalidEntries = new ArrayList<String>();
			if (count > 0) {
				saveSql = "update ddsafm.sqt_upgrade_options set name=?,description=?,value=? " + "where option_id=?";
				Object[] param = { upgradeOptions.getOptionName(), upgradeOptions.getOptionDescription(),
						upgradeOptions.getOptionValue(), upgradeOptions.getOptionId() };
				this.jdbcTemplate.update(saveSql, param);
				// delete all the existing options
				String sqlDelete = "delete from ddsafm.sqt_upgrade_option_details where option_id=?";
				int upgradeIdInt = Integer.parseInt(upgradeOptions.getOptionId());
				this.jdbcTemplate.update(sqlDelete, upgradeIdInt);
				// save all new existing options
				List<UpgradeOptionDetails> upgradeOptionDetails = upgradeOptions.getUpgradeOptionDetails();
				for (UpgradeOptionDetails upgradeOptionDetail : upgradeOptionDetails) {
					if (!getPartOrModelData(upgradeOptionDetail)) {
						invalidEntries.add(upgradeOptionDetail.getPartModel());
						continue;
					}
					String saveOptionDetails = "insert into ddsafm.sqt_upgrade_option_details(option_id,part_model,indicator) values(?,?,?)";
					Object[] paramsOptionDetails = { upgradeOptions.getOptionId(), upgradeOptionDetail.getPartModel(),
							upgradeOptionDetail.getIndicator() };
					this.jdbcTemplate.update(saveOptionDetails, paramsOptionDetails);
				}
				statusinfo.setStatusCode(1);
				statusinfo.setStatusMessage("Data saved Successfully");
				txManager.commit(saveUpgradeDetailsTM);
			} else {
				saveSql = "insert into ddsafm.sqt_upgrade_options(option_id,name,value,description,upgrade_id) "
						+ "values (?,?,?,?,?)";
				Object[] param = { "", upgradeOptions.getOptionName(), upgradeOptions.getOptionValue(),
						upgradeOptions.getOptionDescription(), upgradeOptions.getUpgradeId(), };
				this.jdbcTemplate.update(saveSql, param);
				String sqlMax = "select max(option_id) from ddsafm.sqt_upgrade_options";
				int cntAfterInsert = this.jdbcTemplate.queryForInt(sqlMax);
				List<UpgradeOptionDetails> upgradeOptionDetails = upgradeOptions.getUpgradeOptionDetails();
				for (UpgradeOptionDetails upgradeOptionDetail : upgradeOptionDetails) {
					if (!getPartOrModelData(upgradeOptionDetail)) {
						invalidEntries.add(upgradeOptionDetail.getPartModel());
						continue;
					}
					String saveOptionDetails = "insert into ddsafm.sqt_upgrade_option_details(option_id,part_model,indicator) values(?,?,?)";
					Object[] paramsOptionDetails = { cntAfterInsert, upgradeOptionDetail.getPartModel(),
							upgradeOptionDetail.getIndicator() };
					this.jdbcTemplate.update(saveOptionDetails, paramsOptionDetails);
				}
				statusinfo.setStatusCode(1);
				statusinfo.setStatusMessage("Data saved Successfully");
				txManager.commit(saveUpgradeDetailsTM);
			}
			statusinfo.setStatusCode(1);
			if (invalidEntries.size() > 0)
				statusinfo.setStatusMessage("Partial Data saved and excluding invalid parts/Models\n" + invalidEntries);
			else {
				statusinfo.setStatusMessage("Data saved Successfully");
			}
		} catch (Exception e) {
			statusinfo.setStatusCode(500);
			statusinfo.setStatusMessage("Data deletion failed" + e.getLocalizedMessage());
			logger.error("Exception in Upgrade Options" + e.getLocalizedMessage());
			txManager.rollback(saveUpgradeDetailsTM);
		}
		return statusinfo;
	}

	@Override
	public StatusInfo deleteUpgradeLegacyPnModel(UpgradePartModel upgradePartModel) {
		StatusInfo statusinfo = new StatusInfo();
		try {
			String sql = "delete from ddsafm.upgrade_legacy_pn_model where part_model= ?";
			this.jdbcTemplate.update(sql, upgradePartModel.getPartModel());
			statusinfo.setStatusCode(1);
			statusinfo.setStatusMessage("Data deleted Successfully");
		} catch (Exception e) {
			statusinfo.setStatusCode(500);
			statusinfo.setStatusMessage("Data deletion failed" + e.getLocalizedMessage());
		}
		return statusinfo;
	}

	@Override
	public StatusInfo deleteUpgradeOptionsDetailsPartModel(UpgradeOptionDetails upgradeOptionDetails) {
		StatusInfo statusinfo = new StatusInfo();
		try {
			String sql = "delete from ddsafm.upgrade_option_details where part_model= ?";
			this.jdbcTemplate.update(sql, upgradeOptionDetails.getPartModel());
			statusinfo.setStatusCode(1);
			statusinfo.setStatusMessage("Data deleted Successfully");
		} catch (Exception e) {
			statusinfo.setStatusCode(500);
			statusinfo.setStatusMessage("Data deletion failed" + e.getLocalizedMessage());
		}
		return statusinfo;
	}

	/* Upgrade Management tab and the upgrade options available */
	@Override
	public List<DropDownItem> getUpgradeOptionsDataUI(String sso, String region) {
		List<DropDownItem> dropDownItem = null;
		try {
			logger.error("Is int");
			//sendEmailNotification();
			boolean isInternal = WelcomePkgServiceImpl.isInternalUser(sso);
			logger.error("Is internal value=" + isInternal);
			String query1 = "select upgrade_name as text,upgrade_id as value from FPTODS.SQT_UPGRADE_INFO WHERE VALIDITY_FROM <=SYSDATE AND  VALIDITY_TO>=SYSDATE";
			String query2 = "select upgrade_name as text,upgrade_id as value from FPTODS.SQT_UPGRADE_INFO where region=:region and VALIDITY_FROM <=SYSDATE AND  VALIDITY_TO>=SYSDATE";
			MapSqlParameterSource paramMap = new MapSqlParameterSource();
			paramMap.addValue("region", region);
			String sql = (isInternal == true ? query1 : query2);
			logger.error("Selected query =" + (isInternal == true ? query1 : query2));
			dropDownItem = this.namedParamTemplate.query(sql, paramMap, new DropDownMapper());
		} catch (Exception e) {
			logger.error("Exception while Get upgrade options data UI" + e.getLocalizedMessage());
		}
		return dropDownItem;

	}

	@Override
	public List<EquipmentBoms> getUpgradesByUpgradename(int page, int rowsPerPage, String globalSearch, String sortCol,
			String sortOrder, int upgradeId, String dunsNumber, EquipmentBoms equipmentboms) {
		String sql = "";
		List<EquipmentBoms> equipmentboms1 = null;
		try {
			String initialsql = "SELECT * FROM (select  ROW_NUMBER() OVER (ORDER BY SERIAL_NUMBER desc) rn, A.* from (";
			sql = "SELECT distinct E.Rec_Source, E.serial_number,E.sales_order,E.CUSTOMER_PO,E.SOLD_TO_CUSTOMER_NAME,"
					+ "E.SOLD_TO_CITY,E.SOLD_TO_STATE,E.SOLD_TO_COUNTRY,E.REP_NAME,E.SOURCESYSTEM,E.END_USER_INDUSTRY,E.PRODUCT_CODE,E.PART_NUM "
					+ "from DDSAFM.SQT_UPGRADE_ORDER_INFO_MV E where E.UPGRADE_ID =:upgradeId AND E.DUNS =:dunsNumber";
			MapSqlParameterSource paramMap = new MapSqlParameterSource(
					setFilterEquipmentBomsClause(globalSearch, equipmentboms));
			paramMap.addValue("upgradeId", upgradeId);
			paramMap.addValue("dunsNumber", dunsNumber);
			if (equipmentboms != null) {
				String filter = getFilterEquipmentBomsClause(equipmentboms);
				sql = sql + filter;
			}

			if (!globalSearch.trim().isEmpty()) {
				String globalFilterClause = getGlobalFilterClause();
				sql += " AND " + globalFilterClause;
			}
			if (sortCol != null && !sortCol.equalsIgnoreCase("")) {
				sql += " order by " + sortCol;
			}
			if (sortOrder != null && !sortOrder.equalsIgnoreCase("")) {
				sql += " " + sortOrder;
			}
			sql += ")A)";
			if (rowsPerPage > 0) {
				int lowerLimit = rowsPerPage * page;
				int upperLimit = lowerLimit + rowsPerPage;

				String pageLimitClause = " WHERE rn >=:lowerLimit AND rn <=:upperLimit";
				paramMap.addValue("lowerLimit", lowerLimit);
				paramMap.addValue("upperLimit", upperLimit);
				sql += pageLimitClause;
			}
			String finalsql = initialsql + sql;
			logger.error("final sql=" + finalsql);
			equipmentboms1 = this.namedParamTemplate.query(finalsql, paramMap, new EquipmentInfoMapper());
			logger.error("equipment Boms=" + equipmentboms1);
			return equipmentboms1;
		} catch (Exception ex) {
			logger.error("No data available for the duns", ex);
		}
		return null;
	}

	@Override
	public List<EquipmentBoms> getUpgradesByUpgradenameForGEUsers(int page, int rowsPerPage, String globalSearch,
			String sortCol, String sortOrder, int upgradeId, EquipmentBoms equipmentboms) {
		String sql = "";
		List<EquipmentBoms> equipmentboms1 = null;
		try {
			String initialsql = "SELECT * FROM (select  ROW_NUMBER() OVER (ORDER BY SERIAL_NUMBER desc) rn, A.* from (";
			sql = "SELECT distinct E.Rec_Source, E.serial_number,E.sales_order,E.CUSTOMER_PO,E.SOLD_TO_CUSTOMER_NAME,"
					+ "E.SOLD_TO_CITY,E.SOLD_TO_STATE,E.SOLD_TO_COUNTRY,E.REP_NAME,E.SOURCESYSTEM,E.END_USER_INDUSTRY,E.PRODUCT_CODE,E.PART_NUM "
					+ "from ddsafm.SQT_UPGRADE_ORDER_INFO_MV E where E.UPGRADE_ID =:upgradeId";
			MapSqlParameterSource paramMap = new MapSqlParameterSource(
					setFilterEquipmentBomsClause(globalSearch, equipmentboms));
			paramMap.addValue("upgradeId", upgradeId);
			if (equipmentboms != null) {
				String filter = getFilterEquipmentBomsClause(equipmentboms);
				sql = sql + filter;
			}
			if (!globalSearch.trim().isEmpty()) {
				String globalFilterClause = getGlobalFilterClause();
				sql += " AND " + globalFilterClause;
			}
			if (sortCol != null && !sortCol.equalsIgnoreCase("")) {
				sql += " order by " + sortCol;
			}
			if (sortOrder != null && !sortOrder.equalsIgnoreCase("")) {
				sql += " " + sortOrder;
			}
			sql += ")A)";
			if (rowsPerPage > 0) {
				int lowerLimit = rowsPerPage * page;
				int upperLimit = lowerLimit + rowsPerPage;

				String pageLimitClause = " WHERE rn >=:lowerLimit AND rn <=:upperLimit";
				paramMap.addValue("lowerLimit", lowerLimit);
				paramMap.addValue("upperLimit", upperLimit);
				sql += pageLimitClause;
			}
			String finalsql = initialsql + sql;
			logger.error("final sql=" + finalsql);
			equipmentboms1 = this.namedParamTemplate.query(finalsql, paramMap, new EquipmentInfoMapper());
			logger.error("equipment Boms=" + equipmentboms1);
			return equipmentboms1;
		} catch (Exception ex) {
			logger.error("No data available for the duns", ex);
		}
		return null;
	}

	@Override
	public List<EquipmentBoms> getPartDataByByRecSourceAndSerialNumber(String serialNumber, String recSource,
			String region, String currency) {
		try {
			String sql = "select distinct a.*, b.List_price as LP, c.lead_time as LT, c.ORG_RANK, c.org_name  "
					+ " from  DDSAFM.SQT_UPGRADE_LEGACY_PN_MODEL D, ddsafm.ODS_SQT_BY_SALES_ORDER_V a left outer join ddsafm.ods_sqt_price_look_up_MV b "
					+ " on a.COMPONENT_ITEM_NUMBER = b.part_number and a.spares_indicator in ('C', 'W', 'I', '1', '2') left outer join ddsafm.LEAD_TIME_LOOKUP_MV c "
					+ "on a.COMPONENT_ITEM_NUMBER = c.item_number where  a.rec_source = ? and a.SERIAL_NUMBER = ? and (b.to_currency = ? or b.to_currency is null) "
					+ "and (b.region = ? or b.region is null) and (c.region = ? or c.region is null) and a.COMPONENT_ITEM_NUMBER= D.part_model";
			logger.info("BOMS query start: " + new Date().toString());
			List<EquipmentBoms> boms = this.jdbcTemplate.query(sql,
					new Object[] { recSource, serialNumber, currency, region, region }, new BomsMapper());
			logger.info("BOMS query finish: " + new Date().toString());
			return boms;
		} catch (Exception ex) {
			logger.error("Get BOMS By SSO error:", ex);
		}
		return null;
	}

	@Override
	public int getUpgradesCount(String globalSearch,int upgradeId, String dunsNumber, EquipmentBoms equipmentboms) {
		String sql = "";
		logger.error("duns number=" + dunsNumber);
		sql = "select count(*) from ddsafm.SQT_UPGRADE_ORDER_INFO_MV where UPGRADE_ID =:upgradeId AND DUNS =:dunsNumber";
		
		MapSqlParameterSource paramMap = new MapSqlParameterSource(
				setFilterEquipmentBomsClause(globalSearch,equipmentboms));
		paramMap.addValue("upgradeId", upgradeId);
		paramMap.addValue("dunsNumber", dunsNumber);
		if (equipmentboms != null) {
			String filter = getFilterEquipmentBomsClause(equipmentboms);
			sql = sql + filter;
		}
		
		int count = this.namedParamTemplate.queryForInt(sql, paramMap);
		logger.error("after count return upgradepage()" + count);
		return count;
	}

	@Override
	public int getUpgradesCountForGEUsers(String globalSearch,int upgradeId, EquipmentBoms equipmentboms) {
		String sql = "";
		sql = "select count(*) from ddsafm.SQT_UPGRADE_ORDER_INFO_MV where UPGRADE_ID =:upgradeId";
		logger.error("SQL is=" + sql);
		MapSqlParameterSource paramMap = new MapSqlParameterSource(
				setFilterEquipmentBomsClause(globalSearch,equipmentboms));
		paramMap.addValue("upgradeId", upgradeId);
		if (equipmentboms != null) {
			String filter = getFilterEquipmentBomsClause(equipmentboms);
			sql = sql + filter;
		}
		int count = this.namedParamTemplate.queryForInt(sql, paramMap);
		logger.error("after count return upgradepage()" + count);
		return count;
	}

	public static final class DropDownMapper implements RowMapper<DropDownItem> {
		public DropDownItem mapRow(ResultSet rs, int rowNum) throws SQLException {
			DropDownItem result = new DropDownItem();
			result.setText(rs.getString("text"));
			result.setValue(rs.getString("value"));
			return result;
		}
	}

	private String getGlobalFilterClause() {
		String filter = "";
		filter = " ((UPPER(SERIAL_NUMBER) LIKE '%' || :globalSearch || '%')"
				+ " OR (UPPER(SALES_ORDER) LIKE '%' || :globalSearch || '%')"
				+ " OR (UPPER(CUSTOMER_PO) LIKE '%' || :globalSearch || '%')"
				+ " OR (UPPER(SOLD_TO_CUSTOMER_NAME) LIKE '%' || :globalSearch || '%')"
				+ " OR (UPPER(SOLD_TO_CITY) LIKE '%' || :globalSearch || '%')"
				+ " OR (UPPER(SOLD_TO_STATE) LIKE '%' || :globalSearch || '%')"
				+ " OR (UPPER(SOLD_TO_COUNTRY) LIKE '%' || :globalSearch || '%')"
				+ " OR (UPPER(REP_NAME) LIKE '%' || :globalSearch || '%')"
				+ " OR (UPPER(SOURCESYSTEM) LIKE '%' || :globalSearch || '%')"
				+ " OR (UPPER(END_USER_INDUSTRY) LIKE '%' || :globalSearch || '%'))"
				+ " OR (UPPER(PART_NUM) LIKE '%' || :globalSearch || '%'))"
				+ " OR (UPPER(PRODUCT_CODE) LIKE '%' || :globalSearch || '%'))";
		return filter;
	}

	public String getFilterEquipmentBomsClause(EquipmentBoms equipmentboms) {
		String filter = "";
		List<String> conditions = new ArrayList<String>();
		if (equipmentboms != null) {
			if (equipmentboms.getSerialNumber() != null && !equipmentboms.getSerialNumber().isEmpty()) {
				conditions.add(" UPPER(SERIAL_NUMBER) LIKE '%' || :serialNumber || '%'");
			}
			if (equipmentboms.getSalesOrder() != null && !equipmentboms.getSalesOrder().isEmpty()) {
				conditions.add(" UPPER(SALES_ORDER) LIKE '%' || :salesOrder || '%'");
			}
			if (equipmentboms.getCustomerPo() != null && !equipmentboms.getCustomerPo().isEmpty()) {
				conditions.add(" UPPER(CUSTOMER_PO) LIKE '%' || :customerPo || '%'");
			}
			if (equipmentboms.getSoldToCustomerName() != null && !equipmentboms.getSoldToCustomerName().isEmpty()) {
				conditions.add(" UPPER(SOLD_TO_CUSTOMER_NAME) LIKE '%' || :soldToCustomerName || '%'");
			}
			if (equipmentboms.getSoldToCity() != null && !equipmentboms.getSoldToCity().isEmpty()) {
				conditions.add(" UPPER(SOLD_TO_CITY) LIKE '%' || :soldToCity || '%'");
			}
			if (equipmentboms.getSoldToState() != null && !equipmentboms.getSoldToState().isEmpty()) {
				conditions.add(" UPPER(SOLD_TO_STATE) LIKE '%' || :soldToState || '%'");
			}
			if (equipmentboms.getSoldToCountry() != null && !equipmentboms.getSoldToCountry().isEmpty()) {
				conditions.add(" UPPER(SOLD_TO_COUNTRY) LIKE '%' || :soldToCountry || '%'");
			}
			if (equipmentboms.getRepName() != null && !equipmentboms.getRepName().isEmpty()) {
				conditions.add(" UPPER(REP_NAME) LIKE '%' || :repName || '%'");
			}
			if (equipmentboms.getSourceSystem() != null && !equipmentboms.getSourceSystem().isEmpty()) {
				conditions.add(" UPPER(SOURCESYSTEM) LIKE '%' || :sourceSystem || '%'");
			}
			if (equipmentboms.getEndUserIndustry() != null && !equipmentboms.getEndUserIndustry().isEmpty()) {
				conditions.add(" UPPER(END_USER_INDUSTRY) LIKE '%' || :endUserIndustry || '%'");
			}
			if (equipmentboms.getProductCode() != null && !equipmentboms.getProductCode().isEmpty()) {
				conditions.add(" UPPER(PRODUCT_CODE) LIKE '%' || :productCode || '%'");
			}
			if (equipmentboms.getLegacyPartNumber() != null && !equipmentboms.getLegacyPartNumber().isEmpty()) {
				conditions.add(" UPPER(PART_NUM) LIKE '%' || :legacyPartNumber || '%'");
			}
		}
		if (conditions.size() > 0) {
			String condStr = "";

			for (int i = 0; i < conditions.size(); i++) {
				condStr += (" AND " + conditions.get(i));
			}
			filter = condStr;
		}
		return filter;
	}

	public Map<String, String> setFilterEquipmentBomsClause(String globalSearch, EquipmentBoms equipmentboms) {
		Map<String, String> result = new HashMap<String, String>();
		result.put("globalSearch", globalSearch == null ? "" : globalSearch.toUpperCase());
		result.put("serialNumber",
				equipmentboms.getSerialNumber() == null ? "" : equipmentboms.getSerialNumber().toUpperCase());
		result.put("salesOrder",
				equipmentboms.getSalesOrder() == null ? "" : equipmentboms.getSalesOrder().toUpperCase());
		result.put("customerPo",
				equipmentboms.getCustomerPo() == null ? "" : equipmentboms.getCustomerPo().toUpperCase());
		result.put("soldToCustomerName", equipmentboms.getSoldToCustomerName() == null ? ""
				: equipmentboms.getSoldToCustomerName().toUpperCase());
		result.put("soldToCity",
				equipmentboms.getSoldToCity() == null ? "" : equipmentboms.getSoldToCity().toUpperCase());
		result.put("soldToState",
				equipmentboms.getSoldToState() == null ? "" : equipmentboms.getSoldToState().toUpperCase());
		result.put("soldToCountry",
				equipmentboms.getSoldToCountry() == null ? "" : equipmentboms.getSoldToCountry().toUpperCase());
		result.put("repName", equipmentboms.getRepName() == null ? "" : equipmentboms.getRepName().toUpperCase());
		result.put("sourceSystem",
				equipmentboms.getSourceSystem() == null ? "" : equipmentboms.getSourceSystem().toUpperCase());
		result.put("endUserIndustry",
				equipmentboms.getEndUserIndustry() == null ? "" : equipmentboms.getEndUserIndustry().toUpperCase());
		result.put("productCode",
				equipmentboms.getProductCode() == null ? "" : equipmentboms.getProductCode().toUpperCase());
		result.put("legacyPartNumber",
				equipmentboms.getLegacyPartNumber() == null ? "" : equipmentboms.getLegacyPartNumber().toUpperCase());
		return result;
	}

	private static final class BomsMapper implements RowMapper<EquipmentBoms> {
		public BomsMapper() {
		}

		@Override
		public EquipmentBoms mapRow(ResultSet rs, int rowNum) throws SQLException {
			EquipmentBoms result = new EquipmentBoms();

			result.setRecSource(rs.getString("REC_SOURCE")); //$NON-NLS-1$
			result.setSalesOrder(rs.getString("SALES_ORDER"));
			result.setOrderedItemNumber(rs.getString("ORDERED_ITEM_NUMBER"));
			result.setSerialNumber(rs.getString("SERIAL_NUMBER"));
			result.setSourceSystem(rs.getString("SOURCE_SYSTEM"));
			result.setComponentItemNumber(rs.getString("COMPONENT_ITEM_NUMBER"));
			result.setComponentDescription(rs.getString("COMPONENT_DESCRIPTION"));
			result.setSparesIndicator(rs.getString("SPARES_INDICATOR"));
			result.setStockType(rs.getString("STOCK_TYPE"));
			result.setQuantity(rs.getInt("QUANTITY"));
			result.setListPrice(rs.getString("LP"));
			result.setLeadTime(rs.getLong("LT"));
			result.setSourceSystem(rs.getString("SOURCE_SYSTEM"));
			result.setListPriceLP(rs.getString("LP"));
			return result;

		}
	}

	private static final class EquipmentInfoMapper implements RowMapper<EquipmentBoms> {
		public EquipmentInfoMapper() {
		}

		@Override
		public EquipmentBoms mapRow(ResultSet rs, int rowNum) throws SQLException {
			EquipmentBoms equipmentboms = new EquipmentBoms();
			logger.error("inside equipment()");
			equipmentboms.setSerialNumber(rs.getString("serial_number"));
			equipmentboms.setSalesOrder(rs.getString("SALES_ORDER"));
			equipmentboms.setCustomerPo(rs.getString("CUSTOMER_PO"));
			equipmentboms.setSoldToCustomerName(rs.getString("SOLD_TO_CUSTOMER_NAME"));
			equipmentboms.setSoldToCity(rs.getString("SOLD_TO_CITY"));
			equipmentboms.setSoldToState(rs.getString("SOLD_TO_STATE"));
			equipmentboms.setSoldToCountry(rs.getString("SOLD_TO_COUNTRY"));
			equipmentboms.setRepName(rs.getString("REP_NAME"));
			equipmentboms.setSourceSystem(rs.getString("SOURCESYSTEM"));
			equipmentboms.setEndUserIndustry(rs.getString("END_USER_INDUSTRY"));
			equipmentboms.setProductCode(rs.getString("PRODUCT_CODE"));
			equipmentboms.setRecSource(rs.getString("REC_SOURCE"));
			equipmentboms.setLegacyPartNumber(rs.getString("PART_NUM"));
			logger.error("ended");

			return equipmentboms;
		}
	}

	@Override
	public List<UpgradeOptions> getOptionsByUpgradeId(String upgradeId) {
		logger.error("Inside the getOptionsByUpgradeId method" + upgradeId);
		try {
			String sql = "select * from fptods.sqt_upgrade_options where upgrade_id=?";
			List<UpgradeOptions> finalResults = new ArrayList<UpgradeOptions>();
			List<UpgradeOptions> upgradeOptionsData = this.jdbcTemplate.query(sql,
					new Object[] { Integer.parseInt(upgradeId) }, new UpgradeOptionsMapper());
			for (UpgradeOptions Options : upgradeOptionsData) {
				logger.error("Data in getOptionsByUpgradeId" + Options);
			}
			logger.error("after fetching the data in getOptionsByUpgradeId method");

			for (UpgradeOptions upgradeOption : upgradeOptionsData) {
				String sqlForUpgradeOptions = "select * from ddsafm.sqt_upgrade_option_details where option_id=:optionId";
				MapSqlParameterSource paramMap = new MapSqlParameterSource();
				paramMap.addValue("optionId", upgradeOption.getOptionId());
				List<UpgradeOptionDetails> upgradeOptionDetailsResult = this.namedParamTemplate
						.query(sqlForUpgradeOptions, paramMap, new UpgradeOptionsDetailsMapper());
				upgradeOption.setUpgradeOptionDetails(upgradeOptionDetailsResult);
				finalResults.add(upgradeOption);
			}
			return finalResults;
		} catch (Exception e) {
			logger.error("getOptionsByUpgradeId Data Fetch Error:", e.getLocalizedMessage());
		}
		return null;
	}

	@Override
	public UpgradeInfo getUpgradeCoupon(String upgradeId) {
		logger.error("Inside the getUpgradeCoupon method" + upgradeId);
		try {
			String sql = "select * from fptods.sqt_upgrade_info where upgrade_id=?";
			int upgradeIdValue = Integer.parseInt(upgradeId);
			List<UpgradeInfo> upgradeInfoValues = this.jdbcTemplate.query(sql, new Object[] { upgradeIdValue },
					new UpgradeInfoMapper());
			logger.error("after fetching the data in getUpgradeCoupon method");
			if (upgradeInfoValues.isEmpty()) {
				return null;
			} else {
				return upgradeInfoValues.get(0);
			}

		} catch (Exception e) {
			logger.error("getUpgradeCoupon Data Fetch Error:", e.getLocalizedMessage());
		}
		return null;
	}

	/*@Override
	public List<PromotionalCart> getPromotionalCart(String sso) {
		logger.error("Inside the getPromotionalCart method");
		try {
			String sql = "select distinct sso,upgrade_id,upgrade_name,coupon_code,option_id,option_name,quantity,option_description from fptods.SQT_SSO_PROMOTIONAL_CART where SSO=?";
			List<PromotionalCart> promotionalCartValues = this.jdbcTemplate.query(sql, new Object[] { sso },
					new PromotionalCartMapper());
			List<PromotionalCart> finalPromotionalCartValues = new ArrayList<PromotionalCart>();
			for (PromotionalCart cart : promotionalCartValues) {
				String sqlForUpgradeOptions = "select * from fptods.SQT_SSO_PROMOTIONAL_CART where option_id=:optionId AND sso =:ssoid";
				MapSqlParameterSource paramMap = new MapSqlParameterSource();
				paramMap.addValue("optionId", cart.getOptionId());
				paramMap.addValue("ssoid", sso);
				List<UpgradeOptionDetails> partModel = this.namedParamTemplate.query(sqlForUpgradeOptions, paramMap,
						new UpgradeOptionsDetailsMapper());
				cart.setPartModel(partModel);
				finalPromotionalCartValues.add(cart);
			}
			if (!finalPromotionalCartValues.isEmpty()) {
				String sqlValidity = "select * from fptods.sqt_upgrade_info where upgrade_id=?";
				String finalUpgrade = finalPromotionalCartValues.get(0).getUpgradeId();
				List<UpgradeInfo> upgradeInfoValues = this.jdbcTemplate.query(sqlValidity,
						new Object[] { finalUpgrade }, new UpgradeInfoMapper());
				logger.error("after fetching the data in getUpgradeCoupon method");
				UpgradeInfo info = new UpgradeInfo();
				if (!upgradeInfoValues.isEmpty()) {
					info = upgradeInfoValues.get(0);
					Date date = new Date();
					// check validity of coupon code
					if (!(info.getValidityFrom().before(date) && info.getValidityTo().after(date))) {
						return null;
					}
				}
			}
			return finalPromotionalCartValues;
		} catch (Exception e) {
			logger.error("getPromotionalCart Data Fetch Error:", e);
		}
		return null;
	}*/
	//Changed By Neha
	@Override
	public List<PromotionalCartViewData> getPromotionalCart(String sso) {
		logger.error("Inside the getPromotionalCart method");
		PromotionalCartViewData viewData;
		List<PromotionalCartViewData> result = new ArrayList<>();
		
		try {
			String sql = "select sso,upgrade_id,upgrade_name,option_id,option_name,option_description,part_model,quantity,indicator from fptods.SQT_SSO_PROMOTIONAL_CART where SSO=?";
			List<CPPromotionalCartData> promotionalCartData = this.jdbcTemplate.query(sql, new Object[] { sso },
					new CPPromotionalCartDataMapper());
			logger.info("Data from cart---"+promotionalCartData);
			for(CPPromotionalCartData data : promotionalCartData){
				logger.info("INDICATOR :"+data.getIndicator());
				logger.info("Upgrade id :"+data.getUpgradeId());
				viewData = new PromotionalCartViewData();
				String sqlForUpgrade = "select DESCRIPTION from FPTODS.SQT_UPGRADE_INFO where UPGRADE_ID=?";
				String upgradeDescription = this.jdbcTemplate.queryForObject(sqlForUpgrade, new Object[] { data.getUpgradeId() },
						String.class);
				data.setUpgradeDescription(upgradeDescription);
				viewData.setPartNumber(data.getPartNumber());
				viewData.setQuantity(data.getQuantity());
				viewData.setIndicator(data.getIndicator());
				viewData.setUpgradeId(data.getUpgradeId());
				if(data.getOptionId() == 0){
					logger.info("Inside if ----");
					viewData.setOptionName(data.getUpgradeName());
					viewData.setOptionDescription(data.getUpgradeDescription());
				}else{
					logger.info("Inside else ----");
					viewData.setOptionId(data.getOptionId());
					viewData.setOptionName(data.getOptionName());
					viewData.setOptionDescription(data.getOptionDescription());
				}
				result.add(viewData);
			}
			} catch (Exception e){
				logger.error("getPromotionalCart View Data Fetch Error:", e.getLocalizedMessage());
			}
		return result;
			}

	
	private static final class CPPromotionalCartDataMapper implements RowMapper<CPPromotionalCartData> {
		public CPPromotionalCartDataMapper() {
		}

		@Override
		public CPPromotionalCartData mapRow(ResultSet rs, int rowNum) throws SQLException {
			CPPromotionalCartData result = new CPPromotionalCartData();
			result.setSso(rs.getString("SSO"));
			result.setUpgradeId(rs.getInt("UPGRADE_ID"));
			result.setUpgradeName(rs.getString("UPGRADE_NAME"));
			result.setOptionId(rs.getInt("OPTION_ID"));
			result.setOptionName(rs.getString("OPTION_NAME"));
			result.setOptionDescription(rs.getString("OPTION_DESCRIPTION"));
			result.setPartNumber(rs.getString("PART_MODEL"));
			result.setQuantity(rs.getInt("QUANTITY"));
			result.setIndicator(rs.getString("INDICATOR"));
		    return result;
		}
	}

	@Override
	public int getPromotionalCartCount(String sso) {
		int result = 0;
		try{
		String sql = "select COUNT(*) from (SELECT  upgrade_id,option_id FROM FPTODS.SQT_SSO_PROMOTIONAL_CART WHERE SSO = ?)";
		result = this.jdbcTemplate.queryForInt(sql, new Object[] { sso });
		} catch(Exception e){
			logger.error("getPromotionalCartCount Data Fetch Error:", e.getLocalizedMessage());	
		}
		return result;
	}

	@Override
	public List<String> getSavedPromotionalCarts(String sso) {
		try {
			String sql = "SELECT DISTINCT CART_NAME FROM FPTODS.SQT_SSO_SAVED_PROMOTIONAL_CART WHERE SSO = ? ORDER BY CART_NAME";
			List<String> result = new ArrayList<String>();
			List<String> finalResult = new ArrayList<String>();
		     MapSqlParameterSource parameters = new MapSqlParameterSource();
			result = this.jdbcTemplate.queryForList(sql, new Object[] { sso }, String.class);
			for (String res : result) {
				String sqlUpgradeId = "SELECT DISTINCT UPGRADE_ID FROM FPTODS.SQT_SSO_SAVED_PROMOTIONAL_CART WHERE CART_NAME=?";
			/*	int upgradeId = this.jdbcTemplate.queryForInt(sqlUpgradeId, new Object[] { res });
				String sqlValidity = "select * from fptods.sqt_upgrade_info where upgrade_id=?";
			*/	
				List<Integer> listOfUpgradeIds = this.jdbcTemplate.queryForList(sqlUpgradeId, new Object[] { res },Integer.class);
				parameters.addValue("listOfUpgradeIds", listOfUpgradeIds);
				String sqlValidity = "select * from fptods.sqt_upgrade_info where upgrade_id in (:listOfUpgradeIds)";
				List<UpgradeInfo> upgradeInfoValues = this.namedParamTemplate.query(sqlValidity,parameters,
						new UpgradeInfoMapper());
				UpgradeInfo info = new UpgradeInfo();
				if (!upgradeInfoValues.isEmpty()) {
					info = upgradeInfoValues.get(0);
					Date date = new Date();
					// check validity of coupon code
					if ((info.getValidityFrom().before(date) && info.getValidityTo().after(date))) {
						finalResult.add(res);
					}
				}
			}
			return finalResult;
		} catch (Exception ex) {
			logger.error("Get saved promotional carts error: ", ex);
			return null;
		}
	}

	@Override
	public StatusInfo savePromotionalCart(String sso, String cartName) {
		logger.info("saving cartname" + "sso" + sso + "cartName" + cartName);
		StatusInfo result = new StatusInfo();
		List<Object[]> parameters = new ArrayList<Object[]>();
		try {
			String sql = "SELECT * FROM FPTODS.SQT_SSO_PROMOTIONAL_CART WHERE SSO=?";
			List<PromotionalCart> cartDataList = this.jdbcTemplate.query(sql, new Object[] { sso },
					new PromotionalSaveCartMapper());
			if (cartDataList.size() > 0) {
			//	String upgradeId = cartDataList.get(0).getUpgradeId();
				sql = "DELETE FROM FPTODS.SQT_SSO_SAVED_PROMOTIONAL_CART WHERE SSO = ? AND UPPER(CART_NAME)= ?";
				this.jdbcTemplate.update(sql, new Object[] { sso, cartName.toUpperCase() });
				for (int j = 0; j < cartDataList.size(); j++) {
					logger.info("cardToSaveData" + cartDataList.get(j));
			//	}
					String upgradeId = cartDataList.get(j).getUpgradeId();
				String sqlOptionValue = "select * from fptods.SQT_UPGRADE_PROMOTIONS where upgrade_id=?";
				List<UpgradePromotions> upgradeOptionsData = this.jdbcTemplate.query(sqlOptionValue,
						new Object[] { Integer.parseInt(upgradeId) }, new UpgradePromotionsMapper());
				String smiUpgradeInfo = "select * from FPTODS.SQT_UPGRADE_LEGACY_PN_MODEL where upgrade_id=?";
				List<UpgradePartModel> smiUpgradeInfoData = this.jdbcTemplate.query(smiUpgradeInfo,
						new Object[] { Integer.parseInt(upgradeId)}, new GetUpgradeOptionsPartModelMapper());
				String sqlRegionValue = "select * from fptods.sqt_upgrade_info where upgrade_id=?";
				List<UpgradeInfo> upgradeInfoData = this.jdbcTemplate.query(sqlRegionValue,
						new Object[] { Integer.parseInt(upgradeId) }, new UpgradeInfoMapper());
				String currencyCheck = upgradeInfoData.get(0).getRegion();
				logger.info("currency from upgradeinfo :"+currencyCheck);
				String brandUpgradeInfo = upgradeInfoData.get(0).getUpgradeBrand();
				String currency = "";
				if (currencyCheck.equalsIgnoreCase("EU") || currencyCheck.equalsIgnoreCase("Naples")) {
					currency = "EUR";
				} else if (currencyCheck.equalsIgnoreCase("NA") || currencyCheck.equalsIgnoreCase("LA") || currencyCheck.equalsIgnoreCase("Deer Park") ||
						currencyCheck.equalsIgnoreCase("Singapore")) {
					currency = "USD";
				} 
			//	for (int i = 0; i < cartDataList.size(); i++) {
					PromotionalCart promotionalCart = cartDataList.get(j);
					double listPrice = 0.0d;
					if(upgradeInfoData.get(0).getUpgradeId().equals(promotionalCart.getUpgradeId())
							&& promotionalCart.getOptionId().equals("0") && !upgradeInfoData.get(0).getCategory().equalsIgnoreCase("SMI")){
						listPrice = upgradeInfoData.get(0).getAmount() ;
						logger.info("Upgrades amount :"+ upgradeInfoData.get(0).getAmount());
					}
					for(UpgradeOptionDetails smiUpgrade : promotionalCart.getPartModel()){
						for(UpgradePartModel smiInfo:smiUpgradeInfoData){
							if(smiUpgrade.getPartModel().equalsIgnoreCase(smiInfo.getPartModel())){
								Double price= new Double(smiInfo.getDiscountPrice());
								if(price!=null){
								listPrice=	smiInfo.getDiscountPrice();
								}
								logger.info("smi discounted price  :"+listPrice);
								break;
							}
						}
					}
					for(UpgradePromotions upgradePromotions : upgradeOptionsData) {
						if (promotionalCart.getOptionId().equals(upgradePromotions.getOptionId())) {
							listPrice = upgradePromotions.getDiscountedAmount();
							logger.info("list Price for promotions :"+ listPrice);
							break;
						}
					}
					sql = "INSERT INTO FPTODS.SQT_SSO_SAVED_PROMOTIONAL_CART "
							+ "(CART_NAME, SSO, UPGRADE_ID, UPGRADE_NAME, OPTION_ID, OPTION_NAME, OPTION_DESCRIPTION, COUPON_CODE, PART_MODEL, INDICATOR, QUANTITY, CURRENCY, LIST_PRICE, SAVED_DATE, BRAND) "
							+ "VALUES " + "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? , ?, ? , sysdate , ?)";
					Object[] params = new Object[14];
					params[0] = cartName.toUpperCase();
					params[1] = sso;
					params[2] = Integer.valueOf(promotionalCart.getUpgradeId());
					params[3] = promotionalCart.getUpgradeName();
					params[4] = Integer.valueOf(promotionalCart.getOptionId());
					params[5] = promotionalCart.getOptionName();
					params[6] = promotionalCart.getOptionDescription();
					params[7] = promotionalCart.getCouponCode();
					params[8] = promotionalCart.getPartModel().get(0).getPartModel();
					params[9] = promotionalCart.getPartModel().get(0).getIndicator();
					params[10] = promotionalCart.getQuantity();
					params[11] = currency;
					params[12] = listPrice*(Integer.parseInt(promotionalCart.getQuantity()));
					params[13] = brandUpgradeInfo;
					parameters.add(params);
					logger.info("insert 1 row");
				}
				this.jdbcTemplate.batchUpdate(sql, parameters);
				
				result.setStatusCode(0);
				result.setStatusMessage("Cart promotional saved successfully.");
				return result;
				
			} else {
				logger.info("Save promotional cart error: Cart promotional is empty.");
				result.setStatusCode(-3);
				result.setStatusMessage("Cart promotional is empty.");
			}
			logger.info("Save promotional cart error: Cart promotional is empty.");
			result.setStatusCode(-3);
			result.setStatusMessage("Cart promotional is empty.");
			return result;
		} catch (Exception ex) {
			logger.error("Save cart error: ", ex);
			result.setStatusCode(-1);
			result.setStatusMessage(ex.getMessage());
			return result;
		}
	}

	@Override
	public int checkPromotionalCartExists(String sso, String cartName) {
		try {
			String sql = "SELECT COUNT(*) FROM FPTODS.SQT_SSO_SAVED_PROMOTIONAL_CART WHERE SSO = ? AND UPPER(CART_NAME) = ?";
			Object[] params = { sso, cartName.toUpperCase() };
			int count = this.jdbcTemplate.queryForInt(sql, params);
			if (count > 0)
				return 1;
			else
				return 0;
		} catch (Exception ex) {
			logger.error("Check promotional cart exists error: ", ex);
		}
		return -1;
	}

	@Override
	public StatusInfo loadPromotionalCart(String sso, String cartName) {
		StatusInfo result = new StatusInfo();
		try {
			String sql = "SELECT * FROM FPTODS.SQT_SSO_SAVED_PROMOTIONAL_CART WHERE SSO = ? AND UPPER(CART_NAME) = ?";
			List<PromotionalCart> cartDataList = this.jdbcTemplate.query(sql,
					new Object[] { sso, cartName.toUpperCase() }, new PromotionalSaveCartMapper());
			if (cartDataList.size() > 0) {
				int upgradeId = Integer.valueOf(cartDataList.get(0).getUpgradeId());
				sql = "DELETE FROM FPTODS.SQT_SSO_PROMOTIONAL_CART WHERE SSO = ?";
				this.jdbcTemplate.update(sql, new Object[] { sso });
				for (int i = 0; i < cartDataList.size(); i++) {
					PromotionalCart promotionalCart = cartDataList.get(i);
					sql = "INSERT INTO FPTODS.SQT_SSO_PROMOTIONAL_CART "
							+ "(SSO, UPGRADE_ID, UPGRADE_NAME, OPTION_ID, OPTION_NAME, OPTION_DESCRIPTION, COUPON_CODE, PART_MODEL, INDICATOR, QUANTITY) "
							+ "VALUES " + "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
					Object[] params = new Object[10];
					params[0] = sso;
					params[1] = Integer.valueOf(promotionalCart.getUpgradeId());
					params[2] = promotionalCart.getUpgradeName();
					params[3] = Integer.valueOf(promotionalCart.getOptionId());
					params[4] = promotionalCart.getOptionName();
					params[5] = promotionalCart.getOptionDescription();
					params[6] = promotionalCart.getCouponCode();
					params[7] = promotionalCart.getPartModel().get(0).getPartModel();
					params[8] = promotionalCart.getPartModel().get(0).getIndicator();
					params[9] = promotionalCart.getQuantity();
					logger.error("Data in loadPromotionalCart " + promotionalCart);
					this.jdbcTemplate.update(sql, params);
				}
				result.setStatusCode(0);
				result.setStatusMessage("Promotional Cart loaded successfully.");
			} else {
				logger.error("Load Promotional cart error: Cart does not exist.");
				result.setStatusCode(-2);
				result.setStatusMessage("Promotional Cart does not exist.");
			}
			return result;
		} catch (Exception ex) {
			logger.error("Promotional Load cart error: ", ex);
			result.setStatusCode(-1);
			result.setStatusMessage(ex.getMessage());
			return result;
		}
	}

	@Override
	public StatusInfo deletePromotionFromCart(String sso,PromotionalCartViewData promotionalCartViewData) {
		logger.info("inside deletepromotionCart");
		StatusInfo result = new StatusInfo();
		try {
			String sql = "DELETE FROM FPTODS.SQT_SSO_PROMOTIONAL_CART WHERE SSO = ? AND UPGRADE_ID = ? AND PART_MODEL = ?";
		//	int optionIdValue = promotionalCartViewData.getOptionId();
			logger.info("optionid :"+ promotionalCartViewData.getOptionId());
			logger.info("upgrade :"+ promotionalCartViewData.getUpgradeId());
			logger.info("part_model :"+ promotionalCartViewData.getPartNumber());
			int option_id=promotionalCartViewData.getOptionId();
			int upgrade_id = promotionalCartViewData.getUpgradeId();
			String part_model = promotionalCartViewData.getPartNumber();
			int rowsAffected = this.jdbcTemplate.update(sql, new Object[] {sso,upgrade_id,part_model});
			logger.info("inside deletepromotionCart - Step 1");
			if (rowsAffected == 0) {
				result.setStatusCode(-2);
				result.setStatusMessage("No rows deleted.");
				logger.info("result status :"+ result.getStatusCode());
				logger.info("result status msg :"+ result.getStatusMessage());
			} else {
				result.setStatusCode(0);
				result.setStatusMessage("Cart promotional deleted successfully.");
				logger.info("status :"+ result.getStatusMessage());
			}
			return result;
		} catch (Exception ex) {
			logger.error("Delete all from promotional cart error: ", ex);
			result.setStatusCode(-1);
			result.setStatusMessage(ex.getMessage());
			return result;
		}
	}

	@Override
	public StatusInfo deleteAllPromotionFromCart(String sso) {
		logger.error("inside deleteAllPromotionFromCart");
		StatusInfo result = new StatusInfo();
		try {
			logger.error("inside deleteAllPromotionFromCart --- Step 1");
			String sql = "DELETE FROM FPTODS.SQT_SSO_PROMOTIONAL_CART WHERE SSO = ?";
			int rowsAffected = this.jdbcTemplate.update(sql, new Object[] { sso });
			logger.error("inside deleteAllPromotionFromCart --- Step 2");
			if (rowsAffected == 0) {
				result.setStatusCode(-2);
				result.setStatusMessage("No rows deleted.");
			} else {
				result.setStatusCode(0);
				result.setStatusMessage("Cart promotional deleted successfully.");
			}
			return result;
		} catch (Exception ex) {
			logger.error("Delete all from promotional cart error: ", ex);
			result.setStatusCode(-1);
			result.setStatusMessage(ex.getMessage());
			return result;
		}
	}

	@Override
	public StatusInfo saveQuantity(String sso, PromotionalCartViewData promotionalcartViewData) {
		logger.info("inside saveUpgradeOptionQuantity");
		StatusInfo result = new StatusInfo();
		try {
			logger.info("Inside deleteAllPromotionFromCart --- Step 1" + sso + "optionid" + promotionalcartViewData.getOptionId() + "quantity" 
					+ promotionalcartViewData.getQuantity() + "upgradeId" + promotionalcartViewData.getUpgradeId() );
			String updateSql = "update FPTODS.SQT_SSO_PROMOTIONAL_CART set quantity=? " + "where sso=? and option_id=? and upgrade_id = ? and part_model=?";
			Object[] param = { promotionalcartViewData.getQuantity(), sso, promotionalcartViewData.getOptionId(),promotionalcartViewData.getUpgradeId(),promotionalcartViewData.getPartNumber() };
			this.jdbcTemplate.update(updateSql, param);
			logger.info("Inside deleteAllPromotionFromCart --- Step 2");
			result.setStatusCode(0);
			result.setStatusMessage("Upgrade Option Quantity Updated successfully.");
			logger.info("save quantity status :"+ result.getStatusMessage());
			return result;
		} catch (Exception ex) {
			logger.error("Upgrade Option Quantity Updation error: ", ex);
			result.setStatusCode(-1);
			result.setStatusMessage(ex.getMessage());
			return result;
		}
	}

	private static final class PromotionalSaveCartMapper implements RowMapper<PromotionalCart> {
		public PromotionalSaveCartMapper() {
		}

		@Override
		public PromotionalCart mapRow(ResultSet rs, int rowNum) throws SQLException {
			try {
				PromotionalCart promotionalCart = new PromotionalCart();
				logger.error("Inside PromotionalSaveCartMapper");
				promotionalCart.setSso(rs.getString("SSO") != null ? rs.getString("SSO") : "");
				int upgradeId = rs.getInt("UPGRADE_ID");
				promotionalCart.setUpgradeId(null != String.valueOf(upgradeId) ? String.valueOf(upgradeId) : "");
				promotionalCart
						.setUpgradeName(rs.getString("UPGRADE_NAME") != null ? rs.getString("UPGRADE_NAME") : "");
				int optionId = rs.getInt("OPTION_ID");
				promotionalCart.setOptionId(null != String.valueOf(optionId) ? String.valueOf(optionId) : "");
				promotionalCart.setOptionName(rs.getString("OPTION_NAME") != null ? rs.getString("OPTION_NAME") : "");
				promotionalCart.setOptionDescription(
						rs.getString("OPTION_DESCRIPTION") != null ? rs.getString("OPTION_DESCRIPTION") : "");
				promotionalCart.setCouponCode(rs.getString("COUPON_CODE") != null ? rs.getString("COUPON_CODE") : "");
				promotionalCart.setQuantity(rs.getString("QUANTITY") != null ? rs.getString("QUANTITY") : "");
				UpgradeOptionDetails upgradeOptions = new UpgradeOptionDetails();
				upgradeOptions.setPartModel((rs.getString("PART_MODEL") != null ? rs.getString("PART_MODEL") : ""));
				upgradeOptions.setIndicator((rs.getString("INDICATOR") != null ? rs.getString("INDICATOR") : ""));
				List<UpgradeOptionDetails> upgradeOptionsList = new ArrayList<UpgradeOptionDetails>();
				upgradeOptionsList.add(upgradeOptions);
				promotionalCart.setPartModel(upgradeOptionsList);
				return promotionalCart;
			} catch (Exception e) {
				logger.error("GetPromotionalSaveCartMapper Data Fetch Error:", e);
			}
			return null;
		}
	}

	private static final class PromotionalCartMapper implements RowMapper<PromotionalCart> {
		public PromotionalCartMapper() {
		}

		@Override
		public PromotionalCart mapRow(ResultSet rs, int rowNum) throws SQLException {
			try {
				PromotionalCart promotionalCart = new PromotionalCart();
				logger.error("Inside PromotionalCartMapper");
				promotionalCart.setSso(rs.getString("SSO") != null ? rs.getString("SSO") : "");
				int upgradeId = rs.getInt("UPGRADE_ID");
				promotionalCart.setUpgradeId(null != String.valueOf(upgradeId) ? String.valueOf(upgradeId) : "");
				promotionalCart
						.setUpgradeName(rs.getString("UPGRADE_NAME") != null ? rs.getString("UPGRADE_NAME") : "");
				int optionId = rs.getInt("OPTION_ID");
				promotionalCart.setOptionId(null != String.valueOf(optionId) ? String.valueOf(optionId) : "");
				promotionalCart.setOptionName(rs.getString("OPTION_NAME") != null ? rs.getString("OPTION_NAME") : "");
				promotionalCart.setOptionDescription(
						rs.getString("OPTION_DESCRIPTION") != null ? rs.getString("OPTION_DESCRIPTION") : "");
				promotionalCart.setCouponCode(rs.getString("COUPON_CODE") != null ? rs.getString("COUPON_CODE") : "");
				promotionalCart.setQuantity(rs.getString("QUANTITY") != null ? rs.getString("QUANTITY") : "");
				return promotionalCart;
			} catch (Exception e) {
				logger.error("GetPromotionalCartMapper Data Fetch Error:", e);
			}
			return null;
		}
	}

	private static final class UpgradeOptionsMapper implements RowMapper<UpgradeOptions> {
		public UpgradeOptionsMapper() {
		}

		@Override
		public UpgradeOptions mapRow(ResultSet rs, int rowNum) throws SQLException {
			UpgradeOptions result = new UpgradeOptions();
			int optionId = rs.getInt("option_id");
			result.setOptionId(null != String.valueOf(optionId) ? String.valueOf(optionId) : "");
			result.setOptionName(rs.getString("name") != null ? rs.getString("name") : "");
			result.setOptionValue(rs.getString("value") != null ? rs.getString("value") : "");
			result.setOptionDescription(rs.getString("description") != null ? rs.getString("description") : "");
			int upgradeId = rs.getInt("upgrade_id");
			result.setUpgradeId(null != String.valueOf(upgradeId) ? String.valueOf(upgradeId) : "");
			return result;
		}
	}

	
	private static final class UpgradeOptionsDetailsMapper implements RowMapper<UpgradeOptionDetails> {
		public UpgradeOptionsDetailsMapper() {
		}

		@Override
		public UpgradeOptionDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
			UpgradeOptionDetails result = new UpgradeOptionDetails();
			int optionId = rs.getInt("option_id");
			result.setOptionId(null != String.valueOf(optionId) ? String.valueOf(optionId) : "");
			result.setPartModel(rs.getString("part_model") != null ? rs.getString("part_model") : "");
			result.setIndicator(rs.getString("indicator") != null ? rs.getString("indicator") : "");
			return result;
		}
	}

	private static final class UpgradeOptionsPartModelMapper implements RowMapper<UpgradePartModel> {
		public UpgradeOptionsPartModelMapper() {
		}

		@Override
		public UpgradePartModel mapRow(ResultSet rs, int rowNum) throws SQLException {
			UpgradePartModel result = new UpgradePartModel();
			int upgradeId = rs.getInt("upgrade_id");
			result.setUpgradeId(null != String.valueOf(upgradeId) ? String.valueOf(upgradeId) : "");
			result.setPartModel(rs.getString("part_model") != null ? rs.getString("part_model") : "");
			result.setIndicator(rs.getString("indicator") != null ? rs.getString("indicator") : "");
			return result;
		}
	}

	private static final class UpgradeInfoMapper implements RowMapper<UpgradeInfo> {
		public UpgradeInfoMapper() {
		}

		@Override
		public UpgradeInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
			UpgradeInfo result = new UpgradeInfo();
			int upgradeId = rs.getInt("upgrade_id");
			result.setUpgradeId(null != String.valueOf(upgradeId) ? String.valueOf(upgradeId) : "");
			result.setUpgradeName(rs.getString("upgrade_name") != null ? rs.getString("upgrade_name") : "");
			result.setUpgradeBrand(rs.getString("brand") != null ? rs.getString("brand") : "");
			result.setUpgradeDescription(rs.getString("description") != null ? rs.getString("description") : "");
			result.setUpgradeModel(rs.getString("model") != null ? rs.getString("model") : "");
			result.setUpgradePart(rs.getString("part_id") != null ? rs.getString("part_id") : "");
			result.setCouponCode(rs.getString("coupon_code") != null ? rs.getString("coupon_code") : "");
			String region = rs.getString("region") != null ? rs.getString("region") : "";
			if(region!=""){
				if(region.equalsIgnoreCase("ME"))
					result.setRegion("Jebel Ali");
				else if(region.equalsIgnoreCase("AS"))
					result.setRegion("Singapore");
				else if(region.equalsIgnoreCase("EU"))
					result.setRegion("Naples");
				else if(region.equalsIgnoreCase("AF"))
					result.setRegion("Edenville");
				else if(region.equalsIgnoreCase("NA"))
					result.setRegion("Deer Park");
			}else
				result.setRegion(region);
			//result.setRegion(rs.getString("region") != null ? rs.getString("region") : "");
			result.setValidityFrom(rs.getDate("validity_from") != null ? rs.getDate("validity_from") : null);
			result.setValidityTo(rs.getDate("validity_to") != null ? rs.getDate("validity_to") : null);
			result.setPromo_file(rs.getString("promo_file") != null ? rs.getString("promo_file") : "");
			result.setPromo_name(rs.getString("promo_name") != null ? rs.getString("promo_name") : "");
			result.setAmount(rs.getDouble("amount"));
			result.setCategory(rs.getString("PROMOTION_CATEGORY")!=null?rs.getString("PROMOTION_CATEGORY"):"");
			return result;
		}
	}

	@Override
	public StatusInfo sendEmailNotification() {
		MailcapCommandMap mc = (MailcapCommandMap) CommandMap.getDefaultCommandMap();
		mc.addMailcap("text/html;; x-java-content-handler=com.sun.mail.handlers.text_html");
		mc.addMailcap("text/xml;; x-java-content-handler=com.sun.mail.handlers.text_xml");
		mc.addMailcap("text/plain;; x-java-content-handler=com.sun.mail.handlers.text_plain");
		mc.addMailcap("multipart/*;; x-java-content-handler=com.sun.mail.handlers.multipart_mixed");
		mc.addMailcap("message/rfc822;; x-java-content- handler=com.sun.mail.handlers.message_rfc822");
		logger.info("email notifications");
		String smtpHostServer = "smtpmail.np.ge.com";
		String smptfordev = "10.38.9.235";
		String mailSubject = "New orders to your region -- from welcome package";
		Properties props = System.getProperties();
		props.put("mail.smtp.host", smptfordev);
		props.put("mail.smtp.connectiontimeout", 120000);
	    props.put("mail.smtp.timeout", 120000);
		Session session = Session.getInstance(props, null);
		Message msg = new MimeMessage(session);
		StatusInfo info = new StatusInfo();
		try {
			String sql = "SELECT OU.SSO,TRUNC(OU.CREATION_DATE),TRUNC(OU.LAST_UPDATE_DATE ),CS.EMAIL,OU.SALES_ORDER,"
					+ "OU.PRODUCT_CODE,OU.SOURCESYSTEM,OU.COUNT_VAL,OU.CUSTOMER_PO,OU.SOLD_TO_CUSTOMER_NAME, OU.END_USER,OU.END_USER_INDUSTRY "
					+ "FROM FPTODS.SQT_CHANNEL_SSO CS INNER JOIN DDSAFM.ODS_SQT_BY_SALES_ORDER_SSO OU ON CS.SSO_ID = OU.SSO "
					+ "INNER JOIN FPTODS.SQT_CHANNEL_SETTINGS C ON CS.SSO_ID = C.USER_NAME "
					+ "WHERE TRUNC(OU.CREATION_DATE) > (SYSDATE - 7) AND OU.INTER_COMPANY IS NULL AND C.EMAIL_OPTION = 'Y' order by OU.sso";
			Map<String, List<EmailNotification>> emailData = null;
			emailData = this.jdbcTemplate.query(sql, new EmailSet());
			logger.info("result set" + emailData.size());
			BodyPart messageBodyPart1 = new MimeBodyPart();
			MimeBodyPart messageBodyPart2 = new MimeBodyPart();
			BodyPart messageBodyPart4 = new MimeBodyPart();
			msg.setFrom(new InternetAddress("Functional.Avo111samktdre@ge.com"));
			if (emailData != null) {
				logger.info("Keyset="+emailData.keySet().toString());
				for (String email : emailData.keySet()) {
					int r = 1;
					HSSFWorkbook workbook = new HSSFWorkbook();
					HSSFCellStyle align = workbook.createCellStyle();
					align.setAlignment(HSSFCellStyle.ALIGN_CENTER);
					align.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
					HSSFSheet sheet = workbook.createSheet("Sample Sheet");
					HSSFRow rowhead = sheet.createRow(0);
					rowhead.createCell(0).setCellValue("Sales Order");
					rowhead.createCell(1).setCellValue("Customer PO");
					rowhead.createCell(2).setCellValue("#Valves");
					rowhead.createCell(3).setCellValue("Sold to Customer name");
					rowhead.createCell(4).setCellValue("End User");
					rowhead.createCell(5).setCellValue("End User Industry");
					rowhead.createCell(6).setCellValue("Factory Shipped");
					rowhead.createCell(7).setCellValue("Brand");
					for (int j = 0; j < 8; j++) {
						HSSFCellStyle stylerowHeading = workbook.createCellStyle();
						Font font = workbook.createFont();
						font.setBold(true);
						font.setFontName(HSSFFont.FONT_ARIAL);
						font.setColor(HSSFFont.COLOR_RED);
						font.setFontHeightInPoints((short) 11);
						stylerowHeading.setAlignment(HSSFCellStyle.ALIGN_CENTER);
						stylerowHeading.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
						stylerowHeading.setFont(font);
						rowhead.getCell(j).setCellStyle(stylerowHeading);
					}
					for (EmailNotification emailNots : emailData.get(email)) {
						HSSFRow row = sheet.createRow(r);
						Cell cellId = row.createCell(0);
						cellId.setCellValue(emailNots.getSalesOrder());
						cellId.setCellStyle(align);
						Cell cellPO = row.createCell(1);
						cellPO.setCellValue(emailNots.getCustomerPo());
						cellPO.setCellStyle(align);
						Cell cellValveCount = row.createCell(2);
						cellValveCount.setCellValue(emailNots.getValveCnt());
						cellValveCount.setCellStyle(align);
						Cell cellCustName = row.createCell(3);
						cellCustName.setCellValue(emailNots.getSoldToCustName());
						cellCustName.setCellStyle(align);
						Cell cellEndUser = row.createCell(4);
						cellEndUser.setCellValue(emailNots.getEndUser());
						cellEndUser.setCellStyle(align);
						Cell cellEndUserInd = row.createCell(5);
						cellEndUserInd.setCellValue(emailNots.getEndUserIndustry());
						cellEndUserInd.setCellStyle(align);
						Cell cellFactoryShipped = row.createCell(6);
						cellFactoryShipped.setCellValue(emailNots.getSourceSystem());
						cellFactoryShipped.setCellStyle(align);
						Cell cellProdcode = row.createCell(7);
						cellProdcode.setCellValue(emailNots.getProductCode());
						cellProdcode.setCellStyle(align);
						for (int j = 0; j < 8; j++) {
							sheet.autoSizeColumn(j);
						}
						msg.setSubject(mailSubject);
						String mailText = "<img src=\"cid:image\"><br><br><br><font color=red><font size=\"3\" >This alert is to advise you that \"NEW\" orders have shipped into your "
								+ "territory and are available in GE\'s WELCOME PACKAGE<sup>TM</sup></font></font><br><br>";
						mailText += "<font color=red><font size=\"3\" >Click ";
						mailText += "<a href='https://sparesquotetool.na01.bhge.com/EquipmentTrack/'> <font color=red>here </font></a>"
								+ "to see them in your dashboard or view them from the attached.</font></font><br><br>"
								+ "\n" + "\n";
						mailText += "<font color=red><font size=\"3\" ><b>GE\'s Welcome Package is the <U><i>FASTEST</i></U> way to get a quote for spare parts "
								+ "on new equipment</b></font></font><br>" + "\n" + "\n";
						mailText += "<br><br><br><br><font color=red><font size=\"3\">PLEASE DO NOT REPLY TO THIS MAIL ID AS THIS MAIL BOX IS NOT MONITORED</font></font><br><br><br><br><br>"
								+ "\n" + "<img src=\"cid:image1\">";
						
						msg.setRecipient(javax.mail.Message.RecipientType.TO,
								new javax.mail.internet.InternetAddress(emailNots.getEmail()));
						messageBodyPart1.setContent(mailText, "text/html");
						r++;
					}
					ByteArrayOutputStream bos = new ByteArrayOutputStream();
					workbook.write(bos);
					bos.close();
					workbook.close();
					logger.info("excel written successfully");
					String filename = "ShipmentDetails.xls ";// change accordingly
					ByteArrayDataSource bs = new ByteArrayDataSource(bos.toByteArray(), "application/vnd.ms-excel");
					messageBodyPart2.setDataHandler(new DataHandler(bs));
					messageBodyPart2.setFileName(filename);
					MimeMultipart multipart = new MimeMultipart("related");
					MimeBodyPart messageBodyPart3 = new MimeBodyPart();
					multipart.addBodyPart(messageBodyPart1);
					multipart.addBodyPart(messageBodyPart2);
					byte[] bytes = IOUtils.toByteArray(this.getClass().getResourceAsStream(LOGO_IMAGE_LINK));
					javax.activation.DataSource ds = new ByteArrayDataSource(bytes, "application/x-any");
					multipart.addBodyPart(messageBodyPart3);
					msg.setContent(multipart);
					messageBodyPart3.setDataHandler(new DataHandler(ds));
					messageBodyPart3.setHeader("Content-ID", "<image>");
					byte[] bytes1 = IOUtils.toByteArray(this.getClass().getResourceAsStream(EMAIL_FOOTER));
					javax.activation.DataSource fds1 = new ByteArrayDataSource(bytes1, "application/x-any");
					multipart.addBodyPart(messageBodyPart4);
					msg.setContent(multipart);
					messageBodyPart4.setDataHandler(new DataHandler(fds1));
					messageBodyPart4.setHeader("Content-ID", "<image1>");
					Thread.currentThread().setContextClassLoader(getClass().getClassLoader());
					Transport.send(msg);
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Error=" + e.getLocalizedMessage() + "Get Message" + e.getMessage() + e.toString());
			info.setStatusMessage("Email Notification not successfull");
			info.setStatusCode(0);
		}
		
		info.setStatusMessage("successfull");
		info.setStatusCode(1);
		logger.info("Email Notification successful");
		return info;
	}

	private static final class EmailSet implements ResultSetExtractor<Map<String, List<EmailNotification>>> {

		@Override
		public Map<String, List<EmailNotification>> extractData(ResultSet rs) throws SQLException, DataAccessException {
			Map<String, List<EmailNotification>> result = new HashMap<String, List<EmailNotification>>();

			while (rs.next()) {
				EmailNotification email = new EmailNotification();
				email.setProductCode(rs.getString("product_code") != null ? rs.getString("product_code") : null);
				email.setSourceSystem(rs.getString("sourcesystem") != null ? rs.getString("sourcesystem") : null);
				email.setValveCnt(
						(rs.getString("count_val")) != null ? Integer.parseInt(rs.getString("count_val")) : null);
				email.setSalesOrder(rs.getString("sales_order") != null ? rs.getString("sales_order") : null);
				email.setCustomerPo(rs.getString("customer_po") != null ? rs.getString("customer_po") : null);
				email.setSoldToCustName(
						rs.getString("sold_to_customer_name") != null ? rs.getString("customer_po") : null);
				email.setEndUser(rs.getString("end_user") != null ? rs.getString("end_user") : null);
				email.setEndUserIndustry(
						rs.getString("end_user_industry") != null ? rs.getString("end_user_industry") : null);
				email.setEmail(rs.getString("email") != null ? rs.getString("email") : null);
				email.setCreationDate(
						rs.getDate("TRUNC(OU.CREATION_DATE)") != null ? rs.getDate("TRUNC(OU.CREATION_DATE)") : null);
				email.setLastUpdateDate(rs.getDate("TRUNC(OU.LAST_UPDATE_DATE)") != null
						? rs.getDate("TRUNC(OU.LAST_UPDATE_DATE)") : null);
				email.setSso(rs.getString("sso") != null ? rs.getString("sso") : null);
				if (result.get(rs.getString("sso")) != null) {
					result.get(rs.getString("sso")).add(email);
				} else {
					List<EmailNotification> finale = new ArrayList<EmailNotification>();
					finale.add(email);
					result.put(rs.getString("sso"), finale);
				}
			}
			return result;
		}
	}
	
	//Sindhura : Start :Delete functionality for upgrade module
	
	@Override
	public StatusInfo upgradeprogramdelete(String programupgradeId) {
		StatusInfo statusinfo= new StatusInfo();
		try{
			String sql= "delete from ddsafm.SQT_UPGRADE_LEGACY_PN_MODEL where upgrade_id= ?";
			this.jdbcTemplate.update(sql,programupgradeId);
			String upgradesql= "delete from fptods.sqt_upgrade_info where upgrade_id= ?";
			this.jdbcTemplate.update(upgradesql,programupgradeId);
			statusinfo.setStatusCode(1);
			statusinfo.setStatusMessage("Data deleted Successfully");
		} catch(Exception e){
			statusinfo.setStatusCode(500);
			statusinfo.setStatusMessage("Data deletion failed"+e.getLocalizedMessage());
		}
		return statusinfo;
	}

	@Override
	public StatusInfo upgradeoptionsdelete(String newupgradeId) {
		StatusInfo statusinfo= new StatusInfo();
		List<String> result= new ArrayList<String>();
		try{
			logger.info("Upgrade id in delete method is ="+newupgradeId);
			String sql= "select option_id from sqt_upgrade_options where upgrade_id= ?";
			result=this.jdbcTemplate.queryForList(sql, new Object[] {newupgradeId},String.class);
			logger.info("After query execution");
			for (String res : result) {
				int optionid=Integer.valueOf(res);	
				String deletecart= "delete from fptods.SQT_SSO_PROMOTIONAL_CART where OPTION_ID= ? ";
				this.jdbcTemplate.update(deletecart,optionid);
				String deletesavedcart= "delete from fptods.SQT_SSO_SAVED_PROMOTIONAL_CART where OPTION_ID= ? ";
				this.jdbcTemplate.update(deletesavedcart,optionid);
				String sqlUpgradeId = "delete from fptods.sqt_upgrade_option_details where option_id = ?";
				this.jdbcTemplate.update(sqlUpgradeId,optionid);
				logger.info("deleted part="+res+"option id="+optionid);
			}
				
			String sqloption= "delete from fptods.sqt_upgrade_options where upgrade_id=?";
			this.jdbcTemplate.update(sqloption,newupgradeId);
			logger.info("Deleting the program");
			statusinfo.setStatusCode(1);
			statusinfo.setStatusMessage("Data deleted Successfully");
				
		} catch(Exception e){
			statusinfo.setStatusCode(500);
			statusinfo.setStatusMessage("Data deletion failed"+e.getLocalizedMessage());
		}
		return statusinfo;
	}

	@Override
	public StatusInfo upgradeoptiondeleteById(String newupgradeId, String programOptionId) {
		logger.info("deleted part=option id=");
		StatusInfo statusinfo= new StatusInfo();
		try{
				String deletecart= "delete from fptods.SQT_SSO_PROMOTIONAL_CART where OPTION_ID= ? ";
				this.jdbcTemplate.update(deletecart,programOptionId);
				String deletesavedcart= "delete from fptods.SQT_SSO_SAVED_PROMOTIONAL_CART where OPTION_ID= ? ";
				this.jdbcTemplate.update(deletesavedcart,programOptionId);
				String sqlUpgradeId = "delete from fptods.sqt_upgrade_option_details where option_id = ?";
				this.jdbcTemplate.update(sqlUpgradeId,programOptionId);
				logger.info("deleted part="+"option id="+programOptionId);
				String sql= "delete from fptods.sqt_upgrade_options where option_id=?";
				this.jdbcTemplate.update(sql,programOptionId);
				logger.info("deleting the option"+ sql);
			statusinfo.setStatusCode(1);
			statusinfo.setStatusMessage("Data deleted Successfully");
				
		} catch(Exception e){
			statusinfo.setStatusCode(500);
			statusinfo.setStatusMessage("Data deletion failed"+e.getLocalizedMessage());
		}
		return statusinfo;
	
	}	
	//Sindhura : End :Delete functionality for upgrade module

	
	@Override
	public List<UpgradeInfoNew> getUpgradeDetailsDataNew() {
		String s="/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAIBAQIBAQICAgICAgICAwUDAwMDAwYEBAMFBwYHBwcG BwcICQsJCAgKCAcHCg0KCgsMDAwMBwkODw0MDgsMDAz/2wBDAQICAgMDAwYDAwYMCAcIDAwMDAwM DAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCAAiACADASIA AhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQA AAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3 ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWm p6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEA AwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSEx BhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElK U1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3 uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD5i/4K Ff8ABQn4++Cv2+fjdo2jfG74v6Vo+k/EDXrOysbLxlqMFvZQR6jOkcMcaShURVCqqqAAAABXj7f8 FLf2jmjUj4//ABt5A/5nrUx/7Xp//BS//lI18f8AgFf+Fj+IucY/5ilzXiaMCV9ckHjmv6uwGX4V 4Sk3Sjflj9ldkfkdfE1VVkuZ7vqz7H/4J6/8FBvj540/b5+COj6z8cfjBqukar8QNBs72xvfGOoz 217BJqNukkUkbTFXjdGZWUgggkEc1/U3X8gn/BND/lI98APl+78SfDo4/wCwnbf/AF6/r7r8h8UK FOliqCpxSTi9lbqfZ8LVJzpT53fVfkfyFf8ABS1P+NjHx+A+bPxJ8RfKR/1FLj/P4V4mYtpH9/A7 dK/sC8T/APBPj4B+NvEV/q+s/BD4Qatq2q3Mt5fXt74N06e4vJ5WLySySPCWd3ZmZmYkksSTk1S/ 4dp/s5f9EA+Cf/hDaZ/8Yr2cP4o4WnQhSdCXupLddEcNThStKo5qotX2P5cv+CaS4/4KOfs/8/8A NSfDuMDA/wCQpb/0zX9fNeQeGf8Agnv8A/BfiSw1nR/gf8INJ1fSrmO9sr6y8G6dBc2c8bh45Y5E hDI6uqsrKQQQCDkV6/Xw/GPEtLOa1OrSg48qtr6nvZNlk8FCUZyvdhRRRXxx7IUUUUAf/9k=";
		long n=s.getBytes().length;
		long n1=s.getBytes(Charset.forName("UTF-8")).length;
		logger.info("Mu image string size"+n);
		logger.info("Mu image string size"+n1);

		List<UpgradeInfoNew> result = new ArrayList<UpgradeInfoNew>();
		try {
			String sql = "SELECT A.UPGRADE_ID,UPGRADE_NAME,VALIDITY_FROM,VALIDITY_TO,PROMOTION_CATEGORY,DESCRIPTION,"
					+ " PART_ID,MODEL,DISCOUNT,COUPON_CODE,REGION,BRAND,DOCUMENT_COUNT  from FPTODS.SQT_UPGRADE_INFO  A LEFT OUTER JOIN "
					+ " ( SELECT UPGRADE_ID , COUNT (DISTINCT DOCUMENT_ID) AS DOCUMENT_COUNT FROM FPTODS.SQT_UPGRADE_PACKAGE_DOCUMENT_T  where DCOUMENT_CONTENT ='Upgrade' GROUP BY UPGRADE_ID )B"
					+ " ON B.UPGRADE_ID=A.UPGRADE_ID ";
			result = this.jdbcTemplate.query(sql,new UpgradeInfoNewMapper());
			//return result;

			/*MapSqlParameterSource parameters = new MapSqlParameterSource(setFilterUpgradeInfoParams(upgradeInfo));
			if (upgradeInfo != null) {
				String filter = getFilterUpgradeInfoClause(upgradeInfo);
				sql = sql + filter;
			}
			sql += ")";
			result = this.namedParamTemplate.query(sql, parameters, new UpgradeInfoNewMapper());*/
		} catch (Exception e) {
			logger.error("Exception in getUpgradeDetailsDataNew" + e.getLocalizedMessage());
		}
		return result;
	}
	
	public Map<String, String> setFilterUpgradeInfoParams(UpgradeInfoNew upgradeInfo) {
		Map<String, String> result = new HashMap<String, String>();
		result.put("upgradeId", upgradeInfo.getUpgradeId() == null ? "" : upgradeInfo.getUpgradeId().toUpperCase());
		result.put("upgradeName",
				upgradeInfo.getUpgradeName() == null ? "" : upgradeInfo.getUpgradeName().toUpperCase());
		result.put("upgradeBrand",
				upgradeInfo.getUpgradeBrand() == null ? "" : upgradeInfo.getUpgradeBrand().toUpperCase());
		result.put("upgradeDescription",
				upgradeInfo.getUpgradeDescription() == null ? "" : upgradeInfo.getUpgradeDescription().toUpperCase());
		result.put("upgradeModel",
				upgradeInfo.getUpgradeModel() == null ? "" : upgradeInfo.getUpgradeModel().toUpperCase());
		result.put("upgradePart",
				upgradeInfo.getUpgradePartId() == null ? "" : upgradeInfo.getUpgradePartId().toUpperCase());
		result.put("couponCode", upgradeInfo.getCouponCode() == null ? "" : upgradeInfo.getCouponCode().toUpperCase());
		result.put("region", upgradeInfo.getRegion() == null ? "" : upgradeInfo.getRegion().toUpperCase());
		return result;
	}

	public String getFilterUpgradeInfoClause(UpgradeInfoNew upgradeInfo) {
		String filter = "";
		List<String> conditions = new ArrayList<String>();
		if (upgradeInfo != null) {
			if (upgradeInfo.getUpgradeName() != null && !upgradeInfo.getUpgradeName().isEmpty()) {
				conditions.add(" UPPER(UPGRADE_ID) LIKE '%' || :upgradeId || '%'");
			}
			if (upgradeInfo.getUpgradeName() != null && !upgradeInfo.getUpgradeName().isEmpty()) {
				conditions.add(" UPPER(UPGRADE_NAME) LIKE '%' || :upgradeName || '%'");
			}
			if (upgradeInfo.getUpgradeBrand() != null && !upgradeInfo.getUpgradeBrand().isEmpty()) {
				conditions.add(" UPPER(BRAND) LIKE '%' || :upgradeBrand || '%'");
			}
			if (upgradeInfo.getUpgradeDescription() != null && !upgradeInfo.getUpgradeDescription().isEmpty()) {
				conditions.add(" UPPER(DESCRIPTION) LIKE '%' || :upgradeDescription || '%'");
			}
			if (upgradeInfo.getUpgradeModel() != null && !upgradeInfo.getUpgradeModel().isEmpty()) {
				conditions.add(" UPPER(MODEL) LIKE '%' || :upgradeModel || '%'");
			}
			if (upgradeInfo.getUpgradePartId() != null && !upgradeInfo.getUpgradePartId().isEmpty()) {
				conditions.add(" UPPER(PART_ID) LIKE '%' || :upgradePart || '%'");
			}
			if (upgradeInfo.getCouponCode() != null && !upgradeInfo.getCouponCode().isEmpty()) {
				conditions.add(" UPPER(COUPON_CODE) LIKE '%' || :couponCode || '%'");
			}
			if (upgradeInfo.getRegion() != null && !upgradeInfo.getRegion().isEmpty()) {
				conditions.add(" UPPER(REGION) LIKE '%' || :region || '%'");
			}
		}
		if (conditions.size() > 0) {
			String condStr = "";

			for (int i = 0; i < conditions.size(); i++) {
				condStr += (" AND " + conditions.get(i));
			}

			filter = condStr;
		}
		return filter;
	}
	
	private static final class UpgradeInfoNewMapper implements RowMapper<UpgradeInfoNew> {
		public UpgradeInfoNewMapper() {
		}

		@Override
		public UpgradeInfoNew mapRow(ResultSet rs, int rowNum) throws SQLException {
			UpgradeInfoNew result = new UpgradeInfoNew();
			int upgradeId = rs.getInt("UPGRADE_ID");
			String str = rs.getString("PROMOTION_CATEGORY");
			logger.info("Is internal value=" + str);
			result.setUpgradeId(null != String.valueOf(upgradeId) ? String.valueOf(upgradeId) : "");
			result.setUpgradeName(rs.getString("UPGRADE_NAME") != null ? rs.getString("UPGRADE_NAME") : "");
			result.setValidityFrom(rs.getDate("VALIDITY_FROM") != null ? rs.getDate("VALIDITY_FROM") : null);
			result.setValidityTo(rs.getDate("VALIDITY_TO") != null ? rs.getDate("VALIDITY_TO") : null);
			result.setCategory(rs.getString("PROMOTION_CATEGORY") != null ? rs.getString("PROMOTION_CATEGORY") : "");
			if(null!=str && str.equalsIgnoreCase("Model")){
				logger.info("Inside Model=" + rs.getString("MODEL"));
				result.setUpgradePartId(rs.getString("MODEL") != null ? rs.getString("MODEL") : "");
			}else{
				logger.info("Inside Part=" + rs.getString("PART_ID"));
				result.setUpgradePartId(rs.getString("PART_ID") != null ? rs.getString("PART_ID") : "");
			}
			double discount = rs.getDouble("DISCOUNT");
			result.setDiscount(discount);
			result.setCouponCode(rs.getString("COUPON_CODE") != null ? rs.getString("COUPON_CODE") : "");
			// NEEED TO ASK REGION 
			String region = (rs.getString("REGION") != null ? rs.getString("REGION") : "");
			if(region!=""){
				if(region.equalsIgnoreCase("AS"))
					result.setRegion("Singapore");
				else if(region.equalsIgnoreCase("AF"))
					result.setRegion("Edenville");
				else if(region.equalsIgnoreCase("EU"))
					result.setRegion("Naples");
				else if(region.equalsIgnoreCase("NA"))
					result.setRegion("Deer Park");
				else if(region.equalsIgnoreCase("ME"))
					result.setRegion("Jebel Ali	");
				else if(region.equalsIgnoreCase("LA"))
					result.setRegion("Latin America");
			}
			result.setUpgradeDescription(rs.getString("DESCRIPTION") != null ? rs.getString("DESCRIPTION") : "");
			result.setUpgradeBrand(rs.getString("BRAND") != null ? rs.getString("BRAND") : "");
			/*String brand = rs.getString("BRAND") != null ? rs.getString("BRAND") : "";
			if(brand!=""){
				if(brand.equalsIgnoreCase("MASONEILAN"))
					result.setUpgradeBrand("MN");
				else if(brand.equalsIgnoreCase("CONSOLIDATED"))
					result.setUpgradeBrand("CN");
			}else
				result.setUpgradeBrand(brand);*/
			int document_Count = rs.getInt("DOCUMENT_COUNT");
			result.setDocument_Count(null != String.valueOf(document_Count) ? String.valueOf(document_Count) : "");
			return result;
		}
	}
	
	@Override
	public StatusInfo deleteUpgradeInfoByID(UpgradeInfoNewDTO upgradeInfoNewDTO) {
		StatusInfo statusinfo= new StatusInfo();
		try{
			for (String upgraId : upgradeInfoNewDTO.getUpgradeId()) 
			{
				
				
				String sqlPromo= "Delete From FPTODS.SQT_UPGRADE_PROMOTIONS Where upgrade_id= ?";
				this.jdbcTemplate.update(sqlPromo,upgraId);

				String sql= "Delete From FPTODS.SQT_UPGRADE_INFO Where upgrade_id= ?";
				
				this.jdbcTemplate.update(sql,upgraId);
				statusinfo.setStatusCode(1);
				statusinfo.setStatusMessage("Data deleted Successfully");
			}
		}
		catch(Exception e){
			statusinfo.setStatusCode(500);
			statusinfo.setStatusMessage("Data deletion failed"+e.getLocalizedMessage());
		}
		return statusinfo;
	}
	
	@Override
	public StatusInfo getUpgradeNewInfoPartFileUpload(HashMap getCompleteData) {
		StatusInfo statusinfo= new StatusInfo();
		return statusinfo;

	}
	
	private static final class GetUpgradeInfoNewMapper implements RowMapper<UpgradeInfo> {
		public GetUpgradeInfoNewMapper() {
		}

		@Override
		public UpgradeInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
			UpgradeInfo result = new UpgradeInfo();
			int upgradeId = rs.getInt("UPGRADE_ID");
			result.setUpgradeId(null != String.valueOf(upgradeId) ? String.valueOf(upgradeId) : "");
			result.setUpgradeName(rs.getString("UPGRADE_NAME") != null ? rs.getString("UPGRADE_NAME") : "");
			result.setUpgradeBrand(rs.getString("BRAND") != null ? rs.getString("BRAND") : "");
			result.setUpgradeDescription(rs.getString("DESCRIPTION") != null ? rs.getString("DESCRIPTION") : "");
			String partOrModel = rs.getString("PROMOTION_CATEGORY");
			if(partOrModel.equalsIgnoreCase("Model")){
				result.setUpgradePart(rs.getString("MODEL") != null ? rs.getString("MODEL") : "");
			}else{
				result.setUpgradePart(rs.getString("PART_ID") != null ? rs.getString("PART_ID") : "");
			}
			result.setRegion(rs.getString("REGION") != null ? rs.getString("REGION") : "");
			result.setCouponCode(rs.getString("COUPON_CODE") != null ? rs.getString("COUPON_CODE") : "");
			result.setValidityFrom(rs.getDate("VALIDITY_FROM") != null ? rs.getDate("VALIDITY_FROM") : null);
			result.setValidityTo(rs.getDate("VALIDITY_TO") != null ? rs.getDate("VALIDITY_TO") : null);
			result.setPromo_file(rs.getString("PROMO_FILE") != null ? rs.getString("PROMO_FILE") : "");
			result.setPromo_name(rs.getString("PROMO_NAME") != null ? rs.getString("PROMO_NAME") : "");
			result.setCategory(rs.getString("PROMOTION_CATEGORY") != null ? rs.getString("PROMOTION_CATEGORY") : "");
			result.setFeaturedUpgrade(rs.getString("FEATURED_UPGRADE") != null ? rs.getString("FEATURED_UPGRADE") : "");
			double amount = rs.getDouble("AMOUNT");
			result.setAmount(amount);
			double discount = rs.getDouble("DISCOUNT");
			result.setDiscount(discount);
			result.setDisplayOnDashBoard(rs.getString("DISPLAY_ON_DASHBOARD") != null ? rs.getString("DISPLAY_ON_DASHBOARD") : "");
			return result;
		}
	}
	private static final class GetUpgradeOptionsPartModelMapper implements RowMapper<UpgradePartModel> {
		public GetUpgradeOptionsPartModelMapper() {
		}

		@Override
		public UpgradePartModel mapRow(ResultSet rs, int rowNum) throws SQLException {
			UpgradePartModel result = new UpgradePartModel();
			int upgradeId = rs.getInt("UPGRADE_ID");
			result.setUpgradeId(null != String.valueOf(upgradeId) ? String.valueOf(upgradeId) : "");
			result.setPartModel(rs.getString("PART_MODEL") != null ? rs.getString("PART_MODEL") : "");
			result.setIndicator(rs.getString("INDICATOR") != null ? rs.getString("INDICATOR") : "");
			double discountPrice = rs.getDouble("DISCOUNT_PRICE");
			result.setDiscountPrice(discountPrice);
			return result;
		}
	}
	
	private static final class GetUpgradeDocumentMapper implements RowMapper<UpgradeDocument> {
		public GetUpgradeDocumentMapper() {
		}

		@Override
		public UpgradeDocument mapRow(ResultSet rs, int rowNum) throws SQLException {
			UpgradeDocument result = new UpgradeDocument();
			int upgradeId = rs.getInt("UPGRADE_ID");
			result.setUpgradeId(null != String.valueOf(upgradeId) ? String.valueOf(upgradeId) : "");
			int documentId = rs.getInt("DOCUMENT_ID");
			result.setDocumentId(null != String.valueOf(documentId) ? String.valueOf(documentId) : "");
			int optionId = rs.getInt("OPTION_ID");
			result.setOptionId(null != String.valueOf(optionId) ? String.valueOf(optionId) : "");
			result.setDocumentName(rs.getString("DOCUMENT_NAME") != null ? rs.getString("DOCUMENT_NAME") : "");
			result.setDocumentType(rs.getString("DOCUMENT_TYPE") != null ? rs.getString("DOCUMENT_TYPE") : "");
			result.setLanguage(rs.getString("LANGUAGE") != null ? rs.getString("LANGUAGE") : "");
			result.setDocumentUploadPath(rs.getString("DOCUMENT_UPLOAD_PATH") != null ? rs.getString("DOCUMENT_UPLOAD_PATH") : "");
			
			return result;
		}
	}
	
	@Override
	public List<CPUpgradeInfo> getCpUpgradesListData(String sso,String region,CPUpgradeInfo cpUpgradeInfo) {
	List<CPUpgradeInfo> cpUpgradeInfoList = new ArrayList<>();
	try{
	boolean isInternal = WelcomePkgServiceImpl.isInternalUser(sso);
	logger.info("Is internal value=" + isInternal);
	 //Get all valid upgrades  
	String upgradesType = cpUpgradeInfo.getUpgradesType();
	String query1 = "select * from SQT_UPGRADE_INFO where VALIDITY_FROM<=TRUNC(sysdate) AND VALIDITY_TO>=TRUNC(sysdate) AND PROMOTION_CATEGORY=:upgradesType ORDER BY VALIDITY_FROM DESC,FEATURED_UPGRADE DESC";
	String query2 = "select * from SQT_UPGRADE_INFO where REGION=:region AND VALIDITY_FROM<=TRUNC(sysdate) AND VALIDITY_TO>=TRUNC(sysdate) AND PROMOTION_CATEGORY=:upgradesType ORDER BY VALIDITY_FROM DESC,FEATURED_UPGRADE DESC";
	String sql = (isInternal == true ? query1 : query2);
	logger.info("Selected query =" + (isInternal == true ? query1 : query2));
	MapSqlParameterSource paramMap = new MapSqlParameterSource();
	paramMap.addValue("region", region);
	paramMap.addValue("upgradesType", upgradesType);
	cpUpgradeInfoList=this.namedParamTemplate.query(sql, paramMap,
	new CPUpgradeMapper());
	
	logger.info("All valid upgrades are"+cpUpgradeInfo);
	
	   for(int i=0; i<cpUpgradeInfoList.size();i++)  {
		 //Set Serial Number
		cpUpgradeInfoList.get(i).setSerialNo(i+1);
		  
		//Set Days Remaining 
		int daysBetween = Days.daysBetween(new LocalDate(new Date().getTime()),new LocalDate(cpUpgradeInfoList.get(i).getEndDate().getTime())).getDays();
		 cpUpgradeInfoList.get(i).setDaysRemaining(daysBetween);
		 
	   
		 //Check for State 
         int noOfDays = 7; //i.e one week
       	 GregorianCalendar cal = new GregorianCalendar();
		 cal.setTime(cpUpgradeInfoList.get(i).getStartDate());
		 cal.add(Calendar.DATE, noOfDays);
		 Date validTillDate = cal.getTime();
		   if(validTillDate.after(new Date())){
			   cpUpgradeInfoList.get(i).setState("New");
		   }
		   else{
			   cpUpgradeInfoList.get(i).setState("Old"); 
		   }
		 }
	} catch (Exception ex){
		logger.error("Exception is getCpUpgradesListData method"+ex.getMessage());
	}
	return cpUpgradeInfoList;
	}

	private static final class CPUpgradeMapper implements RowMapper<CPUpgradeInfo> {
		public CPUpgradeMapper() {
		}

		@Override
		public CPUpgradeInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
			CPUpgradeInfo result = new CPUpgradeInfo();
			int upgradeId = rs.getInt("UPGRADE_ID");
			result.setUpgradeId(String.valueOf(upgradeId));
			result.setDiscountPercentage(rs.getLong("DISCOUNT"));
			result.setUpgradeName(rs.getString("UPGRADE_NAME"));
			result.setDescription(rs.getString("DESCRIPTION"));
			result.setUpgradesType(rs.getString("PROMOTION_CATEGORY"));
			result.setImage(rs.getString("PROMO_FILE"));
			result.setStartDate(rs.getDate("VALIDITY_FROM"));
			result.setEndDate(rs.getDate("VALIDITY_TO"));

			return result;
		}
	}
	

	//Raj Changes
	@Override
	public List<UpgradeInfo> getUpgradeNewInfo(String upgradeId) {
		logger.error("Inside the getUpgradeNewInfo method" + upgradeId);
		List<UpgradeInfo> result = new ArrayList<UpgradeInfo>();
		List<UpgradeInfo> finalResults = new ArrayList<UpgradeInfo>();
		try{
			String sql = "select * from FPTODS.SQT_UPGRADE_INFO where upgrade_id=?";	
			result = this.jdbcTemplate.query(sql,new Object[] { Integer.parseInt(upgradeId) }, new GetUpgradeInfoNewMapper());
			for (UpgradeInfo upgradeInfoItems : result) {
				//List Of Part Info
				String sqlForUpgradePartModel = "select * from FPTODS.sqt_upgrade_legacy_pn_model where upgrade_id=:upgradeId";
				MapSqlParameterSource paramMap = new MapSqlParameterSource();
				int upgradeIdNew =Integer.parseInt(upgradeInfoItems.getUpgradeId());
				paramMap.addValue("upgradeId", upgradeIdNew);
				List<UpgradePartModel> newUpgardePartModel = this.namedParamTemplate.query(sqlForUpgradePartModel, paramMap, new GetUpgradeOptionsPartModelMapper());
				upgradeInfoItems.setUpgradePartModel(newUpgardePartModel);
				//List Of Document Info
				String sqlForUpgradeDoc = "select * from FPTODS.SQT_UPGRADE_PACKAGE_DOCUMENT_T where option_id =0 and upgrade_id=:upgradeId ";
				MapSqlParameterSource paramMapDoc = new MapSqlParameterSource();
				paramMapDoc.addValue("upgradeId", upgradeIdNew);
				List<UpgradeDocument> documentList = this.namedParamTemplate.query(sqlForUpgradeDoc, paramMapDoc, new GetUpgradeDocumentMapper());
				upgradeInfoItems.setUpgradeDocument(documentList);
				finalResults.add(upgradeInfoItems);
			
				}
			} catch (Exception e) {
			logger.error("Exception in getUpgradeDetailsData" + e.getLocalizedMessage());
		}
			return finalResults;
}
	
	
	@Override
	public StatusInfo deleteUpgradePackageDocument(String documentID) {
		StatusInfo statusinfo= new StatusInfo();
		try{
			
				// Check Document in DB 
				int documentId=Integer.parseInt(documentID) ;
				
				String sqlCheck = "select count(DOCUMENT_ID) from FPTODS.SQT_UPGRADE_PACKAGE_DOCUMENT_T where DOCUMENT_ID=?";
				int countDoc = this.jdbcTemplate.queryForInt(sqlCheck,documentId);
				// Delete Document from DB 
				if (countDoc>0){
				String sql= "Delete FPTODS.SQT_UPGRADE_PACKAGE_DOCUMENT_T Where DOCUMENT_ID= ?";
				this.jdbcTemplate.update(sql,documentId);
				statusinfo.setStatusCode(1);
				statusinfo.setStatusMessage("Data deleted Successfully");
				}
				
		}
		catch(Exception e){
			statusinfo.setStatusCode(500);
			statusinfo.setStatusMessage("Data deletion failed"+e.getLocalizedMessage());
		}
		return statusinfo;
	}
	
	//Package Code
	@Override
	public List<UpgradeInfoNew> getUpgradeNewInfoById(String upgradeId) {
		logger.error("Inside the getUpgradeNewInfo method" + upgradeId);

		List<UpgradeInfoNew> result = new ArrayList<UpgradeInfoNew>();
		try{
			String sql = QueryConstants.getUpgradeNewInfoById;
			
			result = this.jdbcTemplate.query(sql,new Object[] { Integer.parseInt(upgradeId),Integer.parseInt(upgradeId) }, new UpgradeInfoNewMapper());
			
			} catch (Exception e) {
			logger.error("Exception in getUpgradeDetailsData" + e.getLocalizedMessage());
		}
			return result;
	}
	
	@Override
	public List<UpgradeOptions> getUpgradeOptionNewInfoById(String upgradeId) {
		logger.error("getUpgradeOptionNewInfoById" + upgradeId);
		List<UpgradeOptions> result = new ArrayList<UpgradeOptions>();
		try{
			
			String sql = QueryConstants.getUpgradeOptionNewInfoById;
			
			result = this.jdbcTemplate.query(sql,new Object[] { Integer.parseInt(upgradeId) }, new UpgradeOptionsNewMapper());
			
			} catch (Exception e) {
			logger.error("Exception in getUpgradeDetailsData" + e.getLocalizedMessage());
		}
			return result;
	}
	
	private static final class UpgradeOptionsNewMapper implements RowMapper<UpgradeOptions> {
		public UpgradeOptionsNewMapper() {
		}

		@Override
		public UpgradeOptions mapRow(ResultSet rs, int rowNum) throws SQLException {
			UpgradeOptions result = new UpgradeOptions();
			int optionId = rs.getInt("OPTION_ID");
			result.setOptionId(null != String.valueOf(optionId) ? String.valueOf(optionId) : "");
			result.setOptionName(rs.getString("NAME") != null ? rs.getString("NAME") : "");
			result.setOptionValue(rs.getString("VALUE") != null ? rs.getString("VALUE") : "");
			result.setOptionDescription(rs.getString("DESCRIPTION") != null ? rs.getString("DESCRIPTION") : "");
			int upgradeId = rs.getInt("UPGRADE_ID");
			result.setUpgradeId(null != String.valueOf(upgradeId) ? String.valueOf(upgradeId) : "");
			result.setKitNumber(rs.getString("KIT_NUMBER") != null ? rs.getString("KIT_NUMBER") : "");
			int document_Count = rs.getInt("DOCUMENT_COUNT");
			result.setDocCount (null != String.valueOf(document_Count) ? String.valueOf(document_Count) : "");
		
			result.setDiscountedAmount(rs.getString("discounted_amount") != null ? rs.getString("discounted_amount") : "");
			return result;
		}
	}
	
	@Override
	public StatusInfo deleteUpgradeOptionsNew(UpgradeOptionListDTO OptionList) {
		StatusInfo statusinfo= new StatusInfo();
		
		try{
			for (String optionId : OptionList.getOptionId()) 
			{
				logger.info("OptionID delete method is ="+optionId);
				
				int documentId=Integer.parseInt(optionId) ;
					
					logger.info("Deleting ID"+documentId);
					
					String sqlDocId = "Delete From fptods.SQT_UPGRADE_PACKAGE_DOCUMENT_T Where option_id = ?";
					this.jdbcTemplate.update(sqlDocId,documentId);
					
					String sqlUpgradeId = "Delete From fptods.sqt_upgrade_option_details Where option_id = ?";
					this.jdbcTemplate.update(sqlUpgradeId,documentId);
					
					String sqlUpgradeIdPro = "Delete From FPTODS.SQT_UPGRADE_PROMOTIONS Where option_id = ?";
					this.jdbcTemplate.update(sqlUpgradeIdPro,documentId);
					
					String deletecart= "Delete From fptods.SQT_SSO_PROMOTIONAL_CART Where OPTION_ID= ? ";
					this.jdbcTemplate.update(deletecart,documentId);
					
					String deletesavedcart= "Delete From fptods.SQT_SSO_SAVED_PROMOTIONAL_CART Where OPTION_ID= ? ";
					this.jdbcTemplate.update(deletesavedcart,documentId);
					
					String deletesqloption= "Delete from fptods.sqt_upgrade_options Where option_id=?";
					this.jdbcTemplate.update(deletesqloption,documentId);
				
					statusinfo.setStatusCode(1);
				statusinfo.setStatusMessage("Data deleted Successfully");
			}
			
		}
		catch(Exception e){
			statusinfo.setStatusCode(500);
			statusinfo.setStatusMessage("Data deletion failed"+e.getLocalizedMessage());
		}
		return statusinfo;
	}
	
	
	@Override
	public StatusInfo saveUpgradeOptionInfo(String sso,UpgradeOptions upgradeOptions) {
		StatusInfo statusinfo = new StatusInfo();
		logger.info("inside saveUpgradeOptionInfo");

		TransactionDefinition transDef = new DefaultTransactionDefinition();
		TransactionStatus saveUpgradeDetailsTM = txManager.getTransaction(transDef);
		
		try {
			String sql = "select count(OPTION_ID) from FPTODS.SQT_UPGRADE_OPTIONS where OPTION_ID=?";
			String saveSql = "";
			int count = this.jdbcTemplate.queryForInt(sql, new Object[] { upgradeOptions.getOptionId()});
			List<String> invalidEntries = new ArrayList<String>();

			if (count > 0) {
				Calendar currenttime = Calendar.getInstance();
				Date sqldate = new Date((currenttime.getTime()).getTime());
				// Updating Option Details
				saveSql = "UPDATE FPTODS.SQT_UPGRADE_OPTIONS set NAME=?,VALUE=?,DESCRIPTION=?,UPGRADE_ID=?,"
						+ "KIT_NUMBER=?,UPDATED_BY=?,UPDATED_DATE=?"
						+ "where OPTION_ID=?";
				
				Object[] param = {upgradeOptions.getOptionName(),upgradeOptions.getOptionValue(),upgradeOptions.getOptionDescription(),upgradeOptions.getUpgradeId(),
						upgradeOptions.getKitNumber(),sso,sqldate ,upgradeOptions.getOptionId()};
				
				this.jdbcTemplate.update(saveSql, param);

				// Delete Option Part and Add 
	 
				String sqlDelete = "delete from FPTODS.SQT_UPGRADE_OPTION_DETAILS where OPTION_ID=?";
				int optionIdInt = Integer.parseInt(upgradeOptions.getOptionId());
				this.jdbcTemplate.update(sqlDelete, optionIdInt);
				
				int upgradeIdInt = Integer.parseInt(upgradeOptions.getUpgradeId());
				
				List<UpgradeOptionDetails> upgradeOptionPartModels = upgradeOptions.getUpgradeOptionDetails();
				logger.error("Part Model" + upgradeOptionPartModels);
				for (UpgradeOptionDetails upgradePartModel : upgradeOptionPartModels) {
					
					/*					if (!getPartOrModelData(upgradePartModel)) {
						invalidEntries.add(upgradePartModel.getPartModel());
						continue;
					}*/
				
						String savePartModel = "insert into FPTODS.SQT_UPGRADE_OPTION_DETAILS "
							+ "(OPTION_ID,PART_MODEL,INDICATOR,UPGRADE_ID) values(?,?,?,?)";
						Object[] paramPartModel = {optionIdInt, upgradePartModel.getPartModel(),upgradePartModel.getIndicator(),upgradeIdInt};
						this.jdbcTemplate.update(savePartModel, paramPartModel);
					}
				
				// Delete Promotion and Add 
				String sqlPromoDelete = "delete from FPTODS.SQT_UPGRADE_PROMOTIONS  where OPTION_ID=?";
				this.jdbcTemplate.update(sqlPromoDelete, optionIdInt);
				
				List<UpgradePromotions> upgradeOptionPromos = upgradeOptions.getUpgradePromotions();
				logger.error("Promos " + upgradeOptionPromos);
				for (UpgradePromotions upgradeOptionPromo : upgradeOptionPromos) {
					
					/*					if (!getPartOrModelData(upgradePartModel)) {
						invalidEntries.add(upgradePartModel.getPartModel());
						continue;
					}*/
				
					String savePartModel = "insert into FPTODS.SQT_UPGRADE_PROMOTIONS "
							+ "(OPTION_ID,DISCOUNT,COUPON_CODE,ORIGNAL_AMOUNT,DISCOUNTED_AMOUNT,UPGRADE_ID)"
							+ " values(?,?,?,?,?,?)";			
						Object[] paramPartModel = {optionIdInt,upgradeOptionPromo.getDiscount(),upgradeOptionPromo.getCouponCode(),
								upgradeOptionPromo.getOriginalAmount(),upgradeOptionPromo.getDiscountedAmount(),upgradeIdInt};
						this.jdbcTemplate.update(savePartModel, paramPartModel);
					}
				
				
			} else {

				Calendar currenttime = Calendar.getInstance();
				Date sqldate = new Date((currenttime.getTime()).getTime()); 
			
				saveSql = "INSERT INTO FPTODS.SQT_UPGRADE_OPTIONS "
						+ "(OPTION_ID,NAME,VALUE,DESCRIPTION,UPGRADE_ID,KIT_NUMBER,"
						+" CREATED_BY,CREATED_DATE) "
						+ "VALUES (FPTODS.SQT_UPGRADE_OPTIONS_SEQ.nextval,?,?,?,?,?,?,?)";
				
				int upgradeIdInt = Integer.parseInt(upgradeOptions.getUpgradeId());
				
				Object[] param = {upgradeOptions.getOptionName(),upgradeOptions.getOptionValue(),upgradeOptions.getOptionDescription(),upgradeIdInt,upgradeOptions.getKitNumber(),
						sso,sqldate};
				this.jdbcTemplate.update(saveSql, param);
				
				String sqlMax = "select max(OPTION_ID) from FPTODS.SQT_UPGRADE_OPTIONS";
				int cntAfterInsert = this.jdbcTemplate.queryForInt(sqlMax);
				
				// Add Option Part Details 
				List<UpgradeOptionDetails> upgradeOptionPartModels = upgradeOptions.getUpgradeOptionDetails();
				for (UpgradeOptionDetails upgradePartModel : upgradeOptionPartModels) {
				if (!getPartOrModelData(upgradePartModel)) {
						invalidEntries.add(upgradePartModel.getPartModel());
						continue;
						
					}
				 	
				String savePartModel = "insert into FPTODS.SQT_UPGRADE_OPTION_DETAILS "
						+ "(OPTION_ID,PART_MODEL,INDICATOR,UPGRADE_ID) VALUES (?,?,?,?)";
					Object[] paramPartModel = { cntAfterInsert, upgradePartModel.getPartModel(),upgradePartModel.getIndicator(),upgradeIdInt};
					this.jdbcTemplate.update(savePartModel, paramPartModel);
				}
				
				
				// TO add Promo discount
				List<UpgradePromotions> upgradeOptionPromos = upgradeOptions.getUpgradePromotions();
				logger.error("Promos " + upgradeOptionPromos);
				for (UpgradePromotions upgradeOptionPromo : upgradeOptionPromos) {
					String savePartModel = "insert into FPTODS.SQT_UPGRADE_PROMOTIONS "
							+ "(OPTION_ID,DISCOUNT,COUPON_CODE,ORIGNAL_AMOUNT,DISCOUNTED_AMOUNT,UPGRADE_ID)"
							+ " values(?,?,?,?,?,?)";
				
					Object[] paramPartModel = {cntAfterInsert,upgradeOptionPromo.getDiscount(),upgradeOptionPromo.getCouponCode(),
								upgradeOptionPromo.getOriginalAmount(),upgradeOptionPromo.getDiscountedAmount(),upgradeIdInt};
						this.jdbcTemplate.update(savePartModel, paramPartModel);
					}

				txManager.commit(saveUpgradeDetailsTM);

			}
			statusinfo.setStatusCode(1);
			if (invalidEntries.size() > 0)
				statusinfo.setStatusMessage("Partial Data saved and excluding invalid parts/Models" + invalidEntries);
			else {
				statusinfo.setStatusMessage("Data saved Successfully");
			}
		} catch (Exception e) {
			statusinfo.setStatusCode(500);
			statusinfo.setStatusMessage("Issue in saving data");
			logger.error("Exception in Upgrade Info" + e.getLocalizedMessage());
			txManager.rollback(saveUpgradeDetailsTM);
		}
		return statusinfo;
	}
	
	
	private static final class GetUpgradeOptionsMapper implements RowMapper<UpgradeOptions> {
		public GetUpgradeOptionsMapper() {
		}

		@Override
		public UpgradeOptions mapRow(ResultSet rs, int rowNum) throws SQLException {
			UpgradeOptions result = new UpgradeOptions();
			int optionId = rs.getInt("OPTION_ID");
			result.setOptionId(null != String.valueOf(optionId) ? String.valueOf(optionId) : "");
			result.setOptionName(rs.getString("NAME") != null ? rs.getString("NAME") : "");
			result.setOptionValue(rs.getString("VALUE") != null ? rs.getString("VALUE") : "");
			result.setOptionDescription(rs.getString("DESCRIPTION") != null ? rs.getString("DESCRIPTION") : "");
			int upgradeId = rs.getInt("UPGRADE_ID");
			result.setUpgradeId(null != String.valueOf(upgradeId) ? String.valueOf(upgradeId) : "");
			result.setKitNumber(rs.getString("KIT_NUMBER") != null ? rs.getString("KIT_NUMBER") : "");
			return result;
		}
	}
	
	private static final class GetUpgradeOptionsDetailsMapper implements RowMapper<UpgradeOptionDetails> {
		public GetUpgradeOptionsDetailsMapper() {
		}

		@Override
		public UpgradeOptionDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
			UpgradeOptionDetails result = new UpgradeOptionDetails();
			int optionId = rs.getInt("OPTION_ID");
			result.setOptionId(null != String.valueOf(optionId) ? String.valueOf(optionId) : "");
			int upgradeId = rs.getInt("upgrade_id");
			result.setUpgradeId(null != String.valueOf(upgradeId) ? String.valueOf(upgradeId) : "");
			result.setPartModel(rs.getString("part_model") != null ? rs.getString("part_model") : "");
			result.setIndicator(rs.getString("indicator") != null ? rs.getString("indicator") : "");
			return result;
		}
	}
	
	private static final class UpgradePromotionsMapper implements RowMapper<UpgradePromotions> {
		public UpgradePromotionsMapper() {
		}

		@Override
		public UpgradePromotions mapRow(ResultSet rs, int rowNum) throws SQLException {
			UpgradePromotions result = new UpgradePromotions();
			int optionId = rs.getInt("OPTION_ID");
			result.setOptionId(null != String.valueOf(optionId) ? String.valueOf(optionId) : "");
			int upgradeId = rs.getInt("upgrade_id");
			result.setUpgradeId(null != String.valueOf(upgradeId) ? String.valueOf(upgradeId) : "");
			
			double discount = rs.getDouble("DISCOUNT");
			result.setDiscount(discount);
			
			result.setCouponCode(rs.getString("COUPON_CODE") != null ? rs.getString("COUPON_CODE") : "");
			result.setValidity(rs.getDate("VALIDITY") != null ? rs.getDate("VALIDITY") : null);
			double originalAmt = rs.getDouble("ORIGNAL_AMOUNT");
			result.setOriginalAmount(originalAmt);
			double disCountAmt = rs.getDouble("DISCOUNTED_AMOUNT");
			result.setDiscountedAmount(disCountAmt);
			return result;
		}
	}
	
	//Raj Changes For Option
			@Override
			public List<UpgradeOptions> getUpgradeOptionNewInfo(String optionId) {
				List<UpgradeOptions> result = new ArrayList<UpgradeOptions>();
				List<UpgradeOptions> finalResults = new ArrayList<UpgradeOptions>();
				try{
					String sql = "select * from FPTODS.SQT_UPGRADE_OPTIONS where option_Id=?";	
					result = this.jdbcTemplate.query(sql,new Object[] { Integer.parseInt(optionId) }, new GetUpgradeOptionsMapper());
					
					for (UpgradeOptions upgradeInfoItems : result) {
						//List Of Part Info
						int optionIdNew =Integer.parseInt(upgradeInfoItems.getOptionId());
						
						String sqlForUpgradeDoc = "select * from FPTODS.SQT_UPGRADE_PACKAGE_DOCUMENT_T where option_Id=:optionId";
						MapSqlParameterSource paramMapDoc = new MapSqlParameterSource();
						paramMapDoc.addValue("optionId", optionIdNew);
						
						List<UpgradeDocument> documentList = this.namedParamTemplate.query(sqlForUpgradeDoc, paramMapDoc, new GetUpgradeDocumentMapper());
						upgradeInfoItems.setUpgradeDocument(documentList);
						
						String sqlForUpgradeOption = "select * from FPTODS.SQT_UPGRADE_OPTION_DETAILS where option_Id=:optionId";
						MapSqlParameterSource paramMapNew = new MapSqlParameterSource();
						
						paramMapNew.addValue("optionId", optionIdNew);
						
						//List Of Document Info
						List<UpgradeOptionDetails> newUpgradeOptionDetails = this.namedParamTemplate.query(sqlForUpgradeOption, paramMapNew, new GetUpgradeOptionsDetailsMapper());
			
						upgradeInfoItems.setUpgradeOptionDetails(newUpgradeOptionDetails);
						logger.info("Inside getUpgradeOptionNewInfo() --Before Upgrade Promotions");
						///For Promotional part
						String sqlForPromotionalDoc = "select * from FPTODS.SQT_UPGRADE_PROMOTIONS where option_Id=:optionId";
						MapSqlParameterSource paramMapPromotional = new MapSqlParameterSource();
						paramMapPromotional.addValue("optionId", optionIdNew);
						
						List<UpgradePromotions> promotionList = this.namedParamTemplate.query(sqlForPromotionalDoc, paramMapPromotional, new UpgradePromotionsMapper());
						upgradeInfoItems.setUpgradePromotions(promotionList);
						
						finalResults.add(upgradeInfoItems);
						
						}
					} catch (Exception e) {
					logger.error("Exception in getUpgradeDetailsData" + e.getLocalizedMessage());
				}
					return finalResults;
				
			}
			
			
			@Override
			public List<String> getEndUserList() {
				logger.info("Inside Before getEndUserList");
				List<String> endUserList=new ArrayList<String>();
				try{
				String sql = "SELECT distinct CUSTOMER_NAME FROM FPTODS.SQT_END_USER_MASTER_T";
				logger.info("my SQL"+sql);	
				endUserList = this.jdbcTemplate.queryForList(sql,String.class);
				logger.info("Inside After getEndUserList"+endUserList);
				return 	endUserList;
				} catch (Exception e) {
					logger.error("Exception in getUpgradeDetailsData" + e.getLocalizedMessage());
				}
				  return endUserList;
			}
	
			/*Channel Partner - Upgrades Detail Page - Neha */
			
			@Override
			public CPUpgradeDetailView getCpUpgradeDetailViewData(int upgradeId) {
				logger.info("Inside getCpUpgradeDetailViewData method" + upgradeId);
				List<CPUpgradeDetailView> cpUpgradeDetailsList = new ArrayList<>();
				List<CPUpgradePackage> upgradePackagesList = new ArrayList<>();
				List<CPUpgradePackage> packagePromotionList = new ArrayList<>();
				List<CPUpgradeDocument> documentList = new ArrayList<>();
				List<CPUpgradeDocument> optionDocument = new ArrayList<>();
				CPUpgradeDetailView cpUpgradeDetails = new CPUpgradeDetailView();
				try{
				// Get Upgrade Details
				String sqlForUpgrades = "SELECT COUNT(PART_NUM) AS PART_COUNT,COUNT(DISTINCT SOLD_TO_CUSTOMER_NAME) "
						      + "AS CUST_COUNT , A.UPGRADE_ID, A.UPGRADE_NAME,A.AMOUNT, A.COUPON_CODE,A.DISCOUNT,A.DESCRIPTION "
		                      + "FROM FPTODS.SQT_UPGRADE_INFO A, "
		                      + "(select m.PART_NUM,m.UPGRADE_ID,m.SOLD_TO_CUSTOMER_NAME, row_number() over(PARTITION BY UPGRADE_ID ORDER BY LAST_UPDATE_DATE DESC) AS rn "  
		                      + "from DDSAFM.SQT_UPGRADE_ORDER_INFO_MV m)t  "
		                      + "WHERE a.UPGRADE_ID = T.UPGRADE_ID AND A.upgrade_id=:upgradeId " 
		                      + "group by  A.UPGRADE_ID, A.UPGRADE_NAME,A.AMOUNT,A.COUPON_CODE,A.DISCOUNT,A.DESCRIPTION" ;
				cpUpgradeDetailsList = this.jdbcTemplate.query(sqlForUpgrades,new Object[] { upgradeId }, new CPUpgradeDetailViewMapper());
				if(cpUpgradeDetailsList.size()>0){
				cpUpgradeDetails = cpUpgradeDetailsList.get(0);
				}
				else{
					return null;
				}
				
				// Set Revenue and Savings
				double discountedPrice = cpUpgradeDetails.getAmount();
				double discountPercentage = cpUpgradeDetails.getDiscount();
				
				int noOfParts = cpUpgradeDetails.getNoOfParts();
				
				double revenue = discountedPrice * noOfParts;
				cpUpgradeDetails.setRevenue(Math.round(revenue * 100.0) / 100.0);
			//	double originalPrice = (discountedPrice * (100/(100-discountPercentage)));
				double originalPrice = ((discountedPrice * 100)/(100-discountPercentage));
				double savings = (originalPrice - discountedPrice) * noOfParts;
				cpUpgradeDetails.setSavings(Math.round(savings * 100.0) / 100.0);
				
				//List Of Upgrade Documents
				int optionIdForUpgradeDoc = 0;
				String sqlForUpgradeDoc = "select * from FPTODS.SQT_UPGRADE_PACKAGE_DOCUMENT_T where upgrade_id=:upgradeId AND option_id=:optionIdForUpgradeDoc";
				documentList = this.jdbcTemplate.query(sqlForUpgradeDoc, new Object[] { upgradeId,optionIdForUpgradeDoc }, new CPUpgradeDocumentMapper());
		        cpUpgradeDetails.setUpgradeDocuments(documentList);
		        

		        //List Of Upgrade Options/Packages
		        
		        String sqlForPackages = "Select OPTION_ID,NAME,DESCRIPTION,KIT_NUMBER FROM FPTODS.SQT_UPGRADE_OPTIONS where UPGRADE_ID=:upgradeId";
		        List<CPUpgradePackage> upgradePackages = new ArrayList<>();
		        upgradePackages = this.jdbcTemplate.query(sqlForPackages, new Object[] { upgradeId }, new CPUpgradePackageMapper());
		        logger.info("Upgrade Package size"+upgradePackages.size());          
		        
		        
		        for(CPUpgradePackage upgradepackage : upgradePackages){
		        	    upgradepackage.setQuantity(1);
		        	    int optionId = upgradepackage.getPackageId();
		        	    //Get Promotion
		        	    String sqlForPromotion = "Select COUPON_CODE,DISCOUNTED_AMOUNT,ORIGNAL_AMOUNT from FPTODS.SQT_UPGRADE_PROMOTIONS where UPGRADE_ID=:upgradeId AND OPTION_ID=:optionId";
		                packagePromotionList = this.jdbcTemplate.query(sqlForPromotion, new Object[] { upgradeId,optionId }, new CPUpgradePackageMapper1());
		               if(packagePromotionList.size()>0){
		               CPUpgradePackage upgradePromotion = packagePromotionList.get(0);
		               upgradepackage.setCouponCode(upgradePromotion.getCouponCode());
		               upgradepackage.setDiscountedAmount(upgradePromotion.getDiscountedAmount());
		               upgradepackage.setOriginalAmount(upgradePromotion.getOriginalAmount());
		               }
		               
		        	   //Get Option Documents
						String sqlForOptionDocument = "select * from FPTODS.SQT_UPGRADE_PACKAGE_DOCUMENT_T where UPGRADE_ID=:upgradeId AND OPTION_ID=:optionId";
						 optionDocument = this.jdbcTemplate.query(sqlForOptionDocument, new Object[] { upgradeId,optionId }, new CPUpgradeDocumentMapper());
						upgradepackage.setUpgradeDocument(optionDocument);
						upgradePackagesList.add(upgradepackage);
		                }
		                cpUpgradeDetails.setUpgradePackages(upgradePackagesList);
		                
				}catch (Exception e) {
					logger.error("Exception in getUpgradeDetailsView" + e.getLocalizedMessage());
				}
				 return cpUpgradeDetails;
			}
			
			
			private static final class CPUpgradeDetailViewMapper implements RowMapper<CPUpgradeDetailView> {
				public CPUpgradeDetailViewMapper() {
				}

				@Override
				public CPUpgradeDetailView mapRow(ResultSet rs, int rowNum) throws SQLException {
					CPUpgradeDetailView result = new CPUpgradeDetailView();
					result.setUpgradeId(null != String.valueOf(rs.getInt("UPGRADE_ID"))  ? rs.getInt("UPGRADE_ID") : Integer.parseInt(""));
					result.setUpgradeName(rs.getString("UPGRADE_NAME") !=null ? rs.getString("UPGRADE_NAME") : "");
					result.setDescription(rs.getString("DESCRIPTION") !=null ? rs.getString("DESCRIPTION") : "");
					result.setAmount(rs.getDouble("AMOUNT"));
					result.setCouponCode(rs.getString("COUPON_CODE"));
					result.setDiscount(rs.getDouble("DISCOUNT"));
					result.setNoOfParts(rs.getInt("PART_COUNT"));
					result.setNoOfCustomers(rs.getInt("CUST_COUNT"));
					
		            return result;
				}
			}
			
			private static final class CPUpgradePackageMapper implements RowMapper<CPUpgradePackage> {
				public CPUpgradePackageMapper() {
				}

				@Override
				public CPUpgradePackage mapRow(ResultSet rs, int rowNum) throws SQLException {
					CPUpgradePackage result = new CPUpgradePackage();
					result.setPackageId(null != String.valueOf(rs.getInt("OPTION_ID")) ? rs.getInt("OPTION_ID") : Integer.parseInt(""));
					result.setPackageName(rs.getString("NAME") !=null ? rs.getString("NAME") : "");
					result.setPackageDescription(rs.getString("DESCRIPTION") !=null ? rs.getString("DESCRIPTION") : "");
					result.setKitNumber(rs.getString("KIT_NUMBER") !=null ? rs.getString("KIT_NUMBER") : "");
					return result;
				}
			}
			
			private static final class CPUpgradePackageMapper1 implements RowMapper<CPUpgradePackage> {
				public CPUpgradePackageMapper1() {
				}

				@Override
				public CPUpgradePackage mapRow(ResultSet rs, int rowNum) throws SQLException {
					CPUpgradePackage result = new CPUpgradePackage();
					result.setCouponCode(rs.getString("COUPON_CODE") !=null ? rs.getString("COUPON_CODE") : "");
					result.setDiscountedAmount(rs.getDouble("DISCOUNTED_AMOUNT"));
					result.setOriginalAmount(rs.getDouble("ORIGNAL_AMOUNT"));
					return result;
				}
			}
			
			
			
			private static final class CPUpgradeDocumentMapper implements RowMapper<CPUpgradeDocument> {
				public CPUpgradeDocumentMapper() {
				}

				@Override
				public CPUpgradeDocument mapRow(ResultSet rs, int rowNum) throws SQLException {
					CPUpgradeDocument result = new CPUpgradeDocument();
					result.setDocumentId(null != String.valueOf(rs.getInt("DOCUMENT_ID")) ? rs.getInt("DOCUMENT_ID") : Integer.parseInt(""));
					result.setDocumentName(rs.getString("DOCUMENT_NAME") !=null ? rs.getString("DOCUMENT_NAME") : "");
					result.setDocumentContent(rs.getString("DCOUMENT_CONTENT") !=null ? rs.getString("DCOUMENT_CONTENT") : "");
					result.setDocumentUploadPath(rs.getString("DOCUMENT_UPLOAD_PATH") !=null ? rs.getString("DOCUMENT_UPLOAD_PATH") : "");
					return result;
				}
			}
			
			//End
			
		   
			
			/*Channel Partner - SMI View*/
			
			
			@Override
			public CPUpgradeDetailSMIView getCpUpgradeSMIViewData(int upgradeId) {
				logger.info("Inside getCpUpgradeSMIViewData method" + upgradeId);
				CPUpgradeDetailSMIView result =  new CPUpgradeDetailSMIView();
				List<CPUpgradeDocument> upgradeDocuments = new ArrayList<>();
				List<CPUpgradeParts> upgradeParts = new ArrayList<>();
				result.setUpgradeId(upgradeId);
				
				int optionId = 0;
				try{
				//Get documents for upgradeId
				String sqlForDocuments = "select * from FPTODS.SQT_UPGRADE_PACKAGE_DOCUMENT_T where UPGRADE_ID=:upgradeId AND OPTION_ID=:optionId" ;
				upgradeDocuments = this.jdbcTemplate.query(sqlForDocuments,new Object[] { upgradeId,optionId }, new CPUpgradeDocumentMapper());
				result.setUpgradeDocuments(upgradeDocuments);
				
				//Get Parts for upgradeId
				String sqlForParts = "select * from FPTODS.SQT_UPGRADE_LEGACY_PN_MODEL where UPGRADE_ID=:upgradeId";
				upgradeParts = this.jdbcTemplate.query(sqlForParts,new Object[] { upgradeId }, new CPUpgradePartsMapper());
				for(CPUpgradeParts cpUpgradePart : upgradeParts){
					cpUpgradePart.setQuantity(1);
				}
				result.setUpgradeParts(upgradeParts);
				}catch(Exception e){
					logger.error("Exception in getCpUpgradeSMIViewData" + e.getLocalizedMessage());
				}
				return result;
			}
			
			private static final class CPUpgradePartsMapper implements RowMapper<CPUpgradeParts> {
				public CPUpgradePartsMapper() {
				}

				@Override
				public CPUpgradeParts mapRow(ResultSet rs, int rowNum) throws SQLException {
					CPUpgradeParts result = new CPUpgradeParts();
				    result.setPartNumber(rs.getString("PART_MODEL") !=null ? rs.getString("PART_MODEL") : "");
				    result.setDiscountedPrice(rs.getDouble("DISCOUNT_PRICE"));
				    result.setIndicator(rs.getString("INDICATOR") !=null ? rs.getString("INDICATOR") : "");
				    
					return result;
				}
			}

			@Override
			public CPUpgradeDocument getUpgradeDocumentDetails(int documentId) {
				CPUpgradeDocument upgradeDocument = new CPUpgradeDocument();
				try{
					String sql = "select * from FPTODS.SQT_UPGRADE_PACKAGE_DOCUMENT_T where DOCUMENT_ID=:documentId" ;
					upgradeDocument = this.jdbcTemplate.queryForObject(sql,new Object[] { documentId }, new CPUpgradeDocumentMapper());
					} catch(Exception e){
						logger.error("Exception in getUpgradeDocumentDetails" + e.getLocalizedMessage());
					}
				return upgradeDocument;
			}

}