package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.Date;

public class ProjectDataMaster implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private int plantId;
	private int custId;
	private int projectId;
	private String projectName;
	//private String valveLocation;
	private boolean isPlantLocation;
	//private String serialNumber;
	//private String recSource;
	private Date createdDate;
	private Date updatedDate;
	private String updatedBy;
	private String createdBy;
	private String country;
	private String city;
	private String state;
	private String postalCode;
	private String projectLocation;
	
	public ProjectDataMaster() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public int getPlantId() {
		return plantId;
	}
	public void setPlantId(int plantId) {
		this.plantId = plantId;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public int getProjectId() {
		return projectId;
	}
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public boolean isPlantLocation() {
		return isPlantLocation;
	}
	public void setPlantLocation(boolean isPlantLocation) {
		this.isPlantLocation = isPlantLocation;
	}

	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPostalCode() {
		return postalCode;
	}
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	public String getProjectLocation() {
		return projectLocation;
	}
	public void setProjectLocation(String projectLocation) {
		this.projectLocation = projectLocation;
	}
	public ProjectDataMaster(int plantId, int custId, int projectId, String projectName, boolean isPlantLocation,
			String serialNumber, String recSource, Date createdDate, Date updatedDate, String updatedBy,
			String createdBy, String country, String city, String state, String postalCode, String projectLocation) {
		super();
		this.plantId = plantId;
		this.custId = custId;
		this.projectId = projectId;
		this.projectName = projectName;
		this.isPlantLocation = isPlantLocation;
		this.createdDate = createdDate;
		this.updatedDate = updatedDate;
		this.updatedBy = updatedBy;
		this.createdBy = createdBy;
		this.country = country;
		this.city = city;
		this.state = state;
		this.postalCode = postalCode;
		this.projectLocation = projectLocation;
	}
	@Override
	public String toString() {
		return "ProjectDataMaster [plantId=" + plantId + ", custId=" + custId + ", projectId=" + projectId
				+ ", projectName=" + projectName + ", isPlantLocation=" + isPlantLocation + ", createdDate="
				+ createdDate + ", updatedDate=" + updatedDate + ", updatedBy=" + updatedBy + ", createdBy=" + createdBy
				+ ", country=" + country + ", city=" + city + ", state=" + state + ", postalCode=" + postalCode
				+ ", projectLocation=" + projectLocation + "]";
	}
	
	
	
}
