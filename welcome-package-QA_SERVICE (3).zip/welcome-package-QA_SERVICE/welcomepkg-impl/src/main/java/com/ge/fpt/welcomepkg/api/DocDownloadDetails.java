package com.ge.fpt.welcomepkg.api;

import java.sql.Date;

public class DocDownloadDetails {
	
	private String siteCode;
	private String typeFlowProject;
	private String projectNumber;
	private String salesOrderNumber;
	private String salesOrderLineNumber;
	private String productionOrderNumber;
	private String serialNumber;
	private String documentType;
	private String docDesc;
	private String fileName;
	private String fileLink;
	private String documentLanguage;
	private String document_content_type;
	private String sourceSystem;
	private Date creationDate;
	private Date lastUpdateDate;
	private String MD5;
	private String IfileName;
	private String Ipath;
	private String IResource;
	private String ISerialNumber;
	public String getSiteCode() {
		return siteCode;
	}
	public void setSiteCode(String siteCode) {
		this.siteCode = siteCode;
	}
	public String getTypeFlowProject() {
		return typeFlowProject;
	}
	public void setTypeFlowProject(String typeFlowProject) {
		this.typeFlowProject = typeFlowProject;
	}
	public String getProjectNumber() {
		return projectNumber;
	}
	public void setProjectNumber(String projectNumber) {
		this.projectNumber = projectNumber;
	}
	public String getSalesOrderNumber() {
		return salesOrderNumber;
	}
	public void setSalesOrderNumber(String salesOrderNumber) {
		this.salesOrderNumber = salesOrderNumber;
	}
	public String getSalesOrderLineNumber() {
		return salesOrderLineNumber;
	}
	public void setSalesOrderLineNumber(String salesOrderLineNumber) {
		this.salesOrderLineNumber = salesOrderLineNumber;
	}
	public String getProductionOrderNumber() {
		return productionOrderNumber;
	}
	public void setProductionOrderNumber(String productionOrderNumber) {
		this.productionOrderNumber = productionOrderNumber;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public String getDocDesc() {
		return docDesc;
	}
	public void setDocDesc(String docDesc) {
		this.docDesc = docDesc;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileLink() {
		return fileLink;
	}
	public void setFileLink(String fileLink) {
		this.fileLink = fileLink;
	}
	public String getDocumentLanguage() {
		return documentLanguage;
	}
	public void setDocumentLanguage(String documentLanguage) {
		this.documentLanguage = documentLanguage;
	}
	public String getDocument_content_type() {
		return document_content_type;
	}
	public void setDocument_content_type(String document_content_type) {
		this.document_content_type = document_content_type;
	}
	public String getSourceSystem() {
		return sourceSystem;
	}
	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}
	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}
	public String getMD5() {
		return MD5;
	}
	public void setMD5(String mD5) {
		MD5 = mD5;
	}
	public String getIfileName() {
		return IfileName;
	}
	public void setIfileName(String ifileName) {
		IfileName = ifileName;
	}
	public String getIpath() {
		return Ipath;
	}
	public void setIpath(String ipath) {
		Ipath = ipath;
	}
	public String getIResource() {
		return IResource;
	}
	public void setIResource(String iResource) {
		IResource = iResource;
	}
	public String getISerialNumber() {
		return ISerialNumber;
	}
	public void setISerialNumber(String iSerialNumber) {
		ISerialNumber = iSerialNumber;
	}
	public DocDownloadDetails(String siteCode, String typeFlowProject, String projectNumber, String salesOrderNumber,
			String salesOrderLineNumber, String productionOrderNumber, String serialNumber, String documentType,
			String docDesc, String fileName, String fileLink, String documentLanguage, String document_content_type,
			String sourceSystem, Date creationDate, Date lastUpdateDate, String mD5, String ifileName, String ipath,
			String iResource, String iSerialNumber) {
		super();
		this.siteCode = siteCode;
		this.typeFlowProject = typeFlowProject;
		this.projectNumber = projectNumber;
		this.salesOrderNumber = salesOrderNumber;
		this.salesOrderLineNumber = salesOrderLineNumber;
		this.productionOrderNumber = productionOrderNumber;
		this.serialNumber = serialNumber;
		this.documentType = documentType;
		this.docDesc = docDesc;
		this.fileName = fileName;
		this.fileLink = fileLink;
		this.documentLanguage = documentLanguage;
		this.document_content_type = document_content_type;
		this.sourceSystem = sourceSystem;
		this.creationDate = creationDate;
		this.lastUpdateDate = lastUpdateDate;
		MD5 = mD5;
		IfileName = ifileName;
		Ipath = ipath;
		IResource = iResource;
		ISerialNumber = iSerialNumber;
	}
	public DocDownloadDetails() {
		super();
	}
	@Override
	public String toString() {
		return "DocDownloadDetails [siteCode=" + siteCode + ", typeFlowProject=" + typeFlowProject + ", projectNumber="
				+ projectNumber + ", salesOrderNumber=" + salesOrderNumber + ", salesOrderLineNumber="
				+ salesOrderLineNumber + ", productionOrderNumber=" + productionOrderNumber + ", serialNumber="
				+ serialNumber + ", documentType=" + documentType + ", docDesc=" + docDesc + ", fileName=" + fileName
				+ ", fileLink=" + fileLink + ", documentLanguage=" + documentLanguage + ", document_content_type="
				+ document_content_type + ", sourceSystem=" + sourceSystem + ", creationDate=" + creationDate
				+ ", lastUpdateDate=" + lastUpdateDate + ", MD5=" + MD5 + ", IfileName=" + IfileName + ", Ipath="
				+ Ipath + ", IResource=" + IResource + ", ISerialNumber=" + ISerialNumber + "]";
	}
	
	
	
	
	
	
}
