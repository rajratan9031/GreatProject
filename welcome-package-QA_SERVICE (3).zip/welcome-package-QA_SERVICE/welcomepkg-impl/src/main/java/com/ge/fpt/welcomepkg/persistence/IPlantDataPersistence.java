package com.ge.fpt.welcomepkg.persistence;

import java.util.List;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.api.PlantData;

public interface IPlantDataPersistence {
	
	@Transactional(propagation=Propagation.REQUIRED)
	List<PlantData> getPlantDataByPlantId(String plantId);
	
	@Transactional(propagation=Propagation.REQUIRED)
	StatusInfo savePlantData(PlantData plantData);
	
	@Transactional(propagation=Propagation.REQUIRED)
	List<PlantData> getPlantData(int pageNo,int rowperpage,PlantData plantData);

	@Transactional(propagation=Propagation.REQUIRED)
	int getPlantDataCount(PlantData plantData);
	
	@Transactional(propagation=Propagation.REQUIRED)
	StatusInfo deletePlantData(PlantData plantData);

}
