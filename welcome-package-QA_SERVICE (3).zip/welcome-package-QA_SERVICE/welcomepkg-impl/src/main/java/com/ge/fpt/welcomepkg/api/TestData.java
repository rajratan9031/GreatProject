/**
 * 
 */
package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author 204060632
 *
 */
@XmlRootElement
public class TestData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8724419746598714292L;

	/**
	 * 
	 */
	public TestData() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param key1
	 * @param key2
	 */
	public TestData(String key1, String key2) {
		super();
		this.key1 = key1;
		this.key2 = key2;
	}

	private String key1;
	private String key2;
	
	/**
	 * @return the key1
	 */
	public String getKey1() {
		return key1;
	}
	/**
	 * @param key1 the key1 to set
	 */
	public void setKey1(String key1) {
		this.key1 = key1;
	}
	/**
	 * @return the key2
	 */
	public String getKey2() {
		return key2;
	}
	/**
	 * @param key2 the key2 to set
	 */
	public void setKey2(String key2) {
		this.key2 = key2;
	}
}
