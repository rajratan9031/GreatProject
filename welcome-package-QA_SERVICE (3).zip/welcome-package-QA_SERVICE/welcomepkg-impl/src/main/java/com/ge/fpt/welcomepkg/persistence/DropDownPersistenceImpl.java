package com.ge.fpt.welcomepkg.persistence;

import com.ge.fpt.welcomepkg.api.DropDownItem;
import com.ge.fpt.welcomepkg.api.EndUserDetail;
import com.ge.fpt.welcomepkg.api.UpgradeOptions;
import com.ge.fpt.welcomepkg.api.UpgradePromotions;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;
import com.ge.fpt.welcomepkg.impl.WelcomePkgServiceImpl;
import com.ge.fpt.welcomepkg.util.QueryConstants;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.felix.framework.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

public class DropDownPersistenceImpl  implements IDropDownPersistence
{
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory.getLogger(DropDownPersistenceImpl.class);
  JdbcTemplate jdbcTemplate;
  DataSource dataSource;
  PlatformTransactionManager txManager;
  NamedParameterJdbcTemplate namedParamTemplate;
  
  public DataSource getDataSource()
  {
    return this.dataSource;
  }
  
  public void setDataSource(DataSource ds)
  {
    this.dataSource = ds;
    this.jdbcTemplate = new JdbcTemplate(ds);
  }
  
  public PlatformTransactionManager getTxManager()
  {
    return this.txManager;
  }
  
  public void setTxManager(PlatformTransactionManager txManager)
  {
    this.txManager = txManager;
  }
  
  public List<DropDownItem> getCurrencyCodeList()
  {
    String sql = "select TO_CURRENCY as text, TO_CURRENCY as value from ddsafm.sqt_currency_list";
    List<DropDownItem> dropDownItem = this.jdbcTemplate.query(sql, new DropDownMapper());
    
    return dropDownItem;
  }
  
  public List<DropDownItem> getRegionList()
  {
    String sql = "select distinct Region_name as text , Region as value  from ddsafm.sqt_price_logic";
    List<DropDownItem> dropDownItem = this.jdbcTemplate.query(sql, new DropDownMapper());
    
    return dropDownItem;
  }
  
  public List<DropDownItem> getRegionListByUser(String sso)
  {
	String upperCaseSSO = sso.toUpperCase();
    String sql = "select distinct b.Region_name as text , a.pl_Region as value  from fptods.sqt_pricetool_user a, fptods.sqt_price_logic b where 1=1 "+
    		 	 "and b.region= a.pl_region and UPPER(a.sso)= ?";
    List<DropDownItem> dropDownItem = this.jdbcTemplate.query(sql,new Object[]{upperCaseSSO}, new DropDownMapper());
    
    return dropDownItem;
  }
  
  public List<DropDownItem> getCountryCodeList()
  {
    String sql = "select COUNTRY_NAME as text , COUNTRY_CODE  as value  from ddsafm.ODS_COUNTRY_CODE_LIST";
    List<DropDownItem> dropDownItem = this.jdbcTemplate.query(sql, new DropDownMapper());
    return dropDownItem;
  }
  
  public  List<DropDownItem> getStateList(String country)
  {
    String sql = "select State_name as text , state_code  as value  from ddsafm.BI_STATES_T where country_code2=? ";
    List<DropDownItem> dropDownItem = this.jdbcTemplate.query(sql, new Object[]{country},new DropDownMapper());
    return dropDownItem;
  }
 
  
  public List<DropDownItem> getEndUserIndustryList()
  {
    String sql = "select NAME as text , NAME  as value  from fptods.sqt_end_user_industry";
    List<DropDownItem> dropDownItem = this.jdbcTemplate.query(sql, new DropDownMapper());
    return dropDownItem;
  }
  
  public List<DropDownItem> getSpareIndicatorList()
  {
    String sql = "select distinct spares_indicator as text,spares_indicator as value from ddsafm.sqt_part_info_t "
    		+ "where spares_indicator is not null order by spares_indicator";
    List<DropDownItem> dropDownItem = this.jdbcTemplate.query(sql, new DropDownMapper());
    return dropDownItem;
  }
  
  public List<DropDownItem> getStockTypeList()
  {
    String sql = "select distinct stock_type as text,stock_type as value  from ddsafm.sqt_part_info_t "
    		+ "where stock_type is not null order by stock_type ";
    List<DropDownItem> dropDownItem = this.jdbcTemplate.query(sql, new DropDownMapper());
    return dropDownItem;
  }
  
  public List<DropDownItem> getRecsourceList()
  {
    String sql = "select distinct rec_source as text,rec_source as value  from ddsafm.sqt_part_info_t "
    		+ "where rec_source is not null order by rec_source ";
    List<DropDownItem> dropDownItem = this.jdbcTemplate.query(sql, new DropDownMapper());
    return dropDownItem;
  }
  
  public List<DropDownItem> getConfiguratorOption(){
	  String sql= "select bom_field as text, bom_value as value from ddsafm.ods_bom_field_values";
	  List<DropDownItem> dropDownItem = this.jdbcTemplate.query(sql, new DropDownMapper());
	  return dropDownItem;
  }
  
  public List<DropDownItem> getSiteInfo(String sso) {
	  boolean isInternal = WelcomePkgServiceImpl.isInternalUser(sso);
	  List<DropDownItem> dropDownItem=null;
    String sql = "select distinct CP_LOCATION as text,cp_loc_id as value  from FPTODS.CP_LOCATION_DETAILS"
    		+ " where 1=1 ";
	  dropDownItem = this.jdbcTemplate.query(sql, new DropDownMapper());
	  if(!isInternal){
		 String upperSSO = sso.toUpperCase();
    	sql=sql+" and duns_number in (select DUNS_NUMBER from ddsafm.sqt_channel_sso where UPPER(sso_id)=? )";
    	dropDownItem = this.jdbcTemplate.query(sql,new Object[]{upperSSO}, new DropDownMapper());
    }
    return dropDownItem;
  }
  public static final class DropDownMapper
    implements RowMapper<DropDownItem>
  {
    public DropDownItem mapRow(ResultSet rs, int rowNum)
      throws SQLException
    {
      DropDownItem result = new DropDownItem();
      result.setText(rs.getString("text"));
      result.setValue(rs.getString("value"));
      return result;
    }
  }
@Override
public List<DropDownItem> getChannelList(String productCode) {
	String sql = "select distinct(COMPANY) as text , COMPANY  as value  from ddsafm.SQT_CHANNEL_REGION where COUNTRY='US' and COMPANY_TYPE=?";
	  List<DropDownItem> dropDownItem = this.jdbcTemplate.query(sql,new Object[]{productCode}, new DropDownMapper());
	  return dropDownItem;
}


@Override
public  List<EndUserDetail> getEndUserList(String searchTxt) {
	logger.info("Inside Before getEndUserList"+searchTxt);
	List<EndUserDetail> endUserList=null; 
	searchTxt="%"+searchTxt.toUpperCase()+"%";
	try{
				
	//String sql = "SELECT CUSTOMER_NAME FROM FPTODS.SQT_END_USER_MASTER_T";
	//String sql = "SELECT DISTINCT SOLD_TO_CUSTOMER_NAME || END_USER FROM FPTODS.ODS_SQT_BY_SALES_ORDER_SSO_GE";
	//String sql = "SELECT UPGRADE_NAME FROM FPTODS.SQT_UPGRADE_INFO";
	//String sql = "Select DISTINCT SOLD_TO_CUSTOMER_NAME FROM DDSAFM.ODS_SQT_BY_SALES_ORDER_SSO_GE";
/*	String sql= " Select DISTINCT (SOLD_TO_CUSTOMER_NAME || END_USER || CUSTOMER_NAME),"
			+ " (cdm.END_USER_INDUSTRY || erp.END_USER_INDUSTRY), "
			+ " (cdm.END_USER_COUNTRY || erp.EU_CUST_COUNTRY), "
			+ " (cdm.END_USER_STATE || erp.EU_CUST_STATE), "
			+ " (cdm.END_USER_CITY || erp.EU_CUST_CITY), "
			+ " (cdm.END_USER_POSTAL_CODE || erp.EU_CUST_ZIP) "
			+ " from DDSAFM.ODS_SQT_BY_SALES_ORDER_SSO_GE  erp , FPTODS.CUSTOMER_DATA_MANAGMENT_MASTER cdm "
			+ " where ( UPPER(SOLD_TO_CUSTOMER_NAME)  like ? "
			+ " OR  UPPER(END_USER)  like ? "
			+ " OR  UPPER(CUSTOMER_NAME)  like ?) "
			+ " AND ROWNUM <= 100";*/
		//endUserList = this.jdbcTemplate.query(sql,new Object[]{searchTxt,searchTxt,searchTxt},new EndUserDetailMapper_test());
			
	String sql="Select DISTINCT (SOLD_TO_CUSTOMER_NAME || END_USER || CUSTOMER_NAME) as CUSTOMER_NAME, "
			+ "(cdm.END_USER_INDUSTRY || erp.END_USER_INDUSTRY) as END_USER_INDUSTRY, (cdm.END_USER_COUNTRY || erp.EU_CUST_COUNTRY) "
			+ "as EU_CUST_COUNTRY, (cdm.END_USER_STATE || erp.EU_CUST_STATE) as EU_CUST_STATE, "
			+ "(cdm.END_USER_CITY || erp.EU_CUST_CITY) as EU_CUST_CITY, (cdm.END_USER_POSTAL_CODE || erp.EU_CUST_ZIP) "
			+ "as EU_CUST_ZIP from DDSAFM.ODS_SQT_BY_SALES_ORDER_SSO_GE  erp , FPTODS.CUSTOMER_DATA_MANAGMENT_MASTER cdm "
			+ "where (UPPER(SOLD_TO_CUSTOMER_NAME) like ? OR UPPER(END_USER) like ? "
			+ "OR UPPER(CUSTOMER_NAME) like ?) AND ROWNUM <= 100";	
	
	endUserList = this.jdbcTemplate.query(sql,new Object[]{searchTxt,searchTxt,searchTxt},new EndUserDetailMapper_test());
	
		
	
	logger.info("Inside After getEndUserList");
	return 	endUserList;
	} catch (Exception e) {
		logger.error("Exception in getEndUserList" + e.getLocalizedMessage());
	}
	  return endUserList;
}

private static final class EndUserDetailMapper_test implements RowMapper<EndUserDetail> {
	public EndUserDetailMapper_test() {
	}
	@Override
	public EndUserDetail mapRow(ResultSet rs, int rowNum) throws SQLException {
	
		EndUserDetail result = new EndUserDetail();
		
		result.setEndUserName(rs.getString("CUSTOMER_NAME") != null ? rs.getString("CUSTOMER_NAME") : "");
		result.setIndustry(rs.getString("END_USER_INDUSTRY") != null ? rs.getString("END_USER_INDUSTRY") : "");
		result.setCountry(rs.getString("EU_CUST_COUNTRY") != null ? rs.getString("EU_CUST_COUNTRY") : "");
		result.setState(rs.getString("EU_CUST_STATE") != null ? rs.getString("EU_CUST_STATE") : "");
		result.setCity(rs.getString("EU_CUST_CITY") != null ? rs.getString("EU_CUST_CITY") : "");
		result.setZip(rs.getString("EU_CUST_ZIP") != null ? rs.getString("EU_CUST_ZIP") : "");
		
			return result;
	}
}

@Override
public List<EndUserDetail> getEndUserListByTxt(String searchTxt) {
	logger.info("Inside Before getEndUserListByTxt Start "+searchTxt);
	
	/// TESTING 
	int count =8; // GET FROM SERVICE 
	String fileToSave = "Testing12345_DRAWING.pdf";
	String[] output = fileToSave.split("\\.");
	logger.error("output>>>SIZE>>>>>>" + output.length);
	 fileToSave= output[0]+count+"."+output[1];
	fileToSave = fileToSave.trim();
	logger.error("fileToSave>>>>>>>>>" + fileToSave);
	/// TESTING 
	
	List<EndUserDetail> endUserList=null; 
	searchTxt="%"+searchTxt.toUpperCase()+"%";
	try{
		
		String rowLimit=QueryConstants.ROW_LIMIT;
		String sql=QueryConstants.GET_USER_LIST_BY_TXT;
		
		endUserList = this.jdbcTemplate.query(sql,new Object[]{searchTxt,rowLimit},new EndUserDetailMapper());
		

	return 	endUserList;
	} catch (Exception e) {
		logger.error("Exception in getEndUserListByTxt" + e.getLocalizedMessage());
	}
	  return endUserList;
}

private static final class EndUserDetailMapper implements RowMapper<EndUserDetail> {
	public EndUserDetailMapper() {
	}
	@Override
	public EndUserDetail mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		EndUserDetail result = new EndUserDetail();
		//result.setEndUserId(rs.getInt("ID"));
		result.setEndUserName(rs.getString("CUSTOMER_NAME") != null ? rs.getString("CUSTOMER_NAME") : "");
		result.setIndustry(rs.getString("END_USER_INDUSTRY") != null ? rs.getString("END_USER_INDUSTRY") : "");
		result.setCountry(rs.getString("EU_CUST_COUNTRY") != null ? rs.getString("EU_CUST_COUNTRY") : "");
		result.setState(rs.getString("EU_CUST_STATE") != null ? rs.getString("EU_CUST_STATE") : "");
		result.setCity(rs.getString("EU_CUST_CITY") != null ? rs.getString("EU_CUST_CITY") : "");
		result.setZip(rs.getString("EU_CUST_ZIP") != null ? rs.getString("EU_CUST_ZIP") : "");
		
			return result;
	}
}


}
