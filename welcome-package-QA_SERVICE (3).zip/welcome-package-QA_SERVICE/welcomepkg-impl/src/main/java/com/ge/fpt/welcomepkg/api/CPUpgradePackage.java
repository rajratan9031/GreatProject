package com.ge.fpt.welcomepkg.api;

import java.util.List;

public class CPUpgradePackage {
	
	private int packageId;
	private String packageName;
	private String packageDescription;
	private String kitNumber;
	private String couponCode;
	private int quantity;
	private double originalAmount;
	private double discountedAmount;
    private List<CPUpgradeDocument> upgradeDocument;
	public int getPackageId() {
		return packageId;
	}
	public void setPackageId(int packageId) {
		this.packageId = packageId;
	}
	public String getPackageName() {
		return packageName;
	}
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	public String getPackageDescription() {
		return packageDescription;
	}
	public void setPackageDescription(String packageDescription) {
		this.packageDescription = packageDescription;
	}
	public String getKitNumber() {
		return kitNumber;
	}
	public void setKitNumber(String kitNumber) {
		this.kitNumber = kitNumber;
	}
	public String getCouponCode() {
		return couponCode;
	}
	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}
	public double getOriginalAmount() {
		return originalAmount;
	}
	public void setOriginalAmount(double originalAmount) {
		this.originalAmount = originalAmount;
	}
	public double getDiscountedAmount() {
		return discountedAmount;
	}
	public void setDiscountedAmount(double discountedAmount) {
		this.discountedAmount = discountedAmount;
	}
	public List<CPUpgradeDocument> getUpgradeDocument() {
		return upgradeDocument;
	}
	public void setUpgradeDocument(List<CPUpgradeDocument> upgradeDocument) {
		this.upgradeDocument = upgradeDocument;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "CPUpgradePackage [packageId=" + packageId + ", packageName=" + packageName + ", packageDescription="
				+ packageDescription + ", kitNumber=" + kitNumber + ", couponCode=" + couponCode + ", quantity="
				+ quantity + ", originalAmount=" + originalAmount + ", discountedAmount=" + discountedAmount
				+ ", upgradeDocument=" + upgradeDocument + "]";
	}
	
	
	

}
