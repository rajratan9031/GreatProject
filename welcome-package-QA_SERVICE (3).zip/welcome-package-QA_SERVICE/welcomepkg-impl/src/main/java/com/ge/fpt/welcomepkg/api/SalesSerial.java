package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.List;

public class SalesSerial implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private List<String> orderNumber;
	private String dunsNumber;
	private List<String> serialNumber;
	private String orderNumber1;
	private List<String> recSource;
	
	
	
	
	
	
	
	public List<String> getRecSource() {
		return recSource;
	}
	public void setRecSource(List<String> recSource) {
		this.recSource = recSource;
	}
	public String getOrderNumber1() {
		return orderNumber1;
	}
	public void setOrderNumber1(String orderNumber1) {
		this.orderNumber1 = orderNumber1;
	}
	public List<String> getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(List<String> serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getDunsNumber() {
		return dunsNumber;
	}
	public void setDunsNumber(String dunsNumber) {
		this.dunsNumber = dunsNumber;
	}
	public List<String> getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(List<String> orderNumber) {
		this.orderNumber = orderNumber;
	}
	
	public SalesSerial() {
		super();
	}
	public SalesSerial(List<String> orderNumber, String dunsNumber, List<String> serialNumber, String orderNumber1,
			List<String> recSource) {
		super();
		this.orderNumber = orderNumber;
		this.dunsNumber = dunsNumber;
		this.serialNumber = serialNumber;
		this.orderNumber1 = orderNumber1;
		this.recSource = recSource;
	}
	@Override
	public String toString() {
		return "SalesSerial [orderNumber=" + orderNumber + ", dunsNumber=" + dunsNumber + ", serialNumber="
				+ serialNumber + ", orderNumber1=" + orderNumber1 + ", recSource=" + recSource + "]";
	}
	
	
	
	
	
	
	


}
