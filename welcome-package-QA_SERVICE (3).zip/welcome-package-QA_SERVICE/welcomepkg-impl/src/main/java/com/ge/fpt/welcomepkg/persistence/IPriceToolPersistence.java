package com.ge.fpt.welcomepkg.persistence;

import com.ge.fpt.welcomepkg.api.PriceToolData;
import com.ge.fpt.welcomepkg.api.PriceToolSearchCriteria;
import java.util.List;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

public abstract interface IPriceToolPersistence {
	@Transactional(propagation = Propagation.REQUIRED)
	public abstract List<PriceToolData> getPriceToolList(
			PriceToolSearchCriteria paramPriceToolSearchCriteria);
}
