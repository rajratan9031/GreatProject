package com.ge.fpt.welcomepkg.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.fpt.welcomepkg.api.PartData;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;

public class PartDataPersistenceImpl implements IPartDataPersistence{

	
	@SuppressWarnings("javadoc")
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory.getLogger(PartDataPersistenceImpl.class);
	
	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;

	/**
	 * Data source for the JDBC
	 */
	DataSource dataSource;

	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;
	
	NamedParameterJdbcTemplate namedParamTemplate;

	/**
	 * @return the dataSource
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}

	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate = new NamedParameterJdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}
	
	public String getFilterClause(PartData partData){
		String filter="";
		List<String> conditions = new ArrayList<String>();
		if(partData!=null){
			if(partData.getPartInfoId()!=null && !partData.getPartInfoId().isEmpty()){
				conditions.add(" UPPER(PART_INFO_ID) LIKE '%' || :partInfoId || '%'");
				}
			if(partData.getRecSource()!=null && !partData.getRecSource().isEmpty()){
				conditions.add(" UPPER(REC_SOURCE) LIKE '%' || :recSource || '%'");
			}
			if(partData.getItemNumber()!=null && !partData.getItemNumber().isEmpty()){
				conditions.add(" UPPER(ITEM_NUMBER) LIKE '%' || :itemNumber || '%'");
			}
			if(partData.getDescription()!=null && !partData.getDescription().isEmpty()){
				conditions.add(" UPPER(DESCRIPTION) LIKE '%' || :description || '%'");
			}
			if(partData.getLegacyPartNumber()!=null && !partData.getLegacyPartNumber().isEmpty()){
				conditions.add(" UPPER(LEGACY_PART_NUMBER) LIKE '%' || :legacyPartNumber || '%'");
			}
			if(partData.getSpareIndicator()!=null && !partData.getSpareIndicator().isEmpty()){
				conditions.add(" UPPER(SPARES_INDICATOR) LIKE '%' || :spareIndicator || '%'");
			}
			if(partData.getStockType()!=null && !partData.getStockType().isEmpty()){
				conditions.add(" UPPER(STOCK_TYPE) LIKE '%' || :stockType || '%'");
			}
			if(partData.getLeadTime()!=null && !partData.getLeadTime().isEmpty()){
				conditions.add(" UPPER(LEAD_TIME) LIKE '%' || :leadTime || '%'");
			}
			if(partData.getLeastPrice()!=null && !partData.getLeastPrice().isEmpty()){
				conditions.add(" UPPER(LEAD_PRICE) LIKE '%' || :leastPrice || '%'");
			}
			if(partData.getProductLine()!=null && !partData.getProductLine().isEmpty()){
				conditions.add(" UPPER(PRODUCT_CODE) LIKE '%' || :productLine || '%'");
			}
		}
		if (conditions.size() > 0) {
			String condStr = "";
			
			for (int i = 0; i < conditions.size(); i++) {
				condStr += ( " AND " + conditions.get(i));
			}
			
			filter = condStr;
		}
		return filter;
	}
	
	public  Map<String, String> setFilterParams(PartData partData){

		Map<String, String> result = new HashMap<String, String>();
		result.put("partInfoId", partData.getPartInfoId() == null ? "" : partData.getPartInfoId().toUpperCase());
		result.put("recSource", partData.getRecSource() == null ? "" : partData.getRecSource().toUpperCase());
		result.put("itemNumber", partData.getItemNumber() == null ? "" : partData.getItemNumber().toUpperCase());
		result.put("description", partData.getDescription() == null ? "" : partData.getDescription().toUpperCase());
		result.put("legacyPartNumber", partData.getLegacyPartNumber() == null ? "" : partData.getLegacyPartNumber().toUpperCase());
		result.put("spareIndicator", partData.getSpareIndicator() == null ? "" : partData.getSpareIndicator().toUpperCase());
		result.put("stockType", partData.getStockType() == null ? "" : partData.getStockType().toUpperCase());
		result.put("leadTime", partData.getLeadTime() == null ? "" : partData.getLeadTime().toUpperCase());
		result.put("leastPrice", partData.getLeastPrice() == null ? "" : partData.getLeastPrice().toUpperCase());
		result.put("productLine", partData.getProductLine() == null ? "" : partData.getProductLine().toUpperCase());
		
		return result;
	}
	
	public  int getPartDataCount(PartData partData){
		String sql="select count(*) from fptods.sqt_part_info_t_master a where 1=1 ";
		MapSqlParameterSource parameters = new MapSqlParameterSource(setFilterParams(partData));
		if(partData!=null){
			String filter=getFilterClause(partData);
			
			sql=sql+filter;
			
		}
		return this.namedParamTemplate.queryForInt(sql, parameters);
	}
	public List<PartData> getPartData(int pageNo,int rowsPerPage,PartData partData){
		
		List<PartData> result = null;
		try{
			String sql= "select part_info_id,rec_source,item_number,description,legacy_part_number, "+
						"spares_indicator,stock_type,lead_time,list_price,product_code "+
						"from (select rownum as rnum, a.* from fptods.sqt_part_info_t_master a where 1=1";
			MapSqlParameterSource parameters = new MapSqlParameterSource(setFilterParams(partData));
			
			if(partData!=null){
				String filter=getFilterClause(partData);
				sql=sql+filter;
				
			}
			sql+=")";
			if (rowsPerPage > 0) {
				
				int lowerLimit = rowsPerPage * pageNo;
				int upperLimit = lowerLimit + rowsPerPage;
				
				String pageLimitClause= " where rnum >:lowerLimit AND rnum <=:upperLimit";
				parameters.addValue("lowerLimit", lowerLimit);
				parameters.addValue("upperLimit", upperLimit);
				sql+=pageLimitClause;
				
			}
			
			result=this.namedParamTemplate.query(sql, parameters,
					new PartMapper());
		
		}catch(Exception e){
			logger.info("found Exception :: "+e);
		}
		return result;
	}
	
	
	public List<PartData> getPartDataByPartInfoId(String partInfoId){
		List<PartData> partData = new ArrayList<PartData>();
		try {
			logger.error("value coming from frontend"+partInfoId);
		String sql= "select * from fptods.sqt_part_info_t_master where item_number = ?";
		partData=this.jdbcTemplate.query(sql, new Object[] { partInfoId},
				new PartMapper());
		} catch(Exception ex){
			logger.info("Error occured during fetching the Data :: "+ex);
		}	
		return partData;
	}

	public StatusInfo savePartData(String sso,PartData partData){
		StatusInfo statusinfo= new StatusInfo();
		try {		
		String sql= "select count(item_number) from fptods.sqt_part_info_t_master where item_number= ?";
		String saveSql="";
		int count=this.jdbcTemplate.queryForInt(sql, new Object[]{partData.getItemNumber()});
		if(count>0){
			 saveSql="update fptods.sqt_part_info_t_master set item_number=?,description=?,legacy_part_number=?, "+
					" spares_indicator= ?,stock_type=?,product_code=?,last_update_date=sysdate,Updated_by=? where item_number=?"	;	

			 Object[] param={
				  		  
				  		  partData.getItemNumber(),
				  		  partData.getDescription(),
				  		  partData.getLegacyPartNumber(),
				  		  partData.getSpareIndicator(),
				  		  partData.getStockType(),
				  		  partData.getProductLine(),
				  		  sso,
				  		  partData.getItemNumber()
				 };
		  this.jdbcTemplate.update(saveSql, param);
		}else{
			/*sql="Select max(part_info_id)+1 from fptods.sqt_part_info_t_master";
			int cnt=this.jdbcTemplate.queryForInt(sql);*/
			
			saveSql= "insert into fptods.sqt_part_info_t_master(part_info_id,rec_source,item_number,description,legacy_part_number,spares_indicator,stock_type,product_code,creation_date,last_update_date,updated_by) "+
					 "values (?,?,?,?,?,?,?,?,sysdate,sysdate,?)";
			Object[] param={
					  "",
			  		  partData.getRecSource(),
			  		  partData.getItemNumber(),
			  		  partData.getDescription(),
			  		  partData.getLegacyPartNumber(),
			  		  partData.getSpareIndicator(),
			  		  partData.getStockType(),
			  		  partData.getProductLine(),
			  		  sso
			   };
			this.jdbcTemplate.update(saveSql, param);
		}
		
		String sqlMasterCount=" select  count(item_number) from fptods.sqt_part_info_t where item_number=? ";
		int masterCount=this.jdbcTemplate.queryForInt(sqlMasterCount, new Object[]{partData.getItemNumber()});
			if(masterCount > 0){
			String updateSqlMaster="Update fptods.sqt_part_info_t set Description=?, "+
					"legacy_part_number= ?,spares_indicator=?, Stock_type=?,product_line=? ,last_update_date=sysdate,updated_by=? "+
					"where item_number=?";
			 Object[] updateParam={
					 	partData.getDescription(),
			  		 	partData.getLegacyPartNumber(),
			  		 	partData.getSpareIndicator(),
			  		 	partData.getStockType(),
			  		 	partData.getProductLine(),
			  		 	sso,
			  		 	partData.getItemNumber()
			 };
			 this.jdbcTemplate.update(updateSqlMaster, updateParam);
			}else{
				String insertSqlMaster="insert into fptods.sqt_part_info_t "
						+ "(item_number, description,legacy_part_number,spares_indicator,stock_type,product_line,creation_date,last_update_date,updated_by) values "
						+"(?,?,?,?,?,?,sysdate,sysdate,?)";
				Object[] insertParam={
						partData.getItemNumber(),
					 	partData.getDescription(),
			  		 	partData.getLegacyPartNumber(),
			  		 	partData.getSpareIndicator(),
			  		 	partData.getStockType(),
			  		 	partData.getProductLine(),
			  		 	sso
			  		 	
			 };
				this.jdbcTemplate.update(insertSqlMaster, insertParam);
			}
			
		 statusinfo.setStatusCode(1);
		 statusinfo.setStatusMessage("Data saved Successfully"); 
		} catch(Exception ex){
			logger.info("Error occured during saving the Data :: "+ex);
			statusinfo.setStatusCode(-1);
			statusinfo.setStatusMessage(ex.getMessage());
		}
		return statusinfo;
	}
	
	@SuppressWarnings("nls")
	@Override
	public StatusInfo getPartDataToUpload(HashMap getCompleteData){
		StatusInfo result = new StatusInfo();
		List<List<String>> getCompleteExcelData = (List<List<String>>) getCompleteData.get("getExcelData");
		String ssoID = (String) getCompleteData.get("sso_id");
		Long cnt=0l;
		try{
			if(getCompleteExcelData.size() > 1){
				String maxIdSql="Select max(part_info_id) from ddsafm.sqt_part_info_t";
				cnt=this.jdbcTemplate.queryForLong(maxIdSql);
				cnt=cnt+1;
				
				/*String maxIdMasterSql="Select max(part_info_id)+1 from fptods.sqt_part_info_t_master";
				int maxCountMasterPartInfoId=this.jdbcTemplate.queryForInt(maxIdMasterSql);*/
				
				for(int i=1;i<getCompleteExcelData.size();i++){
					String sql= "select count(item_number) from ddsafm.sqt_part_info_t where item_number= ?";
					
					int count=this.jdbcTemplate.queryForInt(sql, new Object[]{getCompleteExcelData.get(i).get(1)});
					
					if(count>0){
						 String updateSql="update ddsafm.sqt_part_info_t set rec_source=?,item_number=?,description=?,legacy_part_number=?, "+
								" spares_indicator= ?,stock_type=?,product_line=?,last_update_date=sysdate, updated_by = ? where item_number=?"	;	

						 Object[] param={
									 	getCompleteExcelData.get(i).get(0),
									 	getCompleteExcelData.get(i).get(1),
									 	getCompleteExcelData.get(i).get(2),
									 	getCompleteExcelData.get(i).get(3),
									 	getCompleteExcelData.get(i).get(4),
									 	getCompleteExcelData.get(i).get(5),
									 	getCompleteExcelData.get(i).get(6),
									 	ssoID,
									 	getCompleteExcelData.get(i).get(1)
								 	};
						 
					  this.jdbcTemplate.update(updateSql, param);
					}else{
						String Query = "Insert into ddsafm.sqt_part_info_t(part_info_id,rec_source,item_number,description,legacy_part_number, "+
								" spares_indicator,stock_type,creation_date,product_line,updated_by)"+
								"values(?,?,?,?,?,?,?,sysdate,?,?)";
						
						Object[] params = new Object[] {cnt ,getCompleteExcelData.get(i).get(0),getCompleteExcelData.get(i).get(1),
						getCompleteExcelData.get(i).get(2),getCompleteExcelData.get(i).get(3),getCompleteExcelData.get(i).get(4),getCompleteExcelData.get(i).get(5),
						getCompleteExcelData.get(i).get(6),ssoID};
						this.jdbcTemplate.update(Query,params);
						cnt=cnt+1;
					}
					
					String sqlMasterCount= "select count(*) from fptods.sqt_part_info_t_master where item_number= ?";
					
					int masterCount=this.jdbcTemplate.queryForInt(sqlMasterCount, new Object[]{getCompleteExcelData.get(i).get(1)});
					
						if(masterCount > 0){
						String updateSqlMaster="Update fptods.sqt_part_info_t_master set rec_source=?, Description=?, "+
								"legacy_part_number= ?,spares_indicator=?, Stock_type=?,product_code=?, updated_by=?, last_update_date=sysdate "+
								"where item_number=?";
						 Object[] updateParam={
								 	getCompleteExcelData.get(i).get(0),
								 	getCompleteExcelData.get(i).get(2),
								 	getCompleteExcelData.get(i).get(3),
								 	getCompleteExcelData.get(i).get(4),
								 	getCompleteExcelData.get(i).get(5),
								 	getCompleteExcelData.get(i).get(6),
								 	ssoID,
								 	getCompleteExcelData.get(i).get(1)
						 };
						 this.jdbcTemplate.update(updateSqlMaster, updateParam);
						}else{
							String insertSqlMaster="insert into fptods.sqt_part_info_t_master "
									+ "(part_info_id, rec_source, item_number, description,legacy_part_number,spares_indicator,stock_type,creation_date,updated_by,product_code) values "
									+"(?,?,?,?,?,?,?,sysdate,?,?)";
							Object[] insertParam={
									null,
									getCompleteExcelData.get(i).get(0),
									getCompleteExcelData.get(i).get(1),
									getCompleteExcelData.get(i).get(2),
									getCompleteExcelData.get(i).get(3),
									getCompleteExcelData.get(i).get(4),
									getCompleteExcelData.get(i).get(5),
									ssoID,
									getCompleteExcelData.get(i).get(6)
						 };
							this.jdbcTemplate.update(insertSqlMaster, insertParam);
							
						}
				}
				result.setStatusCode(0);
				result.setStatusMessage("File Uploaded successfully.");
			}else{
				result.setStatusCode(1);
				result.setStatusMessage("No Data found in excel to upload.");
			}
		}catch(Exception ex){
			logger.info("File Upload Data Insertion Exception :: "+ex);
			result.setStatusCode(-1);
			result.setStatusMessage(ex.getMessage());
		}
		return result;
	}
	
	private static final class PartMapper implements RowMapper<PartData> {
		public PartMapper() {
		}

		@Override
		public PartData mapRow(ResultSet rs, int rowNum) throws SQLException {
			PartData result = new PartData();
			result.setPartInfoId(rs.getString("part_info_id"));
			result.setRecSource(rs.getString("rec_source"));
			result.setItemNumber(rs.getString("item_number"));
			result.setDescription(rs.getString("description"));
			result.setLegacyPartNumber(rs.getString("legacy_part_number"));
			result.setSpareIndicator(rs.getString("spares_indicator"));
			result.setStockType(rs.getString("stock_type"));
			result.setLeadTime(rs.getString("lead_time"));
			result.setLeastPrice(rs.getString("list_price"));
			result.setProductLine(rs.getString("product_code"));
			return result;
		}
	}
	
}
