package com.ge.fpt.welcomepkg.persistence;

import java.util.Map;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ge.fpt.welcomepkg.api.StatusInfo;

public interface ISPIRReportDataPersistence {
	
	@Transactional(propagation = Propagation.REQUIRED)
	public StatusInfo getExcelDataToPersist(Map getCompleteData);
	
	
}
