/*
 * Copyright (c) 2013 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.fpt.welcomepkg.impl;

import java.io.InputStream;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.jws.WebMethod;
import javax.sql.DataSource;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.web.bind.annotation.RequestBody;

import com.ge.dsp.core.spi.annotation.RestfulServiceAddress;
import com.ge.fpt.welcomepkg.api.AccountData;
import com.ge.fpt.welcomepkg.api.BomConfigurator;
import com.ge.fpt.welcomepkg.api.BomWhereusedData;
import com.ge.fpt.welcomepkg.api.CPPromotionalCart;
import com.ge.fpt.welcomepkg.api.CPUpgradeDetailSMIView;
import com.ge.fpt.welcomepkg.api.CPUpgradeDetailView;
import com.ge.fpt.welcomepkg.api.CPUpgradeDocument;
import com.ge.fpt.welcomepkg.api.CPUpgradeInfo;
import com.ge.fpt.welcomepkg.api.CartData;
import com.ge.fpt.welcomepkg.api.ChannelData;
import com.ge.fpt.welcomepkg.api.CountryDTO;
import com.ge.fpt.welcomepkg.api.CpLocationInfo;
import com.ge.fpt.welcomepkg.api.CustomerData;
import com.ge.fpt.welcomepkg.api.CustomerDataManagmentMaster;
import com.ge.fpt.welcomepkg.api.CustomerLinkMaster;
import com.ge.fpt.welcomepkg.api.CustomerLinkMasterDTO;
import com.ge.fpt.welcomepkg.api.CustomerMgmtMaster;
import com.ge.fpt.welcomepkg.api.DigitalBOMData;
import com.ge.fpt.welcomepkg.api.DigitalEquipmentData;
import com.ge.fpt.welcomepkg.api.DocumentDetails;
import com.ge.fpt.welcomepkg.api.DropDownItem;
import com.ge.fpt.welcomepkg.api.EndUserDetail;
import com.ge.fpt.welcomepkg.api.EquipLookupData;
import com.ge.fpt.welcomepkg.api.EquipmentBoms;
import com.ge.fpt.welcomepkg.api.HeatMapOverlayData;
import com.ge.fpt.welcomepkg.api.IWelcomePkgService;
import com.ge.fpt.welcomepkg.api.InstallBaseFilter;
import com.ge.fpt.welcomepkg.api.InstalledBaseWithDuns;
import com.ge.fpt.welcomepkg.api.InstalledValveInfo;
import com.ge.fpt.welcomepkg.api.Inventory;
import com.ge.fpt.welcomepkg.api.InventoryUser;
import com.ge.fpt.welcomepkg.api.LinkingMasterTO;
import com.ge.fpt.welcomepkg.api.OrderEquipment;
import com.ge.fpt.welcomepkg.api.OrderInfo;
import com.ge.fpt.welcomepkg.api.OtherDocumentDetails;
import com.ge.fpt.welcomepkg.api.PartData;
import com.ge.fpt.welcomepkg.api.PartDataComponents;
import com.ge.fpt.welcomepkg.api.PartDetailsOfComponent;
import com.ge.fpt.welcomepkg.api.PartLookupData;
import com.ge.fpt.welcomepkg.api.PartMasterData;
import com.ge.fpt.welcomepkg.api.PartMasterData1;
import com.ge.fpt.welcomepkg.api.PlantData;
import com.ge.fpt.welcomepkg.api.PlantDataManagmentMaster;
import com.ge.fpt.welcomepkg.api.PlantDataMaster;
import com.ge.fpt.welcomepkg.api.PlantEquipment;
import com.ge.fpt.welcomepkg.api.PriceToolData;
import com.ge.fpt.welcomepkg.api.PriceToolSearchCriteria;
import com.ge.fpt.welcomepkg.api.PriceToolUser;
import com.ge.fpt.welcomepkg.api.ProductData;
import com.ge.fpt.welcomepkg.api.ProjectDataMaster;
import com.ge.fpt.welcomepkg.api.PromotionalCart;
import com.ge.fpt.welcomepkg.api.PromotionalCartViewData;
import com.ge.fpt.welcomepkg.api.RSPCartData;
import com.ge.fpt.welcomepkg.api.RecipData;
import com.ge.fpt.welcomepkg.api.Region_Data;
import com.ge.fpt.welcomepkg.api.Report;
import com.ge.fpt.welcomepkg.api.ReportData;
import com.ge.fpt.welcomepkg.api.SalesSerial;
import com.ge.fpt.welcomepkg.api.SerialNoDetails;
import com.ge.fpt.welcomepkg.api.SqtCustomerLink;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.api.TestData;
import com.ge.fpt.welcomepkg.api.TurboChargerDetail;
import com.ge.fpt.welcomepkg.api.TurboDropDown;
import com.ge.fpt.welcomepkg.api.UpdateCartResponse;
import com.ge.fpt.welcomepkg.api.UpgradeInfo;
import com.ge.fpt.welcomepkg.api.UpgradeInfoNew;
import com.ge.fpt.welcomepkg.api.UpgradeInfoNewDTO;
import com.ge.fpt.welcomepkg.api.UpgradeOptionDetails;
import com.ge.fpt.welcomepkg.api.UpgradeOptionListDTO;
import com.ge.fpt.welcomepkg.api.UpgradeOptions;
import com.ge.fpt.welcomepkg.api.UpgradePartModel;
import com.ge.fpt.welcomepkg.api.UserData;
import com.ge.fpt.welcomepkg.api.UserSettings;
import com.ge.fpt.welcomepkg.api.UsersDataManagmentMaster;
import com.ge.fpt.welcomepkg.api.VKCustOrderInfoSpeqT;
import com.ge.fpt.welcomepkg.api.VKOrderDocument;
import com.ge.fpt.welcomepkg.api.VKReportData;
import com.ge.fpt.welcomepkg.api.VKSTGReportData;
import com.ge.fpt.welcomepkg.api.ValveKeepPushData;
import com.ge.fpt.welcomepkg.api.ValvekeepUploadData;
import com.ge.fpt.welcomepkg.persistence.IAngolaReportServicePersistence;
import com.ge.fpt.welcomepkg.persistence.IBomsPersistence;
import com.ge.fpt.welcomepkg.persistence.ICardDataPersistence;
import com.ge.fpt.welcomepkg.persistence.IChannelDataPersistence;
import com.ge.fpt.welcomepkg.persistence.ICicsPersistence;
import com.ge.fpt.welcomepkg.persistence.ICustomerLinkMasterPersistence;
import com.ge.fpt.welcomepkg.persistence.ICustomermgmtMasterPersistence;
import com.ge.fpt.welcomepkg.persistence.IDocumentPersistence;
import com.ge.fpt.welcomepkg.persistence.IDropDownPersistence;
import com.ge.fpt.welcomepkg.persistence.IEquipmentPersistence;
import com.ge.fpt.welcomepkg.persistence.IInstalledBasePersistence;
import com.ge.fpt.welcomepkg.persistence.IInventoryPersistence;
import com.ge.fpt.welcomepkg.persistence.IInventoryUserPersistence;
import com.ge.fpt.welcomepkg.persistence.IOrderPersistence;
import com.ge.fpt.welcomepkg.persistence.IPartDataPersistence;
import com.ge.fpt.welcomepkg.persistence.IPartDetailsOfComponent;
import com.ge.fpt.welcomepkg.persistence.IPartLookupPersistance;
import com.ge.fpt.welcomepkg.persistence.IPartsComponentDetails;
import com.ge.fpt.welcomepkg.persistence.IPlantDataMasterPersistence;
import com.ge.fpt.welcomepkg.persistence.IPlantDataPersistence;
import com.ge.fpt.welcomepkg.persistence.IPlantEquipmentPersistence;
import com.ge.fpt.welcomepkg.persistence.IPriceToolPersistence;
import com.ge.fpt.welcomepkg.persistence.IRCManagementPersistence;
import com.ge.fpt.welcomepkg.persistence.IReportServicePersistence;
import com.ge.fpt.welcomepkg.persistence.ISPIRReportDataPersistence;
import com.ge.fpt.welcomepkg.persistence.IServiceNowPersistence;
import com.ge.fpt.welcomepkg.persistence.IUpgradeInfoPersistence;
import com.ge.fpt.welcomepkg.persistence.IUserDataPersistence;
import com.ge.fpt.welcomepkg.persistence.IValveKeepSTGPersistance;
import com.ge.fpt.welcomepkg.persistence.IpriceToolUserPersistence;
import com.ge.fpt.welcomepkg.persistence.UserDataPersistenceImpl;
import com.ge.fpt.welcomepkg.util.Constants;

/**
 * Welcome Pkg service implementation
 * 
 * @author 212414241
 */
@RestfulServiceAddress("welcome-pkg")
public  class WelcomePkgServiceImpl implements IWelcomePkgService {

	@SuppressWarnings("javadoc")
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory.getLogger(WelcomePkgServiceImpl.class);
	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;
	/**
	 * Data source for the JDBC
	 */
	DataSource dataSource;
	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;
	NamedParameterJdbcTemplate namedParamTemplate;
	/**
	 * @return the dataSource
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}
	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate = new NamedParameterJdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}
	
	/**
	 * Reference to IOrderPersistence interface
	 */
	private IOrderPersistence orderPersistence;
	/**
	 * Reference to IEquipmentPersistence interface
	 */
	private IEquipmentPersistence equipmentPersistence;
	/**
	 * Reference to IBomsPersistence interface
	 */
	private IBomsPersistence bomsPersistence;

	/**
	 * Reference to IUserDataPersistence interface
	 */
	private IUserDataPersistence userDataPersistence;

	private IPriceToolPersistence priceToolPersistence;
	
	private IDropDownPersistence dropDownPersistence;
	
	private IpriceToolUserPersistence priceToolUserPersistence;
	
	private ISPIRReportDataPersistence spirReportDataPersistence;
	
	private IChannelDataPersistence channelDataPersistence;
	
	private IPartDataPersistence partDataPersistence;
	
	private IPartsComponentDetails partsComponentDetailsPersistence;

	private IPartDetailsOfComponent partDetailsOfComponentPersistence;
	
	private IReportServicePersistence reportServicePersistence;
	
	private IPlantEquipmentPersistence plantEquipmentPersistence;
	
	private IInventoryUserPersistence inventoryUserPersistence;
	
	private IPartLookupPersistance partPersistence;
	
	private ICicsPersistence cicsPersistence;
	
	private IUpgradeInfoPersistence upgradeInfoPersistence;
	
	private IAngolaReportServicePersistence angolaReportServicePersistence;
	
	private IInstalledBasePersistence installedBasePersistence;

	private IValveKeepSTGPersistance valveKeepSTGPersistance;
	
	private IRCManagementPersistence rCManagementPersistence;

	private IServiceNowPersistence serviceNowPersistence;
	
    private ICustomerLinkMasterPersistence customerLinkMasterPersistence;

	private IPlantDataMasterPersistence PlantDataMasterPersistence;
	
	private ICustomermgmtMasterPersistence CustomermgmtMasterPersistence;
	
	private ICardDataPersistence cardDataPersistence;
	
	//Alfresco
	private IDocumentPersistence documentPersistence;


	/**
	 * @return the customerLinkMasterPersistence
	 */
	public ICustomerLinkMasterPersistence getCustomerLinkMasterPersistence() {
		return customerLinkMasterPersistence;
	}
	/**
	 * @param customerLinkMasterPersistence
	 *            the customerLinkMasterPersistence to set
	 */
	public void setCustomerLinkMasterPersistence(ICustomerLinkMasterPersistence customerLinkMasterPersistence) {
		this.customerLinkMasterPersistence = customerLinkMasterPersistence;
	}
	/**
	 * @return the plantDataMasterPersistence
	 */
	public IPlantDataMasterPersistence getPlantDataMasterPersistence() {
		return PlantDataMasterPersistence;
	}
	/**
	 * @param plantDataMasterPersistence
	 *            the plantDataMasterPersistence to set
	 */
	public void setPlantDataMasterPersistence(IPlantDataMasterPersistence plantDataMasterPersistence) {
		PlantDataMasterPersistence = plantDataMasterPersistence;
	}
	/**
	 * @return the customer_mgmt_MasterPersistence
	 */
	
	/**
	 * @return the cardDataPersistence
	 */
	public ICardDataPersistence getCardDataPersistence() {
		return cardDataPersistence;
	}
	public ICustomermgmtMasterPersistence getCustomermgmtMasterPersistence() {
		return CustomermgmtMasterPersistence;
	}
	public void setCustomermgmtMasterPersistence(ICustomermgmtMasterPersistence customermgmtMasterPersistence) {
		CustomermgmtMasterPersistence = customermgmtMasterPersistence;
	}
	/**
	 * @param cardDataPersistence
	 *            the cardDataPersistence to set
	 */
	public void setCardDataPersistence(ICardDataPersistence cardDataPersistence) {
		this.cardDataPersistence = cardDataPersistence;
	}
	/**
	 * @return the documentPersistence
	 */
	public IDocumentPersistence getDocumentPersistence() {
		return documentPersistence;
	}
	/**
	 * @param documentPersistence
	 *            the documentPersistence to set
	 */
	public void setDocumentPersistence(IDocumentPersistence documentPersistence) {
		this.documentPersistence = documentPersistence;
	}
	public IServiceNowPersistence getServiceNowPersistence() {
		return serviceNowPersistence;
	}
	public void setServiceNowPersistence(IServiceNowPersistence serviceNowPersistence) {
		this.serviceNowPersistence = serviceNowPersistence;
	}
	
	public ICicsPersistence getCicsPersistence() {
				return cicsPersistence;
			}
	
    public void setCicsPersistence(ICicsPersistence cicsPersistence) {
			this.cicsPersistence = cicsPersistence;
		}
	
	public IRCManagementPersistence getrCManagementPersistence() {
		return rCManagementPersistence;
	}
	public void setrCManagementPersistence(IRCManagementPersistence rCManagementPersistence) {
		this.rCManagementPersistence = rCManagementPersistence;
	}

	public IValveKeepSTGPersistance getValveKeepSTGPersistance() {
		return valveKeepSTGPersistance;
	}

	public void setValveKeepSTGPersistance(IValveKeepSTGPersistance valveKeepSTGPersistance) {
		this.valveKeepSTGPersistance = valveKeepSTGPersistance;
	}
	
	public IAngolaReportServicePersistence getAngolaReportServicePersistence() {
	return angolaReportServicePersistence;
	}

	public void setAngolaReportServicePersistence(IAngolaReportServicePersistence angolaReportServicePersistence) {
	this.angolaReportServicePersistence = angolaReportServicePersistence;
	}
		
	public IInstalledBasePersistence getInstalledBasePersistence() {
		return installedBasePersistence;
	}

	public void setInstalledBasePersistence(IInstalledBasePersistence installedBasePersistence) {
		this.installedBasePersistence = installedBasePersistence;
	}

	public IUpgradeInfoPersistence getUpgradeInfoPersistence() {
		return upgradeInfoPersistence;
	}

	public void setUpgradeInfoPersistence(IUpgradeInfoPersistence upgradeInfoPersistence) {
		this.upgradeInfoPersistence = upgradeInfoPersistence;
	}
	public IPartLookupPersistance getPartPersistence() {
		return partPersistence;
	}

	public void setPartPersistence(IPartLookupPersistance partPersistence) {
		this.partPersistence = partPersistence;
	}
	public IInventoryUserPersistence getInventoryUserPersistence() {
		return inventoryUserPersistence;
	}

	public void setInventoryUserPersistence(IInventoryUserPersistence inventoryUserPersistence) {
		this.inventoryUserPersistence = inventoryUserPersistence;
	}

	public IPlantEquipmentPersistence getPlantEquipmentPersistence() {
		return plantEquipmentPersistence;
	}

	public void setPlantEquipmentPersistence(IPlantEquipmentPersistence plantEquipmentPersistence) {
		this.plantEquipmentPersistence = plantEquipmentPersistence;
	}

	private IPlantDataPersistence plantDataPersistence;
	
	public IPlantDataPersistence getPlantDataPersistence(){
		return plantDataPersistence;		
	}
	
	public void setPlantDataPersistence(IPlantDataPersistence plantDataPersistence){
		this.plantDataPersistence=plantDataPersistence;
	}
	public IReportServicePersistence getReportServicePersistence() {
		return reportServicePersistence;
	}

	public void setReportServicePersistence(IReportServicePersistence reportServicePersistence) {
		this.reportServicePersistence = reportServicePersistence;
	}

	public IInventoryPersistence getInventoryPersistence() {
		return inventoryPersistence;
	}

	public void setInventoryPersistence(IInventoryPersistence inventoryPersistence) {
		this.inventoryPersistence = inventoryPersistence;
	}

	private IInventoryPersistence inventoryPersistence;

	public IPartsComponentDetails getPartsComponentDetailsPersistence() {
	return partsComponentDetailsPersistence;
	}

	public void setPartsComponentDetailsPersistence(IPartsComponentDetails partsComponentDetailsPersistence) {
	this.partsComponentDetailsPersistence = partsComponentDetailsPersistence;
	}

	public IPartDetailsOfComponent getPartDetailsOfComponentPersistence() {
	return partDetailsOfComponentPersistence;
	}

	public void setPartDetailsOfComponentPersistence(IPartDetailsOfComponent partDetailsOfComponentPersistence) {
	this.partDetailsOfComponentPersistence = partDetailsOfComponentPersistence;
	}

	public IPartDataPersistence getPartDataPersistence() {
	return partDataPersistence;
	}

	public void setPartDataPersistence(IPartDataPersistence partDataPersistence) {
	this.partDataPersistence = partDataPersistence;
	}

	public IChannelDataPersistence getChannelDataPersistence() {
		return channelDataPersistence;
	}

	public void setChannelDataPersistence(IChannelDataPersistence channelDataPersistence) {
		this.channelDataPersistence = channelDataPersistence;
	}

	public ISPIRReportDataPersistence getSpirReportDataPersistence() {
	return spirReportDataPersistence;
	}

	public void setSpirReportDataPersistence(ISPIRReportDataPersistence spirReportDataPersistence) {
	this.spirReportDataPersistence = spirReportDataPersistence;
	}
	public IDropDownPersistence getDropDownPersistence() {
		return this.dropDownPersistence;
	}

	public void setDropDownPersistence(IDropDownPersistence dropDownPersistence) {
		this.dropDownPersistence = dropDownPersistence;
	}

	public IPriceToolPersistence getPriceToolPersistence() {
		return this.priceToolPersistence;
	}

	public void setPriceToolPersistence(IPriceToolPersistence priceToolPersistence) {
		this.priceToolPersistence = priceToolPersistence;
	}

	/**
	 * @return the orderPersistence
	 */
	public IOrderPersistence getOrderPersistence() {
		return this.orderPersistence;
	}

	public IpriceToolUserPersistence getPriceToolUserPersistence() {
		return this.priceToolUserPersistence;
	}

	public void setPriceToolUserPersistence(IpriceToolUserPersistence priceToolUserPersistence) {
		this.priceToolUserPersistence = priceToolUserPersistence;
	}

	/**
	 * @param orderPersistence
	 *            the orderPersistence to set
	 */
	public void setOrderPersistence(IOrderPersistence orderPersistence) {
		this.orderPersistence = orderPersistence;
	}

	/**
	 * @return the equipmentPersistence
	 */
	public IEquipmentPersistence getEquipmentPersistence() {
		return this.equipmentPersistence;
	}

	/**
	 * @param equipmentPersistence
	 *            the equipmentPersistence to set
	 */
	public void setEquipmentPersistence(IEquipmentPersistence equipmentPersistence) {
		this.equipmentPersistence = equipmentPersistence;
	}

	/**
	 * @return the bomsPersistence
	 */
	public IBomsPersistence getBomsPersistence() {
		return this.bomsPersistence;
	}

	/**
	 * @param bomsPersistence
	 *            the bomsPersistence to set
	 */
	public void setBomsPersistence(IBomsPersistence bomsPersistence) {
		this.bomsPersistence = bomsPersistence;
	}

	/**
	 * @return the userDataPersistence
	 */
	public IUserDataPersistence getUserDataPersistence() {
		return this.userDataPersistence;
	}

	/**
	 * @param userDataPersistence
	 *            the userDataPersistence to set
	 */
	public void setUserDataPersistence(IUserDataPersistence userDataPersistence) {
		this.userDataPersistence = userDataPersistence;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ge.fpt.springjpa.api.IWelcomePkgService#getOrdersBySSO(java
	 * .lang.String)
	 */
//	@Override
//	@WebMethod
	// public List<OrderInfo> getOrdersBySSO(String sso, int page, int rowsPerPage)
	// {
//		
//		UserSettings settings = this.userDataPersistence.loadUserSettings(sso);
//
	// List<OrderInfo> orders = this.orderPersistence.getOrdersBySSO(sso, settings,
	// page, rowsPerPage);
//		if (orders != null && orders.size() > 0) {
//			return orders;
//		}
//		return null;
//	}	
	
	@Override
	@WebMethod
	public List<OrderInfo> getOrdersBySSO(String sso, int page, int rowsPerPage, String sortCol, String sortOrder,
			String globalSearch, boolean blanketSearch, String serialNo, String partNo, String tagNo, String fileName,
			String engineeredValve, OrderInfo orderInfo) {
		UserSettings settings = this.userDataPersistence.loadUserSettings(sso);
		List<OrderInfo> orders = this.orderPersistence.getOrdersBySSO(sso, settings, page, rowsPerPage, sortCol,
				sortOrder, orderInfo, globalSearch, blanketSearch, serialNo, partNo, tagNo, fileName, engineeredValve);
		if (orders != null && orders.size() > 0) {
			return orders;
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ge.fpt.springjpa.api.IWelcomePkgService#
	 * getEquipmentByRecSourceAndSalesOrder(java .lang.String, java.lang.String)
	 */
	@Override
	@WebMethod
	public List<OrderEquipment> getEquipmentByRecSourceAndSalesOrder(String recSource, String orderNumber,
			String engineeredValve, String sso) {
		List<ChannelData> channelData = channelDataPersistence.channelDataBySso(sso);
		String dunsNumber=null;
		if(!channelData.isEmpty() && channelData.size()>=0){
			dunsNumber=channelData.get(0).getDuns();
		}
		List<OrderEquipment> equipment = this.equipmentPersistence.getEquipmentBySalesOrderAndRecSource(orderNumber,
				recSource, engineeredValve, dunsNumber);
		if (equipment != null && equipment.size() > 0) {
			return equipment;
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ge.fpt.springjpa.api.IWelcomePkgService#
	 * getBomsByByRecSourceAndSerialNumber(java .lang.String, java.lang.String)
	 */
	@Override
	@WebMethod
	public List<EquipmentBoms> getBomsByByRecSourceAndSerialNumber(String recSource, String serialNumber, String region,
			String currency) {
		List<EquipmentBoms> boms = this.bomsPersistence.getBomBySerialNumberAndRecSource(serialNumber, recSource,
				region, currency);
		if (boms != null && boms.size() > 0) {
			return boms;
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ge.fpt.welcomepkg.api.IWelcomePkgService#
	 * saveRSPCartData(java.lang.String)
	 */
	@Override
	@WebMethod
	public void saveRSPCartData(String cartName) {

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ge.fpt.welcomepkg.api.IWelcomePkgService#
	 * getEquipmentBySalesOrderSerialNumberRecSource
	 * (com.ge.fpt.welcomepkg.api.EquipLookupData)
	 */
	@Override
	@WebMethod
	public List<OrderEquipment> getEquipmentBySalesOrderSerialNumberRecSource(EquipLookupData[] lookupData) {
		List<OrderEquipment> equipment = this.equipmentPersistence
				.getEquipmentBySalesOrderSerialNumberAndRecSource(lookupData);

		if (equipment != null && equipment.size() > 0) {
			return equipment;
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ge.fpt.welcomepkg.api.IWelcomePkgService#getTestData(java.lang.String ,
	 * java.lang.String)
	 */
	@Override
	@WebMethod
	public List<TestData> getTestData(String val1, String val2) {

		TestData elm = new TestData(val1, val2);

		List<TestData> result = new ArrayList<TestData>();

		for (int i = 0; i < 5; i++)
			result.add(elm);

		if (result != null && result.size() > 0)
			return result;
		else
			return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ge.fpt.welcomepkg.api.IWelcomePkgService#postTestData(com.ge.fpt.
	 * welcomepkg.api.TestData[])
	 */
	@Override
	@WebMethod
	public List<TestData> postTestData(TestData[] testData) {

		List<TestData> result = new ArrayList<TestData>();

		for (int i = 0; i < testData.length; i++)
			result.add(testData[i]);

		if (result != null && result.size() > 0)
			return result;
		else
			return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ge.fpt.welcomepkg.api.IWelcomePkgService#addToRSPCart(java.lang.String ,
	 * com.ge.fpt.welcomepkg.api.OrderEquipment[])
	 */
	@Override
	@WebMethod
	public UpdateCartResponse addToRSPCart(String sso, OrderEquipment[] saveData) {

		// AddToCartResponse result = new AddToCartResponse();
		// result.setTotalCartCount(saveData.length);
		// result.setAddedCount(0);
		// result.setMessage("Entry point works.");
		//
		// List<RSPCartData> addedItems = new ArrayList<RSPCartData>();
		// for (int i = 0; i < saveData.length; i++){
		// RSPCartData cartData = new RSPCartData();
		// cartData.setSso(sso);
		// cartData.setSerialNumber(saveData[i].getSerialNumber());
		// cartData.setRecSource(saveData[i].getRecSource());
		//
		// addedItems.add(cartData);
		// }
		//
		// result.setAddedItems(addedItems);

		// //TestData result = this.sparesPersistence.saveToRSPCart(saveData);

		UpdateCartResponse result = this.equipmentPersistence.saveToRSPCart(sso, saveData);

		return result;
	}

	@Override
	@WebMethod
	public int getCartCount(String sso) {
		int result = this.equipmentPersistence.getCartCount(sso);

		return result;
	}

	@Override
	@WebMethod
	public UpdateCartResponse deleteFromRSPCart(String sso, Long[] valveInfoIds) {
		UpdateCartResponse result = this.equipmentPersistence.deleteFromRSPCart(sso, valveInfoIds);

		return result;
	}

	@Override
	@WebMethod
	public List<RSPCartData> getCurrentRSPCart(String sso) {
		List<RSPCartData> result = this.equipmentPersistence.getCurrentRSPCart(sso);

		return result;
	}

	@Override
	@WebMethod
	public int checkCartExists(String sso, String cartName) {
		int result = this.equipmentPersistence.checkCartExists(sso, cartName);

		return result;
	}

	@Override
	@WebMethod
	public StatusInfo saveCart(String sso, String cartName) {
		StatusInfo result = this.equipmentPersistence.saveCart(sso, cartName);

		return result;
	}

	@Override
	@WebMethod
	public StatusInfo loadCart(String sso, String cartName) {
		StatusInfo result = this.equipmentPersistence.loadCart(sso, cartName);

		return result;
	}

	@Override
	@WebMethod
	public StatusInfo deleteSavedCart(String sso, String cartName) {
		StatusInfo result = this.equipmentPersistence.deleteSavedCart(sso, cartName);

		return result;
	}

	@Override
	@WebMethod
	public StatusInfo deleteAllFromRSPCart(String sso) {
		StatusInfo result = this.equipmentPersistence.deleteAllFromRSPCart(sso);

		return result;
	}

	@Override
	@WebMethod
	public List<String> getSavedCarts(String sso) {
		List<String> result = this.equipmentPersistence.getSavedCarts(sso);

		return result;
	}

	@Override
	@WebMethod
	public UserSettings loadUserSettings(String sso) {
		UserSettings result = this.userDataPersistence.loadUserSettings(sso);

		return result;
	}

	@Override
	@WebMethod
	public StatusInfo saveUserSettings(String sso, UserSettings saveData) {
		StatusInfo result = this.userDataPersistence.saveUserSettings(sso, saveData);

		return result;
	}

	@WebMethod
	public List<PriceToolData> getPriceToolList(PriceToolSearchCriteria map) {
		List<PriceToolData> result = this.priceToolPersistence.getPriceToolList(map);
		return result;
	}

	@WebMethod
	public List<DropDownItem> getCurrencyCodeList() {
		List<DropDownItem> result = this.dropDownPersistence.getCurrencyCodeList();
		return result;
	}

	@WebMethod
	public List<DropDownItem> getRegionList() {
		List<DropDownItem> result = this.dropDownPersistence.getRegionList();
		return result;
	}
	
	@WebMethod
	public List<DropDownItem> getRegionListByUser(String sso) {
		List<DropDownItem> result = this.dropDownPersistence.getRegionListByUser(sso);
		return result;
	}
	
	@WebMethod
	public List<PriceToolUser> getPriceToolUser() {
		List<PriceToolUser> result = this.priceToolUserPersistence.getPriceToolUser();
		return result;
	}
	
	@WebMethod
	public StatusInfo savePriceToolUser(String sso,PriceToolUser priceToolUser) {
		return this.priceToolUserPersistence.savePriceToolUser(sso,priceToolUser);	
	}
	
	@WebMethod
	public StatusInfo deletePriceToolUser(PriceToolUser priceToolUser) {
		 return this.priceToolUserPersistence.deletePriceToolUser(priceToolUser);	
	}
	
	@WebMethod
	public boolean getValidAdminUser(String sso) {
		 return this.userDataPersistence.getValidAdminUser(sso);	
	}
	
	@WebMethod
	public boolean getValidPriceToolUser(String sso) {
		 return this.userDataPersistence.getValidPriceToolUser(sso);	
	}

	@Override
	@WebMethod
	public StatusInfo convertOrder(String sso, Long orderNum, String recSource) {
		StatusInfo result = this.orderPersistence.convertOrder(sso, orderNum, recSource);
		return result;
	}
	
	@Override
	@WebMethod
	public UserData getUserData(String sso) {
		UserData result = this.userDataPersistence.getUserData(sso);
		return result;
	}
	
//	@Override
//	@WebMethod
//	public int getOrdersCount(String sso) {
//		UserSettings settings = this.userDataPersistence.loadUserSettings(sso);
//		
//		int result = this.orderPersistence.getOrdersCount(sso, settings);
//		return result;
//	}	
	
	@Override
	@WebMethod
	public int getOrdersCount(String sso, String globalSearch, boolean blanketSearch, String serialNo, String partNo,
			String tagNo, String fileName, String engineeredValve, OrderInfo orderInfo) {
		UserSettings settings = this.userDataPersistence.loadUserSettings(sso);
		
		int result = this.orderPersistence.getOrdersCount(sso, settings, orderInfo, globalSearch, blanketSearch,
				serialNo, partNo, tagNo, fileName, engineeredValve);
		return result;
	}
	
	public static boolean isInternalUser(String sso) {
		return UserDataPersistenceImpl.isInternalUser(sso);
	}
	
	@Override
	@WebMethod
	public List<OrderInfo> getOrdersByDUNS(String sso, String type, String duns, String year, String month, String pc,
			int page, int rowsPerPage, String sortCol, String sortOrder, String globalSearch, OrderInfo orderInfo)
			throws ParseException {
		List<OrderInfo> orders = this.orderPersistence.getOrdersByDUNS(sso, type, duns, year, month, pc, page,
				rowsPerPage, sortCol, sortOrder, globalSearch, orderInfo);
		if (orders != null && orders.size() > 0) {
			return orders;
		}
		return null;
	}
	
	@Override
	@WebMethod
	public int getOrderCountByDUNS(String sso, String type, String duns, String year, String month, String pc,
			String globalSearch, OrderInfo orderInfo) throws ParseException {
		int count = this.orderPersistence.getOrderCountByDUNS(sso, type, duns, year, month, pc, globalSearch,
				orderInfo);
		
		return count;
	}
	
	@Override
	@WebMethod
	public List<OrderInfo> getOrdersBySalesOrder(String sso,String salesOrder){
		List<OrderInfo> orders = this.orderPersistence.getOrdersBySalesOrder(sso, salesOrder);
		if (orders != null && orders.size() > 0) {
			return orders;
		}
		return null;
	}
	
	@Override
	@WebMethod
	 public StatusInfo UpdateSalesOrderInfo(String sso,OrderInfo orderinfo) {
		StatusInfo result = this.orderPersistence.UpdateSalesOrderInfo(sso, orderinfo);
		return result;
	}
	
//@Override
//	@WebMethod
	// public List<RecipData> getRecordsBySerialNumber(String sso,String
	// serialNumber){
	// List<RecipData> records =
	// this.rCManagementPersistence.getRecordsBySerialNumber(sso, serialNumber);
//		if (records != null && records.size() > 0) {
//			return records;
//		}
//		return null;
//	}
//	
//	@Override
//	@WebMethod
//	 public StatusInfo UpdateRecipData(String sso,RecipData recipdata) {
	// StatusInfo result = this.rCManagementPersistence.UpdateRecipData(sso,
	// recipdata);
//		return result;
//	}
	
	@Override
	@WebMethod
	 public List<DropDownItem> getCountryCodeList() {
		List<DropDownItem> result = this.dropDownPersistence.getCountryCodeList();
		return result;
	}
	
	@Override
	@WebMethod
	 public List<DropDownItem> getEndUserIndustryList() {
		List<DropDownItem> result = this.dropDownPersistence.getEndUserIndustryList();
		return result;
	}
	@Override
	@WebMethod
	 public List getAutocompleteDataList(String sso, String col, String input) {
		List result = this.orderPersistence.getAutocompleteDataList( sso, col, input);
		return result;
	}
	
	@Override
	@WebMethod
	 public List<OrderEquipment>  getEquipmentBySn( EquipLookupData lookupData) {
		List<OrderEquipment> result = this.equipmentPersistence. getEquipmentBySn(lookupData);
		return result;
	}
	
	@Override
	@WebMethod
	 public StatusInfo  updateEquipment( String sso,OrderEquipment orderEquipment) {
		StatusInfo result = this.equipmentPersistence. updateEquipment(sso,orderEquipment);
		return result;
	}
	
	@Override
	@WebMethod
	 public List<String>  getPartNo( String recsource,String serialno,String partNo) {
		List<String> result = this.bomsPersistence.getPartNo(recsource,serialno,partNo);
		return result;
	}
	
	
	@Override
	@WebMethod
	 public List<String>  getPartDesc( String recsource,String partNo) {
	   List<String> result = this.bomsPersistence.getPartDesc(recsource,partNo);
		return result;
	}
	
	@Override
	@WebMethod
	 public StatusInfo deletePartHeader( String sso,EquipmentBoms equipmentBoms) {
		StatusInfo result = this.bomsPersistence.deletePartHeader(sso,equipmentBoms);
		return result;
	}
	
	@Override
	@WebMethod
	 public StatusInfo savePartHeader(String serialNumber,String recSource,String sso,EquipmentBoms[] equipmentBoms) {
		StatusInfo result = this.bomsPersistence.savePartHeader(serialNumber,recSource,sso,equipmentBoms);
		return result;
	}
	
		/*@Override
		@WebMethod
		 public List orderList(OrderEquipment orderEquipment) {
			List result = this.orderPersistence.orderList(orderEquipment);
			return result;
		}*/
	
	@Override
	@WebMethod
	 public List<DropDownItem> getStateList(String country) {
		List<DropDownItem> result = this.dropDownPersistence.getStateList(country);
		return result;
	}
	
	@Override
	@WebMethod
	public StatusInfo getExcelFileToUpload(@RequestBody HashMap getData){
		StatusInfo getUploadStatus = this.spirReportDataPersistence.getExcelDataToPersist(getData);
		return getUploadStatus;
	}
	
	@Override
	@WebMethod
	public List<ChannelData> channelDataBySso(String sso){
		logger.info("sso in channelDataBySso ---->>" +sso);
		List<ChannelData> result = this.channelDataPersistence.channelDataBySso(sso);
		return result;
	}
	
	@Override
	@WebMethod
	public StatusInfo saveChannelData(ChannelData channelData){
		StatusInfo status = this.channelDataPersistence.saveChannelData(channelData);
		return status;
	}
	
	@Override
	@WebMethod
	public List<ChannelData> getChannelData(int pageNo,int rowperpage,ChannelData channelData){
		List<ChannelData> result = this.channelDataPersistence.getChannelData(pageNo,rowperpage,channelData);
		return result;
	}
	
	@Override
	@WebMethod
	public int getChannelDataCount(ChannelData channelData){
		int result = this.channelDataPersistence.getChannelDataCount(channelData);
		return result;
	}
	
	@Override
	@WebMethod
	public List<PartData> partDataByPartInfoId(String partInfoId){
	List<PartData> result = this.partDataPersistence.getPartDataByPartInfoId(partInfoId);
	return result;
	}

	@Override
	@WebMethod
	public StatusInfo savePartData(String sso,PartData partData){
	StatusInfo status = this.partDataPersistence.savePartData(sso,partData);
	return status;
	}

	@Override
	@WebMethod
	public List<PartData> getPartData(int pageNo,int rowperpage,PartData partData){
	List<PartData> result = this.partDataPersistence.getPartData(pageNo,rowperpage,partData);
	return result;
	}

	@Override
	@WebMethod
	public int getPartDataCount(PartData PartData){
	int result = this.partDataPersistence.getPartDataCount(PartData);
	return result;
	}
	
//	productInfoID -> productKey?
//	@Override
//	@WebMethod
//	public List<ProductData> productDataByProductInfoId(String productInfoId){
	// List<ProductData> result =
	// this.rcProductDataPersistence.getProductDataByProductInfoId(productInfoId);
//	return result;
//	}
//
//	@Override
//	@WebMethod
//	public StatusInfo saveProductData(String sso,ProductData productData){
	// StatusInfo status =
	// this.rcProductDataPersistence.saveProductData(sso,productData);
//	return status;
//	}
//
//	@Override
//	@WebMethod
	// public List<ProductData> getProductData(int pageNo,int rowperpage,ProductData
	// productData){
	// List<ProductData> result =
	// this.rcProductDataPersistence.getProductData(pageNo,rowperpage,productData);
//	return result;
//	}
//
//	@Override
//	@WebMethod
//	public int getProductDataCount(ProductData ProductData){
//	int result = this.rcProductDataPersistence.getProductDataCount(ProductData);
//	return result;
//	}
	
	@Override
	@WebMethod
	public List<DropDownItem> getSpareIndicatorList(){
		List<DropDownItem> result=this.dropDownPersistence.getSpareIndicatorList();
		return result;
	}
	
	@Override
	@WebMethod
	public List<DropDownItem> getStockTypeList(){
		List<DropDownItem> result=this.dropDownPersistence.getStockTypeList();
		return result;
	}
	
	@Override
	@WebMethod
	public List<DropDownItem> getRecsourceList(){
		List<DropDownItem> result=this.dropDownPersistence.getRecsourceList();
		return result;
	}
	
	@Override
	@WebMethod
	public List getCompanyFromDuns(String duns){
		List<String>result=this.channelDataPersistence.getCompanyFromDuns(duns);
		return result;
		
	}
	
	@Override
	@WebMethod
	public List<VKReportData> getVKReportData(String sso, String region, String currency) {
		List <VKReportData> result = this.equipmentPersistence.getVKReportData(sso, region, currency);
		return result;
	}
	
	@Override
	@WebMethod
	public List<PartDataComponents> getPartDetails(@RequestBody HashMap partData){
	List<PartDataComponents> result=this.partsComponentDetailsPersistence.getComponentDetailsForPart(partData);
	return result;
	}

	@Override
	@WebMethod
	public boolean getValidEnggAdminUser(String sso) {
	return this.userDataPersistence.getValidEnggAdminUser(sso); 
	}
	
	@Override
	@WebMethod
	public List<PartDetailsOfComponent> getComponentDetails(@RequestBody HashMap componentData){
		List<PartDetailsOfComponent> result = this.partDetailsOfComponentPersistence
				.getPartDetailsForComponent(componentData);
	return result;
	}
	
	@Override
	@WebMethod
	public List getcomponentDesc(@RequestBody HashMap partAndComponentData){
	List result=this.partsComponentDetailsPersistence.getcomponentDesc(partAndComponentData);
	return result;
	}
	
	@Override
	@WebMethod
	public StatusInfo saveParentPartDetails(@RequestBody List<PartDataComponents> partData){
	StatusInfo result=this.partsComponentDetailsPersistence.savePartDataComponents(partData);
	return result;
	}
	
	@Override
	@WebMethod
	public StatusInfo getPartDataToUpload(@RequestBody HashMap getData){
	StatusInfo getUploadStatus = this.partDataPersistence.getPartDataToUpload(getData);
	return getUploadStatus;
	}
	
	@Override
	@WebMethod
	public StatusInfo getAssemblyDataToUpload(@RequestBody HashMap getData){
	StatusInfo getUploadStatus = this.partsComponentDetailsPersistence.getAssemblyDataToUpload(getData);
	return getUploadStatus;
	}
	
	@Override
	@WebMethod
	public  List<DropDownItem> getConfiguratorOption(){
		List<DropDownItem> configuratorOptionList =this.dropDownPersistence.getConfiguratorOption();
	return configuratorOptionList;
	}
	
	@Override
	@WebMethod
	public StatusInfo saveBomConfigurator( String sso,BomConfigurator bomConfigurator){
		StatusInfo status=this.bomsPersistence.saveBomConfigurator(sso,bomConfigurator);
			return status;	
	}
	@Override
	@WebMethod
	public List<BomConfigurator> getBomConfigurator( String serialNumber,String recSource){
		List<BomConfigurator> result= this.bomsPersistence.getBomConfigurator(serialNumber,recSource);
			return result;
	}

	@Override
	@WebMethod
	public StatusInfo uploadInventory(@RequestBody HashMap getData){
	StatusInfo getUploadStatus = this.inventoryPersistence.uploadInventory(getData);
	return getUploadStatus;
	}
	
	@Override
	@WebMethod
	public List<Inventory> getInventory(Inventory inventory){
		List<Inventory>  list = this.inventoryPersistence.getInventory(inventory);
	return list;
	}
	
	@Override
	@WebMethod
	public List<DropDownItem> getSiteInfo(String sso){
		List<DropDownItem>  list = this.dropDownPersistence.getSiteInfo(sso);
	return list;
	}

	@Override
	@WebMethod
	public List<Report> getReportData(@RequestBody ReportData reportData,String sso){
		List<Report>  response = this.reportServicePersistence.getReportData(reportData,sso);
	return response;
	}
	@Override
	@WebMethod
	public List<CpLocationInfo> getLocationData(int pageNo,int rowperpage,CpLocationInfo cpLocationInfo) {
		List<CpLocationInfo> result =this.channelDataPersistence.getLocationData(pageNo,rowperpage,cpLocationInfo);
		return result;
	}

	@Override
	@WebMethod
	public StatusInfo saveCpLocationData(CpLocationInfo cpLocationInfo) {
		return this.channelDataPersistence.savecpLocationData(cpLocationInfo);
	}

	@Override
	@WebMethod
	public int getCpLocationDataCount(CpLocationInfo cpLocationInfo) {
		return this.channelDataPersistence.getCpLocationDataCount(cpLocationInfo);
	}

	@Override
	@WebMethod
	public StatusInfo deleteCpLocation(CpLocationInfo cpLocationInfo) {
		return this.channelDataPersistence.deleteCpLocation(cpLocationInfo);
	}

	@Override
	@WebMethod
	public List<String> getEquipments(String serial) {
		return this.plantEquipmentPersistence.getEquipments(serial);
	}

	@Override
	@WebMethod
	public int getEquipmentCountinPlant(PlantEquipment equipment) throws Exception{
		return this.plantEquipmentPersistence.getEquipmentCountinPlant(equipment);
	}

	@Override
	@WebMethod
	public List<PlantEquipment> getEquipmentinPlant(int pageNo, int rowsPerpage, PlantEquipment equipment) {
		return this.plantEquipmentPersistence.getEquipmentinPlant(pageNo, rowsPerpage, equipment);
	}

	@Override
	@WebMethod
	public StatusInfo deleteEquipment(PlantEquipment equipment) {
	return this.plantEquipmentPersistence.deleteEquipment(equipment);
	}

	@Override
	@WebMethod
	public StatusInfo saveequipment(PlantEquipment equipment) {
		return this.plantEquipmentPersistence.savePlantEquipment(equipment);
	}

	@Override
	@WebMethod
	public List<String> getRecSources(String serial) {
		logger.info("fetching recSources for serial:"+serial);
	return this.plantEquipmentPersistence.getRecSources(serial);
	}

	@Override
	@WebMethod
	public Map<String,String> getShippingDate(String recSource, String serial) {
		logger.info("fetching shipment dates"+recSource + serial);
		return this.plantEquipmentPersistence.getShippingDates(recSource, serial);
	}
	
	@Override
	@WebMethod
	public List<PlantData> getPlantData(int pageNo, int rowperpage, PlantData plantData) {
		logger.info("Inside getPlantData step 1");
		List<PlantData> result = this.plantDataPersistence.getPlantData(pageNo,rowperpage,plantData);
		return result;
	}

	@Override
	@WebMethod
	public int getPlantDataCount(PlantData plantData) {
		logger.info("Inside getPlantDataCount step 1");
		int result = this.plantDataPersistence.getPlantDataCount(plantData);	
		return result;		
		/*return 2;*/
	}

	@Override
	@WebMethod
	public StatusInfo savePlantData(PlantData plantData) {
		logger.info("Inside Save Plant");
		StatusInfo status = this.plantDataPersistence.savePlantData(plantData);
		return status;
	}

	@Override
	@WebMethod
	public List<PlantData> plantDataByPlantId(String plantId) {
		List<PlantData> result = this.plantDataPersistence.getPlantDataByPlantId(plantId);
		return result;
	}

	@Override
	@WebMethod
	public StatusInfo deletePlantdata(PlantData plantData) {
		logger.info("Inside Save Plant");
		StatusInfo status = this.plantDataPersistence.deletePlantData(plantData);
		return status;
	}
	
	@Override
	@WebMethod
	public List<InventoryUser> getInventoryUser() {
		List<InventoryUser> result = this.inventoryUserPersistence.getInventoryUser();
		return result;
	}
	@Override
	@WebMethod
	public StatusInfo saveInventoryUser(String sso,InventoryUser inventoryUser) {
		return this.inventoryUserPersistence.saveInventoryUser(sso,inventoryUser);	
	}
	@Override
	@WebMethod
	public StatusInfo deleteInventoryUser(InventoryUser inventoryUser) {
		 return this.inventoryUserPersistence.deleteInventoryUser(inventoryUser);	
	}
	
	@Override
	@WebMethod
	public byte[] exportExcel(ReportData reportData,String sso) {
		 return this.reportServicePersistence.generateExcel( reportData,sso);	
	}
	@Override
	@WebMethod
	public byte[] exportPDF(ReportData reportData,String sso) {
		return  this.reportServicePersistence.generatePdf(reportData,sso);	
	}
	
	@Override
	@WebMethod
	public List<PartLookupData> getPartCrossRefData(PartLookupData part){
	List<PartLookupData>  list = this.partPersistence.getPartCrossRefData(part);
	return list;
	}
	
	@Override
	@WebMethod
	public List<OrderEquipment> getBlanketEquipment(String col, String val, String sso1) {
		logger.error("Inside getBlanketEquipment step 1");
		List<ChannelData> channelData = channelDataPersistence.channelDataBySso(sso1);
		String dunsNumber=null;
		if(!channelData.isEmpty() && channelData.size()>=0){
			dunsNumber=channelData.get(0).getDuns();
		}
		List<OrderEquipment> equipment = this.equipmentPersistence.getBlanketEquipment(col, val, dunsNumber);
		if (equipment != null && equipment.size() > 0) {
			return equipment;
		}
		return null;
	}
	
	@Override
	@WebMethod
	public StatusInfo getEmailDetails(Map mailDetails,String sso) {
	return this.inventoryPersistence.sendEmail(mailDetails,sso); 
	}
	
	@Override
	@WebMethod
	public boolean getValidInventoryUser(String sso) {
	return this.userDataPersistence.getValidInventoryUser(sso); 
	}
		@Override
	public List<UpgradeInfo> getUpgradeInfo(int pageNo, int rowperpage, UpgradeInfo upgradeInfo) {
		logger.error("Inside getUpgradeInfo step 1");
		List<UpgradeInfo> result = this.upgradeInfoPersistence.getUpgradeDetailsData(pageNo,rowperpage,upgradeInfo);
		return result;
	}

	@Override
	public int getUpgradeInfoCount(UpgradeInfo upgradeInfo) {
		logger.error("Inside getUpgradeInfoCount step 1");
		int result = this.upgradeInfoPersistence.getUpgradeDetailsCount(upgradeInfo);	
		return result;	
	}

	@Override
	public List<UpgradeOptions> getUpgradeOptions(int pageNo, int rowperpage, UpgradeOptions upgradeOptions) {
		logger.error("Inside getUpgradeOptions step 1");
		List<UpgradeOptions> result = this.upgradeInfoPersistence.getUpgradeOptionsData(pageNo, rowperpage,
				upgradeOptions);
		return result;
	}

	@Override
	public int getUpgradeOptionsCount(UpgradeOptions upgradeOptions) {
		logger.error("Inside getUpgradeOptionsCount step 1");
		int result = this.upgradeInfoPersistence.getUpgradeOptionsCount(upgradeOptions);	
		return result;
	}

	@Override
	public StatusInfo saveUpgradeInfo(UpgradeInfo upgradeInfo) {
		logger.info("Inside Save Upgrade Info");
		StatusInfo status = this.upgradeInfoPersistence.saveUpgradeDetails(upgradeInfo);
		return status;
	}
	

	@Override
	public StatusInfo saveUpgradeOptions(UpgradeOptions upgradeOptions) {
		logger.info("Inside Save Upgrade Options");
		StatusInfo status = this.upgradeInfoPersistence.saveUpgradeOptions(upgradeOptions);
		return status;
	}
/*
	 * 
	 * @Override public Boolean getModelData(String model) {
	 * logger.error("Inside getModelData step 1"); Boolean result =
	 * this.upgradeInfoPersistence.getModelData(model); return result; }
	 */
	
	@Override
	public Boolean getPartOrModelData(UpgradePartModel partModel) {
		logger.error("Inside getPartData step 1");
		Boolean result = this.upgradeInfoPersistence.getPartOrModelData(partModel);
		return result;
	}

	@Override
	public StatusInfo deleteUpgradeLegacyPnModel(UpgradePartModel upgradePartModel) {
		logger.error("Inside deleteUpgradeLegacyPnModel step 1");
		StatusInfo status =this.upgradeInfoPersistence.deleteUpgradeLegacyPnModel(upgradePartModel);
		return status;
	}

	@Override
	public StatusInfo deleteUpgradeOptionsDetailsPartModel(UpgradeOptionDetails upgradeOptionDetails) {
		logger.error("Inside deleteUpgradeOptionsDetailsPartModel step 1");
		StatusInfo status =this.upgradeInfoPersistence.deleteUpgradeOptionsDetailsPartModel(upgradeOptionDetails);
		return status;
	}

	@Override
	@WebMethod
	public List<DropDownItem> getUpgradeOptionsUI(String sso,String region) {
		List<DropDownItem> result = this.upgradeInfoPersistence.getUpgradeOptionsDataUI(sso,region);
		logger.info("getUpgradeOptionsUI ="+result);
		return result;
	}

	@Override
	public List<EquipmentBoms> getUpgradesByUpgradename(int page, int rowsPerPage, String globalSearch, String sortCol,
			String sortOrder, int upgradeId, String dunsNumber, EquipmentBoms equipmentboms) {
		List<EquipmentBoms> upgradeorders = this.upgradeInfoPersistence.getUpgradesByUpgradename(page, rowsPerPage,
				globalSearch, sortCol, sortOrder, upgradeId, dunsNumber, equipmentboms);
		if (upgradeorders != null && upgradeorders.size() > 0) {
			return upgradeorders;
		}
		return null;	
	}

	@Override
	@WebMethod
	public int getUpgradesCount(String globalSearch,int upgradeId, String dunsNumber,EquipmentBoms equipmentboms) {
		int result = this.upgradeInfoPersistence.getUpgradesCount(globalSearch,upgradeId,dunsNumber, equipmentboms);
		logger.error("getUpgradesCount= "+result);
		return result;
	}

	@Override
	@WebMethod
	public List<EquipmentBoms> getPartDataByByRecSourceAndSerialNumber(String recSource, String serialNumber,
			String region, String currency) {
		List<EquipmentBoms> boms = this.upgradeInfoPersistence.getPartDataByByRecSourceAndSerialNumber(serialNumber,
				recSource, region, currency);
		if (boms != null && boms.size() > 0) {
			return boms;
		}
		return null;
	}
	
	@Override
	@WebMethod
	public byte[] angolaReportService(@RequestBody Map reportParam,@PathParam(value="sso") String sso){
	return this.angolaReportServicePersistence.generateExcelReportForAngola(reportParam,sso); 
	}
	
	@WebMethod
	public boolean getValidUpgradeMgmtUser(String sso) {
		return this.userDataPersistence.getValidUpgradeMgmtUser(sso);	
	}
	
	@Override
	@WebMethod
	public boolean getValidRCAccountMgmtUser(String sso) {
		return this.userDataPersistence.getValidRCAccountMgmtUser(sso);	
	}
	
	@Override
	@WebMethod
	public boolean getValidRCCustomerMgmtUser(String sso) {
		return this.userDataPersistence.getValidRCCustomerMgmtUser(sso);	
	}
	
	@Override
	@WebMethod
	public boolean getValidRCProductMgmtUser(String sso) {
		return this.userDataPersistence.getValidRCProductMgmtUser(sso);	
	}
	
	/*
	 * @Override
	 * 
	 * @WebMethod public boolean getRcUser(String sso){ return
	 * this.userDataPersistence.getRcUser(sso); }
	 */

	public static void logError(Exception ex, String sso) {
		logError(ex, sso, "");
	}	
	
	public static void logError(Exception ex, String sso, String addInfo) {
		logger.error(new Date() + " (SSO: " + sso + ") " + addInfo + ": ", ex);
	}
	
	@Override
	public List<EquipmentBoms> getUpgradesByUpgradenameForGEUsers(int page, int rowsPerPage, String globalSearch,
			String sortCol, String sortOrder, int upgradeId, EquipmentBoms equipmentboms) {
		// TODO Auto-generated method stub
		List<EquipmentBoms> upgradeorders = this.upgradeInfoPersistence.getUpgradesByUpgradenameForGEUsers(page,
				rowsPerPage, globalSearch, sortCol, sortOrder, upgradeId, equipmentboms);
		if (upgradeorders != null && upgradeorders.size() > 0) {
			return upgradeorders;
		}
		return null;
	}

	@Override
	public int getUpgradesCountForGEUsers(String globalSearch,int upgradeId, EquipmentBoms equipmentboms) {
		int result = this.upgradeInfoPersistence.getUpgradesCountForGEUsers(globalSearch,upgradeId,equipmentboms);
		logger.error("getUpgradesCount= "+result);
		return result;
	}

	@Override
	@WebMethod
	public List<UpgradeOptions> getOptionsByUpgradeId(String upgradeId) {
		List<UpgradeOptions> upgradeOptions=this.upgradeInfoPersistence.getOptionsByUpgradeId(upgradeId);
		return upgradeOptions;
	}

	@Override
	@WebMethod
	public UpgradeInfo getUpgradeCoupon(String upgradeId) {
		UpgradeInfo couponCode=this.upgradeInfoPersistence.getUpgradeCoupon(upgradeId);
		return couponCode;
	}

	@Override
	@WebMethod
	public UpdateCartResponse addToPromotionalCart(String sso, PromotionalCart saveData) {		
		UpdateCartResponse result = this.equipmentPersistence.addToPromotionalCart(sso, saveData);
		return result;
	}
	
	@Override
	@WebMethod
	public Boolean checkUpgradeExist(String sso, PromotionalCart saveData) {		
		Boolean result = this.equipmentPersistence.checkUpgradeExist(sso, saveData);
		return result;
	}
	
	@Override
	@WebMethod
	public List<PromotionalCartViewData> getPromotionalCartData(String sso) {
		List<PromotionalCartViewData> promotionalCartData=this.upgradeInfoPersistence.getPromotionalCart(sso);
		logger.info("promotionalCartData- indicator:"+ promotionalCartData.get(0).getIndicator());
		logger.info("promotionalCartData- upgrade id:"+ promotionalCartData.get(0).getUpgradeId());
		return promotionalCartData;
	}
	
	@Override
	@WebMethod
	public int getPromotionalCartCount(String sso) {
		int result = this.upgradeInfoPersistence.getPromotionalCartCount(sso);
		return result;
	}
	
	@Override
	
	public List<String> getSavedPromotionalCarts(String sso) {
		List<String> result = this.upgradeInfoPersistence.getSavedPromotionalCarts(sso);
		return result;
	}
	
	@Override
	@WebMethod
	public StatusInfo savePromotionalCart(String sso, String cartName) {
		StatusInfo result = this.upgradeInfoPersistence.savePromotionalCart(sso,cartName);
		return result;
	}
	
	@Override
	@WebMethod
	public int checkPromotionalCartExists(String sso, String cartName) {
		int result = this.upgradeInfoPersistence.checkPromotionalCartExists(sso, cartName);
		return result;
	}
	
	@Override
	@WebMethod
	public StatusInfo loadPromotionalCart(String sso, String cartName) {
		StatusInfo result = this.upgradeInfoPersistence.loadPromotionalCart(sso, cartName);
		return result;
	}
	
	@Override
	@WebMethod
	public StatusInfo deletePromotionFromCart(String sso,PromotionalCartViewData promotionalCartViewData) {
		logger.info("@@@@@upgrade id :"+ promotionalCartViewData.getUpgradeId() );
		StatusInfo result = this.upgradeInfoPersistence.deletePromotionFromCart(sso,promotionalCartViewData);
		return result;
	}
	
	@Override
	@WebMethod
	public StatusInfo deleteAllPromotionFromCart(String sso) {
		StatusInfo result = this.upgradeInfoPersistence.deleteAllPromotionFromCart(sso);
		return result;
	}
	@Override
	@WebMethod
	public StatusInfo saveCartStatus(String sso, Map<String,String> data) {
		StatusInfo result = this.equipmentPersistence.saveCartStatus(sso, data);
		return result;
	}

	@Override
	@WebMethod
	public List<String> getCartStatus(String sso, Map<String,String> data) {
		List<String> result = this.equipmentPersistence.getCartStatus(sso, data);
		return result;
	}
	@Override
	@WebMethod
	public StatusInfo saveQuantity(String sso,PromotionalCartViewData promotionalcartViewData) {
		logger.info("saveQuantity"+ promotionalcartViewData.getQuantity());
		StatusInfo result = this.upgradeInfoPersistence.saveQuantity(sso,promotionalcartViewData);
		return result;
	}

	@Override
	@WebMethod
	public HeatMapOverlayData getInstallBaseZipcodes(InstallBaseFilter installBaseFilter) {
		HeatMapOverlayData heatMapOverlayData = this.installedBasePersistence.getInstallBaseGeoLoc(installBaseFilter);
		return heatMapOverlayData;
	}

	@Override
	public List<InstalledValveInfo> getInstalledValveInfo(int pageNo, int rowperpage,
			InstalledValveInfo installedValveInfo) {
		List<InstalledValveInfo> installedValveInfos = this.installedBasePersistence.getValveInfo(pageNo, rowperpage,
				installedValveInfo);
		return installedValveInfos;
	}

	@Override
	public InstalledBaseWithDuns getInstallBaseZipcodesWithDuns(InstallBaseFilter installBaseFilter) {
		InstalledBaseWithDuns installedBaseWithDuns = this.installedBasePersistence
				.getInstallBaseGeoLocWithDuns(installBaseFilter);
		return installedBaseWithDuns;
	}

	@Override
	public List<DropDownItem> getChannelList(String productCode) {
		List<DropDownItem> result = this.dropDownPersistence.getChannelList(productCode);
		return result;
	}

	@Override
	public int getInstalledValveInfoCount(InstalledValveInfo installedValveInfo) {
		int result = this.installedBasePersistence.getValveInfoCount(installedValveInfo);
		return result;
	}
	
	@Override
	@WebMethod
	public StatusInfo deleteKitComponent(String sso, String partNo){
		StatusInfo result=this.partsComponentDetailsPersistence.deleteKitComponent(sso,partNo);
	return result;
	}
	@Override
	@WebMethod
	public int getCartPC(String sso, Map<String,String> data) {
		int result = this.equipmentPersistence.getCartPC(sso, data);
		return result;
	}
	
	@Override
	@WebMethod
	public List<VKSTGReportData> getVKSTGReportData(@RequestBody Map param) {
		List<VKSTGReportData> result = this.valveKeepSTGPersistance.getVKSTGReportData(param);
		return result;
	}
	

	@Override
	public StatusInfo sendNotification() {
		logger.info("Inside sendEmailNotification");
		StatusInfo status = this.upgradeInfoPersistence.sendEmailNotification();
		return status;
	}
  
	@Override
	public OrderInfo getSalesorderInfo(String sso, String orderId, String recSource) {
		OrderInfo info = this.orderPersistence.getSalesOrderInfo(sso, orderId, recSource);
		return info;
	}

	
	
	@Override
	@WebMethod
	public StatusInfo digitalDataFileUpload(@RequestBody InputStream file,@Context HttpHeaders httpHeaders) {
		StatusInfo getUploadStatus = this.partsComponentDetailsPersistence.digitalDataUpload(file,httpHeaders);
		return getUploadStatus;
	}
	
	@Override
	@WebMethod
	public List<String>  getChannelSettingsProduct(String sso) {
		List<String>  product=this.orderPersistence.getChannelSettingsProduct(sso);
		return product;
	}
	
	
	@Override
	@WebMethod
	public List<AccountData> getAccountData(int pageNo, int rowperpage, String sortCol, String sortOrder,
			AccountData accountData) {
		List<AccountData> accountDataList = this.rCManagementPersistence.getAccountData(pageNo, rowperpage, sortCol,
				sortOrder, accountData);
		return accountDataList;
	}
	@Override
	@WebMethod
	public int getAccountdatacount(AccountData accountData) {
		int result = this.rCManagementPersistence.getAccountdatacount(accountData);
		return result;
	}
	@Override
	@WebMethod
	public StatusInfo saveAccountData(AccountData accountData) {
		StatusInfo status = this.rCManagementPersistence.saveAccountData(accountData);
		return status;
	}
	
	@Override
	@WebMethod
	public StatusInfo deleteAccountdata(AccountData accountData) {
		StatusInfo status =  this.rCManagementPersistence.deleteAccountdata(accountData);
		return status;
	}
	
	@Override
	@WebMethod
	public List<CustomerData> getCustomerdata(int pageNo, int rowperpage, String sortCol, String sortOrder,
			CustomerData customerData) {
		List<CustomerData> customerDataList = this.rCManagementPersistence.getCustomerdata(pageNo, rowperpage, sortCol,
				sortOrder, customerData);
		return customerDataList;
	}
	@Override
	@WebMethod
	public int getCustomerdatacount(CustomerData customerData) {
		int result = this.rCManagementPersistence.getCustomerdatacount(customerData);
		return result;
	}
	@Override
	@WebMethod
	public StatusInfo saveCustomerdata(CustomerData customerData) {
		StatusInfo status = this.rCManagementPersistence.saveCustomerdata(customerData);
		return status;
	}
	
	@Override
	@WebMethod
	public StatusInfo deleteCustomerdata(CustomerData customerData) {
		StatusInfo status =  this.rCManagementPersistence.deleteCustomerdata(customerData);
		return status;
	}
	
	
	@Override
	@WebMethod
	public List<ProductData> getProductdata(int pageNo, int rowperpage, String sortCol, String sortOrder,
			ProductData productData) {
		List<ProductData> productDataList = this.rCManagementPersistence.getProductdata(pageNo, rowperpage, sortCol,
				sortOrder, productData);
		return productDataList;
	}
	@Override
	@WebMethod
	public int getProductdatacount(ProductData productData) {
		int result = this.rCManagementPersistence.getProductdatacount(productData);
		return result;
	}
	@Override
	@WebMethod
	public StatusInfo saveProductdata(ProductData productData) {
		StatusInfo status = this.rCManagementPersistence.saveProductdata(productData);
		return status;
	}
	
	@Override
	@WebMethod
	public StatusInfo deleteProductdata(ProductData productData) {
		StatusInfo status =  this.rCManagementPersistence.deleteProductdata(productData);
		return status;
	}
	@Override
	@WebMethod
	public List<RecipData> getRecipData(int pageNo, int rowperpage, String globalSearch, String sortCol,
			String sortOrder, RecipData recipData) {
		List<RecipData> recipDataList = this.rCManagementPersistence.getRecipdata(pageNo, rowperpage, globalSearch,
				sortCol, sortOrder, recipData);
		return recipDataList;
	}
	@Override
	@WebMethod
	public int getRecipDataCount(String globalSearch,RecipData recipData) {
		int result = this.rCManagementPersistence.getRecipDataCount(globalSearch,recipData);
		return result;
	}
	
	@Override
	@WebMethod
	public List<EquipmentBoms> getRecipPartData(int pageNo, int rowperpage, RecipData recipData) {
		List<EquipmentBoms> boms = this.rCManagementPersistence.getRecipPartData(pageNo,rowperpage,recipData);
		if (boms != null && boms.size() > 0) {
			return boms;
		}
		return null;
	}
	
	@Override
	@WebMethod
	public int getRecipPartsDataCount(RecipData recipData) {
		int result = this.rCManagementPersistence.getRecipPartsDataCount(recipData);
		return result;
	}
	
	@Override
	@WebMethod
	public StatusInfo updateRecipdata(RecipData recipData) {
		StatusInfo status = this.rCManagementPersistence.updateRecipdata(recipData);
		return status;
	}
	
	@Override
	@WebMethod
	public StatusInfo addRecipdata(RecipData recipData) {
		StatusInfo status = this.rCManagementPersistence.addRecipdata(recipData);
		return status;
	}
	
	@Override
	@WebMethod
	public List<String> getCustomerName(String customerName) {
		return this.rCManagementPersistence.getCustomerName(customerName);
	}
	
	@Override
	@WebMethod
	public List<String> getAccountManagerName(String accountManagerName) {
		return this.rCManagementPersistence.getAccountManagerName(accountManagerName);
	}
	
	@Override
	@WebMethod
	public List<String> getProductName(String productName) {
		return this.rCManagementPersistence.getProductName(productName);
	}
	
	@Override
	@WebMethod
	public StatusInfo saveFilePath(String serialNumber, String recSource, String fileName, String filePath) {
		StatusInfo info = this.partsComponentDetailsPersistence.saveFilePath(serialNumber, recSource, fileName,
				filePath);
		return info;
	}
	
	@Override
	@WebMethod
	public StatusInfo getSerialDigitalUpload(HashMap excelData) {
		StatusInfo getUploadStatus = this.partsComponentDetailsPersistence.getSerialExcelDataToPersist(excelData);
		return getUploadStatus;
	}
	
	@Override
	@WebMethod
	public String saveEquipmentDigital(DigitalEquipmentData digitalEquipmentData) {
		String valveInfoId = this.equipmentPersistence.saveEquipmentDigital(digitalEquipmentData);
		return valveInfoId;
	}
	
	@Override
	@WebMethod
	public StatusInfo saveBomDigital(String valveInfoId, List<DigitalBOMData> digitalBomData) {
		StatusInfo result=this.equipmentPersistence.saveBomDigital(valveInfoId,digitalBomData);
		return result;
	}
	
	
	
	
	/* Sindhura : Service Now Changes : Start */
	

	@Override
	@WebMethod
	public List<DropDownItem> selectChannelPartnerName() {
		logger.info("Inside selectChannelPartnerName");
		List<DropDownItem> result = this.serviceNowPersistence.selectChannelPartnerName();
		return result;
	} 
	
	@Override
	@WebMethod
	public List<ChannelData> getCPusernames(String channelname) {
		logger.info("Inside getusername"+channelname);
		List<ChannelData> result = this.serviceNowPersistence.getCPusernames(channelname);
		return result;
	}
	
	
	@Override
	@WebMethod
	public ChannelData getLoggedUserInfo(String loggedUser) {
		logger.info("Inside getLogged user name");
		ChannelData result = this.serviceNowPersistence.getLoggedUserInfo(loggedUser);
		return result;
	}
	
	@WebMethod
	@Override
	public ChannelData getLoggedUserInfoForCP(String loggedUserSubmitter) {
		logger.info("Inside getLogged user name");
		ChannelData result = this.serviceNowPersistence.getLoggedUserInfoForCP(loggedUserSubmitter);
		return result;
	}
	
	@Override
	@WebMethod
	public List<String> getChannelPartnerName() {
		logger.info("Inside getChannelPartnerName");
		List<String> result = this.serviceNowPersistence.getCPNameByChannelData();
		return result;
	}
	@Override
	@WebMethod
	public List<SerialNoDetails> getSerialNumberForValve(String serialNumberValue,String newvalve) {
		logger.info("Inside getSerialNumberForValve");
		List<SerialNoDetails> result = this.serviceNowPersistence.getSerialNumberForValve(serialNumberValue, newvalve);
		return result;
	}
	@Override
	@WebMethod
	public ChannelData getUserDataFromCP(String channelpartnername) {
		logger.info("Inside getuserdata"+channelpartnername);
		ChannelData result = this.serviceNowPersistence.getUserDataFromChannelPartner(channelpartnername);
		return result;
	}
	
	
	
	/* Sindhura : Service Now Changes : End */
	
	
	//Sindhura : Start :Delete functionality for upgrade module	
	
		@Override
		@WebMethod
		public StatusInfo upgradeprogramdelete(String programupgradeId) {
			logger.info("Inside upgrade delete");
			StatusInfo status = this.upgradeInfoPersistence.upgradeprogramdelete(programupgradeId);
			return status;	
		}
		@Override
		@WebMethod
		public StatusInfo upgradeoptionsdelete(String newupgradeId) {
			logger.info("Inside upgrade options delete");
			StatusInfo status = this.upgradeInfoPersistence.upgradeoptionsdelete(newupgradeId);
			return status;
		}
		@Override
		@WebMethod
		public StatusInfo deletedoptionById(String newupgradeId, String programOptionId) {
			logger.info("Inside upgrade options delete by id");
			StatusInfo status = this.upgradeInfoPersistence.upgradeoptiondeleteById(newupgradeId,programOptionId);
			return status;
		}
		
		//Sindhura : End :Delete functionality for upgrade module
		

		@Override
		@WebMethod
		public List<DocumentDetails> downloadDocument(String serialNumber, List<String> docName) {
			logger.info("docName size :"+ docName.size());
			List<DocumentDetails> result = this.documentPersistence.getDocumentsBySerialNumber(serialNumber,docName);
			return result;
		}
		
		@Override
		@WebMethod
		public List<DocumentDetails> getAllDocDetails(String serialNumber) {
			logger.info("inside getAllDocDetails service");
			List<DocumentDetails> result = this.documentPersistence.getAllDocDetails(serialNumber);
			return result;
		}
		
/*--------------CICS Services-------------------------------*/
		
		@Override
		@WebMethod
	public List<PartMasterData> getPartNumberData(String searchBy, String partNo, Integer startPartIndex,
			Integer endPartIndex) {
                System.out.println("getPartNumberData Service method--------");
		List<PartMasterData> result = this.cicsPersistence.getPartNumberData(searchBy, partNo, startPartIndex,
				endPartIndex);
			return result;
		}
		
		
		@Override
		@WebMethod
	public List<PartMasterData> getSubPartNumberData(String searchBy, String partNo, String subPartNo,
			Integer startPartIndex, Integer endPartIndex) {
                System.out.println("getSubPartNumberData Service method--------");
		List<PartMasterData> result = this.cicsPersistence.getSubPartNumberData(searchBy, partNo, subPartNo,
				startPartIndex, endPartIndex);
			return result;
		}
		
		@Override
		@WebMethod
		public List<PartMasterData1> getPartDataOnClick(String partNo) {
                System.out.println("getPartDataOnClick Service method--------");
			List<PartMasterData1> result = this.cicsPersistence.getPartDataOnClick(partNo);
			return result;
		}
		
		//Sindhura : End :Delete functionality for upgrade module

		@WebMethod
		public List<BomWhereusedData> getWhereusedData(String partNo, Integer startIndex, Integer endIndex) {
                System.out.println("getWhereusedData Service method--------");
			List<BomWhereusedData> result = this.cicsPersistence.getWhereusedData(partNo, startIndex, endIndex);
			return result;
		}
		
		@Override
		@WebMethod
		public List<BomWhereusedData> getBOMData(String partNo, Integer startIndex, Integer endIndex) {
                System.out.println("getBOMData Service method--------");
			List<BomWhereusedData> result = this.cicsPersistence.getBOMData(partNo, startIndex, endIndex);
			return result;
		}
		
		//turbocharger service
		@Override
		@WebMethod
		public List<TurboDropDown> getTurboChargerDropDownValues(){
		    logger.info("inside recip dropDown service ");
			List<TurboChargerDetail> list = this.rCManagementPersistence.getTurboChargerValues();
			Set<String> turboChargerMakeValues = new HashSet<>();
			List<TurboDropDown> dropDownList= new ArrayList<>();
			for(TurboChargerDetail turboCharger :list ){
				turboChargerMakeValues.add(turboCharger.getTurbochargerMake());
				}
			logger.info("turboChargerMake list size :"+turboChargerMakeValues.size());
			logger.info("modal list size :"+list.size());
			for(String make : turboChargerMakeValues){
				logger.info("make :"+make);
				List<String> modals = new ArrayList<>();
				for(TurboChargerDetail turboCharger : list){
					if(turboCharger.getTurbochargerMake().equals(make)){
						modals.add(turboCharger.getTurbochargerModel());
					}
				}
				TurboDropDown dropDownValues= new TurboDropDown();
				dropDownValues.setTurbochargerMake(make);
				dropDownValues.setTurbochargerModal(modals);
				dropDownList.add(dropDownValues);
			}
			return dropDownList;
			
		}
		
		//added by sujeet


		@Override
		@WebMethod
		public List<PlantDataManagmentMaster> getPlantDataMaster(String customerId,String sso){
			List<ChannelData> channelData = channelDataPersistence.channelDataBySso(sso);
		List<PlantDataManagmentMaster> plantDataMaster = this.customerLinkMasterPersistence
				.getPlantDataMaster(customerId, sso, channelData);
			if (plantDataMaster != null && plantDataMaster.size() > 0) {
				return plantDataMaster;
			}
			return null;
		}

		@Override
		@WebMethod
		public List<CustomerDataManagmentMaster> getCustomerDataMaster(String sso){
			
			List<ChannelData> channelData = channelDataPersistence.channelDataBySso(sso);
		List<CustomerDataManagmentMaster> customerDataManagmentMaster = this.customerLinkMasterPersistence
				.getCustomerDataMaster(sso, channelData);
			
			if (customerDataManagmentMaster != null && customerDataManagmentMaster.size() > 0) {
				return customerDataManagmentMaster;
			}
			return null;
			
		}
		
		@Override
		@WebMethod
		public StatusInfo saveCustomerDataMaster(String sso,CustomerDataManagmentMaster customerDataManagmentMaster){
			logger.info("Before calling impl saveCustomerDataMaster()");
			return this.customerLinkMasterPersistence.saveCustomerDataMaster(sso,customerDataManagmentMaster);	

		}
		
		@Override
		@WebMethod
		public StatusInfo savePlantDataMaster(String sso,PlantDataManagmentMaster plantDataManagmentMaster){
			logger.info("Inside the impl savePlantDataMaster()");
			return this.customerLinkMasterPersistence.savePlantDataMaster(sso,plantDataManagmentMaster);	

		}
		
		@Override
		@WebMethod
		public StatusInfo editplantdatamaster(String sso,PlantDataManagmentMaster plantDataManagmentMaster){
			logger.info("Inside the impl editplantdatamaster()");
			return this.customerLinkMasterPersistence.editPlantDataMaster(sso,plantDataManagmentMaster);	

		}
		
		@Override
		@WebMethod
		public StatusInfo saveUsersDataMaster(String sso,UsersDataManagmentMaster usersDataManagmentMaster){
			logger.info("Inside the impl saveUsersDataMaster()"+usersDataManagmentMaster.getCreatedDate());
			return this.customerLinkMasterPersistence.saveUsersDataMaster(sso,usersDataManagmentMaster);	

		}
		
		@Override
		@WebMethod
		public StatusInfo editUsersDataMaster(String sso,UsersDataManagmentMaster usersDataManagmentMaster){
			logger.info("Inside the impl editUsersDataMaster()");
			return this.customerLinkMasterPersistence.editUsersDataMaster(sso,usersDataManagmentMaster);	

		}
		
		@Override
		@WebMethod
		public List<UsersDataManagmentMaster> getUsersDataMaster(String customerId){
		List<UsersDataManagmentMaster> usersDataManagmentMaster = this.customerLinkMasterPersistence
				.getUsersDataMaster(customerId);
			if (usersDataManagmentMaster != null && usersDataManagmentMaster.size() > 0) {
				return usersDataManagmentMaster;
			}
			return null;
		}
		
		@Override
		@WebMethod
		public List<OrderEquipment> getCustomerDataManagement(String customerId){
			List<OrderEquipment> orderEquipment=this.equipmentPersistence.getCustomerDataManagement(customerId);
			if (orderEquipment != null && orderEquipment.size() > 0) {
				return orderEquipment;
			}
			return null;
		}
		
		@Override
		@WebMethod
		public List<OrderEquipment> getCustomerForSerial(){
			List<OrderEquipment> orderEquipment=this.equipmentPersistence.getCustomerForSerial();
			if (orderEquipment != null && orderEquipment.size() > 0) {
				return orderEquipment;
			}
			return null;
		}
		
		@Override
		public List<UpgradeInfoNew> getUpgradeNewInfo() {
			logger.error("Inside getUpgradeInfo step 1");
			List<UpgradeInfoNew> result = this.upgradeInfoPersistence.getUpgradeDetailsDataNew();
			return result;
		}
		
		@Override
		@WebMethod
		public StatusInfo deleteUpgradeInfoByID(UpgradeInfoNewDTO upgradeInfoNewDTO){
			logger.info("INSIDE THE deleteUpgradeInfoByID()");
			StatusInfo result=this.upgradeInfoPersistence.deleteUpgradeInfoByID(upgradeInfoNewDTO);
		return result;
		}
		
		@Override
		@WebMethod
		public StatusInfo getUpgradeNewInfoPartFileUpload(@RequestBody HashMap getData){
			logger.info("INSIDE THE getUpgradeNewInfoPartFileUpload()");
			StatusInfo getUploadStatus = this.upgradeInfoPersistence.getUpgradeNewInfoPartFileUpload(getData);
			return getUploadStatus;
		}

		//end by sujeets
		
			// Added By @ashish
			
			
			@Override
			@WebMethod
			public List<PlantDataMaster> getplantMaster(String customerId) {
				List<PlantDataMaster> result = this.PlantDataMasterPersistence.getplantMaster(customerId);
				return result;
			}
			
			@Override
			@WebMethod
			public StatusInfo deleteplantMaster(String sso, String customerId){
				StatusInfo result=this.PlantDataMasterPersistence.deleteplantMaster(sso, customerId);
			return result;
			}
			
			@Override
			@WebMethod
			public List<CustomerMgmtMaster> getcustomermgmt() {
				List<CustomerMgmtMaster> result = this.CustomermgmtMasterPersistence.getcustomermgmt();
				return result;
			}
			
			@Override
			@WebMethod
			public List<CartData> getcartData() {
				List<CartData> result = this.cardDataPersistence.getcartData();
				return result;
			}
			//added by Ashish for linking customerby serial
			@Override
			public StatusInfo addLinkingdata(String sso,LinkingMasterTO linkingMasterTO) {
				StatusInfo statusinfo=this.customerLinkMasterPersistence.addLinkingdata(sso,linkingMasterTO);
				return statusinfo;
			}

		
			@Override
			@WebMethod
			public StatusInfo deleteCartData(String serialNumber){
				StatusInfo result=this.cardDataPersistence.deleteCartData(serialNumber);

			return result;
			}
			
			
	        @Override
	        public List<Region_Data> getRegionCoutryStatesDetails() {
	               logger.error("inside the getRegionCoutryStatesDetails");
	               List<Region_Data> result = this.CustomermgmtMasterPersistence.getRegionCoutryStatesDetails();
	               return result;
	               
	        }
	        
	       
			
	        @Override
			@WebMethod
			public StatusInfo documentFileUpload(@RequestBody InputStream file,@Context HttpHeaders httpHeaders) {
				System.out.println("inside the digital upload");
				StatusInfo getUploadStatus = this.documentPersistence.documentFileUpload(file,httpHeaders);
				return getUploadStatus;
			}
			
			@Override
	public StatusInfo saveFileForDataBook(String serialNumber, String docType, String DocumentDescription, String FileName,
					String FileLINK, String language) {
				
				
				logger.error("inside the save file path");
		StatusInfo info = this.documentPersistence.saveFileForDataBook(serialNumber, docType, DocumentDescription, FileName,
				FileLINK, language);
				return info;
			}
			
			@Override
	public StatusInfo saveFileForOthers(String serialNumber, String docType, String DocumentDescription, String FileName,
					String FileLINK, String language) {
				logger.error("inside the save file path");
		StatusInfo info = this.documentPersistence.saveFileForOthers(serialNumber, docType, DocumentDescription, FileName,
				FileLINK, language);
				return info;
			}
			
			@Override
			@WebMethod
			public List<OtherDocumentDetails> getAllDocDownloadDetails(String serialNumber) {
				logger.info("inside getAllDocDetails service");
				List<OtherDocumentDetails> result = this.documentPersistence.getAllDocDownloadDetails(serialNumber);
				return result;
			}
			
		
			@Override
			@WebMethod
	public List<OtherDocumentDetails> OtherMultipleDocumentsDownload(String serialNumber, List<String> docName,
			String docType) {
				logger.info("inside getAllDocDetails service");
		List<OtherDocumentDetails> result = this.documentPersistence.getAllOtherDocDetails(serialNumber, docName,
				docType);
				return result;
			}
			

		
			@Override
			@WebMethod
			public String getCustLinkData(SalesSerial salesSerial) {
				logger.info("inside the getInfoByOrderNumber");
				ObjectMapper mapper=new ObjectMapper();
				mapper.setSerializationInclusion(Inclusion.NON_NULL);
				try {
					return mapper.writeValueAsString(this.orderPersistence.getCustLinkData(salesSerial));
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				
			}

			return null;

		}
			
        /*Channel partner upgrades landing Page*/
			
			@Override
			public List<CPUpgradeInfo> getCpUpgradesList(String sso,String region,CPUpgradeInfo cpUpgradeInfo) {
				logger.info("Inside getCPUpgradeList ");
				List<CPUpgradeInfo> result = this.upgradeInfoPersistence.getCpUpgradesListData(sso,region,cpUpgradeInfo);
				return result;
			}	


		
		
			 @Override
				@WebMethod
				public StatusInfo uploadUpgradeDocument(@RequestBody InputStream file,@Context HttpHeaders httpHeaders) {
					System.out.println("inside the digital upload");
					StatusInfo getUploadStatus = this.documentPersistence.documentFileUpload(file,httpHeaders);
					return getUploadStatus;
				}
			
			 @Override
				public StatusInfo saveUpgradeFile(String upgradeId,String optionId, String docContentType, String docType,
			String DocName, String fileLINK, String language, String sso) {
					
					logger.error("inside the save file path");
		StatusInfo info = this.documentPersistence.saveUpgradeFile(upgradeId, optionId, docContentType, docType,
				DocName, fileLINK, language, sso);
					return info;
				}
			 
			 //Raj Changes for Get Details 
				@Override
				@WebMethod
				public List<UpgradeInfo> getUpgradeNewInfo(String upgradeId) {
					List<UpgradeInfo> upgradeInfo = this.upgradeInfoPersistence.getUpgradeNewInfo(upgradeId);
					return upgradeInfo;
				}
			
				@Override
				public StatusInfo saveUpgradeNewInfo(String sso,UpgradeInfo upgradeInfo) {
					logger.info("Inside Save Upgrade Info");
					StatusInfo status = this.upgradeInfoPersistence.saveUpgradeNewDetails(sso,upgradeInfo);
					return status;
				}
				
				@Override
				public StatusInfo deleteUpgradePackageDocument(String documentID) {
					logger.info("Inside deleteUpgradePackageDocument");
					StatusInfo status = this.upgradeInfoPersistence.deleteUpgradePackageDocument(documentID);
					return status;
				}
				
				
	@Override
	@WebMethod
	public StatusInfo valvekeepXMLDataSync(@RequestBody List<String[]> xmlData) {
		StatusInfo status = new StatusInfo();
		try {
			status = this.valveKeepSTGPersistance.valveKeepXMLDataSync(xmlData);
			status.setStatusCode(Constants.SUCCESS_STATUS_CODE);
			status.setStatusMessage("Scheduler successful.");
			logger.info("Valvekeep scheduler is successful. ");
		} catch (Exception ex) {
			status.setStatusCode(Constants.FAIL_STATUS_CODE);
			status.setStatusMessage("Exception in Scheduler valvekeep.");
			logger.error("Exception in Valvekeep XML save Path : " + ex.getMessage());
		}
		return status;
	}

	@Override
	@WebMethod
	public StatusInfo saveFilePathValvekeep(ValvekeepUploadData vkUploadData) {
		StatusInfo info = new StatusInfo();
		try {
			info = this.valveKeepSTGPersistance.saveFilePathValvekeep(vkUploadData);
			info.setStatusCode(Constants.SUCCESS_STATUS_CODE);
			info.setStatusMessage("Valvekeep Upload Successful.");
			logger.info("Valvekeep upload is successfull. ");
		} catch (Exception ex) {
			info.setStatusCode(Constants.FAIL_STATUS_CODE);
			info.setStatusMessage("Exception While uploading the file in valvekeep.");
			logger.error("Exception in Valvekeep XML save Path : " + ex.getMessage());
		}
		return info;
	}

	@Override
	@WebMethod
	public List<ValveKeepPushData> getDocData(List<CartData> cartData) {
		try {
			List<ValveKeepPushData> vkPushData = this.valveKeepSTGPersistance.getDocData(cartData);
			return vkPushData;
		} catch (Exception ex) {
			logger.error("Exception in Valvekeep Push Data from Cart : " + ex.getMessage());
			return null;
		}
	}

	/*
	 * @Override
	 * 
	 * @WebMethod public List<VKOrderDocument> getVkOrderDocumentData(List<CartData>
	 * cartData) { List<VKOrderDocument> vkorderDocumentData = new ArrayList<>();
	 * try { vkorderDocumentData =
	 * this.valveKeepSTGPersistance.getVkOrderDocument(cartData); } catch (Exception
	 * ex) {
	 * logger.error("Exception in Valvekeep Push while fetching Data from Cart : " +
	 * ex.getMessage()); } return vkorderDocumentData; }
*/
	@Override
	@WebMethod
	public List<VKCustOrderInfoSpeqT> getVkCustOrderInfoSpeqT(@RequestBody List<CartData> vkCartdata) {

		List<CartData> uniqueOrderList = removeDuplicateSalesOrders(vkCartdata);
		List<VKCustOrderInfoSpeqT> vkCustOrderInfoSpeqTData = new ArrayList<>();

		try {
			vkCustOrderInfoSpeqTData = this.valveKeepSTGPersistance.getVkCustOrderInfoSpeqT(uniqueOrderList);

		} catch (Exception ex) {
			logger.info("Exception in Valvekeep Push Data from Cart : " + ex.getMessage());
		}
		return vkCustOrderInfoSpeqTData;

	}
	
	private List<CartData> removeDuplicateSalesOrders(List<CartData> vkCartData) {
		List<CartData> result = new ArrayList<>();
		HashSet<String> set = new HashSet<>();

		for (CartData valveKeepCartData : vkCartData) {

			if (!set.contains(valveKeepCartData.getSalesOrder())) {
								result.add(valveKeepCartData);
							set.add(valveKeepCartData.getSalesOrder());
				 	}
		}
		return result;
	}
	
	@Override
	@WebMethod
	public List<CartData> getCartData(@RequestBody Map postData) {
		List<CartData> cartData = new ArrayList<>();
		try {
			cartData = this.valveKeepSTGPersistance.getcartData(postData);

		} catch (Exception ex) {
			logger.error("Exception in Valvekeep Push while Fetching Cart : " + ex.getMessage());
		}
		return cartData;
	}
	
	@Override
	@WebMethod
	public String getSOFromDocName(@RequestBody String documentName) {
		String document = "";
		try {
			document = this.valveKeepSTGPersistance.getDocName(documentName);

		} catch (Exception ex) {
			logger.error("Exception in Valvekeep while Fetching SO for document : " + documentName + " - "
					+ ex.getMessage());
		}
		return document;
	}
	
	@Override
	@WebMethod
	public StatusInfo removeDuplicateSOValveKeep(@RequestBody String orderNumber) {
		StatusInfo info = new StatusInfo();
		try {
			info = this.valveKeepSTGPersistance.removeDuplicateSOValveKeep(orderNumber);
			info.setStatusCode(Constants.SUCCESS_STATUS_CODE);
			info.setStatusMessage("Valvekeep Delete Duplicate SO Successful.");
			logger.info("Valvekeep upload is successfull. ");
		} catch (Exception ex) {
			info.setStatusCode(Constants.FAIL_STATUS_CODE);
			info.setStatusMessage("Exception Valvekeep Delete Duplicate SO.");
			logger.error("Exception in Valvekeep Delete Duplicate SO  : " + ex.getMessage());
		}
		return info;
	}
	
	@Override
	@WebMethod
	public List<OrderInfo> validateSO(String orderNumber) {
		List<OrderInfo> orderInfoList = new ArrayList<>();
		try {
			orderInfoList = this.valveKeepSTGPersistance.validateSO(orderNumber);
		} catch (Exception ex) {
			logger.error("Exception While Validation SO - " + ex.getMessage());
		}
		return orderInfoList;
	}
	
	@Override
	@WebMethod
	public List<EndUserDetail> getEndUserListByTxt(String searchTxt) {
		List<EndUserDetail> result = this.dropDownPersistence.getEndUserListByTxt(searchTxt);
		return result;
	} 
	
	
	
		@Override
		@WebMethod
		public List<ProjectDataMaster> getProjectDataMaster(String customerId,String plantId,String sso){
			//List<ChannelData> channelData = channelDataPersistence.channelDataBySso(sso);
		List<ProjectDataMaster> plantDataMaster = this.customerLinkMasterPersistence.getProjectDataMaster(customerId,
				plantId, sso);
			if (plantDataMaster != null && plantDataMaster.size() > 0) {
				return plantDataMaster;
			}
			return null;
		} 

		@Override
		@WebMethod
		public StatusInfo saveProjectDataMaster(String sso,ProjectDataMaster projectDataMaster){
			logger.info("Inside the impl saveProjectDataMaster()");
			return this.customerLinkMasterPersistence.saveProjectDataMaster(sso,projectDataMaster);	
}
		
		@Override
		@WebMethod
		public List<UpgradeOptions> getUpgradeOptionNewInfo(String optionId) {
			logger.info("Inside Save saveUpgradeOptionInfo");
			List<UpgradeOptions> upgradeOptions = this.upgradeInfoPersistence.getUpgradeOptionNewInfo(optionId);
			return upgradeOptions;
			}
		
		@Override
		@WebMethod
		public List<UpgradeInfoNew> getUpgradeNewInfoById(String upgradeId) {
			List<UpgradeInfoNew> upgradeInfoNew = this.upgradeInfoPersistence.getUpgradeNewInfoById(upgradeId);
			return upgradeInfoNew;
					}
	
		@Override
		@WebMethod
		public List<UpgradeOptions> getUpgradeOptionNewInfoById(String upgradeId) {
			List<UpgradeOptions> upgradeOptionInfo = this.upgradeInfoPersistence.getUpgradeOptionNewInfoById(upgradeId);
				return upgradeOptionInfo;
				}
				
		@Override
		@WebMethod
		public StatusInfo deleteUpgradeOptionsNew(UpgradeOptionListDTO  OptionList) {
			logger.info("Inside deleteUpgradeOptionsNew");
			StatusInfo status = this.upgradeInfoPersistence.deleteUpgradeOptionsNew(OptionList);
					return status;
			}
				
		@Override
		@WebMethod
		public StatusInfo saveUpgradeOptionInfo(String sso,UpgradeOptions upgradeOptions) {
				logger.info("Inside Save saveUpgradeOptionInfo");
					//StatusInfo status=null; 
					StatusInfo status = this.upgradeInfoPersistence.saveUpgradeOptionInfo(sso,upgradeOptions);
					return status;
				}

		@Override
		public List<CountryDTO> getCoutryList() {
               logger.error("inside the getCoutryDetails");
               List<CountryDTO> result = this.CustomermgmtMasterPersistence.getCoutryList();
               return result;
               }
		
		
		
		/*Channel Partner Upgrade Detail Page	*/

		@Override
		public CPUpgradeDetailView getCpUpgradeDetailView(int upgradeId) {
			logger.info("Inside getCpUpgradeDetailView ");
			CPUpgradeDetailView result = this.upgradeInfoPersistence.getCpUpgradeDetailViewData(upgradeId);
		     return result;
		}
	
		//end
		
		@Override
		public CPUpgradeDetailSMIView getCpUpgradeSMIViewData(int upgradeId) {
			logger.info("Inside getCpUpgradeSMIViewData ");
			CPUpgradeDetailSMIView result = this.upgradeInfoPersistence.getCpUpgradeSMIViewData(upgradeId);
			return result;
		}
		
	      /*CP - Add To Promotional Cart	*/
		
		@Override
	public StatusInfo addToPromotionalCartCP(String sso, String promotionalCartLevel, CPPromotionalCart data) {
			logger.info("Inside addToPromotionalCartCP Service");
			StatusInfo result = this.equipmentPersistence.addToPromotionalCartCP(sso,promotionalCartLevel,data);
			return result;
		}
		
		
		/*CP SMI - Add To Promotional Cart	*/
		
		@Override
		public StatusInfo addToPromotionalCartSMI(String sso, CPPromotionalCart data) {
			logger.info(" Add to promotional Cart service - SMI View");
			StatusInfo result = this.equipmentPersistence.addToPromotionalCartSMI(sso,data);
			return result;
			
		}
		@Override
		public CPUpgradeDocument getUpgradeDocumentDetails(int documentId) {
			logger.info(" Get Upgrade Document Details Method");
			CPUpgradeDocument result = this.upgradeInfoPersistence.getUpgradeDocumentDetails(documentId);
			return result;
		}

	@Override
	public List<DocumentDetails> getDocument(@PathParam("sourceSystem") String sourceSystem,
			@PathParam("docType") String docType, @PathParam("updatedDate") String updatedDate) {
		List<DocumentDetails> result = this.documentPersistence.getDocuments(sourceSystem, docType, updatedDate);
		return result;
	}
	
	@Override
	@WebMethod
	public List<EndUserDetail> getEndUserList(String searchTxt) {
		List<EndUserDetail> result = this.dropDownPersistence.getEndUserList(searchTxt);
		return result;
	}
	
	@Override
	@WebMethod
	public int getFileImageDataCount(String serialNumber) {
		return this.partsComponentDetailsPersistence.getFileImageDataCount(serialNumber);
	}
}