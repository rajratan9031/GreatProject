package com.ge.fpt.welcomepkg.api;

import java.util.List;

public class TurboDropDown {
    private String turbochargerMake;
    private List<String> turbochargerModal;
	/**
	 * @return the turbochargerMake
	 */
	public String getTurbochargerMake() {
		return turbochargerMake;
	}
	/**
	 * @param turbochargerMake the turbochargerMake to set
	 */
	public void setTurbochargerMake(String turbochargerMake) {
		this.turbochargerMake = turbochargerMake;
	}
	/**
	 * @return the turbochargerModal
	 */
	public List<String> getTurbochargerModal() {
		return turbochargerModal;
	}
	/**
	 * @param turbochargerModal the turbochargerModal to set
	 */
	public void setTurbochargerModal(List<String> turbochargerModal) {
		this.turbochargerModal = turbochargerModal;
	}
    
    
}
