package com.ge.fpt.welcomepkg.persistence;

import java.util.List;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ge.fpt.welcomepkg.api.ChannelData;
import com.ge.fpt.welcomepkg.api.CustomerDataManagmentMaster;
import com.ge.fpt.welcomepkg.api.CustomerLinkMaster;
import com.ge.fpt.welcomepkg.api.CustomerLinkMasterDTO;
import com.ge.fpt.welcomepkg.api.CustomerSqtLinkT;
import com.ge.fpt.welcomepkg.api.LinkingMasterTO;
import com.ge.fpt.welcomepkg.api.CustomerMgmtMaster;
import com.ge.fpt.welcomepkg.api.PlantDataManagmentMaster;
import com.ge.fpt.welcomepkg.api.PlantDataMaster;
import com.ge.fpt.welcomepkg.api.ProjectDataMaster;
import com.ge.fpt.welcomepkg.api.SqtCustomerLink;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.api.UsersDataManagmentMaster;

public interface ICustomerLinkMasterPersistence {
		
		@Transactional(propagation = Propagation.REQUIRED)
		List<PlantDataManagmentMaster> getPlantDataMaster(String customerId,String sso,List<ChannelData> channelData);
		
		@Transactional(propagation = Propagation.REQUIRED)
		List<CustomerDataManagmentMaster> getCustomerDataMaster(String sso,List<ChannelData> channelData);
		
		@Transactional(propagation = Propagation.REQUIRED)
		StatusInfo saveCustomerDataMaster(String sso,CustomerDataManagmentMaster customerDataManagmentMaster);
		
		@Transactional(propagation = Propagation.REQUIRED)
		StatusInfo savePlantDataMaster(String sso,PlantDataManagmentMaster plantDataManagmentMaster);
		
		@Transactional(propagation = Propagation.REQUIRED)
		StatusInfo editPlantDataMaster(String sso,PlantDataManagmentMaster plantDataManagmentMaster);
		
		@Transactional(propagation = Propagation.REQUIRED)
		StatusInfo saveUsersDataMaster(String sso,UsersDataManagmentMaster usersDataManagmentMaster);
		
		@Transactional(propagation = Propagation.REQUIRED)
		StatusInfo editUsersDataMaster(String sso,UsersDataManagmentMaster usersDataManagmentMaster);
		
		@Transactional(propagation = Propagation.REQUIRED)
		List<UsersDataManagmentMaster> getUsersDataMaster(String customerId);
		
	
		@Transactional(propagation=Propagation.REQUIRED)
		 Integer getcountfromcustLinkMasterbySerialNo(String serialNo);
		
		@Transactional(propagation=Propagation.REQUIRED)
		CustomerDataManagmentMaster getCustomerNameById(String custId);
		
		@Transactional(propagation=Propagation.REQUIRED)
		PlantDataManagmentMaster getplantMasterNameById(String plantId);
		
		@Transactional(propagation=Propagation.REQUIRED)
		 Integer getcountfromcustLinkMasterbySalesOrder(String orderNumber);
		
		
		
		
		@Transactional(propagation=Propagation.REQUIRED)
		boolean isPlantActive(String plantLocation);

		@Transactional(propagation = Propagation.REQUIRED)
		List<ProjectDataMaster> getProjectDataMaster(String customerId,String plantId,String sso);

		@Transactional(propagation = Propagation.REQUIRED)
		StatusInfo saveProjectDataMaster(String sso,ProjectDataMaster projectDataMaster);
		
		@Transactional(propagation = Propagation.REQUIRED)
		StatusInfo addLinkingdata(String sso,LinkingMasterTO linkingMasterTO);;
		
		

}
