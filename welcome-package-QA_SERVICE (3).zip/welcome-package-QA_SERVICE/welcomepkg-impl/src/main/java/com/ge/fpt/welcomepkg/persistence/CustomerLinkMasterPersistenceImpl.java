package com.ge.fpt.welcomepkg.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.jxpath.ri.compiler.Constant;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.ge.fpt.welcomepkg.api.ChannelData;
import com.ge.fpt.welcomepkg.api.CustomerDataManagmentMaster;
import com.ge.fpt.welcomepkg.api.CustomerLinkMaster;
import com.ge.fpt.welcomepkg.api.CustomerLinkMasterDTO;
import com.ge.fpt.welcomepkg.api.CustomerSqtLinkT;
import com.ge.fpt.welcomepkg.api.LinkingMasterTO;
import com.ge.fpt.welcomepkg.api.CustomerMgmtMaster;
import com.ge.fpt.welcomepkg.api.PlantDataManagmentMaster;
import com.ge.fpt.welcomepkg.api.PlantDataMaster;
import com.ge.fpt.welcomepkg.api.ProjectDataMaster;
import com.ge.fpt.welcomepkg.api.SqtCustomerLink;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.api.UsersDataManagmentMaster;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;
import com.ge.fpt.welcomepkg.impl.WelcomePkgServiceImpl;
import com.ge.fpt.welcomepkg.persistence.CustomermgmtMasterPersistenceImpl.CustomerSqtLinkTMapper;
import com.ge.fpt.welcomepkg.persistence.PlantDataMasterPersistenceImpl.PlantDataMasterMapper;
import com.ge.fpt.welcomepkg.util.QueryConstants;
import com.ge.fpt.welcomepkg.util.Constants;

public class CustomerLinkMasterPersistenceImpl implements ICustomerLinkMasterPersistence {
	@SuppressWarnings("javadoc")
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory.getLogger(CustomerLinkMasterPersistenceImpl.class);

	static final int SQL_RETURN_RECORD_LIMIT = 10;

	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;

	/**
	 * Data source for the JDBC
	 */
	DataSource dataSource;

	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;

	NamedParameterJdbcTemplate namedParamTemplate;

	/**
	 * @return the dataSource
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}

	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate= new NamedParameterJdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}
	
	private IChannelDataPersistence channelDataPersistence;
	public IChannelDataPersistence getChannelDataPersistence() {
		return channelDataPersistence;
	}

	public void setChannelDataPersistence(IChannelDataPersistence channelDataPersistence) {
		this.channelDataPersistence = channelDataPersistence;
	}

	//added by Ashish
	@Override
	public Integer getcountfromcustLinkMasterbySerialNo(String serialNo) {
	
	try{
		String sql="select count(SERIAL_NUMBER) from FPTODS.CUSTOMER_LINK_MASTER_T where SERIAL_NUMBER=?";
	int count=this.jdbcTemplate.queryForInt(sql, new Object[]{serialNo});
		
		return count;
	
		}
	catch (Exception e){
logger.error("exception in counting serial no",e);
	return null;
}
	
	}
	
	
	
	
	
	
	
	private static final class CustomerLinkMasterMapper implements RowMapper<CustomerLinkMaster> {
		public CustomerLinkMasterMapper() {
		}

		@Override
		public CustomerLinkMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
			CustomerLinkMaster result = new CustomerLinkMaster();
			result.setOrderId(rs.getString("ORDER_ID"));
			result.setOrderNumber(rs.getString("ORDER_NUMBER"));
			result.setOrderLineId(rs.getString("ORDER_LINE_ID"));
			result.setSerialNumber(rs.getString("SERIAL_NUMBER"));
			result.setRecSource(rs.getString("REC_SOURCE"));
			result.setCustomerName(rs.getString("CUSTOMER_NAME"));
			result.setCustId(rs.getString("CUST_ID"));
			result.setLinkCustomerName(rs.getString("LINK_CUSTOMER_NAME"));
			result.setPlantId(rs.getString("PLANT_ID"));
			result.setPlantLocation(rs.getString("PLANT_LOCATION"));
			result.setDunsNumber(rs.getString("DUNS_NUMBER"));
			result.setCreatedBy(rs.getString("CREATED_BY"));
			result.setUpdatedBy(rs.getString("UPDATED_BY"));
			result.setUpdatedDate(rs.getDate("UPDATED_DATE"));
			result.setCreatedDate(rs.getDate("CREATED_DATE"));

			return result;
		}
	}
	
	private static final class PlantDataManagmentMasterMapper implements RowMapper<PlantDataManagmentMaster> {
		public PlantDataManagmentMasterMapper() {
		}

		@Override
		public PlantDataManagmentMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
			PlantDataManagmentMaster result = new PlantDataManagmentMaster();
			int plantId = rs.getInt("PLANT_ID");
			result.setPlantId(null != String.valueOf(plantId) ? String.valueOf(plantId) : "");
			int custId = rs.getInt("CUST_ID");
			result.setCustomerId(null != String.valueOf(custId) ? String.valueOf(custId) : "");
//			result.setCustomerName(rs.getString("CUSTOMER_NAME"));
			result.setPlantLocation(rs.getString("PLANT_LOCATION") != null ? rs.getString("PLANT_LOCATION") : "");
			
			//result.setPlantArea(rs.getString("PLANT_AREA"));
			//result.setPlantAccount(rs.getString("PLANT_ACCOUNT"));
			//result.setPlantUniversal(rs.getString("PLANT_UNVIVERSAL"));
			//result.setContact(rs.getString("CONTACT"));
			result.setContact(rs.getString("CUSTOMER_CONTACT_NAME") != null ? rs.getString("CUSTOMER_CONTACT_NAME") : "");
			result.setMaintaenaceInternal(rs.getString("MAINTAENANCE_INTERNAL") != null ? rs.getString("MAINTAENANCE_INTERNAL") : "");
			result.setCountry(rs.getString("COUNTRY") != null ? rs.getString("COUNTRY") : "");
			//result.setRegion(rs.getString("REGION"));
			result.setIsActive(rs.getString("ACTIVE_INACTIVE") != null ? rs.getString("ACTIVE_INACTIVE") : "");
			result.setDunsNumber(rs.getString("DUNS_NUMBER") != null ? rs.getString("DUNS_NUMBER") : "");
			result.setCreatedDate(rs.getDate("CREATED_DATE"));
			result.setCreatedBy(rs.getString("CREATED_BY") != null ? rs.getString("CREATED_BY") : "");
			result.setUpdatedDate(rs.getDate("UPDATED_DATE"));
			result.setUpdatedBy(rs.getString("UPDATED_BY") != null ? rs.getString("UPDATED_BY") : "");
			result.setPlantName(rs.getString("PLANT_NAME") != null ? rs.getString("PLANT_NAME") : "");
			result.setCustomerEmail(rs.getString("CUSTOMER_EMAIL") != null ? rs.getString("CUSTOMER_EMAIL") : "");
			result.setCity(rs.getString("CITY") != null ? rs.getString("CITY") : "");
			result.setState(rs.getString("STATE") != null ? rs.getString("STATE") : "");
			result.setPostalCode(rs.getString("POSTAL_CODE") != null ? rs.getString("POSTAL_CODE") : "");
			result.setValveLocation(rs.getString("VALVE_LOCATION") != null ? rs.getString("VALVE_LOCATION") : "");
			return result;
		}
	}
	
	private static final class CustomerDataManagmentMasterMapper implements RowMapper<CustomerDataManagmentMaster> {
		public CustomerDataManagmentMasterMapper() {
		}

		@Override
		public CustomerDataManagmentMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
			CustomerDataManagmentMaster result = new CustomerDataManagmentMaster();
			int custId = rs.getInt("CUST_ID");
			result.setCustId(null != String.valueOf(custId) ? String.valueOf(custId) : "");
			result.setCustomerName(rs.getString("CUSTOMER_NAME") != null ? rs.getString("CUSTOMER_NAME") : "");
			result.setIsActive(rs.getString("ACTIVE_INACTIVE") != null ? rs.getString("ACTIVE_INACTIVE") : "");
			result.setDunsNumber(rs.getString("DUNS_NUMBER") != null ? rs.getString("DUNS_NUMBER") : "");
			result.setCreatedDate( rs.getDate("CREATED_DATE"));
			result.setUpdatedDate(rs.getDate("UPDATED_DATE"));
			result.setUpdatedBy(rs.getString("UPDATED_BY") != null ? rs.getString("UPDATED_BY") : "");
			result.setCreatedBy(rs.getString("CREATED_BY") != null ? rs.getString("CREATED_BY") : "");
			result.setEuIndustry(rs.getString("END_USER_INDUSTRY") != null ? rs.getString("END_USER_INDUSTRY") : "");
			result.setEuState(rs.getString("END_USER_STATE") != null ? rs.getString("END_USER_STATE") : "");
			result.setEucountry(rs.getString("END_USER_COUNTRY") != null ? rs.getString("END_USER_COUNTRY") : "");
			result.setEuCity(rs.getString("END_USER_CITY") != null ? rs.getString("END_USER_CITY") : "");
			result.setEuPostalCode(rs.getString("END_USER_POSTAL_CODE") != null ? rs.getString("END_USER_POSTAL_CODE") : "");
		
			return result;
		
		}
	}
	
	private static final class SqtCustomerLinkMapper implements RowMapper<SqtCustomerLink> {
		public SqtCustomerLinkMapper() {
		}

		@Override
		public SqtCustomerLink mapRow(ResultSet rs, int rowNum) throws SQLException {
			SqtCustomerLink result = new SqtCustomerLink();
			result.setOrderId(rs.getLong("ORDER_IDENTIFIER"));
			//result.setOrderNumber(rs.getString("ORDER_NUMBER"));
		//	result.setOrderLineId(rs.getLong("ORDER_LINE_ID"));
			result.setSerialNumber(rs.getString("SERIAL_NUMBER"));
			result.setRecSource(rs.getString("REC_SOURCE"));

			return result;
		}
	}
	
	private static final class UsersDataManagmentMasterMapper implements RowMapper<UsersDataManagmentMaster> {
		public UsersDataManagmentMasterMapper() {
		}

		@Override
		public UsersDataManagmentMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
			UsersDataManagmentMaster result = new UsersDataManagmentMaster();
			int custId = rs.getInt("CUSTOMER_ID");
			result.setCustomerId(null != String.valueOf(custId) ? String.valueOf(custId) : "");

			//Commented Removed Column 
			//result.setCustomerName(rs.getString("CUSTOMER_NAME"));
			result.setPlantId(rs.getString("PLANT_ID"));
			result.setPlantLocation(rs.getString("PLANT_LOCATION"));
			result.setSso(rs.getString("SSO"));
			//result.setRegion(rs.getString("REGION"));
			result.setCreatedBy(rs.getString("CREATED_BY"));
			result.setCreatedDate(rs.getDate("CREATED_DATE"));
			result.setUpdatedBy(rs.getString("UPDATED_BY"));
			result.setUpdatedDate(rs.getDate("UPDATED_DATE"));
			result.setIsActive(rs.getString("ACTIVE_INACTIVE"));
			result.setCountry(rs.getString("COUNTRY"));
			result.setDunsNumber(rs.getString("DUNS_NUMBER"));


			return result;
		}
	}

	
	
	//added by sujeet
		
		
		public List<PlantDataManagmentMaster> getPlantDataMaster(String customerId,String sso,List<ChannelData> channelData){
			try{
				List<PlantDataManagmentMaster> plantDataManagmentMaster=new ArrayList<PlantDataManagmentMaster>();
				boolean isInternal = WelcomePkgServiceImpl.isInternalUser(sso);
				String dunsNumber=null;
				if(!channelData.isEmpty() && channelData.size()>=0){
					dunsNumber=channelData.get(0).getDuns();
				}
				if(isInternal){
					logger.info("customerId is:-"+customerId);
					String sql = "SELECT * FROM FPTODS.PLANT_DATA_MANAGMENT_MASTER WHERE CUST_ID='"+customerId+"'";
					plantDataManagmentMaster=this.jdbcTemplate.query(sql,new PlantDataManagmentMasterMapper());
				}else{
					//String sql = "SELECT * FROM FPTODS.PLANT_DATA_MANAGMENT_MASTER WHERE CUST_ID='"+customerId+"' AND DUNS_NUMBER='"+dunsNumber+"'";
					// PLANT DETAILS WAS NOT SHOWING FOR CP USER IN GLOB SEARCH CASE .. so removing duns logic 
					String sql = "SELECT * FROM FPTODS.PLANT_DATA_MANAGMENT_MASTER WHERE CUST_ID='"+customerId+"'";
					plantDataManagmentMaster=this.jdbcTemplate.query(sql,new PlantDataManagmentMasterMapper());
				}
				return plantDataManagmentMaster;
			}catch(Exception e){
				e.printStackTrace();
				logger.error("Get getPlantDataMaster By CUSTOMER_ID:",e);
			}
			return null;
		}
		
		public List<CustomerDataManagmentMaster> getCustomerDataMaster(String sso,List<ChannelData> channelData){
			try{
				boolean isInternal = WelcomePkgServiceImpl.isInternalUser(sso);
				String dunsNumber=null;
				if(!channelData.isEmpty() && channelData.size()>=0){
					dunsNumber=channelData.get(0).getDuns();
				}
				List<CustomerDataManagmentMaster> customerDataManagmentMaster=new ArrayList<CustomerDataManagmentMaster>();
				if(isInternal) {
					String sql = "SELECT * FROM FPTODS.CUSTOMER_DATA_MANAGMENT_MASTER";
					customerDataManagmentMaster = this.jdbcTemplate.query(sql,new CustomerDataManagmentMasterMapper());
					logger.info("inside getCustomerDataMaster:"+customerDataManagmentMaster.size());	
				}else{
					String sql = "SELECT * FROM FPTODS.CUSTOMER_DATA_MANAGMENT_MASTER WHERE DUNS_NUMBER=?";
					customerDataManagmentMaster = this.jdbcTemplate.query(sql,new Object[]{dunsNumber},new CustomerDataManagmentMasterMapper());
					logger.info("inside getCustomerDataMaster:-"+customerDataManagmentMaster.size());
				}
				return customerDataManagmentMaster;
			}catch(Exception e){
				e.printStackTrace();
				logger.error("Get getCustomerDataMaster:",e);
			}
			return null;
		}
		
		public String getDunsNumnersBySSO(String sso){
			
			boolean isInternal = WelcomePkgServiceImpl.isInternalUser(sso);
				String dunsNumber=null;
			if(!isInternal){
				String upperCaseSSO = sso.toUpperCase();
				logger.info("SSO in upper case:"+upperCaseSSO);
				String sql= "select DUNS_NUMBER from ddsafm.sqt_channel_sso where UPPER(sso_id)=? and ROWNUM <= 1";
				dunsNumber=this.jdbcTemplate.queryForObject(sql, new Object[] { upperCaseSSO}, String.class);	
						
			} 			
			return dunsNumber;		
		}
		
		public boolean checkedCustomerExits(CustomerDataManagmentMaster customerDataManagmentMaster,String dunsNumber) {
			boolean isCustomerExits = false;
			logger.info("Inside checkedCustomerExits()");
			try {	
			String condition =" ";
			if(null!=dunsNumber){
				//if we have dunsNumber then add dunsNumber case in SQL
				condition =" and DUNS_NUMBER='"+dunsNumber+"'";
			}
			
			String sql = "select CUST_ID from FPTODS.CUSTOMER_DATA_MANAGMENT_MASTER "
					+ " where CUSTOMER_NAME=? and END_USER_INDUSTRY=? "
					+ " and END_USER_COUNTRY=? and END_USER_STATE=? "
					+ " and END_USER_CITY=? and END_USER_POSTAL_CODE=? "
					+ condition;
			
			Object[] params = {customerDataManagmentMaster.getCustomerName(),customerDataManagmentMaster.getEuIndustry(),
					customerDataManagmentMaster.getEucountry(),customerDataManagmentMaster.getEuState(),
					customerDataManagmentMaster.getEuCity(),customerDataManagmentMaster.getEuPostalCode()};
			
			//int count=this.jdbcTemplate.queryForInt(sql,params);
			
			List<String> result=jdbcTemplate.queryForList(sql, params, String.class);
		
			if (result.size()>0){
				isCustomerExits=true;
				for (String dbCustId : result ){
					if (dbCustId.equals(customerDataManagmentMaster.getCustId())){
						// allow to update 
						isCustomerExits=false;
						break;
					}
				}
			}				
				
			} catch (EmptyResultDataAccessException ex) { 
				return false;
			} catch (Exception ex) {
				logger.error("checkedCustomerExits error: ", ex);
				return false;
			}
			return isCustomerExits;
		}
		
		public StatusInfo saveCustomerDataMaster(String sso,CustomerDataManagmentMaster customerDataManagmentMaster){
			StatusInfo result=new StatusInfo();
			TransactionDefinition transDef = new DefaultTransactionDefinition();
			TransactionStatus saveCustomerDataMasterTM = txManager.getTransaction(transDef);
			
			// Removing Space 
			customerDataManagmentMaster.setCustomerName(customerDataManagmentMaster.getCustomerName().trim());
			customerDataManagmentMaster.setEuIndustry(customerDataManagmentMaster.getEuIndustry().trim());
			customerDataManagmentMaster.setEucountry(customerDataManagmentMaster.getEucountry().trim());
			customerDataManagmentMaster.setEuState(customerDataManagmentMaster.getEuState().trim());
			customerDataManagmentMaster.setEuCity(customerDataManagmentMaster.getEuCity().trim());
			customerDataManagmentMaster.setEuPostalCode(customerDataManagmentMaster.getEuPostalCode().trim());
			
			
			try {
				//GET DUNS NUMBER FOR CP USER ONLY
				String dunsNumber= getDunsNumnersBySSO(sso);
				
				boolean isCustomerExits =checkedCustomerExits(customerDataManagmentMaster,dunsNumber);
				if(!isCustomerExits){
					
					//Checking CUST_ID to identify Add Case or Update Case. 
					if(null != customerDataManagmentMaster.getCustId()){
						if(customerDataManagmentMaster.getCustId().equals("")){
							//ADD CASE
							
							logger.info("ADD CASE");
							// GET MAX from table to get recent added records
							String sqlMaxCount =QueryConstants.GET_SQ_FOR_CUSTOMER_DATA_TABLE;
							String maxCount = this.jdbcTemplate.queryForObject(sqlMaxCount, String.class);
							
							String sql = QueryConstants.ADD_CUSTOMER_DATA;
							Object[] params = { maxCount,
									customerDataManagmentMaster.getCustomerName(), 
									customerDataManagmentMaster.getIsActive(),dunsNumber,sso,
									customerDataManagmentMaster.getEuIndustry(),customerDataManagmentMaster.getEucountry(),customerDataManagmentMaster.getEuState(),
									customerDataManagmentMaster.getEuCity(),customerDataManagmentMaster.getEuPostalCode()};

							int insertResult =this.jdbcTemplate.update(sql, params);
							
							
							//Returning Inserted CUST_ID in maxCount
							result.setPrimaryKey(maxCount);
							result.setStatusCode(0);
							result.setStatusMessage(Constants.MSG_CUSTOMER_ADD_SUCCESSFUL);
							txManager.commit(saveCustomerDataMasterTM);
							
							
						}else{
							// UPDATE CASE
							logger.info("UPDATE CASE");
							String sql = QueryConstants.UPDATE_CUSTOMER_DATA;
							
							Object[] params = {customerDataManagmentMaster.getCustomerName(), 
									customerDataManagmentMaster.getIsActive(),sso,
									customerDataManagmentMaster.getEuIndustry(),customerDataManagmentMaster.getEucountry(),customerDataManagmentMaster.getEuState(),
									customerDataManagmentMaster.getEuCity(),customerDataManagmentMaster.getEuPostalCode(),
									customerDataManagmentMaster.getCustId()};
							int updateResult =this.jdbcTemplate.update(sql, params);
							
							//UPDATE CUSTOMER NAME IN CUSTOMER LINK MASTER TABLE
							String sqlCustomerLink = QueryConstants.UPDATE_CUSTOMER_NAME_IN_LINK_TABLE;
							this.jdbcTemplate.update(sqlCustomerLink, new Object[]{customerDataManagmentMaster.getCustomerName(),customerDataManagmentMaster.getCustId()});
							
							result.setPrimaryKey(customerDataManagmentMaster.getCustId());
							result.setStatusCode(0);
							result.setStatusMessage(Constants.MSG_CUSTOMER_UPDATE_SUCCESSFUL);
							txManager.commit(saveCustomerDataMasterTM);
						}
						
					}
					
				}else{
					logger.info("Customer already present");
					result.setPrimaryKey(customerDataManagmentMaster.getCustId());
					result.setStatusCode(0);
					result.setStatusMessage(Constants.MSG_CUSTOMER_DUPLICATE);	
					return result;
				}
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				txManager.rollback(saveCustomerDataMasterTM);	
				
			}
				
			return result;
		}
			
		
		public StatusInfo savePlantDataMaster(String sso,PlantDataManagmentMaster plantDataManagmentMaster){
			logger.info("Inside the savePlantDataMaster:-"+plantDataManagmentMaster);
			StatusInfo result=new StatusInfo();
			boolean isInternal = WelcomePkgServiceImpl.isInternalUser(sso);
			boolean isActive =isCustomerActive(plantDataManagmentMaster.getCustomerId().trim());
			//Removing space 
			plantDataManagmentMaster.setCustomerId(plantDataManagmentMaster.getCustomerId().trim());
			plantDataManagmentMaster.setPlantName(plantDataManagmentMaster.getPlantName().trim());
			plantDataManagmentMaster.setDunsNumber(plantDataManagmentMaster.getDunsNumber().trim());
			
			if(isActive){
				if(isInternal){

					boolean isCheckedPlantNameExits =checkedPlantNameExits(plantDataManagmentMaster.getCustomerId().trim(),plantDataManagmentMaster.getPlantName().trim(),plantDataManagmentMaster.getDunsNumber().trim(),plantDataManagmentMaster.getPlantId().trim());
					logger.info("Inside isCheckedPlantLocationExits method to check exist:-"+isCheckedPlantNameExits);

					if(!isCheckedPlantNameExits){
						
						String sql =QueryConstants.CUSTOMER_PLANT_ADD;

						Object[] params = {plantDataManagmentMaster.getCustomerId(),
								plantDataManagmentMaster.getPlantLocation(),
								plantDataManagmentMaster.getContact(),
								plantDataManagmentMaster.getMaintaenaceInternal(),
								
								plantDataManagmentMaster.getCountry(),
								plantDataManagmentMaster.getIsActive(),
								plantDataManagmentMaster.getDunsNumber(),
								sso,
								
								plantDataManagmentMaster.getPlantName(),
								plantDataManagmentMaster.getCustomerEmail(),
								plantDataManagmentMaster.getCity(),
								plantDataManagmentMaster.getState(),
								plantDataManagmentMaster.getPostalCode(),
								plantDataManagmentMaster.getValveLocation()};

						this.jdbcTemplate.update(sql, params);
						result.setStatusCode(0);
						result.setStatusMessage("Plant has been added sucessfully");
						try {
							String sql1 ="select PLANT_ID from ( select a.*, max(PLANT_ID) over () as max_pk from fptods.PLANT_DATA_MANAGMENT_MASTER a) where PLANT_ID = max_pk";
							String result1 = this.jdbcTemplate.queryForObject(sql1, String.class);
							logger.info("For get primary Key:-"+result1);
							result.setPrimaryKey(result1);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}else{
						result.setStatusCode(-1);
						result.setStatusMessage("Plant has been already added by your organization");	
					}

					return result;
				}else{
					logger.info("Inside the savePlantDataMaster FOR CP USERS");

					boolean isCheckedPlantNameExits =checkedPlantNameExits(plantDataManagmentMaster.getCustomerId().trim(),plantDataManagmentMaster.getPlantName().trim(),plantDataManagmentMaster.getDunsNumber().trim(),plantDataManagmentMaster.getPlantId().trim());
					logger.info("Inside isCheckedPlantLocationExitsForCPUsers method to check exist"+isCheckedPlantNameExits);

					if(!isCheckedPlantNameExits){
						
						logger.info("inside isCheckedPlantLocationExitsForCPUsers methode"+isCheckedPlantNameExits);
						String sql = QueryConstants.CUSTOMER_PLANT_ADD;

						Object[] params = {plantDataManagmentMaster.getCustomerId(),
								plantDataManagmentMaster.getPlantLocation(),
								plantDataManagmentMaster.getContact(),
								plantDataManagmentMaster.getMaintaenaceInternal(),
								plantDataManagmentMaster.getCountry(),
								
								plantDataManagmentMaster.getIsActive(),
								plantDataManagmentMaster.getDunsNumber(),
								sso,
								plantDataManagmentMaster.getPlantName(),
								
								plantDataManagmentMaster.getCustomerEmail(),
								plantDataManagmentMaster.getCity(),
								plantDataManagmentMaster.getState(),
								plantDataManagmentMaster.getPostalCode(),
								plantDataManagmentMaster.getValveLocation()};
						try{
							this.jdbcTemplate.update(sql, params);
							result.setStatusCode(0);
							result.setStatusMessage("Plant has been added sucessfully");
						}catch(Exception e){
							e.printStackTrace();
						}
						
						try {
							String sql1 ="select PLANT_ID from ( select a.*, max(PLANT_ID) over () as max_pk from fptods.PLANT_DATA_MANAGMENT_MASTER a) where PLANT_ID = max_pk";
							String result1 = this.jdbcTemplate.queryForObject(sql1, String.class);
							logger.info("For get primary Key:-"+result1);
							result.setPrimaryKey(result1);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}else{
						result.setStatusCode(-1);
						result.setStatusMessage("Plant has been already added by your organization");	
					}

					return result;
				}
			}else{
				result.setStatusCode(-1);
				result.setStatusMessage("Customer is inactive !!!");
				return result;
			}
			
		}
		
		public StatusInfo editPlantDataMaster(String sso,PlantDataManagmentMaster plantDataManagmentMaster){
			logger.info(" inside editPlantDataMaster()");
			StatusInfo result=new StatusInfo();
			boolean isInternal = WelcomePkgServiceImpl.isInternalUser(sso);
			//Removing space 
			plantDataManagmentMaster.setCustomerId(plantDataManagmentMaster.getCustomerId().trim());
			plantDataManagmentMaster.setPlantName(plantDataManagmentMaster.getPlantName().trim());
			plantDataManagmentMaster.setDunsNumber(plantDataManagmentMaster.getDunsNumber().trim());
			
			boolean isCheckedPlantNameExits =checkedPlantNameExits(plantDataManagmentMaster.getCustomerId().trim(),plantDataManagmentMaster.getPlantName().trim(),plantDataManagmentMaster.getDunsNumber().trim(),plantDataManagmentMaster.getPlantId().trim());
			logger.info("Inside isCheckedPlantLocationExits method to check exist:-"+isCheckedPlantNameExits);
			
			if(!isCheckedPlantNameExits){
				if(isInternal){
					String sql = QueryConstants.CUSTOMER_PLANT_EDIT;
					Object[] params = {plantDataManagmentMaster.getPlantLocation(),
							plantDataManagmentMaster.getContact(),
							plantDataManagmentMaster.getMaintaenaceInternal(),
							plantDataManagmentMaster.getCountry(),
							plantDataManagmentMaster.getIsActive(),
							sso,
							plantDataManagmentMaster.getCity(),
							plantDataManagmentMaster.getState(),
							plantDataManagmentMaster.getPostalCode(),
							plantDataManagmentMaster.getPlantName(),
							
							plantDataManagmentMaster.getCustomerEmail(),
							plantDataManagmentMaster.getValveLocation(),
							plantDataManagmentMaster.getPlantId()};
					this.jdbcTemplate.update(sql, params);
					result.setStatusCode(0);
					result.setStatusMessage("Plant has been updated sucessfully");
					return result;			
				} else {
					String sqlForDuns = QueryConstants.CUSTOMER_PLANT_EDIT_FOR_DUNS;
					Object[] paramsForDuns = {plantDataManagmentMaster.getPlantLocation(),
							plantDataManagmentMaster.getContact(),
							plantDataManagmentMaster.getMaintaenaceInternal(),
							plantDataManagmentMaster.getCountry(),
							plantDataManagmentMaster.getIsActive(),
							sso,
							plantDataManagmentMaster.getCity(),
							plantDataManagmentMaster.getState(),
							plantDataManagmentMaster.getPostalCode(),
							plantDataManagmentMaster.getPlantName(),
							
							plantDataManagmentMaster.getCustomerEmail(),
							plantDataManagmentMaster.getValveLocation(),
							plantDataManagmentMaster.getPlantId(),
							plantDataManagmentMaster.getDunsNumber()};
					this.jdbcTemplate.update(sqlForDuns, paramsForDuns);
					result.setStatusCode(0);
					result.setStatusMessage("Plant has been updated sucessfully");
					return result;
				}
			}else{
				result.setStatusCode(-1);
				result.setStatusMessage("Plant has been already added by your organization");	
				return result;
			}
			
		}
		
		public StatusInfo saveUsersDataMaster(String sso,UsersDataManagmentMaster usersDataManagmentMaster){
			logger.info(" inside saveUsersDataMaster()");
			boolean isCustomerActive =isCustomerActive(usersDataManagmentMaster.getCustomerId().trim());
			boolean isPlantActive =isPlantActive(usersDataManagmentMaster.getPlantId().trim());


			StatusInfo result=new StatusInfo();
			String isActive="YES";
			boolean isInternal = WelcomePkgServiceImpl.isInternalUser(sso);
			if(isCustomerActive && isPlantActive){
				if(isInternal){
					logger.info("inside saveUsersDataMaster() FOR GE USERS");
					boolean isCheckedUsersExits =checkedUsersExits(usersDataManagmentMaster.getCustomerId().trim(),usersDataManagmentMaster.getPlantId().trim(),usersDataManagmentMaster.getSso().trim());
					logger.info("Inside isCheckedUsersExits method to check exist"+isCheckedUsersExits);

					if(!isCheckedUsersExits){
						//Need to remove Customer_Name,plant_location
						String sql = "INSERT INTO fptods.USER_DATA_MANAGMENT_MASTER "
								+ "(USER_ID, CUSTOMER_ID,  PLANT_ID,  SSO,  CREATED_BY, CREATED_DATE, UPDATED_BY, UPDATED_DATE, ACTIVE_INACTIVE, COUNTRY, DUNS_NUMBER) "
								+ "VALUES "
								+ "(fptods.USER_INFO_SEQ.nextval,?, ?, ?, ?, sysdate, ?,sysdate,?, ?, ?)";

						Object[] params = {usersDataManagmentMaster.getCustomerId(),usersDataManagmentMaster.getPlantId(),
								usersDataManagmentMaster.getSso(), sso,sso,
								isActive,usersDataManagmentMaster.getCountry(),usersDataManagmentMaster.getDunsNumber()};

						this.jdbcTemplate.update(sql, params);
						result.setStatusCode(0);
						result.setStatusMessage("User has been added sucessfully");
					}else{
						result.setStatusCode(-1);
						result.setStatusMessage("User has already been added for this customer");	
					}
				}else{
					logger.info("inside saveUsersDataMaster() FOR GP USERS");
					boolean isCheckedUsersExitsForCPUsers =checkedUsersExitsForCPUsers(usersDataManagmentMaster.getCustomerId().trim(),usersDataManagmentMaster.getPlantId().trim(),usersDataManagmentMaster.getSso().trim(),usersDataManagmentMaster.getDunsNumber().trim());
					logger.info("Inside isCheckedUsersExits method to check exist"+isCheckedUsersExitsForCPUsers);

					if(!isCheckedUsersExitsForCPUsers){
//Need to remove Customer_Name,plant_location
						String sql = "INSERT INTO fptods.USER_DATA_MANAGMENT_MASTER "
								+ "(USER_ID ,CUSTOMER_ID,  PLANT_ID,  SSO, CREATED_BY, CREATED_DATE, UPDATED_BY, UPDATED_DATE, ACTIVE_INACTIVE, COUNTRY, DUNS_NUMBER) "
								+ "VALUES "
								+ "(fptods.USER_INFO_SEQ.nextval,?, ?, ?,  ?, sysdate, ?,sysdate,?, ?, ?)";

						Object[] params = {usersDataManagmentMaster.getCustomerId(),usersDataManagmentMaster.getPlantId(),
								usersDataManagmentMaster.getSso(), sso,sso,
								isActive,usersDataManagmentMaster.getCountry(),usersDataManagmentMaster.getDunsNumber()};

						this.jdbcTemplate.update(sql, params);
						result.setStatusCode(0);
						result.setStatusMessage("User has been added sucessfully");
					}else{
						result.setStatusCode(-1);
						result.setStatusMessage("User has already been added for this customer");	
					}
				}
			}else{
				result.setStatusCode(-1);
				result.setStatusMessage("Customer or Plant is inactive !!!");
			}
			return result;

		}
		
		public StatusInfo editUsersDataMaster(String sso,UsersDataManagmentMaster usersDataManagmentMaster){
			logger.info("inside editUsersDataMaster()");
			boolean isInternal = WelcomePkgServiceImpl.isInternalUser(sso);
			StatusInfo result=new StatusInfo();
				if(isInternal){
					//Need to remove Customer_Name,plant_location
					logger.info("inside editUsersDataMaster() for GE users ");
					String sql = "update fptods.USER_DATA_MANAGMENT_MASTER "
							+ "SET  PLANT_ID=?, SSO=?, UPDATED_BY=?, UPDATED_DATE=sysdate, ACTIVE_INACTIVE=?, COUNTRY=? WHERE CUSTOMER_ID=? AND PLANT_ID=? AND SSO=?";

					Object[] params = {usersDataManagmentMaster.getPlantId(),
							usersDataManagmentMaster.getSso(),sso,
							usersDataManagmentMaster.getIsActive(),usersDataManagmentMaster.getCountry(),usersDataManagmentMaster.getCustomerId(),
							usersDataManagmentMaster.getOldPlantId(),usersDataManagmentMaster.getOldSSO()};

					this.jdbcTemplate.update(sql, params);
					logger.info("User has been updated sucessfully");
					result.setStatusCode(0);
					result.setStatusMessage("User has been updated sucessfully");
				}else{
					//Need to remove Customer_Name,plant_location
					logger.info(" inside editUsersDataMaster() for CP users ");
					String sql = "update fptods.USER_DATA_MANAGMENT_MASTER "
							+ "SET PLANT_ID=?,  SSO=?,  UPDATED_BY=?, UPDATED_DATE=sysdate, ACTIVE_INACTIVE=?, COUNTRY=? WHERE CUSTOMER_ID=? AND PLANT_ID=? AND SSO=? AND DUNS_NUMBER=?";

					Object[] params = {usersDataManagmentMaster.getPlantId(),
							usersDataManagmentMaster.getSso(),sso,
							usersDataManagmentMaster.getIsActive(),usersDataManagmentMaster.getCountry(),usersDataManagmentMaster.getCustomerId(),
							usersDataManagmentMaster.getOldPlantId(),usersDataManagmentMaster.getOldSSO(),usersDataManagmentMaster.getDunsNumber()};

					this.jdbcTemplate.update(sql, params);
					logger.info("User has been updated sucessfully");
					result.setStatusCode(0);
					result.setStatusMessage("User has been updated sucessfully");
				}
			
			return result;
			
		}
		
		public List<SqtCustomerLink> get_SQT_CUSTOMER_LINK_V(String orderNumber){
			try{
				List<SqtCustomerLink> customerLinkMaster=new ArrayList<SqtCustomerLink>();
				String sql = "SELECT * FROM FPTODS.SQT_CUSTOMER_LINK_V where ORDER_NUMBER= ?";
				customerLinkMaster = this.jdbcTemplate.query(sql,new Object[]{orderNumber},new SqtCustomerLinkMapper());
				return customerLinkMaster;
			}catch(Exception e){
				e.printStackTrace();
				logger.error("Get get_SQT_CUSTOMER_LINK_V:",e);
			}
			return null;
		}
		
		public List<UsersDataManagmentMaster> getUsersDataMaster(String customerId){
			try{
				List<UsersDataManagmentMaster> usersDataManagmentMaster=new ArrayList<UsersDataManagmentMaster>();
				logger.info("customerId is:-"+customerId);
				String sql = "SELECT A.CUSTOMER_ID,A.PLANT_ID,A.SSO,A.CREATED_BY,A.CREATED_DATE,A.UPDATED_BY,A.UPDATED_DATE,A.ACTIVE_INACTIVE,A.COUNTRY,A.DUNS_NUMBER,B.PLANT_LOCATION FROM fptods.USER_DATA_MANAGMENT_MASTER A left outer join fptods.PLANT_DATA_MANAGMENT_MASTER B on A.plant_id = B.PLANT_ID  where CUSTOMER_ID=?";
				usersDataManagmentMaster=this.jdbcTemplate.query(sql, new Object[]{customerId},new UsersDataManagmentMasterMapper());
				
				//List<String> plantDetail=getPlantIdANDPlantName(customerId);
				return usersDataManagmentMaster;
			}catch(Exception e){
				e.printStackTrace();
				logger.error("Get getUsersDataMaster By CUSTOMER_ID:",e);
			}
			return null;
		}
		
		@Override
		public CustomerDataManagmentMaster getCustomerNameById(String custId) {
			String sql= "select * from FPTODS.CUSTOMER_DATA_MANAGMENT_MASTER where CUST_ID='"+custId+"'";
			List<CustomerDataManagmentMaster> customerDataManagmentMaster=this.jdbcTemplate.query(sql,new CustomerDataManagmentMasterMapper());
			logger.info("Inside the getCustomerNameById...");
			return customerDataManagmentMaster.get(0);
		}
		
		List<String> getPlantIdANDPlantName(String customerId){
			try{
				String sql ="";
				List<String> results= new ArrayList<String>();
				logger.info("customerId####"+customerId);
				//sql ="SELECT DISTINCT PLANT_LOCATION FROM FPTODS.USER_DATA_MANAGMENT_MASTER where CUSTOMER_ID='"+customerId+"'";
				sql ="Select DISTINCT PLANT_LOCATION from fptods.PLANT_DATA_MANAGMENT_MASTER where cust_id='"+customerId+"'";
				 
				results = this.jdbcTemplate.queryForList(sql, String.class);
				return results;
			}catch(Exception e){
				e.printStackTrace();
				logger.error("Get getCustomerLinkMaster:",e);
			}
			return null;
			
		}
		
		@Override
		public Integer getcountfromcustLinkMasterbySalesOrder(String orderNumber) {
			try{
				String sql="select count(SERIAL_NUMBER) from FPTODS.CUSTOMER_LINK_MASTER_T where ORDER_NUMBER=?";
				Integer count=this.jdbcTemplate.queryForObject(sql, new Object[]{orderNumber},Integer.class);
				return count;
			}
			catch (Exception e){
				logger.error("exception in counting sales order no",e);
				return null;
			}

		}
		
		@Override
		public PlantDataManagmentMaster getplantMasterNameById(String plantId) {
			List<PlantDataManagmentMaster> result=new ArrayList<PlantDataManagmentMaster>();
			String sql= "select * from FPTODS.PLANT_DATA_MANAGMENT_MASTER where PLANT_LOCATION=? ";
			result=this.jdbcTemplate.query(sql, new Object[] { plantId}, new PlantDataManagmentMasterMapper());
			return result.get(0);

		}
		
				
		
		public boolean isCustomerActive(String custId) {
			boolean customerActive = false;
			String sql = "select count(*) from FPTODS.CUSTOMER_DATA_MANAGMENT_MASTER where CUST_ID=? AND ACTIVE_INACTIVE='YES'";
			int result = this.jdbcTemplate.queryForInt(sql, new Object[] {custId });
			if (result > 0) {
				customerActive = true;
			}
			return customerActive;
		}
		
		public boolean isPlantActive(String pid) {
			boolean plantActive = false;
			//String sql = "select count(*) from FPTODS.PLANT_DATA_MANAGMENT_MASTER where PLANT_LOCATION=? AND ACTIVE_INACTIVE='YES'";
			String sql = "select count(*) from FPTODS.PLANT_DATA_MANAGMENT_MASTER where PLANT_ID=? AND ACTIVE_INACTIVE='YES'";
			int result = this.jdbcTemplate.queryForInt(sql, new Object[] {pid });
			if (result > 0) {
				plantActive = true;
			}
			return plantActive;
		}
		

		
		public boolean checkedPlantNameExits(String custId,String plantName,String dunsNumber,String plantId){
			boolean isCheckedPlantNameExits = false;
			List<String> result =null;
			try {
			if(dunsNumber==null || dunsNumber.isEmpty() || dunsNumber.equalsIgnoreCase("")){
				String sql = "SELECT PLANT_ID FROM FPTODS.PLANT_DATA_MANAGMENT_MASTER where CUST_ID= ? and PLANT_NAME=?";
				
				result = this.jdbcTemplate.queryForList(sql,new Object[] {custId,plantName}, String.class);
	                logger.info("Case 1 Inside checkedPlantLocationExits method()"+result);
				}
				else {
					String sql = "SELECT PLANT_ID FROM FPTODS.PLANT_DATA_MANAGMENT_MASTER where CUST_ID=? and PLANT_NAME= ? AND DUNS_NUMBER=? ";
					result = this.jdbcTemplate.queryForList(sql,new Object[] {custId,plantName,dunsNumber}, String.class);
					 logger.info("Case 2 Inside checkedPlantLocationExits method()"+result);
				}
			logger.info("result"+result);
			
			if (result.size()>0){
				logger.info("Inside Check");
				isCheckedPlantNameExits=true;
				for (String dbPlantID : result ){
					if (dbPlantID.equals(plantId) && !plantId.equals("")){
						// allow to update 
						logger.info("allow to update");
						isCheckedPlantNameExits=false;
						break;
					}
				}
			}
			
			}catch (EmptyResultDataAccessException ex) { 
					return false;
				} catch (Exception ex) {
					logger.error("isCheckedPlantLocationExits error: ", ex);
				}
			return isCheckedPlantNameExits;
			}
		
				
		
/*		public boolean checkedPlantLocationExits(String custId,String plantName) {
			boolean isCheckedPlantLocationExits = false;
			String sql = "SELECT PLANT_LOCATION FROM FPTODS.PLANT_DATA_MANAGMENT_MASTER where CUST_ID= ? AND PLANT_NAME=?";

			try {
				String result = this.jdbcTemplate.queryForObject(sql,new Object[] {custId,plantName}, String.class);
                logger.info("Inside checkedPlantLocationExits method()"+result);
				if (result != null) {
					isCheckedPlantLocationExits = true;
				}
			} catch (EmptyResultDataAccessException ex) { 
				return false;
			} catch (Exception ex) {
				logger.error("isCheckedPlantLocationExits error: ", ex);
			}
			return isCheckedPlantLocationExits;
		}
		
		public boolean checkedPlantLocationExitsForCPUsers(String custId,String plantName,String dunsNumber) {
			boolean isCheckedPlantLocationExitsForCPUsers = false;
			String sql = "SELECT PLANT_LOCATION FROM FPTODS.PLANT_DATA_MANAGMENT_MASTER where CUST_ID=? AND PLANT_NAME=? AND DUNS_NUMBER=?";

			try {
				String result = this.jdbcTemplate.queryForObject(sql,new Object[] {custId,plantName,dunsNumber}, String.class);
                logger.info("Inside checkedPlantLocationExitsForCPUsers method()"+result);
				if (result != null) {
					isCheckedPlantLocationExitsForCPUsers = true;
				}
			} catch (EmptyResultDataAccessException ex) { 
				return false;
			} catch (Exception ex) {
				logger.error("isCheckedPlantLocationExitsForCPUsers error: ", ex);
			}
			return isCheckedPlantLocationExitsForCPUsers;
		}*/
		
		public boolean checkedProjectNameExist(int custId,String projectName) {
			boolean isCheckedProjectNameExist = false;
			
			String sql = "SELECT PROJECT_NAME FROM FPTODS.SQT_CUSTOMER_PROJECT_MASTER_T where CUST_ID=? AND PROJECT_NAME=?";

			try {
				String result = this.jdbcTemplate.queryForObject(sql,new Object[] {custId,projectName}, String.class);
                logger.info("Inside checkedProjectNameExist method()"+result);
				if (result != null) {
					isCheckedProjectNameExist = true;
				}
			} catch (EmptyResultDataAccessException ex) { 
				return false;
			} catch (Exception ex) {
				logger.error("isCheckedProjectNameExist error: ", ex);
			}
			return isCheckedProjectNameExist;
		}
		
		
		public boolean checkedUsersExits(String custId,String plantId,String sso) {
			boolean isCheckedUsersExits = false;
			String sql = "SELECT count(*) FROM FPTODS.USER_DATA_MANAGMENT_MASTER where CUSTOMER_ID=? AND PLANT_ID=? AND SSO=?";

			try {
				int result = this.jdbcTemplate.queryForInt(sql, new Object[] {custId,plantId,sso });
				if (result > 0) {
					isCheckedUsersExits = true;
				}
			} catch (EmptyResultDataAccessException ex) { 
				return false;
			} catch (Exception ex) {
				logger.error("checkedUsersExits error: ", ex);
			}
			return isCheckedUsersExits;
		}
		
		public boolean checkedUsersExitsForCPUsers(String custId,String plantId,String sso,String dunsNumber) {
			boolean isCheckedUsersExitsForCPUsers = false;
			String sql = "SELECT count(*) FROM FPTODS.USER_DATA_MANAGMENT_MASTER where CUSTOMER_ID=? AND PLANT_ID=? AND SSO=? AND DUNS_NUMBER=?";

			try {
				int result = this.jdbcTemplate.queryForInt(sql, new Object[] {custId,plantId,sso,dunsNumber});
				if (result > 0) {
					isCheckedUsersExitsForCPUsers = true;
				}
			} catch (EmptyResultDataAccessException ex) { 
				return false;
			} catch (Exception ex) {
				logger.error("isCheckedPlantLocationExitsForCPUsers error: ", ex);
			}
			return isCheckedUsersExitsForCPUsers;
		}
		//end by sujeet

		
		
		public List<ProjectDataMaster> getProjectDataMaster(String customerId,String plantId,String sso){
			logger.info("Inside the getProjectDataMaster:-"+customerId+" Plant "+plantId);
			List<ProjectDataMaster> projectDataManagmentMaster=new ArrayList<ProjectDataMaster>();
			
			try{		
				String sql = QueryConstants.GET_PROJECT_DATA;
				
				
					//For Plant ID we append condition in where clause 
					if(!plantId.equals("0")){
						String	condition=" AND PLANT_ID= ? ";
						sql=sql + condition;
						projectDataManagmentMaster=this.jdbcTemplate.query(sql,new Object[] {customerId,plantId}, new ProjectDataMapper());
						
					}else{
						projectDataManagmentMaster=this.jdbcTemplate.query(sql,new Object[] {customerId}, new ProjectDataMapper());
					}
					
					return projectDataManagmentMaster;	
			}catch(Exception e){
				e.printStackTrace();
				logger.error("Get getProjectDataMaster By CUSTOMER_ID:",e);
			}
			return projectDataManagmentMaster;	
			
		}
		
		private static final class ProjectDataMapper implements RowMapper<ProjectDataMaster> {
			public ProjectDataMapper() {
			}

			@Override
			public ProjectDataMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				ProjectDataMaster result = new ProjectDataMaster();
				result.setPlantId(rs.getInt("PLANT_ID"));
				result.setCustId(rs.getInt("CUST_ID"));
				result.setProjectId(rs.getInt("PROJECT_ID"));
				result.setProjectName(rs.getString("PROJECT_NAME") != null ? rs.getString("PROJECT_NAME") : "");
				result.setPlantLocation(rs.getBoolean("IS_PLANT_LOCATION"));
				//result.setSerialNumber(rs.getString("SERIAL_NUMBER") != null ? rs.getString("SERIAL_NUMBER") : "");
				//result.setRecSource(rs.getString("REC_SOURCE") != null ? rs.getString("REC_SOURCE") : "");
				result.setCountry(rs.getString("COUNTRY") != null ? rs.getString("COUNTRY") : "");
				result.setCity(rs.getString("CITY") != null ? rs.getString("CITY") : "");
				result.setState(rs.getString("STATE") != null ? rs.getString("STATE") : "");
				result.setPostalCode(rs.getString("POSTAL_CODE") != null ? rs.getString("POSTAL_CODE") : "");
				result.setProjectLocation(rs.getString("PROJECT_LOCATION") != null ? rs.getString("PROJECT_LOCATION") : "");
				
				
				return result;
			}
		}

		
		
		public StatusInfo saveProjectDataMaster(String sso,ProjectDataMaster projectDataMaster){
			logger.info("Inside the saveProjectDataMaster:-"+projectDataMaster);
			StatusInfo result=new StatusInfo();
			// Removing space 
			projectDataMaster.setProjectName(projectDataMaster.getProjectName().trim());
			
			
			Calendar currenttime = Calendar.getInstance();
			Date sqldate = new Date((currenttime.getTime()).getTime()); 
			
				
			try {
				Integer plantId=null; // SET plantId null while its 0 to avoid FK violation
				if(projectDataMaster.getPlantId()!=0){
					plantId=projectDataMaster.getPlantId();
				}
				logger.info(" before isCheckedProjectNameExist:-"+plantId);
				boolean isCheckedProjectNameExist =checkedProjectNameExist(projectDataMaster.getCustId(),projectDataMaster.getProjectName());
				// Insert Project Info
				logger.info(" after isCheckedProjectNameExist:-"+isCheckedProjectNameExist);
				if (!isCheckedProjectNameExist){
					if(projectDataMaster.isPlantLocation()== false){
						plantId=null;
					}
					String sqlInsert = QueryConstants.SAVE_PROJECT;
					
					Object[] params = {plantId,projectDataMaster.getCustId(),projectDataMaster.getProjectName(),
							projectDataMaster.isPlantLocation(),projectDataMaster.getCountry(),projectDataMaster.getCity(),projectDataMaster.getState(),
							projectDataMaster.getPostalCode(),projectDataMaster.getProjectLocation(),sso,sqldate};
					this.jdbcTemplate.update(sqlInsert, params);
					result.setStatusCode(0);
					result.setStatusMessage("Proeject has been added sucessfully");
				}else{
					result.setStatusCode(-1);
					result.setStatusMessage("Project name is already added for this customer");
				}

				
			} catch (Exception e) {
				result.setStatusCode(500);
				result.setStatusMessage("Issue in saving data");
				logger.error("Exception in Project Info" + e.getLocalizedMessage());
				
			}
			
			return result;
		}
		
		public StatusInfo addLinkingdata(String sso,LinkingMasterTO linkingMasterTO) {
			StatusInfo statusinfo= new StatusInfo();
			
			//Handling Null value
			if(linkingMasterTO.getIsActivePlant()==null || linkingMasterTO.getIsActivePlant().equals("")){
				linkingMasterTO.setIsActivePlant("NO");
			}
			
		
			
			//To check Customer is Active
			if(!linkingMasterTO.getIsActiveCust().equalsIgnoreCase("YES")){
				statusinfo.setStatusCode(-1);
				statusinfo.setStatusMessage("Customer is inactive !!!");
				return statusinfo;
			}
			// To check plant is Active
			if(!linkingMasterTO.getIsActivePlant().equalsIgnoreCase("YES") && linkingMasterTO.getPlantId()!=0){
				statusinfo.setStatusCode(-1);
				statusinfo.setStatusMessage("Plant is inactive !!!");
				return statusinfo;
			}
			Calendar currenttime = Calendar.getInstance();
			Date sqldate = new Date((currenttime.getTime()).getTime()); 

			try{
				if(!linkingMasterTO.getSerialNumber().isEmpty() && linkingMasterTO.getSerialNumber().size()>=0){
					for (String serialNo : linkingMasterTO.getSerialNumber()) {
						int count=getcountfromcustLinkMasterbySerialNo(serialNo);
						// Make plantId to null when its 0 
						Integer plantIdInt= linkingMasterTO.getPlantId()==0? null:linkingMasterTO.getPlantId(); 
						// Make ProjectId to null when its 0 
						Integer projectIdInt= linkingMasterTO.getProjectId()==0? null:linkingMasterTO.getProjectId(); 
						
						if(count>0){
							//UPDATE LINKING CASE
							String sql=QueryConstants.UPDATE_CUST_LINKING;	
							Object[] params ={linkingMasterTO.getOrderId(),linkingMasterTO.getCustomerId(),linkingMasterTO.getCustomerName(),plantIdInt,linkingMasterTO.getDunsNumber(),sso,projectIdInt,serialNo};
							this.jdbcTemplate.update(sql, params);
							statusinfo.setStatusCode(1);
							statusinfo.setStatusMessage("Customer has been linked successfully to the selected serial number/s");
						}else{
							//ADD LINKING CASE  
							String sql =QueryConstants.ADD_CUST_LINKING;

							Object[] params ={linkingMasterTO.getOrderId(),linkingMasterTO.getOrderNumber(),
									serialNo,linkingMasterTO.getRecSource(),
									linkingMasterTO.getCustomerId(),linkingMasterTO.getCustomerName(),plantIdInt,
									linkingMasterTO.getDunsNumber(),sso,sqldate,projectIdInt,sso,sqldate};
							this.jdbcTemplate.update(sql, params);
							statusinfo.setStatusCode(1);
							statusinfo.setStatusMessage("Customer has been linked successfully to the selected serial number/s");
						}
						
					}
					
				}else{
					statusinfo.setStatusCode(-1);
					statusinfo.setStatusMessage("Sales order's isn't empty !!!");
					return statusinfo;
				}
				
			}
			catch(Exception e){
				statusinfo.setStatusCode(-1);
				statusinfo.setStatusMessage("exception occured while linking data");	
				logger.error("exception occured while linking data",e);
			}
			return statusinfo;
		}

		

		
}
