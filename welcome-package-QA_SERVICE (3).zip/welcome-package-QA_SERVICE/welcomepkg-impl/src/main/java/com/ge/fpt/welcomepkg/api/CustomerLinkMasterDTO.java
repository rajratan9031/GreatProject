package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.List;


public class CustomerLinkMasterDTO implements Serializable {
	private static final long serialVersionUID =1L;


	private List<String> orderNumber;
	private String custId;
	private String customerName;
	private String plantId;
	private String plantLocation;
	private String dunsNumber;

	public CustomerLinkMasterDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public CustomerLinkMasterDTO(List<String> orderNumber, String custId, String customerName, String plantId,
			String plantLocation, String dunsNumber) {
		super();
		this.orderNumber = orderNumber;
		this.custId = custId;
		this.customerName = customerName;
		this.plantId = plantId;
		this.plantLocation = plantLocation;
		this.dunsNumber = dunsNumber;
	}


	public List<String> getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(List<String> orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getPlantId() {
		return plantId;
	}

	public void setPlantId(String plantId) {
		this.plantId = plantId;
	}

	public String getPlantLocation() {
		return plantLocation;
	}

	public void setPlantLocation(String plantLocation) {
		this.plantLocation = plantLocation;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getDunsNumber() {
		return dunsNumber;
	}

	public void setDunsNumber(String dunsNumber) {
		this.dunsNumber = dunsNumber;
	}




	
	
	
	
}
