package com.ge.fpt.welcomepkg.persistence;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.fpt.welcomepkg.api.PlantData;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;

public class PlantDataPersistenceImpl implements IPlantDataPersistence{


	@SuppressWarnings("javadoc")
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory.getLogger(PlantDataPersistenceImpl.class);

	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;

	/**
	 * Data source for the JDBC
	 */
	DataSource dataSource;

	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;

	NamedParameterJdbcTemplate namedParamTemplate;

	/**
	 * @return the dataSource
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}

	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate = new NamedParameterJdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	public String getFilterClause(PlantData plantData){
		String filter="";
		List<String> conditions = new ArrayList<String>();
		if(plantData!=null){
			if(plantData.getPlantId()!=null && !plantData.getPlantId().isEmpty()){
				conditions.add(" UPPER(PLANT_ID) LIKE '%' || :plantId || '%'");
			}
			if(plantData.getPlantName()!=null && !plantData.getPlantName().isEmpty()){
				conditions.add(" UPPER(PLANT_NAME) LIKE '%' || :plantName || '%'");
			}
			if(plantData.getPlantLocation()!=null && !plantData.getPlantLocation().isEmpty()){
				conditions.add(" UPPER(PLANT_LOCATION) LIKE '%' || :plantLocation || '%'");
			}
			if(plantData.getRegion()!=null && !plantData.getRegion().isEmpty()){
				conditions.add(" UPPER(PLANT_REGION) LIKE '%' || :region || '%'");
			}
			if(plantData.getState()!=null && !plantData.getState().isEmpty()){
				conditions.add(" UPPER(PLANT_STATE) LIKE '%' || :state || '%'");
			}
			if(plantData.getCountry()!=null && !plantData.getCountry().isEmpty()){
				conditions.add(" UPPER(PLANT_COUNTRY) LIKE '%' || :country || '%'");
			}
			if(plantData.getPlantPhone()!=null && !plantData.getPlantPhone().isEmpty()){
				conditions.add(" UPPER(PI_PHONE) LIKE '%' || :plantPhone || '%'");
			}
			if(plantData.getPlantEmail()!=null && !plantData.getPlantEmail().isEmpty()){
				conditions.add(" UPPER(PI_EMAIL) LIKE '%' || :plantEmail || '%'");
			}
			if(plantData.getPlantPrevOutageDate()!=null && !plantData.getPlantPrevOutageDate().isEmpty()){
				conditions.add(" UPPER(PREVIOUS_OUTAGE_DATE) LIKE '%' || :plantPrevOutageDate || '%'");
			}
			if(plantData.getPlantNextOutageDate()!=null && !plantData.getPlantNextOutageDate().isEmpty()){
				conditions.add(" UPPER(NEXT_OUTAGE_DATE) LIKE '%' || :plantNextOutageDate || '%'");
			}
			if(plantData.getcPDunsId()!=null && !plantData.getcPDunsId().isEmpty()){
				conditions.add(" UPPER(DUNS_NUMBER) LIKE '%' || :cPDunsId || '%'");
			}
			if(plantData.getPlantZip()!=null && !plantData.getPlantZip().isEmpty()){
				conditions.add(" UPPER(PI_ZIP) LIKE '%' || :plantZip || '%'");
			}
			if(plantData.getPlantFax()!=null && !plantData.getPlantFax().isEmpty()){
				conditions.add(" UPPER(PI_FAX) LIKE '%' || :plantFax || '%'");
			}
		}
		if (conditions.size() > 0) {
			String condStr = "";

			for (int i = 0; i < conditions.size(); i++) {
				condStr += ( " AND " + conditions.get(i));
			}

			filter = condStr;
		}
		return filter;
	}

	public  Map<String, String> setFilterParams(PlantData plantData){
		Map<String, String> result = new HashMap<String, String>();
		result.put("plantId", plantData.getPlantId() == null ? "" : plantData.getPlantId().toUpperCase());
		result.put("plantName", plantData.getPlantName() == null ? "" : plantData.getPlantName().toUpperCase());
		result.put("plantLocation", plantData.getPlantLocation() == null ? "" : plantData.getPlantLocation().toUpperCase());
		result.put("region", plantData.getRegion() == null ? "" : plantData.getRegion().toUpperCase());
		result.put("state", plantData.getState() == null ? "" : plantData.getState().toUpperCase());
		result.put("country", plantData.getCountry() == null ? "" : plantData.getCountry().toUpperCase());
		result.put("plantPhone", plantData.getPlantPhone() == null ? "" : plantData.getPlantPhone().toUpperCase());
		result.put("plantEmail", plantData.getPlantEmail() == null ? "" : plantData.getPlantEmail().toUpperCase());
		result.put("plantPrevOutageDate", plantData.getPlantPrevOutageDate() == null ? "" : plantData.getPlantPrevOutageDate().toUpperCase());
		result.put("plantNextOutageDate", plantData.getPlantNextOutageDate() == null ? "" : plantData.getPlantNextOutageDate().toUpperCase());
		result.put("cPDunsId", plantData.getcPDunsId() == null ? "" : plantData.getcPDunsId().toUpperCase());
		result.put("plantZip",plantData.getPlantZip() == null ? "" : plantData.getPlantZip().toUpperCase());
		result.put("plantFax",plantData.getPlantFax() == null ? "" : plantData.getPlantFax().toUpperCase());

		return result;
	}

	public  int getPlantDataCount(PlantData plantData){
		if(null==plantData.getcPDunsId() || plantData.getcPDunsId().equals("")){
			return 0;
			}
		String sql="select count(*) from fptods.plant_info a where 1=1";
		MapSqlParameterSource parameters = new MapSqlParameterSource(setFilterParams(plantData));
		if(plantData!=null){
			String filter=getFilterClause(plantData);			
			sql=sql+filter;			
		}
		return this.namedParamTemplate.queryForInt(sql, parameters);
	}
	public List<PlantData> getPlantData(int pageNo,int rowsPerPage,PlantData plantData){
		List<PlantData> result = null;
		try{
			if(null==plantData.getcPDunsId() || ("").equals(plantData.getcPDunsId())){
				return result;
			}
			String sql= "select * from (select rownum as rnum, a.* from fptods.plant_info a where 1=1";
			MapSqlParameterSource parameters = new MapSqlParameterSource(setFilterParams(plantData));

			if(plantData!=null){
				String filter=getFilterClause(plantData);
				sql=sql+filter;		
			}
			sql+=")";
			if (rowsPerPage > 0) {				
				int lowerLimit = rowsPerPage * pageNo;
				int upperLimit = lowerLimit + rowsPerPage;

				String pageLimitClause= " where rnum >:lowerLimit AND rnum <=:upperLimit";
				parameters.addValue("lowerLimit", lowerLimit);
				parameters.addValue("upperLimit", upperLimit);				
				sql+=pageLimitClause;			
			}
			result=this.namedParamTemplate.query(sql, parameters,
					new PlantMapper());	
		}catch(Exception e){
			logger.info("found Exception :: "+e);
		}
		return result;
	}


	public List<PlantData> getPlantDataByPlantId(String plantId){
		String sql= "select * from fptods.plant_info where plant_id = ?";
		List<PlantData> plantData=this.jdbcTemplate.query(sql, new Object[] { plantId},
				new PlantMapper());
		return plantData;
	}


	@Override
	public StatusInfo savePlantData(PlantData plantData) {		
	StatusInfo statusinfo= new StatusInfo();
	java.util.Date SQLPlantNextOutageDate = null;
	java.util.Date SQLPreviousOutageDate =null;
	java.sql.Date sqlDate = null;
	java.sql.Date sqlPreviousDate = null;
	String sql= "select count(plant_id) from fptods.plant_info where plant_id= ?";
	String saveSql="";		
	int count=this.jdbcTemplate.queryForInt(sql, new Object[]{plantData.getPlantId()});		
	if(count>0){	
		try {
			//getting last outage date and assigning it to previous outage date
			String getPreviousOutageSql="";
			String previousOutageDate="";
			getPreviousOutageSql="select * from fptods.plant_info where plant_id=?";		
			PlantData plantDataValues=this.jdbcTemplate.queryForObject(getPreviousOutageSql,new Object[] { plantData.getPlantId() },new PlantMapper());	
			previousOutageDate=plantDataValues.getPlantNextOutageDate();
			if(null!=previousOutageDate && !previousOutageDate.equals("")){			
				SQLPreviousOutageDate = new SimpleDateFormat("yyyy-MM-dd").parse(previousOutageDate);					
				sqlPreviousDate = new java.sql.Date(SQLPreviousOutageDate.getTime());			
			} 		
			saveSql="update fptods.plant_info set plant_name=?,plant_location=?,"+
					"plant_region=?,plant_state=?,plant_country=?,pi_email=?, pi_phone=?,next_outage_date=?,previous_outage_date=?,pi_zip=?,pi_fax=? where plant_id=?";	
			if(plantData.getPlantNextOutageDate()!=null && !plantData.getPlantNextOutageDate().equals("")){
				SQLPlantNextOutageDate = new SimpleDateFormat("yyyy-MM-dd").parse(plantData.getPlantNextOutageDate());					
				sqlDate = new java.sql.Date(SQLPlantNextOutageDate.getTime());		
			}
			Object[] param={
					plantData.getPlantName(),
					plantData.getPlantLocation(),
					plantData.getRegion(),
					plantData.getState(),
					plantData.getCountry(),
					plantData.getPlantEmail(),
					plantData.getPlantPhone(),
					sqlDate,
					sqlPreviousDate,
					plantData.getPlantZip(),
					plantData.getPlantFax(),
					Integer.parseInt(plantData.getPlantId())		  		  
			};
			this.jdbcTemplate.update(saveSql, param);
			statusinfo.setStatusCode(1);
			statusinfo.setStatusMessage("Data saved Successfully");
		} catch (Exception e) {
			logger.error("Exception in saving plant"+e.getLocalizedMessage());
			statusinfo.setStatusCode(500);
			statusinfo.setStatusMessage("Failed to save data"+e.getLocalizedMessage());
		}
	}
	else
	{		
		saveSql= "Insert into FPTODS.PLANT_INFO (PLANT_NAME,PLANT_LOCATION,NEXT_OUTAGE_DATE,DUNS_NUMBER,PLANT_REGION,PLANT_COUNTRY,PLANT_STATE,PREVIOUS_OUTAGE_DATE,PI_EMAIL,PI_PHONE,PI_ZIP,PI_FAX)"+
				"values (?,?,?,?,?,?,?,?,?,?,?,?)";				
		java.util.Date date=null;
		java.sql.Date sqlDateSaveNew=null;
		try {
			if(null!=plantData.getPlantNextOutageDate() && !("".equals(plantData.getPlantNextOutageDate())) ){
				date = new SimpleDateFormat("yyyy-MM-dd").parse(plantData.getPlantNextOutageDate());
				sqlDateSaveNew = new java.sql.Date(date.getTime());
			}
		Object[] param={					 
				plantData.getPlantName(),
				plantData.getPlantLocation(),
				sqlDateSaveNew,
				plantData.getcPDunsId(),
				plantData.getRegion(),
				plantData.getCountry(),
				plantData.getState(),	
				"",
				plantData.getPlantEmail(),
				plantData.getPlantPhone(),
				plantData.getPlantZip(),
				plantData.getPlantFax()
		};
		this.jdbcTemplate.update(saveSql, param);
		statusinfo.setStatusCode(1);
		statusinfo.setStatusMessage("Data saved Successfully");
		} catch (Exception e) {
			logger.error("Exception in saving plant"+e.getLocalizedMessage());
			statusinfo.setStatusCode(500);
			statusinfo.setStatusMessage("Failed to save data"+e.getLocalizedMessage());
		}
	}	
	
	return statusinfo;
}

private static final class PlantMapper implements RowMapper<PlantData> {
	public PlantMapper() {
	}

	@Override
	public PlantData mapRow(ResultSet rs, int rowNum) throws SQLException {
		PlantData result = new PlantData();
		int plantIdData=rs.getInt("plant_id");
		result.setPlantId(null!=String.valueOf(plantIdData)?String.valueOf(plantIdData):"");
		result.setPlantName(rs.getString("plant_name")!=null?rs.getString("plant_name"):"");
		result.setPlantLocation(rs.getString("plant_location")!=null?rs.getString("plant_location"):"");
		result.setcPDunsId(rs.getString("duns_number")!=null?rs.getString("duns_number"):"");
		result.setRegion(rs.getString("plant_region")!=null?rs.getString("plant_region"):"");
		result.setState(rs.getString("plant_state")!=null?rs.getString("plant_state"):"");
		result.setCountry(rs.getString("plant_country")!=null?rs.getString("plant_country"):"");
		/*Long plantPhoneData=rs.getLong("pi_phone");
		result.setPlantPhone(null!=String.valueOf(plantPhoneData)?String.valueOf(plantPhoneData):"");*/
		result.setPlantPhone(rs.getString("pi_phone")!=null?rs.getString("pi_phone"):"");
		result.setPlantEmail(rs.getString("pi_email")!=null?rs.getString("pi_email"):"");
		Date previousOutageDateData=rs.getDate("previous_outage_date");
		result.setPlantPrevOutageDate(null!=previousOutageDateData?previousOutageDateData.toString():"");
		Date nextOutageDateData=rs.getDate("next_outage_date");		
		result.setPlantNextOutageDate(null!=nextOutageDateData?nextOutageDateData.toString():"");
		result.setPlantZip(rs.getString("pi_zip")!=null?rs.getString("pi_zip"):"");
		/*Long plantFaxData=rs.getLong("pi_fax");
		result.setPlantFax(null!=String.valueOf(plantFaxData)?String.valueOf(plantFaxData):"");*/
		result.setPlantFax(rs.getString("pi_fax")!=null?rs.getString("pi_fax"):"");
		return result;
	}
}


@Override
public StatusInfo deletePlantData(PlantData plantData) {
	StatusInfo statusinfo= new StatusInfo();
	try{
		int plantIdData=Integer.valueOf(plantData.getPlantId());		
		String sql= "delete from fptods.plant_info where plant_id= ?";
		this.jdbcTemplate.update(sql,plantIdData);
		statusinfo.setStatusCode(1);
		statusinfo.setStatusMessage("Data deleted Successfully");
	} catch(Exception e){
		statusinfo.setStatusCode(500);
		statusinfo.setStatusMessage("Data deletion failed"+e.getLocalizedMessage());
	}
	return statusinfo;
}	
}
