package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;

public class CurrencyDetails implements Serializable {
	private static final long serialVersionUID = 27151901153309561L;
	
	private String currencySymbol;
	private String toCurrency;
	private String fromCurrency;
	public String getCurrencySymbol() {
		return currencySymbol;
	}
	public void setCurrencySymbol(String currencySymbol) {
		this.currencySymbol = currencySymbol;
	}
	public String getToCurrency() {
		return toCurrency;
	}
	public void setToCurrency(String toCurrency) {
		this.toCurrency = toCurrency;
	}
	public String getFromCurrency() {
		return fromCurrency;
	}
	public void setFromCurrency(String fromCurrency) {
		this.fromCurrency = fromCurrency;
	}
   
}

