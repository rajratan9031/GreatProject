package com.ge.fpt.welcomepkg.persistence;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.fpt.welcomepkg.api.BomWhereusedData;
import com.ge.fpt.welcomepkg.api.PartMasterData;
import com.ge.fpt.welcomepkg.api.PartMasterData1;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;


public class CICSPersistenceImpl implements ICicsPersistence{


	@SuppressWarnings("javadoc")
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory.getLogger(CICSPersistenceImpl.class);

	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;

	/**
	 * Data source for the JDBC
	 */
	DataSource dataSource;

	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;

	NamedParameterJdbcTemplate namedParamTemplate;

	/**
	 * @return the dataSource
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}

	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate = new NamedParameterJdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}
	
	
	@Override
	public List<PartMasterData> getPartNumberData(String searchBy, String partNo, Integer startPartIndex, Integer endPartIndex) {
		
		List<PartMasterData> partMasterData = null;
		String partNumber = partNo.concat("%");
		if(searchBy.equalsIgnoreCase("PartNumber")){
		String sql= "Select * from (SELECT b.PMT_PART_NUMBER as Part_Number,b.PMT_DESCRIPTION,b.PMT_DRAWING_NUMBER,ROW_NUMBER() OVER (ORDER BY pmt_Key) AS RowNumber from fptOds.PartMaster b where b.pmt_Key >=( SELECT a.pmt_Key FROM fptOds.PartMaster a where TRIM(upper(PMT_PART_NUMBER)) like upper(?) and rownum = 1) ) a where RowNumber >=? and RowNumber <= ? order by RowNumber asc";
		partMasterData=this.jdbcTemplate.query(sql, new Object[] { partNumber,startPartIndex,endPartIndex },
				new PartMasterMapper());
		
		} else if(searchBy.equalsIgnoreCase("Description")){
			String sql= "Select * from (SELECT b.PMT_PART_NUMBER as Part_Number,b.PMT_DESCRIPTION,b.PMT_DRAWING_NUMBER,ROW_NUMBER() OVER (ORDER BY pmt_Key) AS RowNumber FROM fptOds.PartMaster b where TRIM(upper(PMT_DESCRIPTION)) like upper(?)) a where RowNumber >=? and RowNumber <= ? order by PMT_DESCRIPTION asc";
		partMasterData=this.jdbcTemplate.query(sql, new Object[] { partNumber,startPartIndex,endPartIndex },
					new PartMasterMapper());
		} else if(searchBy.equalsIgnoreCase("DrawingNumber")) {
			String sql= "Select * from (SELECT b.PMT_PART_NUMBER as Part_Number,b.PMT_DESCRIPTION,b.PMT_DRAWING_NUMBER,ROW_NUMBER() OVER (ORDER BY pmt_Key) AS RowNumber FROM fptOds.PartMaster b where TRIM(upper(PMT_DRAWING_NUMBER)) like upper(?)) a where RowNumber >=? and RowNumber <= ? order by PMT_DRAWING_NUMBER asc";
		partMasterData=this.jdbcTemplate.query(sql, new Object[] { partNumber,startPartIndex,endPartIndex },
					new PartMasterMapper());
		}
		System.out.println("Response from Query------"+partMasterData);
		return partMasterData;
	}
	
	@Override
	public List<PartMasterData> getSubPartNumberData(String searchBy, String partNo, String subPartNo, Integer startPartIndex,
			Integer endPartIndex) {
		
		List<PartMasterData> partMasterData = null;
		String partNumber = partNo.concat("%");
		String subPartNumber = subPartNo.concat("%");
		if(searchBy.equalsIgnoreCase("PartNumber")){
		
		String sql= "Select * from (SELECT b.PMT_PART_NUMBER as Part_Number,b.PMT_DESCRIPTION,b.PMT_DRAWING_NUMBER,ROW_NUMBER() OVER (ORDER BY pmt_Key) AS RowNumber from fptOds.PartMaster b where b.pmt_Key >=( SELECT a.pmt_Key FROM fptOds.PartMaster a where LTRIM(upper(PMT_PART_NUMBER)) like upper(?) and LTRIM(upper(PMT_PART_NUMBER)) like upper(?) and rownum = 1) ) a where RowNumber >=? and RowNumber <= ? order by RowNumber asc";
		partMasterData=this.jdbcTemplate.query(sql, new Object[] { partNumber,subPartNumber,startPartIndex,endPartIndex },
				new PartMasterMapper());
		System.out.println("Response from Query Inside------"+partMasterData);
		} else if(searchBy.equalsIgnoreCase("Description")){
			String sql= "Select * from (SELECT b.PMT_PART_NUMBER as Part_Number,b.PMT_DESCRIPTION,b.PMT_DRAWING_NUMBER,ROW_NUMBER() OVER (ORDER BY pmt_Key) AS RowNumber FROM fptOds.PartMaster b where TRIM(upper(PMT_DESCRIPTION)) like upper(?) and LTRIM(upper(PMT_PART_NUMBER)) like upper(?)) a where RowNumber >=? and RowNumber <= ? order by PMT_DESCRIPTION asc";
		partMasterData=this.jdbcTemplate.query(sql, new Object[] { partNumber,subPartNumber,startPartIndex,endPartIndex },
					new PartMasterMapper());
		} else if(searchBy.equalsIgnoreCase("DrawingNumber")) {
			String sql= "Select * from (SELECT b.PMT_PART_NUMBER as Part_Number,b.PMT_DESCRIPTION,b.PMT_DRAWING_NUMBER,ROW_NUMBER() OVER (ORDER BY pmt_Key) AS RowNumber FROM fptOds.PartMaster b where TRIM(upper(PMT_DRAWING_NUMBER)) like upper(?) and LTRIM(upper(PMT_PART_NUMBER)) like upper(?)) a where RowNumber >=? and RowNumber <= ? order by PMT_DRAWING_NUMBER asc";
		partMasterData=this.jdbcTemplate.query(sql, new Object[] { partNumber,subPartNumber,startPartIndex,endPartIndex },
					new PartMasterMapper());
		}
		System.out.println("Response from Query------"+partMasterData);
		return partMasterData;
	}

	
	

	private static final class PartMasterMapper implements RowMapper<PartMasterData> {
		public PartMasterMapper() {
		}
	
	public PartMasterData mapRow(ResultSet rs, int rowNum) throws SQLException {
		PartMasterData result = new PartMasterData();
		result.setPartNumber(rs.getString("PART_NUMBER"));
		result.setPmtDescription(rs.getString("PMT_DESCRIPTION"));
		result.setPmtDrawingNumber(rs.getString("PMT_DRAWING_NUMBER"));
		result.setRowNumber(rs.getLong("ROWNUMBER"));
		logger.info("Test result"+result.getPartNumber());
		return result;
	}

	}

	@Override
	public List<PartMasterData1> getPartDataOnClick(String partNo) {
	    List<PartMasterData1> partMasterData1 = null;
		String sql= "SELECT p.*,MDSC_GENERAL,SPECIFIC FROM fptOds.PartMaster p left outer join fptOds.MDSC m on p.PMT_MATERIAL_DESC_CD = m.MDSC WHERE TRIM(upper(PMT_PART_NUMBER)) = upper(?)";
		partMasterData1=this.jdbcTemplate.query(sql, new Object[] { partNo}, new PartMasterMapper1());
		return partMasterData1;
	}

    
	
	private static final class PartMasterMapper1 implements RowMapper<PartMasterData1> {
		public PartMasterMapper1() {
		}
	
	public PartMasterData1 mapRow(ResultSet rs, int rowNum) throws SQLException {
		PartMasterData1 result = new PartMasterData1();
		result.setPmtPartNumber(rs.getString("PMT_PART_NUMBER"));
		result.setPmtConsignedAccount(rs.getString("PMT_CONSIGNED_ACCOUNT"));
		result.setPmtRespCode(rs.getString("PMT_RESP_CODE"));
		result.setPmtDrawingNumber(rs.getString("PMT_DRAWING_NUMBER"));
		result.setPmtAccountNumber(rs.getString("PMT_ACCOUNT_NUMBER"));
		result.setPmtDateLastActive(rs.getDate("PMT_DATE_LAST_ACTIVE"));
		result.setPmtDateOfLastRecpt(rs.getDate("PMT_DATE_OF_LAST_RECPT"));
	    result.setPmtLastPhyInvDate(rs.getDate("PMT_LAST_PHY_INV_DATE"));
	    result.setPmtDescription(rs.getString("PMT_DESCRIPTION"));
	    result.setPmtLeadTime(rs.getString("PMT_LEAD_TIME"));
	    result.setPmtEconomicOq(rs.getLong("PMT_ECONOMIC_OQ"));
		result.setPmtVendorPrimary(rs.getString("PMT_VENDOR_PRIMARY"));
		result.setPmtYtdUseProduction(rs.getLong("PMT_YTD_USE_PRODUCTION"));
		result.setPmtLastYearsUsage(rs.getLong("PMT_LAST_YEARS_USAGE"));
		result.setPmtStatusCode(rs.getString("PMT_STATUS_CODE"));
		result.setPmtDateCreated(rs.getDate("PMT_DATE_CREATED"));
		result.setPmtTpoCostMaterial(rs.getDouble("PMT_TPO_COST_MATERIAL"));
		result.setPmtTpoCostLabor(rs.getDouble("PMT_TPO_COST_LABOR"));
		result.setPmtTpoStdLabHours(rs.getDouble("PMT_TPO_STD_LAB_HOURS"));
		result.setPmtRplCostMtl(rs.getDouble("PMT_RPL_COST_MTL"));
		result.setPmtRplCostLab(rs.getDouble("PMT_RPL_COST_LAB"));
		result.setPmtRplCostOvhd(rs.getDouble("PMT_RPL_COST_OVHD"));
		result.setPmtStandardOq(rs.getLong("PMT_STANDARD_OQ"));
		result.setPmtSvcListPrice(rs.getDouble("PMT_SVC_LIST_PRICE"));
		result.setPmtPriceFactorCode(rs.getString("PMT_PRICE_FACTOR_CODE"));
		result.setPmtPartRevalueFlag(rs.getString("PMT_PART_REVALUE_FLAG"));
		result.setPmtCompRevalueFlag(rs.getString("PMT_COMP_REVALUE_FLAG"));
		result.setPmtSvcNotAvailCode(rs.getString("PMT_SVC_NOT_AVAIL_CODE"));
		result.setPmtPartsClassCode(rs.getString("PMT_PARTS_CLASS_CODE"));
		result.setPmtPartsCatalogCode(rs.getString("PMT_PARTS_CATALOG_CODE"));
		result.setPmtLyrCostMtl(rs.getDouble("PMT_LYR_COST_MTL"));
		result.setPmtLyrCostLab(rs.getDouble("PMT_LYR_COST_LAB"));
		result.setPmtActNoOfPieces(rs.getLong("PMT_ACT_NO_OF_PIECES"));
		result.setPmtSize(rs.getString("PMT_SIZE"));
		result.setPmtStdCostMaterial(rs.getDouble("PMT_STD_COST_MATERIAL"));
		result.setPmtStdCostLabor(rs.getDouble("PMT_STD_COST_LABOR"));
		result.setPmtStdLaborHours(rs.getDouble("PMT_STD_LABOR_HOURS"));
		result.setPmtStdCostNoValue(rs.getString("PMT_STD_COST_NO_VALUE"));
		result.setPmtStartExtMtlAmt(rs.getLong("PMT_START_EXT_MTL_AMT"));
		result.setPmtStartExtLabAmt(rs.getLong("PMT_START_EXT_LAB_AMT"));
		result.setPmtProdComm(rs.getString("PMT_PROD_COMM"));
		result.setPmtUnitMeasureStock(rs.getString("PMT_UNIT_MEASURE_STOCK"));
		result.setPmtUnitMeasurePurch(rs.getString("PMT_UNIT_MEASURE_PURCH"));
		result.setPmtDateOfCost(rs.getDate("PMT_DATE_OF_COST"));
		result.setPmtHtsCat(rs.getString("PMT_HTS_CAT"));
		result.setPmtEccnCode(rs.getString("PMT_ECCN_CODE"));
		result.setPmtMaterialDescCd(rs.getString("PMT_MATERIAL_DESC_CD"));
		result.setPmtLowLevelCode(rs.getString("PMT_LOW_LEVEL_CODE"));
		result.setPmtCountryOfOrigin1(rs.getString("PMT_COUNTRY_OF_ORIGIN_1"));
		result.setPmtCountryOfOrigin2(rs.getString("PMT_COUNTRY_OF_ORIGIN_2"));
		result.setPmtMstrRtgNum(rs.getString("PMT_MSTR_RTG_NUM"));
		result.setPmtEngrChangeNumber1(rs.getString("PMT_ENGR_CHANGE_NUMBER_1"));
		result.setPmtMaterialChangeNo(rs.getString("PMT_MATERIAL_CHANGE_NO"));
		result.setPmtEngrChangeNumber2(rs.getString("PMT_ENGR_CHANGE_NUMBER_2"));
		result.setPmtEngrChangeNumber3(rs.getString("PMT_ENGR_CHANGE_NUMBER_3"));
		result.setPmtEngrChangeDate1(rs.getDate("PMT_ENGR_CHANGE_DATE_1"));
		result.setPmtEngrChangeDate2(rs.getDate("PMT_ENGR_CHANGE_DATE_2"));
		result.setPmtEngrChangeDate3(rs.getDate("PMT_ENGR_CHANGE_DATE_3"));
		result.setPmtEngrChangeInit1(rs.getString("PMT_ENGR_CHANGE_INIT_1"));
		result.setPmtEngrChangeInit2(rs.getString("PMT_ENGR_CHANGE_INIT_2"));
		result.setPmtEngrChangeInit3(rs.getString("PMT_ENGR_CHANGE_INIT_3"));
		result.setPmtStatusCategory(rs.getString("PMT_STATUS_CATEGORY"));
		result.setPmtEngrChgDisp(rs.getString("PMT_ENGR_CHG_DISP"));
		result.setPmtCadDrawing(rs.getString("PMT_CAD_DRAWING"));
		result.setPmtAssyRecCount(rs.getLong("PMT_ASSY_REC_COUNT"));
		result.setPmtWhereuseRecCount(rs.getLong("PMT_WHEREUSE_REC_COUNT"));
		result.setPmtRoutingRecCount(rs.getLong("PMT_ROUTING_REC_COUNT"));
		result.setPmtOrdPolicyCode(rs.getString("PMT_ORD_POLICY_CODE"));
		result.setMdscGeneral(rs.getString("MDSC_GENERAL"));
		result.setSpecific(rs.getString("SPECIFIC"));
		return result;
	}
	}

	@Override
	public List<BomWhereusedData> getWhereusedData(String partNo, Integer startIndex, Integer endIndex) {
		List<BomWhereusedData> whereusedData = null;
		String sql= "SELECT * FROM (SELECT BomAll.BOM_KEY, BomAll.PARENTPART as COMPONENTPART, BomAll.Quantity_per_assembly,BomAll.Destination_Code,BomAll.ENGR_CHANGE_NUMBER,PartMaster.PMT_Status_CODE,PartMaster.PMT_DRAWING_NUMBER,PartMaster.PMT_DESCRIPTION,ROW_NUMBER() OVER (ORDER BY BomAll.BOM_KEY) AS RowNumber FROM fptOds.BomAll LEFT OUTER JOIN fptOds.PartMaster ON BomAll.PARENTPART = PartMaster.PMT_PART_NUMBER where   TRIM(upper(COMPONENTPART)) = upper(?))  e where e.RowNumber>=? and e.RowNumber<=?";
		whereusedData=this.jdbcTemplate.query(sql, new Object[] { partNo,startIndex,endIndex },
				new BomWhereusedMapper());
		logger.info(" Whereused response from Query ------"+whereusedData);
		return whereusedData;
	}

	@Override
	public List<BomWhereusedData> getBOMData(String partNo, Integer startIndex, Integer endIndex) {
		List<BomWhereusedData> bomData = null;
		String sql= "SELECT * FROM (SELECT BomAll.BOM_KEY, BomAll.COMPONENTPART as COMPONENTPART, BomAll.Quantity_per_assembly,BomAll.Destination_Code, BomAll.ENGR_CHANGE_NUMBER,PartMaster.PMT_Status_CODE,PartMaster.PMT_DRAWING_NUMBER,PartMaster.PMT_DESCRIPTION, ROW_NUMBER() OVER (ORDER BY BomAll.BOM_KEY) AS RowNumber FROM fptOds.BomAll LEFT OUTER JOIN fptOds.PartMaster ON BomAll.COMPONENTPART = PartMaster.PMT_PART_NUMBER where   TRIM(upper(BomAll.PARENTPART)) = upper(?))  e where e.RowNumber>=? and e.RowNumber<=?";
		bomData=this.jdbcTemplate.query(sql, new Object[] { partNo,startIndex,endIndex },
				new BomWhereusedMapper());
		logger.info("Response from Query Inside------"+bomData);
		return bomData;
	}
	
	private static final class BomWhereusedMapper implements RowMapper<BomWhereusedData> {
		public BomWhereusedMapper() {
		}
	
	public BomWhereusedData mapRow(ResultSet rs, int rowNum) throws SQLException {
		BomWhereusedData result = new BomWhereusedData();
		result.setComponentPart(rs.getString("COMPONENTPART"));
		result.setDestinationCode(rs.getString("DESTINATION_CODE"));
		result.setEngrChangeNumber(rs.getString("ENGR_CHANGE_NUMBER"));
		result.setPmtDescription(rs.getString("PMT_DESCRIPTION"));
		result.setPmtDrawingNumber(rs.getString("PMT_DRAWING_NUMBER"));
		result.setPmtStatusCode(rs.getString("PMT_STATUS_CODE"));
		result.setQuantityPerAssembly(rs.getDouble("QUANTITY_PER_ASSEMBLY"));
		return result;
	}

	}

	
	
		
}

	
