package com.ge.fpt.welcomepkg.persistence;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.fpt.welcomepkg.api.PlantData;
import com.ge.fpt.welcomepkg.api.PlantDataMaster;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;


public class PlantDataMasterPersistenceImpl implements IPlantDataMasterPersistence {
	@SuppressWarnings("javadoc")
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory.getLogger(PlantDataMasterPersistenceImpl.class);

	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;

	/**
	 * Data source for the JDBC
	 */
	DataSource dataSource;

	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;

	NamedParameterJdbcTemplate namedParamTemplate;

	/**
	 * @return the dataSource
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}

	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate = new NamedParameterJdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	@Override
	public StatusInfo deleteplantMaster(String sso, String customerId) {
		StatusInfo result= new StatusInfo();
		try{
			String sql="Delete from FPTODS.PLANT_DATA_MANAGMENT_MASTER where CUSTOMER_ID=?";
			this.jdbcTemplate.update(sql, new Object[]{customerId});
			result.setStatusCode(0);
			result.setStatusMessage("Deleted Successfully!!");
			return result;
		
		

	}
	catch (Exception e){
		result.setStatusCode(-1);
		result.setStatusMessage("Error occurred while deleted..");
		return result;
	}
	}
		@Override
		public List<PlantDataMaster> getplantMaster(String custId) {
			try{
				logger.info("inside getplant mamster");
				List<PlantDataMaster> result=new ArrayList<PlantDataMaster>();
				String sql= "select * from FPTODS.PLANT_DATA_MANAGMENT_MASTER where CUST_ID=?";
				 result=this.jdbcTemplate.query(sql, new Object[] { custId}, new PlantDataMasterMapper());
				logger.info("after jsdbctemplate ");
				return result;
			}
			catch(Exception e){
				e.printStackTrace();
				logger.error("");
			}
			return null;
		}


		public static final class PlantDataMasterMapper implements RowMapper<PlantDataMaster> {
			public PlantDataMasterMapper() {
			}

			@Override
			public PlantDataMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				PlantDataMaster result = new PlantDataMaster();
				
				int plantidData=rs.getInt("PLANT_ID");
				result.setPlantId(plantidData);
				int custIddata=rs.getInt("CUST_ID");
				result.setCustId(custIddata);
				/*result.setCustomerName(rs.getString("CUSTOMER_NAME")!=null?rs.getString("CUSTOMER_NAME"):"");*/
				
				result.setPlantLocation(rs.getString("PLANT_LOCATION")!=null?rs.getString("PLANT_LOCATION"):"");
				//result.setPlantArea(rs.getString("PLANT_AREA")!=null?rs.getString("PLANT_AREA"):"");
				//result.setPlantAccount(rs.getString("PLANT_ACCOUNT")!=null?rs.getString("PLANT_ACCOUNT"):"");
				//result.setPlanUniversal(rs.getString("PLANT_UNVIVERSAL")!=null?rs.getString("PLANT_UNVIVERSAL"):"");
				/*Long plantPhoneData=rs.getLong("pi_phone");
				result.setPlantPhone(null!=String.valueOf(plantPhoneData)?String.valueOf(plantPhoneData):"");*/
				result.setContact(rs.getString("CUSTOMER_CONTACT_NAME")!=null?rs.getString("CUSTOMER_CONTACT_NAME"):"");
				result.setMaintaenanceInternal(rs.getString("MAINTAENANCE_INTERNAL")!=null?rs.getString("MAINTAENANCE_INTERNAL"):"");
				result.setCountry(rs.getString("COUNTRY")!=null?rs.getString("COUNTRY"):"");
				//result.setRegion(rs.getString("REGION")!=null?rs.getString("REGION"):"");
				result.setActiveInavctive(rs.getString("ACTIVE_INACTIVE")!=null?rs.getString("ACTIVE_INACTIVE"):"");
				
				result.setDunsNumber(rs.getString("DUNS_NUMBER"));
				result.setCreatedDate(rs.getDate("CREATED_DATE"));
				result.setUpdatedDate(rs.getDate("UPDATED_DATE"));
				result.setUpdatedBy(rs.getString("UPDATED_BY"));
				result.setCreatedBy(rs.getString("CREATED_BY"));
				/*Long plantFaxData=rs.getLong("pi_fax");
				result.setPlantFax(null!=String.valueOf(plantFaxData)?String.valueOf(plantFaxData):"");*/
				
				
				return result;
			}
		}


		@Override
		public PlantDataMaster getplantMasterById(int plantId) {
			try{
				
			
			logger.info("inside getplant mamster");
			List<PlantDataMaster> result=new ArrayList<PlantDataMaster>();
			String sql= "select * from FPTODS.PLANT_DATA_MANAGMENT_MASTER where PLANT_ID=? ";
			 result=this.jdbcTemplate.query(sql, new Object[] { plantId}, new PlantDataMasterMapper());
			logger.info("after jsdbctemplate");
			
			return result.get(0);
			}
			catch(Exception e){
				return null;
			
				
			}
		}
}



