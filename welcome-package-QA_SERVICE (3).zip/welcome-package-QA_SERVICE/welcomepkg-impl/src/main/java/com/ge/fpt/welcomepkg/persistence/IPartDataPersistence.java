package com.ge.fpt.welcomepkg.persistence;

import java.util.HashMap;
import java.util.List;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ge.fpt.welcomepkg.api.PartData;
import com.ge.fpt.welcomepkg.api.StatusInfo;

public interface IPartDataPersistence {
	
	@Transactional(propagation=Propagation.REQUIRED)
	List<PartData> getPartDataByPartInfoId(String partInfoId);
	
	@Transactional(propagation=Propagation.REQUIRED)
	StatusInfo savePartData(String sso,PartData partData);
	
	@Transactional(propagation=Propagation.REQUIRED)
	List<PartData> getPartData(int pageNo,int rowperpage,PartData partData);

	@Transactional(propagation=Propagation.REQUIRED)
	int getPartDataCount(PartData partData);
	
	@Transactional(propagation=Propagation.REQUIRED)
	StatusInfo getPartDataToUpload(HashMap getCompleteData);
	
}
