package com.ge.fpt.welcomepkg.persistence;

import java.util.Map;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ge.fpt.welcomepkg.api.ReportData;

public interface IAngolaReportServicePersistence {

	@Transactional(propagation = Propagation.REQUIRED)
	byte[] generateExcelReportForAngola(Map reportParam,String sso);
}
