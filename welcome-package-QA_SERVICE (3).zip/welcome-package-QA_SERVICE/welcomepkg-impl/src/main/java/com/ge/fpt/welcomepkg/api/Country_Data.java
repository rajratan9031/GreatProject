package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Country_Data implements Serializable{
	
	private static final long serialVersionUID = 1L;

	private String country_Name;
	//private List<State_Data> states=new ArrayList<State_Data>();
	private List<String> state=new ArrayList<String>();
	
	
	
	



	/**
	 * @return the states
	 *//*
	public List<State_Data> getStates() {
		return states;
	}



	*//**
	 * @param states the states to set
	 *//*
	public void setStates(List<State_Data> states) {
		this.states = states;
	}

*/

	/**
	 * @return the country_Name
	 */
	public String getCountry_Name() {
		return country_Name;
	}



	/**
	 * @param country_Name the country_Name to set
	 */
	public void setCountry_Name(String country_Name) {
		this.country_Name = country_Name;
	}



	/**
	 * @return the state
	 */
	public List<String> getState() {
		return state;
	}



	/**
	 * @param state the state to set
	 */
	public void setState(List<String> state) {
		this.state = state;
	}



	@Override
	public String toString() {
		return "Country_Data [country_Name=" + country_Name + ", state=" + state + "]";
	}
	
	/*@Override
	public String toString() {
		return "Country_Data [countryCode=" + countryCode + ", countryName=" + countryName + ", state=" + state + "]";
	}*/
	
	



}
