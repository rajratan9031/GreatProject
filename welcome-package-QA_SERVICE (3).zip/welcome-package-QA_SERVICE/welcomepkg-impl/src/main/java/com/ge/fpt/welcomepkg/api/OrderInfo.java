/*
 * Copyright (c) 2013 GE Global Research. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Global Research. The software may be used and/or copied only
 * with the written permission of GE Global Research or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author 212414241
 * 
 */

// @Entity
@XmlRootElement
public class OrderInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String recSource;
	private String salesOrder;
	private String customerPo;
	private String soldToCustName;
	private String soldToCustCountry;
	private String soldToCustState;
	private String soldToCustProvince;
	private String soldToCustCity;
	private String repName;
	private String sourceSystem;
	private String channel;
	private String username;
	private String sso;
	private String endUser;
	private String endUserIndustry;
	private Date lastUpdateDate;
	private String lastUpdateDateStr;
	private Long orderId;
	private Boolean orderConverted;
	private String note;
	private String postalCode;
	private String plantName;
	private String duns;
	private Date creationDate;
	private String productCode;
	private String valveCnt;
	private String euCountry;
	private String euState;
	private String euCity;
	private String scPostalCode;
	
	private String serializable;
	private String engineeredValve;
	private String linkCustomerName;  //Added by sujeet
	private String custId; 
	private List<CustomerLinkMasterModel> customerLinkMasterModel;
	

	
	/**
	 * 
	 */
	public OrderInfo() {
		super();
	}

	/**
	 * @param recSource
	 * @param salesOrder
	 * @param customerPo
	 * @param soldToCustName
	 * @param soldToCustCountry
	 * @param soldToCustState
	 * @param soldToCustProvince
	 * @param soldToCustCity
	 * @param repName
	 * @param sourceSystem
	 * @param channel
	 * @param username
	 * @param sso
	 */
	
	
	public String getValveCnt() {
		return valveCnt;
	}

	public OrderInfo(String recSource, String salesOrder, String customerPo, String soldToCustName,
			String soldToCustCountry, String soldToCustState, String soldToCustProvince, String soldToCustCity,
			String repName, String sourceSystem, String channel, String username, String sso, String endUser,
			String endUserIndustry, Date lastUpdateDate, String lastUpdateDateStr, Long orderId, Boolean orderConverted,
			String note, String postalCode, String plantName, String duns, Date creationDate, String productCode,
			String valveCnt, String euCountry, String euState, String euCity, String scPostalCode, String serializable,
			String engineeredValve,String linkCustomerName,List<CustomerLinkMasterModel> customerLinkMasterModel,String custId) {
		super();
		this.recSource = recSource;
		this.salesOrder = salesOrder;
		this.customerPo = customerPo;
		this.soldToCustName = soldToCustName;
		this.soldToCustCountry = soldToCustCountry;
		this.soldToCustState = soldToCustState;
		this.soldToCustProvince = soldToCustProvince;
		this.soldToCustCity = soldToCustCity;
		this.repName = repName;
		this.sourceSystem = sourceSystem;
		this.channel = channel;
		this.username = username;
		this.sso = sso;
		this.endUser = endUser;
		this.endUserIndustry = endUserIndustry;
		this.lastUpdateDate = lastUpdateDate;
		this.lastUpdateDateStr = lastUpdateDateStr;
		this.orderId = orderId;
		this.orderConverted = orderConverted;
		this.note = note;
		this.postalCode = postalCode;
		this.plantName = plantName;
		this.duns = duns;
		this.creationDate = creationDate;
		this.productCode = productCode;
		this.valveCnt = valveCnt;
		this.euCountry = euCountry;
		this.euState = euState;
		this.euCity = euCity;
		this.scPostalCode = scPostalCode;
		this.serializable = serializable;
		this.engineeredValve = engineeredValve;
		this.linkCustomerName=linkCustomerName;
		this.customerLinkMasterModel=customerLinkMasterModel;
		this.custId=custId;
	}

	public String getSerializable() {
		return serializable;
	}

	public void setSerializable(String serializable) {
		this.serializable = serializable;
	}

	public String getEngineeredValve() {
		return engineeredValve;
	}

	public void setEngineeredValve(String engineeredValve) {
		this.engineeredValve = engineeredValve;
	}

	public void setValveCnt(String valveCnt) {
		this.valveCnt = valveCnt;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getDuns() {
		return duns;
	}

	public void setDuns(String duns) {
		this.duns = duns;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getPlantName() {
		return plantName;
	}

	public void setPlantName(String plantName) {
		this.plantName = plantName;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	/**
	 * @return the recSource
	 */
	public String getRecSource() {
		return recSource;
	}

	/**
	 * @param recSource
	 *            the recSource to set
	 */
	public void setRecSource(String recSource) {
		this.recSource = recSource;
	}

	/**
	 * @return the salesOrder
	 */
	public String getSalesOrder() {
		return salesOrder;
	}

	/**
	 * @param salesOrder
	 *            the salesOrder to set
	 */
	public void setSalesOrder(String salesOrder) {
		this.salesOrder = salesOrder;
	}

	/**
	 * @return the customerPo
	 */
	public String getCustomerPo() {
		return customerPo;
	}

	/**
	 * @param customerPo
	 *            the customerPo to set
	 */
	public void setCustomerPo(String customerPo) {
		this.customerPo = customerPo;
	}

	/**
	 * @return the soldToCustName
	 */
	public String getSoldToCustName() {
		return soldToCustName;
	}

	/**
	 * @param soldToCustName
	 *            the soldToCustName to set
	 */
	public void setSoldToCustName(String soldToCustName) {
		this.soldToCustName = soldToCustName;
	}

	/**
	 * @return the soldToCustCountry
	 */
	public String getSoldToCustCountry() {
		return soldToCustCountry;
	}

	/**
	 * @param soldToCustCountry
	 *            the soldToCustCountry to set
	 */
	public void setSoldToCustCountry(String soldToCustCountry) {
		this.soldToCustCountry = soldToCustCountry;
	}

	/**
	 * @return the soldToCustState
	 */
	public String getSoldToCustState() {
		return soldToCustState;
	}

	/**
	 * @param soldToCustState
	 *            the soldToCustState to set
	 */
	public void setSoldToCustState(String soldToCustState) {
		this.soldToCustState = soldToCustState;
	}

	/**
	 * @return the soldToCustProvince
	 */
	public String getSoldToCustProvince() {
		return soldToCustProvince;
	}

	/**
	 * @param soldToCustProvince
	 *            the soldToCustProvince to set
	 */
	public void setSoldToCustProvince(String soldToCustProvince) {
		this.soldToCustProvince = soldToCustProvince;
	}

	/**
	 * @return the soldToCustCity
	 */
	public String getSoldToCustCity() {
		return soldToCustCity;
	}

	/**
	 * @param soldToCustCity
	 *            the soldToCustCity to set
	 */
	public void setSoldToCustCity(String soldToCustCity) {
		this.soldToCustCity = soldToCustCity;
	}

	/**
	 * @return the repName
	 */
	public String getRepName() {
		return repName;
	}

	/**
	 * @param repName
	 *            the repName to set
	 */
	public void setRepName(String repName) {
		this.repName = repName;
	}

	/**
	 * @return the sourceSystem
	 */
	public String getSourceSystem() {
		return sourceSystem;
	}

	/**
	 * @param sourceSystem
	 *            the sourceSystem to set
	 */
	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	/**
	 * @return the channel
	 */
	public String getChannel() {
		return channel;
	}

	/**
	 * @param channel
	 *            the channel to set
	 */
	public void setChannel(String channel) {
		this.channel = channel;
	}

	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @param username
	 *            the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * @return the sso
	 */
	public String getSso() {
		return sso;
	}

	/**
	 * @param sso
	 *            the sso to set
	 */
	public void setSso(String sso) {
		this.sso = sso;
	}

	/**
	 * @return the endUser
	 */
	public String getEndUser() {
		return endUser;
	}

	/**
	 * @param endUser the endUser to set
	 */
	public void setEndUser(String endUser) {
		this.endUser = endUser;
	}

	/**
	 * @return the endUserIndustry
	 */
	public String getEndUserIndustry() {
		return endUserIndustry;
	}

	/**
	 * @param endUserIndustry the endUserIndustry to set
	 */
	public void setEndUserIndustry(String endUserIndustry) {
		this.endUserIndustry = endUserIndustry;
	}

	/**
	 * @return the lastUpdateDate
	 */
	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	/**
	 * @param lastUpdateDate the lastUpdateDate to set
	 */
	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	/**
	 * @return the lastUpdateDateStr
	 */
	public String getLastUpdateDateStr() {
		return lastUpdateDateStr;
	}

	/**
	 * @param lastUpdateDateStr the lastUpdateDateStr to set
	 */
	public void setLastUpdateDateStr(String lastUpdateDateStr) {
		this.lastUpdateDateStr = lastUpdateDateStr;
	}

	/**
	 * @return the orderId
	 */
	public Long getOrderId() {
		return orderId;
	}

	/**
	 * @param orderId the orderId to set
	 */
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	/**
	 * @return the orderConverted
	 */
	public Boolean getOrderConverted() {
		return orderConverted;
	}

	/**
	 * @param orderConverted the orderConverted to set
	 */
	public void setOrderConverted(Boolean orderConverted) {
		this.orderConverted = orderConverted;
	}

	public String getEuCountry() {
		return euCountry;
	}

	public void setEuCountry(String euCountry) {
		this.euCountry = euCountry;
	}

	public String getEuState() {
		return euState;
	}

	public void setEuState(String euState) {
		this.euState = euState;
	}

	public String getEuCity() {
		return euCity;
	}

	public void setEuCity(String euCity) {
		this.euCity = euCity;
	}

	public String getScPostalCode() {
		return scPostalCode;
	}

	public void setScPostalCode(String scPostalCode) {
		this.scPostalCode = scPostalCode;
	}

	public String getLinkCustomerName() {
		return linkCustomerName;
	}

	public void setLinkCustomerName(String linkCustomerName) {
		this.linkCustomerName = linkCustomerName;
	}
	

	
	
	public List<CustomerLinkMasterModel> getCustomerLinkMasterModel() {
		return customerLinkMasterModel;
	}

	public void setCustomerLinkMasterModel(List<CustomerLinkMasterModel> customerLinkMasterModel) {
		this.customerLinkMasterModel = customerLinkMasterModel;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	@Override
	public String toString() {
		return "OrderInfo [recSource=" + recSource + ", salesOrder=" + salesOrder + ", customerPo=" + customerPo
				+ ", soldToCustName=" + soldToCustName + ", soldToCustCountry=" + soldToCustCountry
				+ ", soldToCustState=" + soldToCustState + ", soldToCustProvince=" + soldToCustProvince
				+ ", soldToCustCity=" + soldToCustCity + ", repName=" + repName + ", sourceSystem=" + sourceSystem
				+ ", channel=" + channel + ", username=" + username + ", sso=" + sso + ", endUser=" + endUser
				+ ", endUserIndustry=" + endUserIndustry + ", lastUpdateDate=" + lastUpdateDate + ", lastUpdateDateStr="
				+ lastUpdateDateStr + ", orderId=" + orderId + ", orderConverted=" + orderConverted + ", note=" + note
				+ ", postalCode=" + postalCode + ", plantName=" + plantName + ", duns=" + duns + ", creationDate="
				+ creationDate + ", productCode=" + productCode + ", valveCnt=" + valveCnt + ", euCountry=" + euCountry
				+ ", euState=" + euState + ", euCity=" + euCity + ", scPostalCode=" + scPostalCode + ", serializable="
				+ serializable + ", engineeredValve=" + engineeredValve + ", linkCustomerName=" + linkCustomerName
				+ ", customerLinkMasterModel=" + customerLinkMasterModel + "]";
	}

	

	
	

	
	


}
