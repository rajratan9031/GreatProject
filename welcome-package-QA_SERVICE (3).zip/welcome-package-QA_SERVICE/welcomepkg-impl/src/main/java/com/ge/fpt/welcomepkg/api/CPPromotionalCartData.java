package com.ge.fpt.welcomepkg.api;

import java.util.List;

public class CPPromotionalCartData {
	
	
	private String sso;
	private int upgradeId;
	private String upgradeName;
	private String upgradeDescription;
	private int optionId;
	private String optionName;
	private String optionDescription;
	private String partNumber;
	private int quantity;
	private String indicator;
	public String getSso() {
		return sso;
	}
	public void setSso(String sso) {
		this.sso = sso;
	}
	public int getUpgradeId() {
		return upgradeId;
	}
	public void setUpgradeId(int upgradeId) {
		this.upgradeId = upgradeId;
	}
	public int getOptionId() {
		return optionId;
	}
	public void setOptionId(int optionId) {
		this.optionId = optionId;
	}
	public String getUpgradeName() {
		return upgradeName;
	}
	public void setUpgradeName(String upgradeName) {
		this.upgradeName = upgradeName;
	}
	public String getOptionName() {
		return optionName;
	}
	public void setOptionName(String optionName) {
		this.optionName = optionName;
	}
	public String getOptionDescription() {
		return optionDescription;
	}
	public void setOptionDescription(String optionDescription) {
		this.optionDescription = optionDescription;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public String getUpgradeDescription() {
		return upgradeDescription;
	}
	public void setUpgradeDescription(String upgradeDescription) {
		this.upgradeDescription = upgradeDescription;
	}
	@Override
	public String toString() {
		return "CPPromotionalCartData [sso=" + sso + ", upgradeId=" + upgradeId + ", upgradeName=" + upgradeName
				+ ", upgradeDescription=" + upgradeDescription + ", optionId=" + optionId + ", optionName=" + optionName
				+ ", optionDescription=" + optionDescription + ", partNumber=" + partNumber + ", quantity=" + quantity
				+ "]";
	}
	/**
	 * @return the indicator
	 */
	public String getIndicator() {
		return indicator;
	}
	/**
	 * @param indicator the indicator to set
	 */
	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}
	
	
	
	

}
