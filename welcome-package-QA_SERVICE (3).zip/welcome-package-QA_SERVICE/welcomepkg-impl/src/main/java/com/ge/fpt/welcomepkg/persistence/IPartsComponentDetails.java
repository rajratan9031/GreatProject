package com.ge.fpt.welcomepkg.persistence;

import java.util.HashMap;
import java.util.List;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ge.fpt.welcomepkg.api.PartDataComponents;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import java.io.InputStream;
import javax.ws.rs.core.HttpHeaders;

public interface IPartsComponentDetails {
	@Transactional(propagation=Propagation.REQUIRED)
	List<PartDataComponents> getComponentDetailsForPart(HashMap partData);

	@Transactional(propagation=Propagation.REQUIRED)
	List getcomponentDesc(HashMap partAndComponentData);
	
	@Transactional(propagation=Propagation.REQUIRED)
	StatusInfo savePartDataComponents(List<PartDataComponents> partData);
	
	@Transactional(propagation=Propagation.REQUIRED)
	StatusInfo getAssemblyDataToUpload(HashMap getCompleteData);
	
	@Transactional(propagation=Propagation.REQUIRED)
	StatusInfo deleteKitComponent(String sso, String partNo);
	
	@Transactional(propagation=Propagation.REQUIRED)
	StatusInfo digitalDataUpload(InputStream file,HttpHeaders httpHeaders);

	@Transactional(propagation=Propagation.REQUIRED)
	StatusInfo saveFilePath(String serialNumber, String recSource, String fileName, String filePath);

	@Transactional(propagation=Propagation.REQUIRED)
	StatusInfo getSerialExcelDataToPersist(HashMap excelData);
	
	@Transactional(propagation=Propagation.REQUIRED)
	int getFileImageDataCount(String serialNumber);
}
