package com.ge.fpt.welcomepkg.persistence;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;

public class SPIRReportDataPersistenceImpl implements ISPIRReportDataPersistence{
	@SuppressWarnings("javadoc")
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory.getLogger(SPIRReportDataPersistenceImpl.class);

	//static final int SQL_RETURN_RECORD_LIMIT = 25;


	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;

	/**
	 * Data source for the JDBC
	 */
	DataSource dataSource;

	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;

	/**
	 * @return the dataSource
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}

	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	@SuppressWarnings("nls")
	@Override
	public StatusInfo getExcelDataToPersist(Map getCompleteData){
		StatusInfo result = new StatusInfo();
		List<List<String>> getCompleteExcelData = (List<List<String>>) getCompleteData.get("getExcelData");
		String ssoID = (String) getCompleteData.get("sso_id");
		String factory = (String) getCompleteData.get("factory");
		DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
		Date date = new Date();
		String currDate = dateFormat.format(date);
		logger.info("Inside getExcelDataToPersist :: "+getCompleteExcelData.size());
		try{
			if(getCompleteExcelData.size() > 1){
				String deleQuery="delete from fptods.sqt_wip_spir_report where  created_by = '"+ssoID+"' ";
				this.jdbcTemplate.update(deleQuery);
				logger.info("Delete Done :: ");
				for(int i=1;i<getCompleteExcelData.size();i++){
					String Query = "Insert into fptods.sqt_wip_spir_report(VALVE_SRNO ,SPARE_PARTS_CODE,PART_NO ,DESCRIPTION,QUANTITY,CURRENCY,BUBBLE_CODE ,"+
									"	PURCHASE_ORDER_NUMBER,PO_DATE,SOLD_TO_PARTY,SOLD_TO_NAME,SHIP_TO_PARTY,SHIP_TO_NAME,"+
									"	END_USER,END_USER_NAME,END_USER_COUNTRY,SALES_ORGANISATION,DISTRIBUTION_CHANNEL,"+
									"	DIVISION1,SALES_DOCUMENT_TYPE,SALES_OFFICE,SALES_GROUP,REQUESTED_DELIV_DATE,"+
									"	PLANT,PURCHASE_ORDER_TYPE,YOUR_REFERENCE,PURCHASE_ORDER_TYPE_1,YOUR_REFERENCE_1,"+
									"	CUSTOMER_MATERIAL_NUMBER,PROJECT,SO_REF,ITEM,TAG,VALVE_DESCRIPTION,DOCUMENT,"+
									"	MATERIAL,LIST_PRICE,DISCOUNT,ADD_DISCOUNT,SELLING_PRICE,TOTAL,DELIVERY_DATE,"+
									"	WEIGHT,CREATED_BY,CREATED_TIME,FACTORY) "+
									"values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
					
					Object[] params = new Object[] {getCompleteExcelData.get(i).get(0),getCompleteExcelData.get(i).get(1),
							getCompleteExcelData.get(i).get(2),getCompleteExcelData.get(i).get(3),getCompleteExcelData.get(i).get(4),getCompleteExcelData.get(i).get(5),
							getCompleteExcelData.get(i).get(6),getCompleteExcelData.get(i).get(7),getCompleteExcelData.get(i).get(8),getCompleteExcelData.get(i).get(9),
							getCompleteExcelData.get(i).get(10),getCompleteExcelData.get(i).get(11),getCompleteExcelData.get(i).get(12),getCompleteExcelData.get(i).get(13),
							getCompleteExcelData.get(i).get(14),getCompleteExcelData.get(i).get(15),getCompleteExcelData.get(i).get(16),getCompleteExcelData.get(i).get(17),
							getCompleteExcelData.get(i).get(18),getCompleteExcelData.get(i).get(19),getCompleteExcelData.get(i).get(20),getCompleteExcelData.get(i).get(21),
							getCompleteExcelData.get(i).get(22),getCompleteExcelData.get(i).get(23),getCompleteExcelData.get(i).get(24),getCompleteExcelData.get(i).get(25),
							getCompleteExcelData.get(i).get(26),getCompleteExcelData.get(i).get(27),getCompleteExcelData.get(i).get(28),getCompleteExcelData.get(i).get(29),
							getCompleteExcelData.get(i).get(30),getCompleteExcelData.get(i).get(31),getCompleteExcelData.get(i).get(32),getCompleteExcelData.get(i).get(33),
							getCompleteExcelData.get(i).get(34),getCompleteExcelData.get(i).get(35),getCompleteExcelData.get(i).get(36),getCompleteExcelData.get(i).get(37),
							getCompleteExcelData.get(i).get(38),getCompleteExcelData.get(i).get(39),getCompleteExcelData.get(i).get(40),getCompleteExcelData.get(i).get(41),
							getCompleteExcelData.get(i).get(42),ssoID,currDate,factory};
					
							this.jdbcTemplate.update(Query,params);
							
				}
				logger.info("insert Done :: ");
				result.setStatusCode(0);
				result.setStatusMessage("File Uploaded successfully.");
			}else{
				result.setStatusCode(1);
				result.setStatusMessage("No Data found in excel to upload.");
			}
		}catch(Exception ex){
			logger.info("File Upload Data Insertion Exception :: "+ex);
			result.setStatusCode(-1);
			result.setStatusMessage(ex.getMessage());
		}
		return result;
	}
	
	
	
	
	
}
