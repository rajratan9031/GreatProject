/**
 * 
 */
package com.ge.fpt.welcomepkg.persistence;

import java.util.List;

import com.ge.fpt.welcomepkg.api.AlfrescoDocumentDetail;

/**
 * @author 212670449
 *
 */
public interface IAlfrescoDocumentPersistence {

	List<AlfrescoDocumentDetail> getAllDocDetails();
	
	AlfrescoDocumentDetail getDocumentsBySerialNumber(String serialNumber);
}
