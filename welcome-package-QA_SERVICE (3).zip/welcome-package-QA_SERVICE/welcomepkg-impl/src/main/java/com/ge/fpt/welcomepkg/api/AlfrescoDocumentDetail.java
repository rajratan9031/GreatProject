package com.ge.fpt.welcomepkg.api;

public class AlfrescoDocumentDetail {

	private String siteCode;
	private String typeFlowProject;
	private String categoryNuclearCommercial;
	private String salesOrderNumber;
	private String salesOrderLineNumber;
	private String productionOrderNumber;
	private String serialNumber;
	private String documentType;
	private String docDesc;
	private String fileName;
	private String fileLink;
	/**
	 * @return the siteCode
	 */
	public String getSiteCode() {
		return siteCode;
	}
	/**
	 * @param siteCode the siteCode to set
	 */
	public void setSiteCode(String siteCode) {
		this.siteCode = siteCode;
	}
	/**
	 * @return the typeFlowProject
	 */
	public String getTypeFlowProject() {
		return typeFlowProject;
	}
	/**
	 * @param typeFlowProject the typeFlowProject to set
	 */
	public void setTypeFlowProject(String typeFlowProject) {
		this.typeFlowProject = typeFlowProject;
	}
	/**
	 * @return the categoryNuclearCommercial
	 */
	public String getCategoryNuclearCommercial() {
		return categoryNuclearCommercial;
	}
	/**
	 * @param categoryNuclearCommercial the categoryNuclearCommercial to set
	 */
	public void setCategoryNuclearCommercial(String categoryNuclearCommercial) {
		this.categoryNuclearCommercial = categoryNuclearCommercial;
	}
	/**
	 * @return the salesOrderNumber
	 */
	public String getSalesOrderNumber() {
		return salesOrderNumber;
	}
	/**
	 * @param salesOrderNumber the salesOrderNumber to set
	 */
	public void setSalesOrderNumber(String salesOrderNumber) {
		this.salesOrderNumber = salesOrderNumber;
	}
	/**
	 * @return the salesOrderLineNumber
	 */
	public String getSalesOrderLineNumber() {
		return salesOrderLineNumber;
	}
	/**
	 * @param salesOrderLineNumber the salesOrderLineNumber to set
	 */
	public void setSalesOrderLineNumber(String salesOrderLineNumber) {
		this.salesOrderLineNumber = salesOrderLineNumber;
	}
	/**
	 * @return the productionOrderNumber
	 */
	public String getProductionOrderNumber() {
		return productionOrderNumber;
	}
	/**
	 * @param productionOrderNumber the productionOrderNumber to set
	 */
	public void setProductionOrderNumber(String productionOrderNumber) {
		this.productionOrderNumber = productionOrderNumber;
	}
	/**
	 * @return the serialNumber
	 */
	public String getSerialNumber() {
		return serialNumber;
	}
	/**
	 * @param serialNumber the serialNumber to set
	 */
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	/**
	 * @return the documentType
	 */
	public String getDocumentType() {
		return documentType;
	}
	/**
	 * @param documentType the documentType to set
	 */
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	/**
	 * @return the docDesc
	 */
	public String getDocDesc() {
		return docDesc;
	}
	/**
	 * @param docDesc the docDesc to set
	 */
	public void setDocDesc(String docDesc) {
		this.docDesc = docDesc;
	}
	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}
	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	/**
	 * @return the fileLink
	 */
	public String getFileLink() {
		return fileLink;
	}
	/**
	 * @param fileLink the fileLink to set
	 */
	public void setFileLink(String fileLink) {
		this.fileLink = fileLink;
	}
	
	
}
