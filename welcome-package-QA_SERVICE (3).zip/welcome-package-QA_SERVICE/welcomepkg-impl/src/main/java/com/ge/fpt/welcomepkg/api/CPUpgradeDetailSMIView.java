package com.ge.fpt.welcomepkg.api;

import java.util.List;

public class CPUpgradeDetailSMIView {
	
	private int upgradeId;
	List<CPUpgradeDocument> upgradeDocuments;
	List<CPUpgradeParts> upgradeParts;
	
	
	public int getUpgradeId() {
		return upgradeId;
	}
	public void setUpgradeId(int upgradeId) {
		this.upgradeId = upgradeId;
	}
	
	
	public List<CPUpgradeDocument> getUpgradeDocuments() {
		return upgradeDocuments;
	}
	public void setUpgradeDocuments(List<CPUpgradeDocument> upgradeDocuments) {
		this.upgradeDocuments = upgradeDocuments;
	}
	public List<CPUpgradeParts> getUpgradeParts() {
		return upgradeParts;
	}
	public void setUpgradeParts(List<CPUpgradeParts> upgradeParts) {
		this.upgradeParts = upgradeParts;
	}
	@Override
	public String toString() {
		return "CPUpgradeDetailSMIView [upgradeId=" + upgradeId + ", upgradeDocuments=" + upgradeDocuments + ", upgradeParts=" + upgradeParts + "]";
	}
	
	
	

}
