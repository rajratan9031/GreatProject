package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;

public class CountryDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String country_code;
	private String country;
	
	public String getCountry_code() {
		return country_code;
	}
	public void setCountry_code(String country_code) {
		this.country_code = country_code;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	@Override
	public String toString() {
		return "CountryDTO [country_code=" + country_code + ", country=" + country + "]";
	}
	
	
}
