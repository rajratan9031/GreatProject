package com.ge.fpt.welcomepkg.api;

import java.sql.Date;

public class DocumentDetails {

	private String siteCode;
	private String typeFlowProject;
	private String categoryNuclearCommercial;
	private String salesOrderNumber;
	private String salesOrderLineNumber;
	private String productionOrderNumber;
	private String serialNumber;
	private String documentType;
	private String docDesc;
	private String fileName;
	private String fileLink;
	private Integer uniqId;
	private String projectNumber;
	private String documentLanguage;
	private String document_content_type;
	private String sourceSystem;
	private Date creationDate;
	private Date lastUpdateDate;
	private String iresource;
	private String iserialnumber;
	private String amd5;
	
	
	
	public String getIresource() {
		return iresource;
	}
	public void setIresource(String iresource) {
		this.iresource = iresource;
	}
	public String getIserialnumber() {
		return iserialnumber;
	}
	public void setIserialnumber(String iserialnumber) {
		this.iserialnumber = iserialnumber;
	}
	public String getAmd5() {
		return amd5;
	}
	public void setAmd5(String amd5) {
		this.amd5 = amd5;
	}
	/**
	 * @return the siteCode
	 */
	public String getSiteCode() {
		return siteCode;
	}
	/**
	 * @param siteCode the siteCode to set
	 */
	public void setSiteCode(String siteCode) {
		this.siteCode = siteCode;
	}
	/**
	 * @return the typeFlowProject
	 */
	public String getTypeFlowProject() {
		return typeFlowProject;
	}
	/**
	 * @param typeFlowProject the typeFlowProject to set
	 */
	public void setTypeFlowProject(String typeFlowProject) {
		this.typeFlowProject = typeFlowProject;
	}
	/**
	 * @return the categoryNuclearCommercial
	 */
	public String getCategoryNuclearCommercial() {
		return categoryNuclearCommercial;
	}
	/**
	 * @param categoryNuclearCommercial the categoryNuclearCommercial to set
	 */
	public void setCategoryNuclearCommercial(String categoryNuclearCommercial) {
		this.categoryNuclearCommercial = categoryNuclearCommercial;
	}
	/**
	 * @return the salesOrderNumber
	 */
	public String getSalesOrderNumber() {
		return salesOrderNumber;
	}
	/**
	 * @param salesOrderNumber the salesOrderNumber to set
	 */
	public void setSalesOrderNumber(String salesOrderNumber) {
		this.salesOrderNumber = salesOrderNumber;
	}
	/**
	 * @return the salesOrderLineNumber
	 */
	public String getSalesOrderLineNumber() {
		return salesOrderLineNumber;
	}
	/**
	 * @param salesOrderLineNumber the salesOrderLineNumber to set
	 */
	public void setSalesOrderLineNumber(String salesOrderLineNumber) {
		this.salesOrderLineNumber = salesOrderLineNumber;
	}
	/**
	 * @return the productionOrderNumber
	 */
	public String getProductionOrderNumber() {
		return productionOrderNumber;
	}
	/**
	 * @param productionOrderNumber the productionOrderNumber to set
	 */
	public void setProductionOrderNumber(String productionOrderNumber) {
		this.productionOrderNumber = productionOrderNumber;
	}
	/**
	 * @return the serialNumber
	 */
	public String getSerialNumber() {
		return serialNumber;
	}
	/**
	 * @param serialNumber the serialNumber to set
	 */
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	/**
	 * @return the documentType
	 */
	public String getDocumentType() {
		return documentType;
	}
	/**
	 * @param documentType the documentType to set
	 */
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	/**
	 * @return the docDesc
	 */
	public String getDocDesc() {
		return docDesc;
	}
	/**
	 * @param docDesc the docDesc to set
	 */
	public void setDocDesc(String docDesc) {
		this.docDesc = docDesc;
	}
	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}
	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	/**
	 * @return the fileLink
	 */
	public String getFileLink() {
		return fileLink;
	}
	/**
	 * @param fileLink the fileLink to set
	 */
	public void setFileLink(String fileLink) {
		this.fileLink = fileLink;
	}
	public Integer getUniqId() {
		return uniqId;
	}
	public void setUniqId(Integer uniqId) {
		this.uniqId = uniqId;
	}
	public String getProjectNumber() {
		return projectNumber;
	}
	public void setProjectNumber(String projectNumber) {
		this.projectNumber = projectNumber;
	}
	public String getDocumentLanguage() {
		return documentLanguage;
	}
	public void setDocumentLanguage(String documentLanguage) {
		this.documentLanguage = documentLanguage;
	}
	public String getDocument_content_type() {
		return document_content_type;
	}
	public void setDocument_content_type(String document_content_type) {
		this.document_content_type = document_content_type;
	}
	public String getSourceSystem() {
		return sourceSystem;
	}
	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}
	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}
	
	
}
