package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class UsersDataManagmentMaster implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String customerId;
	private String customerName;
	private String plantId;
	private String plantLocation;
	private String sso;
	private String region;
	private String createdBy;
	private Date createdDate;
	private String updatedBy;
	private Date updatedDate;
	private String isActive;
	private String country;
	private String dunsNumber;
	private String oldSSO;
	private String oldPlantId;


	public UsersDataManagmentMaster() {
		super();
		// TODO Auto-generated constructor stub
	}


	/**
	 * @param customerId
	 * @param customerName
	 * @param plantId
	 * @param plantLocation
	 * @param sso
	 * @param region
	 * @param createdBy
	 * @param createdDate
	 * @param updatedBy
	 * @param updatedDate
	 * @param isActive
	 * @param country
	 * @param dunsNumber
	 * @param oldSSO
	 * @param oldPlantId
	 */
	public UsersDataManagmentMaster(String customerId, String customerName, String plantId, String plantLocation,
			String sso, String region, String createdBy, Date createdDate, String updatedBy, Date updatedDate,
			String isActive, String country, String dunsNumber, String oldSSO, String oldPlantId) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.plantId = plantId;
		this.plantLocation = plantLocation;
		this.sso = sso;
		this.region = region;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.updatedBy = updatedBy;
		this.updatedDate = updatedDate;
		this.isActive = isActive;
		this.country = country;
		this.dunsNumber = dunsNumber;
		this.oldSSO = oldSSO;
		this.oldPlantId = oldPlantId;
	}


	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getPlantId() {
		return plantId;
	}

	public void setPlantId(String plantId) {
		this.plantId = plantId;
	}

	public String getPlantLocation() {
		return plantLocation;
	}

	public void setPlantLocation(String plantLocation) {
		this.plantLocation = plantLocation;
	}

	public String getSso() {
		return sso;
	}

	public void setSso(String sso) {
		this.sso = sso;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getDunsNumber() {
		return dunsNumber;
	}

	public void setDunsNumber(String dunsNumber) {
		this.dunsNumber = dunsNumber;
	}

	public String getOldSSO() {
		return oldSSO;
	}

	public void setOldSSO(String oldSSO) {
		this.oldSSO = oldSSO;
	}

	public String getOldPlantId() {
		return oldPlantId;
	}

	public void setOldPlantId(String oldPlantId) {
		this.oldPlantId = oldPlantId;
	}
	
	
}
