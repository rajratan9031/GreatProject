/*
 * Copyright (c) 2013 GE Global Research. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Global Research. The software may be used and/or copied only
 * with the written permission of GE Global Research or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.fpt.welcomepkg.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.fpt.welcomepkg.api.CnDataInfo;
import com.ge.fpt.welcomepkg.api.CustomerDetailsForOrderNumber;
import com.ge.fpt.welcomepkg.api.CustomerDetailsforSerial;
import com.ge.fpt.welcomepkg.api.CustomerInfo;
import com.ge.fpt.welcomepkg.api.CustomerLinkMaster;
import com.ge.fpt.welcomepkg.api.CustomerLinkMasterModel;
import com.ge.fpt.welcomepkg.api.OrderInfo;
import com.ge.fpt.welcomepkg.api.PlantDataManagmentMaster;
import com.ge.fpt.welcomepkg.api.PlantDataMaster;
import com.ge.fpt.welcomepkg.api.ProjectDataMaster;
import com.ge.fpt.welcomepkg.api.SalesSerial;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.api.UserSettings;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;
import com.ge.fpt.welcomepkg.impl.WelcomePkgServiceImpl;
import com.ge.fpt.welcomepkg.util.QueryConstants;

/**
 * @author 212414241
 * 
 */
public class OrderPersistenceImpl implements IOrderPersistence {
	@SuppressWarnings("javadoc")
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory.getLogger(OrderPersistenceImpl.class);

	static final int SQL_RETURN_RECORD_LIMIT = 10;

	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;

	/**
	 * Data source for the JDBC
	 */
	DataSource dataSource;

	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;

	NamedParameterJdbcTemplate namedParamTemplate;

	/**
	 * @return the dataSource
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}

	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate= new NamedParameterJdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	private String getSettingsClause(UserSettings settings) {
		String result = "";
		String dateRange = settings == null ? "" : settings.getDateRange();
		String brand = settings == null ? "" : settings.getBrand();
		String interCompany=settings==null?"":settings.getInterCompany();
		List<String> conditions = new ArrayList<String>();

		if (brand != null && !brand.trim().equals("")) {
			conditions.add("(PRODUCT_CODE IN (" + brand + ") OR PRODUCT_CODE IS NULL)");
		}
		if (interCompany!=null && interCompany.trim().equalsIgnoreCase("N")){
			conditions.add("INTER_COMPANY is null ");
		}

		if (dateRange != null && !dateRange.trim().equals("")) {
			Integer dateRangeInt = Integer.parseInt(dateRange);

			if (dateRangeInt != 30 && dateRangeInt != 60 && dateRangeInt != 90 && dateRangeInt != -1) {
				logger.error("Get Orders by SSO Error: Invalid date range");
				return null;
			}if (dateRangeInt != -1) {
				String rangeStr = "sysdate - " + dateRangeInt.toString();

				conditions.add("(LAST_UPDATE_DATE >= " + rangeStr + ")");
			}
		}

		if (conditions.size() > 0) {
			String condStr = "";

			for (int i = 0; i < conditions.size(); i++) {
				condStr += ((condStr.equals("") ? "" : " AND ") + conditions.get(i));
			}

			result = condStr;
		}

		return result;
	}

	private String getGlobalFilterClause() {
		String filter = "";

		filter = " ((UPPER(SALES_ORDER) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(COUNT_VAL) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(CUSTOMER_PO) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(SOLD_TO_CUSTOMER_NAME) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(SOLD_TO_CITY) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(SOLD_TO_STATE) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(SOLD_TO_COUNTRY) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(REP_NAME) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(SOURCESYSTEM) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(END_USER_INDUSTRY) LIKE '%' || :globalSearch || '%')" +
				" OR (UPPER(PRODUCT_CODE) LIKE '%' || :globalSearch || '%')" +
				" OR (TO_CHAR(LAST_UPDATE_DATE, 'YYYY/MM/DD') LIKE '%' || :globalSearch || '%'))";
				//" OR (UPPER(LINK_CUSTOMER_NAME) LIKE '%' || :globalSearch || '%'))"+
		       // " OR (UPPER(CUST_ID) LIKE '%' || :globalSearch || '%'))";
		return filter;
	}

	private String getFilterClause(OrderInfo orderInfo,boolean blanketSearch) {
		String filter="";
		List<String> conditions = new ArrayList<String>();
		if(orderInfo!=null){
			if(orderInfo.getSalesOrder()!=null && !orderInfo.getSalesOrder().isEmpty()){
				conditions.add(" UPPER(SALES_ORDER) LIKE '%' || :salesOrder || '%'");
			}
			if(orderInfo.getCustomerPo()!=null && !orderInfo.getCustomerPo().isEmpty()){
				if(blanketSearch){
					//conditions.add("C_PO LIKE '%'|| :customerPo || '%'");
					conditions.add(" UPPER(CUSTOMER_PO) LIKE '%' || :customerPo || '%'");
				}else{
					conditions.add(" UPPER(CUSTOMER_PO) LIKE '%' || :customerPo || '%'");
				}
			}
			if(orderInfo.getValveCnt()!=null && !orderInfo.getValveCnt().isEmpty()){
				conditions.add(" COUNT_VAL LIKE '%' || :valveCnt || '%'");
			}
			if(orderInfo.getSoldToCustName()!=null && !orderInfo.getSoldToCustName().isEmpty()){
				conditions.add(" UPPER(SOLD_TO_CUSTOMER_NAME) LIKE '%' || :soldToCustName || '%'");
			}
			if(orderInfo.getSoldToCustCity()!=null && !orderInfo.getSoldToCustCity().isEmpty()){
				conditions.add(" UPPER(SOLD_TO_CITY) LIKE '%' || :soldToCity || '%'");
			}
			if(orderInfo.getSoldToCustState()!=null && !orderInfo.getSoldToCustState().isEmpty()){
				conditions.add(" UPPER(SOLD_TO_STATE) LIKE '%' || :soldToState || '%'");
			}
			if(orderInfo.getSoldToCustCountry()!=null && !orderInfo.getSoldToCustCountry().isEmpty()){
				conditions.add(" UPPER(SOLD_TO_COUNTRY) LIKE '%' || :soldToCountry || '%'");
			}
			if(orderInfo.getRepName()!=null && !orderInfo.getRepName().isEmpty()){
				conditions.add(" UPPER(REP_NAME) LIKE '%' || :repName || '%'");
			}
			if(orderInfo.getSourceSystem()!=null && !orderInfo.getSourceSystem().isEmpty()){
				conditions.add(" UPPER(SOURCESYSTEM) LIKE '%' || :sourceSystem || '%'");
			}
			if(orderInfo.getEndUserIndustry()!=null && !orderInfo.getEndUserIndustry().isEmpty()){
				conditions.add(" UPPER(END_USER_INDUSTRY) LIKE '%' || :endUserIndustry || '%'");
			}
			if(orderInfo.getProductCode()!=null && !orderInfo.getProductCode().isEmpty()){
				conditions.add(" UPPER(PRODUCT_CODE) LIKE '%' || :productCode || '%'");
			}
			if(orderInfo.getLastUpdateDateStr()!=null && !orderInfo.getLastUpdateDateStr().isEmpty()){
				conditions.add(" TO_CHAR(LAST_UPDATE_DATE, 'YYYY/MM/DD') LIKE '%' || :lastUpdateDate || '%'");
			}
			/*if(orderInfo.getLinkCustomerName()!=null && !orderInfo.getLinkCustomerName().isEmpty()){
				conditions.add(" UPPER(LINK_CUSTOMER_NAME) LIKE '%' || :linkCustomerName || '%'");
			}
			if(orderInfo.getCustId()!=null && !orderInfo.getCustId().isEmpty()){
				conditions.add(" UPPER(CUST_ID) LIKE '%' || :custId || '%'");
			}*/

		} 
		if (conditions.size() > 0) {
			String condStr = "";

			for (int i = 0; i < conditions.size(); i++) {
				condStr += ((condStr.equals("") ? "" : " AND ") + conditions.get(i));
			}

			filter = condStr;
		}return filter;
	}

	private Map<String, String> setFilterParams(String globalSearch, OrderInfo orderInfo,boolean blanketSearch) {

		Map<String, String> result = new HashMap<String, String>();

		result.put("globalSearch", globalSearch == null ? "" : globalSearch.toUpperCase());
		result.put("salesOrder", orderInfo.getSalesOrder() == null ? "" : orderInfo.getSalesOrder().toUpperCase());
		if(blanketSearch && orderInfo.getCustomerPo()!=null){
			/*String cPO=orderInfo.getCustomerPo().replaceAll("[^\\dA-Za-z ]", "").replaceAll("\\s+", "%");
			result.put("customerPo", cPO.toUpperCase());*/
			result.put("customerPo", orderInfo.getCustomerPo() == null ? "" : orderInfo.getCustomerPo().toUpperCase());
		}else{
			result.put("customerPo", orderInfo.getCustomerPo() == null ? "" : orderInfo.getCustomerPo().toUpperCase());
		}
		result.put("valveCnt", orderInfo.getValveCnt() == null ? "" : orderInfo.getValveCnt());
		result.put("soldToCustName", orderInfo.getSoldToCustName() == null ? "" : orderInfo.getSoldToCustName().toUpperCase());
		result.put("soldToCity", orderInfo.getSoldToCustCity() == null ? "" : orderInfo.getSoldToCustCity().toUpperCase());
		result.put("soldToState", orderInfo.getSoldToCustState() == null ? "" : orderInfo.getSoldToCustState().toUpperCase());
		result.put("soldToCountry", orderInfo.getSoldToCustCountry() == null ? "" : orderInfo.getSoldToCustCountry().toUpperCase());
		result.put("repName", orderInfo.getRepName() == null ? "" : orderInfo.getRepName().toUpperCase());
		result.put("sourceSystem", orderInfo.getSourceSystem() == null ? "" : orderInfo.getSourceSystem().toUpperCase());
		result.put("endUserIndustry", orderInfo.getEndUserIndustry() == null ? "" : orderInfo.getEndUserIndustry().toUpperCase());
		result.put("productCode", orderInfo.getProductCode() == null ? "" : orderInfo.getProductCode().toUpperCase());
		result.put("lastUpdateDate", orderInfo.getLastUpdateDateStr() == null ? "" : orderInfo.getLastUpdateDateStr().toUpperCase());
		/*result.put("linkCustomerName", orderInfo.getLinkCustomerName() == null ? "" : orderInfo.getLinkCustomerName().toUpperCase());
		result.put("custId", orderInfo.getCustId() == null ? "" : orderInfo.getCustId());*/

			
		return result;
	}



	@Override
	public int getOrdersCount(String sso, UserSettings settings,OrderInfo orderInfo, String globalSearch,boolean blanketSearch,String serialNo, String partNo,String tagNo,String fileName,String engineeredValve){
		int result = 0;
		String sql="";
		String settingsClause="";
        String SSO = sso.toUpperCase();

		try {
			boolean isInternal = WelcomePkgServiceImpl.isInternalUser(sso);
			if(!blanketSearch){
				if(isInternal) {
					if(engineeredValve.equals("Y")) {
						sql="SELECT COUNT(*) FROM DDSAFM.ODS_SQT_BY_SALES_ORDER_SSO_GE WHERE 1=1 AND ENGINEERED_VALVE="+"'"+engineeredValve+"'";
					} else {
						sql="SELECT COUNT(*) FROM DDSAFM.ODS_SQT_BY_SALES_ORDER_SSO_GE WHERE 1=1";
					}
					
				} else {
					if(engineeredValve.equals("Y")) {
						sql="SELECT COUNT(*) FROM DDSAFM.ODS_SQT_BY_SALES_ORDER_SSO WHERE 1=1 AND UPPER(SSO) = :sso AND ENGINEERED_VALVE="+"'"+engineeredValve+"'";
					} else {
						sql="SELECT COUNT(*) FROM DDSAFM.ODS_SQT_BY_SALES_ORDER_SSO WHERE 1=1 AND UPPER(SSO) = :sso ";
					}
					
				}
			}else{
				sql="SELECT COUNT(*) FROM DDSAFM.ODS_CHECK_EXISTS_SO_MV WHERE 1=1 ";
			}
			if(!blanketSearch){
				settingsClause=getSettingsClause(settings);
			}

			if (!settingsClause.trim().equals("")) {
				sql+=" AND "+ settingsClause;
			}

			if (!globalSearch.trim().isEmpty()) {
				String globalFilterClause = getGlobalFilterClause();			
				sql += " AND " + globalFilterClause;
			}

			String filterClause=getFilterClause(orderInfo,blanketSearch);		

			if (!filterClause.trim().equals("")) {
				sql+=" AND "+ filterClause;
			}

            logger.info("FINAL QUERY FOR getOrdersCount IS ::"+sql);

			MapSqlParameterSource parameters = new MapSqlParameterSource(setFilterParams(globalSearch, orderInfo,blanketSearch));
			if (!isInternal) {
				parameters.addValue("sso", SSO);
			}
			result=this.namedParamTemplate.queryForInt(sql, parameters);
		}catch (Exception ex) {
			logger.error("Get orders count error: ", ex);
			result = -1;
		}
		return result;
	}





	public List<OrderInfo> getOrdersBySSO(String sso, UserSettings settings, int page, int rowsPerPage,String sortCol,String sortOrder,OrderInfo orderInfo, String globalSearch,boolean blanketSearch,String serialNo, String partNo,String tagNo,String fileName, String engineeredValve){
		List<OrderInfo> orders = null;
		List<OrderInfo> finalResults = new ArrayList<OrderInfo>();

		boolean isInternal =false;
		//logger.error("GetOrdersBySSO  :"+engineeredValve);

		try{
			//boolean isInternal = WelcomePkgServiceImpl.isInternalUser(sso);
			isInternal = WelcomePkgServiceImpl.isInternalUser(sso);
			String settingsClause="";
			String sql = "";
			String upperCaseSSO = sso.toUpperCase();
			sql = "SELECT DISTINCT ORDER_NUMBER FROM FPTODS.SQT_SSO_CONVERTED ORDER BY ORDER_NUMBER";
			List<Long> convOrders = this.jdbcTemplate.queryForList(sql, Long.class); 


			String sortColSql = sortCol != null && !sortCol.equalsIgnoreCase("") ? "order by " + sortCol : "";
			String sortOrderSql = sortOrder != null && !sortOrder.equalsIgnoreCase("") ? sortOrder : "";

			String rowNumOrderSql = sortColSql.equalsIgnoreCase("") ? "ORDER BY last_update_date desc" : sortColSql + " " + sortOrderSql;

			sql="SELECT * FROM (";

			if(!blanketSearch){
				if(isInternal) {
					if(engineeredValve.equals("Y")) {
						sql+="SELECT ROW_NUMBER() OVER (" + rowNumOrderSql + ") rn ,a.* FROM DDSAFM.ODS_SQT_BY_SALES_ORDER_SSO_GE a WHERE 1=1 AND ENGINEERED_VALVE ="+"'"+engineeredValve+"'";

						/*sql+="SELECT ROW_NUMBER() OVER (" + rowNumOrderSql + ") rn ,a.* from (SELECT distinct REC_SOURCE,SALES_ORDER,CUSTOMER_PO,SOLD_TO_CUSTOMER_NAME,SOLD_TO_COUNTRY,SOLD_TO_STATE,"
                                                + "SOLD_TO_PROVINCE,SOLD_TO_CITY,REP_NAME,SOURCESYSTEM,END_USER,END_USER_INDUSTRY,ORDER_ID,LAST_UPDATE_DATE,COUNT_VAL,SERIALIZABLE,ENGINEERED_VALVE,"
                                                + "t.LINK_CUSTOMER_NAME,t.CUST_ID,PRODUCT_CODE FROM (SELECT  x.*, row_number() OVER( ORDER BY LAST_UPDATE_DATE DESC) AS RANKVAL "
                                                + "fROM DDSAFM.ODS_SQT_BY_SALES_ORDER_SSO_GE x) a LEFT OUTER JOIN (select m.ORDER_NUMBER,m.LINK_CUSTOMER_NAME,m.CUST_ID,m.REC_SOURCE as source, row_number() over(PARTITION BY CUSTOMER_NAME,"
                                                + "ORDER_NUMBER,rec_source ORDER BY serial_number DESC) AS rn  from fptods.CUSTOMER_LINK_MASTER_T m) t on T.ORDER_NUMBER= A.SALES_ORDER and t.source=a.REC_SOURCE "
                                                + "where  1=1 AND ENGINEERED_VALVE ="+"'"+engineeredValve+"'";*/
					} else {
						sql+="SELECT ROW_NUMBER() OVER (" + rowNumOrderSql + ") rn ,a.* FROM DDSAFM.ODS_SQT_BY_SALES_ORDER_SSO_GE a WHERE 1=1 " ;

						/*sql+="SELECT ROW_NUMBER() OVER (" + rowNumOrderSql + ") rn ,a.* from (SELECT distinct REC_SOURCE,SALES_ORDER,CUSTOMER_PO,SOLD_TO_CUSTOMER_NAME,SOLD_TO_COUNTRY,SOLD_TO_STATE,"
                                                + "SOLD_TO_PROVINCE,SOLD_TO_CITY,REP_NAME,SOURCESYSTEM,END_USER,END_USER_INDUSTRY,ORDER_ID,LAST_UPDATE_DATE,COUNT_VAL,SERIALIZABLE,ENGINEERED_VALVE,"
                                                + "t.LINK_CUSTOMER_NAME,t.CUST_ID,PRODUCT_CODE FROM (SELECT  x.*, row_number() OVER( ORDER BY LAST_UPDATE_DATE DESC) AS RANKVAL "
                                                + "fROM DDSAFM.ODS_SQT_BY_SALES_ORDER_SSO_GE x) a LEFT OUTER JOIN (select m.ORDER_NUMBER,m.LINK_CUSTOMER_NAME,m.CUST_ID,m.REC_SOURCE as source, row_number() over(PARTITION BY CUSTOMER_NAME,"
                                                + "ORDER_NUMBER,rec_source ORDER BY serial_number DESC) AS rn  from fptods.CUSTOMER_LINK_MASTER_T m) t on T.ORDER_NUMBER= A.SALES_ORDER and t.source=a.REC_SOURCE "
                                                + "where  1=1 ";*/
					}

				}else {
					if(engineeredValve.equals("Y")) {
						sql+="SELECT ROW_NUMBER() OVER (" + rowNumOrderSql + ") rn ,a.* FROM DDSAFM.ODS_SQT_BY_SALES_ORDER_SSO a WHERE 1=1 AND UPPER(SSO) = :sso AND ENGINEERED_VALVE ="+"'"+engineeredValve+"'";

						/*sql+="SELECT ROW_NUMBER() OVER (" + rowNumOrderSql + ") rn ,a.* from (SELECT distinct REC_SOURCE, ORDER_ID, SALES_ORDER, CUSTOMER_PO, SOLD_TO_CUSTOMER_NAME,SOLD_TO_COUNTRY, SOLD_TO_STATE, SOLD_TO_PROVINCE, SOLD_TO_CITY, REP_NAME,SOURCESYSTEM, CHANNEL, USERNAME, SSO, DATE_LAST, END_USER, END_USER_INDUSTRY,PRODUCT_CODE, DUNS, CREATION_DATE, EU_CUST_COUNTRY, EU_CUST_STATE, EU_CUST_CITY,EU_CUST_ZIP, EU_CUST_PROVINCE, INTER_COMPANY, COUNT_VAL, LAST_UPDATE_DATE, SERIALIZABLE,ENGINEERED_VALVE,t.LINK_CUSTOMER_NAME,t.CUST_ID "
                                                + "FROM (SELECT  x.*, row_number() OVER( ORDER BY LAST_UPDATE_DATE DESC) AS RANKVAL "
                                                + "fROM DDSAFM.ODS_SQT_BY_SALES_ORDER_SSO x) a LEFT OUTER JOIN (select m.ORDER_NUMBER,m.LINK_CUSTOMER_NAME,m.CUST_ID,m.REC_SOURCE as source, row_number() over(PARTITION BY CUSTOMER_NAME,"
                                                + "ORDER_NUMBER,rec_source ORDER BY serial_number DESC) AS rn  from fptods.CUSTOMER_LINK_MASTER_T m) t on T.ORDER_NUMBER= A.SALES_ORDER and t.source=a.REC_SOURCE "
                                                + "where  1=1 AND UPPER(SSO) = :sso AND ENGINEERED_VALVE ="+"'"+engineeredValve+"'";*/
					} else {
						sql+="SELECT ROW_NUMBER() OVER (" + rowNumOrderSql + ") rn ,a.* FROM DDSAFM.ODS_SQT_BY_SALES_ORDER_SSO a WHERE 1=1 AND UPPER(SSO) = :sso";


						/*sql+="SELECT ROW_NUMBER() OVER (" + rowNumOrderSql + ") rn ,a.* from (SELECT distinct REC_SOURCE, ORDER_ID, SALES_ORDER, CUSTOMER_PO, SOLD_TO_CUSTOMER_NAME,SOLD_TO_COUNTRY, SOLD_TO_STATE, SOLD_TO_PROVINCE, SOLD_TO_CITY, REP_NAME,SOURCESYSTEM, CHANNEL, USERNAME, SSO, DATE_LAST, END_USER, END_USER_INDUSTRY,PRODUCT_CODE, DUNS, CREATION_DATE, EU_CUST_COUNTRY, EU_CUST_STATE, EU_CUST_CITY,EU_CUST_ZIP, EU_CUST_PROVINCE, INTER_COMPANY, COUNT_VAL, LAST_UPDATE_DATE, SERIALIZABLE,ENGINEERED_VALVE,t.LINK_CUSTOMER_NAME,t.CUST_ID "
                                                + "FROM (SELECT  x.*, row_number() OVER( ORDER BY LAST_UPDATE_DATE DESC) AS RANKVAL "
                                                + "fROM DDSAFM.ODS_SQT_BY_SALES_ORDER_SSO x) a LEFT OUTER JOIN (select m.ORDER_NUMBER,m.LINK_CUSTOMER_NAME,m.CUST_ID,m.REC_SOURCE as source, row_number() over(PARTITION BY CUSTOMER_NAME,"
                                                + "ORDER_NUMBER,rec_source ORDER BY serial_number DESC) AS rn  from fptods.CUSTOMER_LINK_MASTER_T m) t on T.ORDER_NUMBER= A.SALES_ORDER and t.source=a.REC_SOURCE "
                                                + "where  1=1 AND UPPER(SSO) = :sso";*/
					}

				}            
			}else{
				    sql+="SELECT ROW_NUMBER() OVER (" + rowNumOrderSql + ") rn ,a.* FROM DDSAFM.ODS_CHECK_EXISTS_SO_MV a WHERE 1=1 " ;
				/*sql+="SELECT ROW_NUMBER() OVER (" + rowNumOrderSql + ") rn ,a.* from (SELECT distinct ORDER_ID, REC_SOURCE, SOLD_TO_CUSTOMER_NAME, SOLD_TO_COUNTRY, SOLD_TO_STATE, SOLD_TO_PROVINCE,SOLD_TO_CITY, SALES_ORDER, SOURCESYSTEM, REP_NAME, CUSTOMER_PO, C_PO, END_USER, END_USER_INDUSTRY,COUNT_VAL, LAST_UPDATE_DATE, SERIALIZABLE, ENGINEERED_VALVE,t.LINK_CUSTOMER_NAME,t.CUST_ID "
						+ "FROM (SELECT  x.*, row_number() OVER( ORDER BY LAST_UPDATE_DATE DESC) AS RANKVAL "
						+ "fROM DDSAFM.ODS_CHECK_EXISTS_SO_MV x) a LEFT OUTER JOIN (select m.ORDER_NUMBER,m.LINK_CUSTOMER_NAME,m.CUST_ID,m.REC_SOURCE as source,m.order_id as order_identifier, row_number() over(PARTITION BY "
						+ "ORDER_NUMBER,rec_source ORDER BY serial_number DESC) AS rn  from fptods.CUSTOMER_LINK_MASTER_T m) t on t.order_identifier=a.order_id and T.ORDER_NUMBER= A.SALES_ORDER and t.source=a.REC_SOURCE)a "
						+ "where  1=1";*/
			}

			if(!blanketSearch){
				settingsClause=getSettingsClause(settings);
			}
			if (!settingsClause.trim().equals("")) {
				sql+=" AND "+ settingsClause;
			}

			if (!globalSearch.trim().isEmpty()) {
				String globalFilterClause = getGlobalFilterClause();                
				sql += " AND " + globalFilterClause;
			}

			String filterClause=getFilterClause(orderInfo,blanketSearch);            

			if (!filterClause.trim().equals("")) {
				sql+=" AND "+ filterClause;
			}


			MapSqlParameterSource parameters = new MapSqlParameterSource(setFilterParams(globalSearch, orderInfo,blanketSearch));
			if (!isInternal) {
				parameters.addValue("sso", upperCaseSSO);
			}

			if(sortCol!=null && !sortCol.equalsIgnoreCase("")){
				sql+="order by "+sortCol;
			}
			if(sortOrder!=null && !sortOrder.equalsIgnoreCase("")){
				sql+=" "+sortOrder;
			}

			if(!blanketSearch){ 
				//sql += ")a)";     
				sql += ")";
			}else{
				sql += ")";
			}



			if (rowsPerPage > 0) {
				int lowerLimit = rowsPerPage * page;
				int upperLimit = lowerLimit + rowsPerPage;

				String pageLimitClause= " WHERE rn >:lowerLimit AND rn <=:upperLimit";
				parameters.addValue("lowerLimit", lowerLimit);
				parameters.addValue("upperLimit", upperLimit);
				sql+=pageLimitClause;
			}

			logger.info("FINAL SQL QUERY IS "+sql);

			orders=this.namedParamTemplate.query(sql, parameters, new OrderInfoMapper());

			logger.info("order Size:-"+orders.size());

			if (convOrders != null && convOrders.size() > 0) {
				for (int i = 0; i < orders.size(); i++) {
					OrderInfo currOrder = orders.get(i);

					if (convOrders.contains(currOrder.getOrderId()))
						currOrder.setOrderConverted(true);
					else
						currOrder.setOrderConverted(false);

					orders.set(i, currOrder);
				}
			}
		} catch (Exception ex){
			logger.error("Error getOrdersBySSO:", ex);
		}                   
		
		//Start Here :: Link Customer Name For Sales Order
	//if(!blanketSearch){

			for (OrderInfo orderInfo1 : orders) {
				logger.info("orderInfo1"+orderInfo1);
				String sqlForCustomerLinkMasterModel="";
				if(isInternal) {
					logger.info("Inside Internal GE USERS");
					sqlForCustomerLinkMasterModel = "SELECT distinct t.LINK_CUSTOMER_NAME,t.CUST_ID FROM (SELECT  x.*, row_number() OVER( ORDER BY LAST_UPDATE_DATE DESC) AS RANKVAL "
							+ "fROM DDSAFM.ODS_SQT_BY_SALES_ORDER_SSO_GE x) a LEFT OUTER JOIN (select m.ORDER_NUMBER,m.LINK_CUSTOMER_NAME,m.CUST_ID,m.REC_SOURCE as source,m.order_id as order_identifier, row_number() over(PARTITION BY "
							+ "ORDER_NUMBER,rec_source ORDER BY serial_number DESC) AS rn  from fptods.CUSTOMER_LINK_MASTER_T m) t on t.order_identifier=a.order_id and  T.ORDER_NUMBER= A.SALES_ORDER and t.source=a.REC_SOURCE where  1=1  AND SALES_ORDER=:salesOrder";
				}else if(blanketSearch){
					
					logger.info("Inside blanketSearch");
					sqlForCustomerLinkMasterModel = "SELECT distinct t.LINK_CUSTOMER_NAME,t.CUST_ID FROM (SELECT  x.*, row_number() OVER( ORDER BY LAST_UPDATE_DATE DESC) AS RANKVAL "
							+ "fROM DDSAFM.ODS_SQT_BY_SALES_ORDER_SSO_GE x) a LEFT OUTER JOIN (select m.ORDER_NUMBER,m.LINK_CUSTOMER_NAME,m.CUST_ID,m.REC_SOURCE as source,m.order_id as order_identifier, row_number() over(PARTITION BY "
							+ "ORDER_NUMBER,rec_source ORDER BY serial_number DESC) AS rn  from fptods.CUSTOMER_LINK_MASTER_T m) t on t.order_identifier=a.order_id and  T.ORDER_NUMBER= A.SALES_ORDER and t.source=a.REC_SOURCE where  1=1  AND SALES_ORDER=:salesOrder";
				}else{
					logger.info("Inside CHANNEL PATNERS USERS");
					sqlForCustomerLinkMasterModel = "SELECT distinct t.LINK_CUSTOMER_NAME,t.CUST_ID FROM (SELECT  x.*, row_number() OVER( ORDER BY LAST_UPDATE_DATE DESC) AS RANKVAL "
							+ "fROM DDSAFM.ODS_SQT_BY_SALES_ORDER_SSO x) a LEFT OUTER JOIN (select m.ORDER_NUMBER,m.LINK_CUSTOMER_NAME,m.CUST_ID,m.REC_SOURCE as source,m.DUNS_NUMBER as duns,m.order_id as order_identifier, row_number() over(PARTITION BY "
							+ "ORDER_NUMBER,rec_source ORDER BY serial_number DESC) AS rn  from fptods.CUSTOMER_LINK_MASTER_T m) t on t.order_identifier=a.order_id and T.ORDER_NUMBER= A.SALES_ORDER and t.source=a.REC_SOURCE and t.duns=a.DUNS where 1=1  AND SALES_ORDER=:salesOrder";
				}
				MapSqlParameterSource paramMap = new MapSqlParameterSource();
				paramMap.addValue("salesOrder", orderInfo1.getSalesOrder());
				logger.info("sqlForCustomerLinkMasterModel query"+sqlForCustomerLinkMasterModel);
				List<CustomerLinkMasterModel> customerLinkMasterModelResult = this.namedParamTemplate
						.query(sqlForCustomerLinkMasterModel, paramMap, new CustomerLinkMasterModelMapper());
				

				List<CustomerLinkMasterModel> finalLinkMaster=new ArrayList<CustomerLinkMasterModel>();
				if(!customerLinkMasterModelResult.isEmpty() && customerLinkMasterModelResult.size()>=0){
					logger.info("customerLinkMasterModelResult size"+customerLinkMasterModelResult.size());
					for (int i = 0; i <customerLinkMasterModelResult.size(); i++) {
						CustomerLinkMasterModel customerLinkMasterModel=customerLinkMasterModelResult.get(i);
						if(customerLinkMasterModel!=null){
							if(customerLinkMasterModel.getLinkCustomerName()!=null && customerLinkMasterModel.getCustId()!=null){
								if(!customerLinkMasterModelResult.get(i).getLinkCustomerName().equals("") && (!customerLinkMasterModelResult.get(i).getCustId().equals(""))){

									finalLinkMaster.add(customerLinkMasterModel);
									//orderInfo1.setCustomerLinkMasterModel(finalLinkMaster);
									logger.info("finalLinkMaster"+finalLinkMaster.size());
								}

							}
						}
					}
					orderInfo1.setCustomerLinkMasterModel(finalLinkMaster);
					finalResults.add(orderInfo1);
				}
				
			}
		//}
		//End Here :: Link Customer Name For Sales Order
		
		/*if(!blanketSearch){
			return finalResults;
		}else{
	
			return finalResults;
		}
*/
			return finalResults;
	}

	public StatusInfo convertOrder(String sso, Long orderNum, String recSource) {
		StatusInfo result = new StatusInfo();
		result.setStatusCode(-1);
		try {

			String sql = "SELECT COUNT(*) FROM FPTODS.SQT_SSO_CONVERTED WHERE ORDER_NUMBER = ?";

			int count = this.jdbcTemplate.queryForInt(sql, new Object[] { orderNum });

			if (count > 0) {
				result.setStatusCode(1);
				result.setStatusMessage("Order already converted.");
			}else {
				sql = "INSERT INTO FPTODS.SQT_SSO_CONVERTED (SSO, ORDER_NUMBER, REC_SOURCE, DATE_CONVERTED) " +
						"VALUES (?, ?, ?, sysdate)";	

				this.jdbcTemplate.update(sql, new Object[] { sso, orderNum, recSource });

				result.setStatusCode(0);
				result.setStatusMessage("Order converted successfully");
			}

		} catch (Exception ex) {
			result.setStatusCode(-1);
			result.setStatusMessage(ex.getMessage());
			WelcomePkgServiceImpl.logError(ex, sso, "Convert Order");
			logger.error("Convert Order error:", ex);
		}

		return result;
	}

	public List<OrderInfo>getOrdersBySalesOrder(String sso, String salesOrder){
		List<OrderInfo> orders = null;
		try {
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		boolean isInternal = WelcomePkgServiceImpl.isInternalUser(sso);
		String sql="";
		if(!isInternal) {
			String upperCaseSSO= sso.toUpperCase();
			sql=" select  distinct REC_SOURCE,SALES_ORDER,CUSTOMER_PO, sold_to_customer_name,sold_to_country,sold_to_state,sold_to_province,sold_to_city,REP_NAME,SOURCESYSTEM,channel,username,sso,duns,creation_Date ,end_user,end_user_industry,product_code,ORDER_ID,note,LAST_UPDATE_DATE,EU_PLANT_NAME,EU_CUST_ZIP "+
					" from DDSAFM.ODS_SQT_BY_SALES_ORDER_UPDATE  where sales_order = :salesOrder and UPPER(sso) = :sso ";
			parameters.addValue("salesOrder", salesOrder);
			parameters.addValue("sso", upperCaseSSO);
		}else {
			sql=" select distinct REC_SOURCE,SALES_ORDER,CUSTOMER_PO, sold_to_customer_name,sold_to_country,sold_to_state,sold_to_province,sold_to_city,REP_NAME,SOURCESYSTEM, null as channel, end_user, end_user_industry,product_code,ORDER_ID,LAST_UPDATE_DATE,note,EU_PLANT_NAME,EU_CUST_ZIP  "+
					" from DDSAFM.ODS_SQT_BY_SO_UPDATE_GE where sales_order= :salesOrder ";
			parameters.addValue("salesOrder", salesOrder);
		}
		orders = this.namedParamTemplate.query(sql, parameters, new OrderInfoMapper());
		}  catch (Exception ex){
			logger.error("Error getOrdersBySalesOrder:", ex);
		}
		return orders;
	}

	public StatusInfo UpdateSalesOrderInfo(String sso,OrderInfo orderinfo) {
		StatusInfo result= new StatusInfo();
		try {
		/// To validate End User Start 
		String endCustomer = orderinfo.getEndUser().toUpperCase();
		logger.info("UpdateSalesOrderInfo"+endCustomer);
		//String endcustsql = "Select count(*) from  FPTODS.SQT_END_USER_MASTER_T where CUSTOMER_NAME = ?";
		String endcustsql ="SELECT count(*) FROM ( Select DISTINCT ( END_USER ) as CUSTOMER_NAME,END_USER_INDUSTRY  as END_USER_INDUSTRY, "
				+ "EU_CUST_COUNTRY AS  EU_CUST_COUNTRY ,   EU_CUST_STATE AS EU_CUST_STATE, "
				+ "EU_CUST_CITY AS EU_CUST_CITY , EU_CUST_ZIP AS EU_CUST_ZIP      "
				+ " from DDSAFM.ODS_SQT_BY_SALES_ORDER_SSO_GE      "
				+ " UNION"
				+ " SELECT DISTINCT CUSTOMER_NAME,END_USER_INDUSTRY,"
				+ "END_USER_COUNTRY AS EU_CUST_COUNTRY , END_USER_STATE AS EU_CUST_STATE, "
				+ "END_USER_CITY as EU_CUST_CITY ,END_USER_POSTAL_CODE AS EU_CUST_ZIP    "
				+ "   FROM FPTODS.CUSTOMER_DATA_MANAGMENT_MASTER) where UPPER(CUSTOMER_NAME) like ? AND ROWNUM <= 1 ";
		
		int endCustomerResult = this.jdbcTemplate.queryForInt(endcustsql, new Object[] { endCustomer });
		if (endCustomerResult == 0) {
			logger.info("In not found case");
			result.setStatusCode(-1);
			result.setStatusMessage("End user is invalid");
			return result;
		}
		logger.info("valide user case");
		// To validate End User End
		
		
		boolean isInternal = WelcomePkgServiceImpl.isInternalUser(sso);
		String sql="";
		if(!isInternal) {
			String upperCaseSSO = sso.toUpperCase();
			sql="select count(1) from DDSAFM.ODS_SQT_BY_SALES_ORDER_UPDATE where sales_order = ? and UPPER(sso) = ?";
			int count= this.jdbcTemplate.queryForInt(sql,new Object[]{orderinfo.getSalesOrder(),upperCaseSSO});
			if(count>0){
				
				
				
				sql=" update DDSAFM.ODS_SQT_BY_SALES_ORDER_UPDATE set CUSTOMER_PO= ?,SOLD_TO_CUSTOMER_NAME=? ,SOLD_TO_COUNTRY=?,SOLD_TO_STATE=?,SOLD_TO_PROVINCE=?, SOLD_TO_CITY=?,REP_NAME=?,END_USER=?,END_USER_INDUSTRY=?,NOTE=? ,LAST_UPDATE_DATE= sysdate"+
						" ,EU_CUST_ZIP=?,EU_PLANT_NAME=?,EU_CUST_COUNTRY=?,EU_CUST_STATE=?,EU_CUST_CITY=?  where sales_order = ? and sso = ? "; 

				Object[] params = {
						orderinfo.getCustomerPo(),
						orderinfo.getSoldToCustName(),
						orderinfo.getSoldToCustCountry(),
						orderinfo.getSoldToCustState(),
						orderinfo.getSoldToCustProvince(),
						orderinfo.getSoldToCustCity(),
						orderinfo.getRepName(),
						orderinfo.getEndUser(),
						orderinfo.getEndUserIndustry(),
						orderinfo.getNote(),
						orderinfo.getPostalCode(),
						orderinfo.getPlantName(),
						orderinfo.getEuCountry(),
						orderinfo.getEuState(),
						orderinfo.getEuCity(),
						orderinfo.getSalesOrder(),
						sso

				};
				this.jdbcTemplate.update(sql,params);	
			}else{
				sql= "insert into DDSAFM.ODS_SQT_BY_SALES_ORDER_UPDATE "+
						"(REC_SOURCE,ORDER_ID,SALES_ORDER,CUSTOMER_PO,SOLD_TO_CUSTOMER_NAME,SOLD_TO_COUNTRY,SOLD_TO_STATE,SOLD_TO_PROVINCE, "+
						" SOLD_TO_CITY,REP_NAME,SOURCESYSTEM,CHANNEL,USERNAME,SSO,LAST_UPDATE_DATE,END_USER,END_USER_INDUSTRY,PRODUCT_CODE,DUNS,CREATION_DATE,NOTE,EU_PLANT_NAME,EU_CUST_ZIP"
						+ ",EU_CUST_COUNTRY,EU_CUST_STATE,EU_CUST_CITY)"+
						"values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,sysdate,?,?,?,?,?,?,?,?,?,?,?)";

				Object[] params={
						orderinfo.getRecSource(),
						orderinfo.getOrderId(),
						orderinfo.getSalesOrder(),
						orderinfo.getCustomerPo(),
						orderinfo.getSoldToCustName(),
						orderinfo.getSoldToCustCountry(),
						orderinfo.getSoldToCustState(),
						orderinfo.getSoldToCustProvince(),
						orderinfo.getSoldToCustCity(),
						orderinfo.getRepName(),
						orderinfo.getSourceSystem(),
						orderinfo.getChannel(),
						orderinfo.getUsername(),
						orderinfo.getSso(),
						orderinfo.getEndUser(),
						orderinfo.getEndUserIndustry(),
						orderinfo.getProductCode(),
						orderinfo.getDuns(),
						orderinfo.getCreationDate(),
						orderinfo.getNote(),
						orderinfo.getPlantName(),
						orderinfo.getPostalCode(),
						orderinfo.getEuCountry(),
						orderinfo.getEuState(),
						orderinfo.getEuCity(),
				};
				this.jdbcTemplate.update(sql,params);
			}
		}else {
			sql="select count(1) from DDSAFM.ODS_SQT_BY_SO_UPDATE_GE where sales_order = ? ";
			int count=this.jdbcTemplate.queryForInt(sql,new Object[]{orderinfo.getSalesOrder()});
			if(count>0){
				
				/*/// To validate End User Start 
				String endCustomer = orderinfo.getEndUser();
				logger.info("UpdateSalesOrderInfo"+endCustomer);
				String endcustsql = "Select count(*) from  FPTODS.SQT_END_USER_MASTER_T where CUSTOMER_NAME = ?";
				int endCustomerResult = this.jdbcTemplate.queryForInt(endcustsql, new Object[] { endCustomer });
				if (endCustomerResult == 0) {
					logger.info("In not found case");
					result.setStatusCode(-1);
					result.setStatusMessage("End user is invalid");
					return result;
				}
				logger.info("valide user case");
				// To validate End User End
*/				
				
				sql=" update  DDSAFM.ODS_SQT_BY_SO_UPDATE_GE set SOLD_TO_CUSTOMER_NAME=? ,SOLD_TO_COUNTRY=?,SOLD_TO_STATE=?,SOLD_TO_PROVINCE=?, SOLD_TO_CITY=?,REP_NAME=?,END_USER=?,END_USER_INDUSTRY=?,note=? ,LAST_UPDATE_DATE= sysdate, UPDATED_BY=?"+
						"  ,EU_CUST_ZIP=?,EU_PLANT_NAME=?,EU_CUST_COUNTRY=?,EU_CUST_STATE=?,EU_CUST_CITY=? where sales_order = ? "; 

				Object[] params = {
						orderinfo.getSoldToCustName(),
						orderinfo.getSoldToCustCountry(),
						orderinfo.getSoldToCustState(),
						orderinfo.getSoldToCustProvince(),
						orderinfo.getSoldToCustCity(),
						orderinfo.getRepName(),
						orderinfo.getEndUser(),
						orderinfo.getEndUserIndustry(),
						orderinfo.getNote(),
						sso,
						orderinfo.getPostalCode(),
						orderinfo.getPlantName(),
						orderinfo.getEuCountry(),
						orderinfo.getEuState(),
						orderinfo.getEuCity(),
						orderinfo.getSalesOrder()
				};
				this.jdbcTemplate.update(sql,params);	
			}else{
				sql="insert into DDSAFM.ODS_SQT_BY_SO_UPDATE_GE ( REC_SOURCE, "+
						"order_id,sales_order,customer_po,sold_to_customer_name,sold_to_country,sold_to_state,sold_to_province, "+	  
						"sold_to_city,rep_name,sourcesystem,end_user,end_user_industry,product_code,note,eu_cust_zip,eu_plant_name, "+
						"updated_by,last_update_date,EU_CUST_COUNTRY,EU_CUST_STATE,EU_CUST_CITY) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,sysdate,?,?,?) ";

				Object[] params={
						orderinfo.getRecSource(),
						orderinfo.getOrderId(),
						orderinfo.getSalesOrder(),
						orderinfo.getCustomerPo(),
						orderinfo.getSoldToCustName(),
						orderinfo.getSoldToCustCountry(),
						orderinfo.getSoldToCustState(),
						orderinfo.getSoldToCustProvince(),
						orderinfo.getSoldToCustCity(),
						orderinfo.getRepName(),
						orderinfo.getSourceSystem(),
						orderinfo.getEndUser(),
						orderinfo.getEndUserIndustry(),
						orderinfo.getProductCode(),
						orderinfo.getNote(),
						orderinfo.getPostalCode(),
						orderinfo.getPlantName(),
						sso,
						orderinfo.getEuCountry(),
						orderinfo.getEuState(),
						orderinfo.getEuCity()
				};
				this.jdbcTemplate.update(sql,params);	
			}
		}
		sql=" update  DDSAFM.sqt_order_info_t  set SHIP_TO_CUST_NAME=? ,SHIP_TO_CUST_COUNTRY=?,SHIP_TO_CUST_STATE=?,SHIP_TO_CUST_PROVINCE=?, "
				+ "SHIP_TO_CUST_CITY=?,ship_to_cust_postal=?,SALESREP_NAME=?,END_USER=?,END_USER_INDUSTRY=?,LAST_UPDATE_DATE= sysdate"+
				",EU_CUST_COUNTRY=?,EU_CUST_STATE=?, EU_CUST_CITY=?,EU_CUST_ZIP=?  where order_number = ? and rec_source=? "; 
		Object[] params = {
				orderinfo.getSoldToCustName(),
				orderinfo.getSoldToCustCountry(),
				orderinfo.getSoldToCustState(),
				orderinfo.getSoldToCustProvince(),
				orderinfo.getSoldToCustCity(),
				orderinfo.getScPostalCode(),
				orderinfo.getRepName(),
				orderinfo.getEndUser(),
				orderinfo.getEndUserIndustry(),
				orderinfo.getEuCountry(),
				orderinfo.getEuState(),
				orderinfo.getEuCity(),
				orderinfo.getPostalCode(),
				orderinfo.getSalesOrder(),
				orderinfo.getRecSource(),

		};
		this.jdbcTemplate.update(sql,params);	
		result.setStatusCode(0);
		result.setStatusMessage("Order updated successfully.");
		return result; 
		
		}catch (Exception e) {
			e.printStackTrace();
			logger.error("Error in UpdateSalesOrderInfo:",e);
			result.setStatusCode(-1);
			result.setStatusMessage("Something went wrong try again later");
			return result;
		}
		
	}


	public List<String> getAutocompleteDataList(String sso, String col, String input){
		boolean isInternal = WelcomePkgServiceImpl.isInternalUser(sso);
		List<String> result=new ArrayList<String>();
		String sql="select distinct "+col +" from ";
		sql+= isInternal ?
				"DDSAFM.ODS_SQT_BY_SALES_ORDER_SSO_GE ":
					"DDSAFM.ODS_SQT_BY_SALES_ORDER_SSO ";
		sql+=" where upper("+col+ ") like upper('%"+input+"%')";
		List<Map<String, Object>> rows=this.jdbcTemplate.queryForList(sql);
		for(Map<String, Object> row : rows){
			result.add((String) row.get(col));
		}
		return result;
	}

	public int getOrderCountByDUNS(String sso, String type,String duns,String year, String month,String pc,String globalSearch,OrderInfo orderInfo) {
		int count = 0;
		try {
		boolean blanketSearch=false;
		MapSqlParameterSource parameters = new MapSqlParameterSource(setFilterParams(globalSearch, orderInfo,blanketSearch));
		String sql="";
		String sqlLook="";
		String sqlConverted="";
		String sqlQuotes="";
		String pcClause="";
		String yrClause="";
		String monthClause="";
		String [] yearitems = year.split(",");
		String [] monthitems = month.split(",");

		sql="SELECT count(distinct Sales_Order) "+
				"from ddsafm.ods_sqt_by_sales_order_sso "+
				"where DUNS in (SELECT distinct Duns_code "+
				"FROM FPTODS.SQT_CHANNEL_MGRS "+
				"START WITH Duns_code = :duns "+
				"CONNECT BY nocycle PRIOR Duns_code = manager )";

		parameters.addValue("duns", duns); 
		if(!pc.equalsIgnoreCase("")) {
			pcClause= "and PRODUCT_CODE =:pc";
			parameters.addValue("pc", pc); 

			parameters.addValue("duns", duns);  
		}
		if (!globalSearch.trim().isEmpty()) {
			String globalFilterClause = getGlobalFilterClause();			
			sql += " AND " + globalFilterClause;
		}
		if(type.equalsIgnoreCase("Viewed")) {
			sqlLook = " and  sales_order in (SELECT  distinct order_number "
					+ " FROM fptods.sqt_sso_saved_carts "
					+ " where sso in (select distinct sso from ddsafm.ods_sqt_by_sales_order_sso "
					+ " where duns in (SELECT distinct Duns_code "
					+ " FROM FPTODS.SQT_CHANNEL_MGRS "
					+ " START WITH Duns_code = :duns "
					+ " CONNECT BY nocycle PRIOR Duns_code = manager))) ";  
			parameters.addValue("duns", duns);
		}

		if(type.equalsIgnoreCase("Converted")) {
			sqlConverted = " and order_id in (SELECT  distinct order_number"
					+ " FROM fptods.sqt_sso_converted"
					+ " where sso in (select distinct sso from ddsafm.ods_sqt_by_sales_order_sso "
					+ " where duns in (SELECT distinct Duns_code "
					+ " FROM FPTODS.SQT_CHANNEL_MGRS "
					+ " START WITH Duns_code = :duns "
					+ " CONNECT BY nocycle PRIOR Duns_code = manager))) ";
			parameters.addValue("duns", duns);
		}
		if(type.equalsIgnoreCase("Quotes")) {
			sqlQuotes=" and sales_order in (SELECT  distinct order_number"
					+ " FROM fptods.SQT_SSO_CART"
					+ " where sso in (select distinct sso from ddsafm.ods_sqt_by_sales_order_sso "
					+ " where duns in (SELECT distinct Duns_code "
					+ " FROM FPTODS.SQT_CHANNEL_MGRS "
					+ " START WITH Duns_code = :duns "
					+ " CONNECT BY nocycle PRIOR Duns_code = manager))) ";
			parameters.addValue("duns", duns);
		}
		if(yearitems.length!=0) {
			yrClause=" and  extract(year from creation_date) BETWEEN  :fromYear and :toYear ";
			parameters.addValue("fromYear", yearitems[0]);
			parameters.addValue("toYear", yearitems[1]);
		}
		if(monthitems.length!=0) {

			monthClause=" and (extract(month from creation_date) >=  :frommonth or extract(month from creation_date) <=  :tomonth ) ";
			parameters.addValue("frommonth", monthitems[0]);
			parameters.addValue("tomonth", monthitems[1]);
		}
		String finalSql=sql+pcClause+sqlLook+sqlConverted+sqlQuotes+yrClause+monthClause;
		String filterClause=getFilterClause(orderInfo,blanketSearch);
		if (!filterClause.trim().equals("")) {
			finalSql+=" AND "+ filterClause;
		}

		try{
			count = this.namedParamTemplate.queryForInt(finalSql, parameters);
		}catch (Exception ex) {
			WelcomePkgServiceImpl.logError(ex, sso, "Get orders count");
			logger.error("Get orders count error: ", ex);
			count = -1;
		}
		}catch (Exception ex) {
			logger.error("Get orders count error: ", ex);
		}
		

		return count;
	}

	public List<OrderInfo> getOrdersByDUNS(String sso, String type,String duns,String year, String month,String pc,int page, int rowsPerPage,String sortCol,String sortOrder,String globalSearch,OrderInfo orderInfo) {
		List<OrderInfo> orders = null;
		try{
		int lowerLimit = rowsPerPage * page;
		int upperLimit = lowerLimit + rowsPerPage;
		String initSql="";
		String sql="";
		String sqlLook="";
		String sqlConverted="";
		String sqlQuotes="";
		String pcClause="";
		String yrClause="";
		String monthClause="";
		String sortClause="";
		String sortOrderClause="";
		String endSql="";
		String	pageLimitClause="";
		boolean isInternal = WelcomePkgServiceImpl.isInternalUser(sso);
		boolean blanketSearch=false;
		MapSqlParameterSource parameters = new MapSqlParameterSource(setFilterParams(globalSearch, orderInfo,blanketSearch));
		String [] yearitems = year.split(",");
		String [] monthitems = month.split(",");

		initSql="SELECT * FROM (select ROW_NUMBER() OVER (ORDER BY last_update_date desc) rn, A.* from ( ";

		sql="SELECT distinct REC_SOURCE, "+
				" SALES_ORDER, "+
				" CUSTOMER_PO, "+
				" SOLD_TO_CUSTOMER_NAME,"+
				" SOLD_TO_COUNTRY,"+
				" SOLD_TO_STATE,"+
				" SOLD_TO_PROVINCE,"+
				" product_code,"+
				" SOLD_TO_CITY,"+
				" REP_NAME,"+
				" SOURCESYSTEM,"+
				" END_USER,"+
				" END_USER_INDUSTRY,"+
				" ORDER_ID,"+
				" LAST_UPDATE_DATE"+
				" , " + "ENGINEERED_VALVE ," + " SERIALIZABLE" +
				" from ddsafm.ods_sqt_by_sales_order_sso "+
				" where DUNS in (SELECT distinct Duns_code"+
				"  FROM FPTODS.SQT_CHANNEL_MGRS"+
				" START WITH Duns_code = :duns 	"+
				" CONNECT BY nocycle PRIOR Duns_code = manager) ";  
		parameters.addValue("duns", duns);  

		if(!pc.equalsIgnoreCase("")) {
			pcClause= "and PRODUCT_CODE =:pc";
			parameters.addValue("pc", pc); 
		}
		if (!globalSearch.trim().isEmpty()) {
			String globalFilterClause = getGlobalFilterClause();			
			sql += " AND " + globalFilterClause;
		}
		if(type.equalsIgnoreCase("Viewed")) {
			sqlLook = " and  sales_order in (SELECT  distinct order_number "
					+ " FROM fptods.sqt_sso_saved_carts "
					+ " where sso in (select distinct sso from ddsafm.ods_sqt_by_sales_order_sso "
					+ " where duns in (SELECT distinct Duns_code "
					+ " FROM FPTODS.SQT_CHANNEL_MGRS "
					+ " START WITH Duns_code = :duns "
					+ " CONNECT BY nocycle PRIOR Duns_code = manager))) ";  
			parameters.addValue("duns", duns);
		}

		if(type.equalsIgnoreCase("Converted")) {
			sqlConverted = " and order_id in (SELECT  distinct order_number"
					+ " FROM fptods.sqt_sso_converted"
					+ " where sso in (select distinct sso from ddsafm.ods_sqt_by_sales_order_sso "
					+ " where duns in (SELECT distinct Duns_code "
					+ " FROM FPTODS.SQT_CHANNEL_MGRS "
					+ " START WITH Duns_code = :duns "
					+ " CONNECT BY nocycle PRIOR Duns_code = manager))) ";
			parameters.addValue("duns", duns);
		}
		if(type.equalsIgnoreCase("Quotes")) {
			sqlQuotes=" and sales_order in (SELECT  distinct order_number"
					+ " FROM fptods.SQT_SSO_CART"
					+ " where sso in (select distinct sso from ddsafm.ods_sqt_by_sales_order_sso "
					+ " where duns in (SELECT distinct Duns_code "
					+ " FROM FPTODS.SQT_CHANNEL_MGRS "
					+ " START WITH Duns_code = :duns "
					+ " CONNECT BY nocycle PRIOR Duns_code = manager))) ";
			parameters.addValue("duns", duns);
		}
		if(yearitems.length!=0) {
			yrClause=" and  extract(year from creation_date) BETWEEN  :fromYear and :toYear ";
			parameters.addValue("fromYear", yearitems[0]);
			parameters.addValue("toYear", yearitems[1]);
		}
		if(monthitems.length!=0) {

			monthClause=" and (extract(month from creation_date) >=  :frommonth or extract(month from creation_date) <=  :tomonth ) ";
			parameters.addValue("frommonth", monthitems[0]);
			parameters.addValue("tomonth", monthitems[1]);
		}
		String filterClause=getFilterClause(orderInfo,blanketSearch);
		if (!filterClause.trim().equals("")) {
			filterClause=" AND "+ filterClause;
		}
		if(sortCol!=null && !sortCol.equalsIgnoreCase("")){
			sortClause="order by "+sortCol;
		}
		if(sortOrder!=null && !sortOrder.equalsIgnoreCase("")){
			sortOrderClause+=" "+sortOrder;
		}

		endSql=")A)";

		if(rowsPerPage>0){
			pageLimitClause=" WHERE rn >:lowerLimit AND rn <=:upperLimit";
			parameters.addValue("lowerLimit", lowerLimit);
			parameters.addValue("upperLimit", upperLimit);
		}
		String finalSql=initSql+sql+pcClause+sqlLook+sqlConverted+sqlQuotes+yrClause+monthClause+filterClause+sortClause+sortOrderClause+endSql+pageLimitClause;
		orders = this.namedParamTemplate.query(finalSql, parameters, new OrderInfoMapper());
		logger.info("final Query:-"+finalSql);
		}catch (Exception ex) {
			logger.error("getOrdersByDUNS error: ", ex);
		}
		return orders;
	}


	private  static final class OrderInfoMapper implements RowMapper<OrderInfo> {
		public OrderInfoMapper() {
		}

		@Override
		public OrderInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
			OrderInfo orderInfo = new OrderInfo();

			orderInfo.setRecSource(rs.getString("REC_SOURCE")); //$NON-NLS-1$
			orderInfo.setSalesOrder(rs.getString("SALES_ORDER")); //$NON-NLS-1$
			orderInfo.setCustomerPo(rs.getString("CUSTOMER_PO")); //$NON-NLS-1$
			orderInfo.setSoldToCustName(rs.getString("SOLD_TO_CUSTOMER_NAME")); //$NON-NLS-1$
			orderInfo.setSoldToCustCountry(rs.getString("SOLD_TO_COUNTRY")); //$NON-NLS-1$
			orderInfo.setSoldToCustState(rs.getString("SOLD_TO_STATE")); //$NON-NLS-1$
			orderInfo.setSoldToCustProvince(rs.getString("SOLD_TO_PROVINCE")); //$NON-NLS-1$
			orderInfo.setSoldToCustCity(rs.getString("SOLD_TO_CITY")); //$NON-NLS-1$
			orderInfo.setRepName(rs.getString("REP_NAME")); //$NON-NLS-1$
			orderInfo.setSourceSystem(rs.getString("SOURCESYSTEM")); //$NON-NLS-1$
			orderInfo.setEndUser(rs.getString("END_USER"));
			orderInfo.setEndUserIndustry(rs.getString("END_USER_INDUSTRY"));
			orderInfo.setOrderId(rs.getLong("ORDER_ID"));
			orderInfo.setLastUpdateDate(rs.getDate("LAST_UPDATE_DATE"));
			orderInfo.setValveCnt(rs.getString("COUNT_VAL"));
			orderInfo.setSerializable(rs.getString("SERIALIZABLE"));
			orderInfo.setEngineeredValve(rs.getString("ENGINEERED_VALVE"));
			
			try {
				orderInfo.setProductCode(rs.getString("PRODUCT_CODE"));
				orderInfo.setNote(rs.getString("NOTE"));
				orderInfo.setPlantName(rs.getString("EU_PLANT_NAME"));
				orderInfo.setPostalCode(rs.getString("EU_CUST_ZIP"));
				orderInfo.setChannel(rs.getString("CHANNEL"));
				orderInfo.setUsername(rs.getString("USERNAME"));
				orderInfo.setSso(rs.getString("SSO"));
				orderInfo.setDuns(rs.getString("DUNS"));
				orderInfo.setCreationDate(rs.getDate("CREATION_DATE"));
			} catch (Exception e) {
				//e.printStackTrace();
				logger.info("column not present in query!!");
			}

			return orderInfo;
		}
	}

	@Override
	public List<String>  getChannelSettingsProduct(String sso) {
		try {
			List<String> results= new ArrayList<String>();
			String upperCaseSSO = sso.toUpperCase();
			logger.info("upper case SSO :"+upperCaseSSO);
			String query="SELECT P_L FROM  FPTODS.SQT_CHANNEL_SETTINGS where UPPER(USER_NAME)=?";
			String result = this.jdbcTemplate.queryForObject(query,new Object[] { upperCaseSSO }, String.class);
			results.add(result);
			return results;
		} catch (Exception ex) {
			logger.error("Exception in getChannelSettingsProduct"+ex.getMessage());
		}
		return null;
	}


	private  static final class OrderMapper implements RowMapper<OrderInfo> {
		public OrderMapper() {
		}

		@Override
		public OrderInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
			OrderInfo orderInfo = new OrderInfo();

			orderInfo.setRecSource(rs.getString("REC_SOURCE")); //$NON-NLS-1$
			orderInfo.setSalesOrder(rs.getString("ORDER_NUMBER")); //$NON-NLS-1$
			orderInfo.setCustomerPo(rs.getString("CUST_PO_NUMBER")); //$NON-NLS-1$
			orderInfo.setSoldToCustName(rs.getString("SHIP_TO_CUST_NAME")); //$NON-NLS-1$
			orderInfo.setSoldToCustCountry(rs.getString("SHIP_TO_CUST_COUNTRY")); //$NON-NLS-1$
			orderInfo.setSoldToCustState(rs.getString("SHIP_TO_CUST_STATE")); //$NON-NLS-1$
			orderInfo.setSoldToCustProvince(rs.getString("SHIP_TO_CUST_PROVINCE")); //$NON-NLS-1$
			orderInfo.setSoldToCustCity(rs.getString("SHIP_TO_CUST_CITY"));
			orderInfo.setScPostalCode(rs.getString("SHIP_TO_CUST_POSTAL"));
			orderInfo.setRepName(rs.getString("SALESREP_NAME")); //$NON-NLS-1$
			orderInfo.setEndUser(rs.getString("END_USER"));
			orderInfo.setEndUserIndustry(rs.getString("END_USER_INDUSTRY"));
			orderInfo.setOrderId(rs.getLong("ORDER_ID"));
			orderInfo.setLastUpdateDate(rs.getDate("LAST_UPDATE_DATE"));
			orderInfo.setEuCountry(rs.getString("EU_CUST_COUNTRY")); //$NON-NLS-1$
			orderInfo.setEuState(rs.getString("EU_CUST_STATE")); //$NON-NLS-1$
			orderInfo.setEuCity(rs.getString("EU_CUST_CITY")); //$NON-NLS-1$
			orderInfo.setSerializable(rs.getString("SERIALIZABLE"));
			orderInfo.setEngineeredValve(rs.getString("ENGINEERED_VALVE"));
			try{
				orderInfo.setProductCode(rs.getString("PRODUCT_CODE"));	
				orderInfo.setPostalCode(rs.getString("EU_CUST_ZIP"));
				
				orderInfo.setCreationDate(rs.getDate("CREATION_DATE"));
				
			}catch(Exception e){
				logger.info("column not present in query!!");
			}

			return orderInfo;
		}
	}

	@Override
	public OrderInfo getSalesOrderInfo(String sso, String order, String recSource) {
		OrderInfo info = null;
		boolean isInternal = WelcomePkgServiceImpl.isInternalUser(sso);
		try{
			// Set and ROWNUM <= 1 to avoid Duplicate Records. 
			String sql = "select * from ddsafm.sqt_order_info_t where ORDER_ID='"+order+"' and rec_source='"+recSource+"' and ROWNUM <= 1";
			info = this.jdbcTemplate.queryForObject(sql, new OrderMapper());
			String sqlForNote = "";
			if(isInternal)
				sqlForNote = "select note from DDSAFM.ODS_SQT_BY_SO_UPDATE_GE where ORDER_ID='"+order+"'and rec_source='"+recSource+"' and ROWNUM <= 1";
			else
				sqlForNote = "select note from DDSAFM.ODS_SQT_BY_SALES_ORDER_UPDATE where ORDER_ID='"+order+"' and rec_source='"+recSource+"' and ROWNUM <= 1";
			info.setNote(this.jdbcTemplate.queryForObject(sqlForNote, String.class));
		}catch(Exception e){
			logger.info("Error in getSalesOrderInfo()"+e.getLocalizedMessage());
		}
		return info;
	}


	/*@Override
	public CnDataInfo getCnDataInfo(String serialNumber) {	
		logger.error("value in serialNumber"+serialNumber);
		List<CnDataInfo> info = new ArrayList<CnDataInfo>();
		CnDataInfo result =null;
		try{
			// Find Serial Number = DVS_KEY_RECORD_CODE 
			String sql = "select DVS_KEY_RECORD_CODE,DVS_KEY_SERIAL_NO,DVS_KEY_SERL_NO_DUP_SHIP_DATE,DVS_VALVE_SKU,NOTES,DVS_INVOICE_NO,DVS_SET_PRESSURE,DVS_CDS,DVS_BACK_PRESSURE,DVS_TEMPERATURE,DVS_CAPACITY,DVS_SERVICE,DVS_CAP_CODE,DVS_SPRING_TYPE "+
					",DVS_SPRING,DVS_ASME,DVS_SIZE,DVS_BELLOWS,DVS_SPECIAL_FEATURES,DVS_ORIFICE,DVS_PRODUCT_COMMODITY,DVS_BILL_OF_MATERIAL_NO "+
					"from fptods.dresser_valve_segment where DVS_KEY_RECORD_CODE || DVS_KEY_SERIAL_NO || DVS_KEY_SERL_NO_DUP_SHIP_DATE  =:serialNumber";
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("serialNumber", serialNumber);
			info = this.namedParamTemplate.query(sql, parameters,new CNDataMapper());
			if(!info.isEmpty()) {
				result=info.get(0);
			}			
			// DVS_KEY_RECORD_CODE If duplicate Exists and get maximum of the DVS_KEY_RECORD_CODE + 
			if(!info.isEmpty() && info.size()>1){
				String max=info.get(0).getDvsKeyRecordCode()+info.get(0).getDvsKeySerlNoDupShipDate();
				int index=0;
				for(int i=1;i<info.size();i++){	
					String check=info.get(i).getDvsKeyRecordCode()+info.get(i).getDvsKeySerlNoDupShipDate();
					if(max.compareToIgnoreCase(check)==-1){
						max=check;
						index=i;
					}		 
				}
				result=info.get(index);
			} else if(!info.isEmpty() && info.size()==1) {
				result=info.get(0);
			} else {
				// Find  Serial Number = DVS_KEY_SERIAL_NO
				String sqlSerial = "select DVS_KEY_RECORD_CODE,DVS_KEY_SERIAL_NO,DVS_KEY_SERL_NO_DUP_SHIP_DATE,DVS_VALVE_SKU,NOTES,DVS_INVOICE_NO,DVS_SET_PRESSURE,DVS_CDS,DVS_BACK_PRESSURE,DVS_TEMPERATURE,DVS_CAPACITY,DVS_SERVICE,DVS_CAP_CODE,DVS_SPRING_TYPE "+
						",DVS_SPRING,DVS_ASME,DVS_SIZE,DVS_BELLOWS,DVS_SPECIAL_FEATURES,DVS_ORIFICE,DVS_PRODUCT_COMMODITY,DVS_BILL_OF_MATERIAL_NO "+
						"from fptods.dresser_valve_segment where DVS_KEY_RECORD_CODE  =:serialNumber";
				MapSqlParameterSource parametersSerial = new MapSqlParameterSource();
				parameters.addValue("serialNumber", serialNumber);
				info = this.namedParamTemplate.query(sqlSerial, parametersSerial,new CNDataMapper());	
				if(!info.isEmpty()){
					result=info.get(0);
				} else {

					// Find  Serial Number = DVS_KEY_SERIAL_NO
					String sqlSerialDate = "select DVS_KEY_RECORD_CODE,DVS_KEY_SERIAL_NO,DVS_KEY_SERL_NO_DUP_SHIP_DATE,DVS_VALVE_SKU,NOTES,DVS_INVOICE_NO,DVS_SET_PRESSURE,DVS_CDS,DVS_BACK_PRESSURE,DVS_TEMPERATURE,DVS_CAPACITY,DVS_SERVICE,DVS_CAP_CODE,DVS_SPRING_TYPE "+
							",DVS_SPRING,DVS_ASME,DVS_SIZE,DVS_BELLOWS,DVS_SPECIAL_FEATURES,DVS_ORIFICE,DVS_PRODUCT_COMMODITY,DVS_BILL_OF_MATERIAL_NO "+
							"from fptods.dresser_valve_segment where DVS_KEY_RECORD_CODE||DVS_KEY_SERL_NO_DUP_SHIP_DATE =:serialNumber";
					MapSqlParameterSource parametersSerialDate = new MapSqlParameterSource();
					parameters.addValue("serialNumber", serialNumber);
					info = this.namedParamTemplate.query(sqlSerialDate, parametersSerialDate,new CNDataMapper());
					if(!info.isEmpty()){
						result=info.get(0);
					} 	 
				}
			}	 
			return result;
		}catch(Exception e){
			logger.info("Error in getCnDataInfo()"+e.getLocalizedMessage());
		}
		return result;
	}*/

	private  static final class CNDataMapper implements RowMapper<CnDataInfo> {
		public CNDataMapper() {
		}

		@Override
		public CnDataInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
			CnDataInfo info = new CnDataInfo();		
			try{
				info.setDvsKeyRecordCode(rs.getString("DVS_KEY_RECORD_CODE"));
				info.setDvsKeySerialNo(rs.getString("DVS_KEY_SERIAL_NO"));
				info.setDvsKeySerlNoDupShipDate(rs.getString("DVS_KEY_SERL_NO_DUP_SHIP_DATE"));
				info.setValvesSku(rs.getString("DVS_VALVE_SKU")); 
				info.setNotes(rs.getString("NOTES"));
				info.setInvoiceNo(rs.getString("DVS_INVOICE_NO"));
				info.setSetPressure(rs.getString("DVS_SET_PRESSURE"));
				info.setCds(rs.getString("DVS_CDS"));
				info.setBackPressure(rs.getString("DVS_BACK_PRESSURE"));
				info.setTemperature(rs.getString("DVS_TEMPERATURE"));
				info.setCapacity(rs.getString("DVS_CAPACITY"));
				info.setService(rs.getString("DVS_SERVICE"));
				info.setCapCode(rs.getString("DVS_CAP_CODE"));
				info.setSpringType(rs.getString("DVS_SPRING_TYPE"));
				info.setSpring(rs.getString("DVS_SPRING"));
				info.setAsme(rs.getString("DVS_ASME"));
				info.setSize(rs.getString("DVS_SIZE"));
				info.setBellows(rs.getString("DVS_BELLOWS"));
				info.setSpecialFeatures(rs.getString("DVS_SPECIAL_FEATURES"));
				info.setOrifice(rs.getString("DVS_ORIFICE"));
				info.setProductCommodity(rs.getString("DVS_PRODUCT_COMMODITY"));
				info.setBillOfMaterialNo(rs.getString("DVS_BILL_OF_MATERIAL_NO"));
			}catch(Exception e){
				logger.info("column not present in query!!");
			}

			return info;
		}
	}
	
	public List<String> getCustomerLinkMaster(String salesOrder){
		try{
			String sql ="";
			List<String> results= new ArrayList<String>();
			logger.info("salesOrder####"+salesOrder);
			sql ="SELECT DISTINCT CUSTOMER_NAME FROM DDSAFM.ODS_SQT_BY_SALES_ORDER_SSO a, fptods.CUSTOMER_LINK_MASTER_T t where T.ORDER_NUMBER= A.SALES_ORDER and rownum<=10";
			/*if (rowsPerPage > 0) {
				int lowerLimit = rowsPerPage * page;
				int upperLimit = lowerLimit + rowsPerPage;
				String pageLimitClause= " WHERE rn >:lowerLimit AND rn <=:upperLimit";
				parameters.addValue("lowerLimit", lowerLimit);
				parameters.addValue("upperLimit", upperLimit);
				sql+=pageLimitClause;
			}*/
			//sql = "SELECT distinct CUSTOMER_NAME FROM FPTODS.CUSTOMER_LINK_MASTER_T where ORDER_NUMBER=?";
			//results = this.jdbcTemplate.queryForList(sql,new Object[]{salesOrder}, String.class);
			results = this.jdbcTemplate.queryForList(sql, String.class);
			return results;
		}catch(Exception e){
			e.printStackTrace();
			logger.error("Get getCustomerLinkMaster:",e);
		}
		return null;
	}
	
	private static final class CustomerLinkMasterModelMapper implements RowMapper<CustomerLinkMasterModel> {
		public CustomerLinkMasterModelMapper() {
		}

		@Override
		public CustomerLinkMasterModel mapRow(ResultSet rs, int rowNum) throws SQLException {
			CustomerLinkMasterModel result = new CustomerLinkMasterModel();
			result.setCustId(rs.getString("CUST_ID") != null ? rs.getString("CUST_ID") : "");
			result.setLinkCustomerName(rs.getString("LINK_CUSTOMER_NAME") != null ? rs.getString("LINK_CUSTOMER_NAME") : "");
			return result;
		}
	}

	

	private static final class PlantDataMapper implements RowMapper<PlantDataMaster> {
		public PlantDataMapper() {
		}
		@Override
		public PlantDataMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
			PlantDataMaster result = new PlantDataMaster();

			result.setPlantId(rs.getInt("PLANT_ID"));
			result.setPlantName(rs.getString("PLANT_NAME") != null ? rs.getString("PLANT_NAME") : "");
			result.setPlantLocation(rs.getString("PLANT_LOCATION") != null ? rs.getString("PLANT_LOCATION") : "");			
			
			return result;
		
		}
	}
	
	private static final class ProjectDataMapper implements RowMapper<ProjectDataMaster> {
		public ProjectDataMapper() {
		}
		@Override
		public ProjectDataMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
			ProjectDataMaster result = new ProjectDataMaster();

			result.setProjectId(rs.getInt("PROJECT_ID"));
			result.setProjectName(rs.getString("PROJECT_NAME") != null ? rs.getString("PROJECT_NAME") : "");
			//result.setValveLocation(rs.getString("VALVE_LOCATION") != null ? rs.getString("VALVE_LOCATION") : "");			
			
			return result;
		
		}
	}
	public List<PlantDataMaster> getPartlistByCustId(int custId){
		List<PlantDataMaster> plantList = new ArrayList<PlantDataMaster>();
		try{
			String plantSql = "Select PLANT_ID,PLANT_NAME,PLANT_LOCATION from FPTODS.PLANT_DATA_MANAGMENT_MASTER Where CUST_ID?";	
			plantList = this.jdbcTemplate.query(plantSql,new Object[] { custId }, new PlantDataMapper());
			
			} catch (Exception e) {
			logger.error("Exception in getUpgradeDetailsData" + e.getLocalizedMessage());
		}
		return plantList;
	}
	
	public List<ProjectDataMaster> getProjectlistByCustId(int custId){
		List<ProjectDataMaster> projectList = new ArrayList<ProjectDataMaster>();
		try{
			String Sql = "Select PLANT_ID,PLANT_NAME,PLANT_LOCATION from FPTODS.PLANT_DATA_MANAGMENT_MASTER Where CUST_ID?";	
			projectList = this.jdbcTemplate.query(Sql,new Object[] { custId }, new ProjectDataMapper());
			
			} catch (Exception e) {
			logger.error("Exception in getUpgradeDetailsData" + e.getLocalizedMessage());
		}
		return projectList;
	}

	@Override
	public List<CustomerDetailsforSerial> getCustLinkData(SalesSerial salesSerial) {

		try{	

			List<CustomerDetailsforSerial> results= new ArrayList<CustomerDetailsforSerial>();
			String SALESORDER=salesSerial.getOrderNumber1().trim();
			String dunsNumber=salesSerial.getDunsNumber().trim();
		
			
			String sql=QueryConstants.GET_CUST_LINK_DATA;
				
				List<String> serialNO=salesSerial.getSerialNumber();

				for(String serialNum : serialNO){
					
					serialNum = serialNum.replaceAll("\\P{Print}", "");  // Removing ax0 char 
					serialNum=serialNum.trim();// Removing Space
					
					logger.info("SQL:-"+sql.replace(":SERIALNUM", serialNum+"%"));
					
					List<CustomerDetailsforSerial> result = this.jdbcTemplate.query(sql.replace(":SERIALNUM", serialNum+"%"), new Object[] { SALESORDER },new CustomerDetailsforSerialMapper());	
					
					if(result.size()>0){
						CustomerDetailsforSerial obj=new CustomerDetailsforSerial();
						obj.setSerialNumber(result.get(0).getSerialNumber());
						obj.setOrderId(result.get(0).getOrderId());
						obj.setRecSource(result.get(0).getRecSource());
						obj.setOrderId(result.get(0).getOrderId());
						obj.setCustData(new ArrayList<CustomerInfo>());
						obj.setPlantData(new ArrayList<PlantDataManagmentMaster>());
						obj.setProjectDataMaster(new ArrayList<ProjectDataMaster>());
						for(CustomerDetailsforSerial custdata:result){
							
							CustomerInfo custinfo=new CustomerInfo();
							// TO add CustomerLink Details ///
							custinfo.setCustomerId(custdata.getCustId());
							custinfo.setLastupdateDate(custdata.getLastupdateDate());
							custinfo.setLinkcustomerName(custdata.getLinkcustomerNmae());
							custinfo.setSerialNumber(custdata.getSerialNumber());
							//custinfo.setUpdatedBy(custdata.getUpdatedBy());
							// Add Cust Data 
							custinfo.setEuCustomerName(custdata.getCustEuCustomerName());
							custinfo.setEuIndustry(custdata.getCustEuIndustry());
							custinfo.setEuCountry(custdata.getCustEuCountry());
							custinfo.setEuState(custdata.getCustEuState());
							custinfo.setEuCity(custdata.getCustEuCity());
							custinfo.setEuPostalCode(custdata.getCustEuPostalCode());
							custinfo.setIsActive(custdata.getCustEuActiveInactive());
							
							// Setting Link by Details
							if(dunsNumber.equals("") || dunsNumber.equalsIgnoreCase(custdata.getDunsNumber())){
								custinfo.setUpdatedBy(custdata.getUpdatedBy());
								custinfo.setLinkcustomerName(custdata.getLinkcustomerNmae());
							}else {
								custinfo.setUpdatedBy(null); 
								//custinfo.setLinkcustomerName(""); Commented for temperary purpose 
							}
							obj.getCustData().add(custinfo);
							
							// TO add Plant Details ///
							PlantDataManagmentMaster plantinto=new PlantDataManagmentMaster();
							plantinto.setPlantId(custdata.getPlantId()+"");
							plantinto.setPlantName(custdata.getPlantName());
							plantinto.setPlantLocation(custdata.getPlantLocation());
							plantinto.setMaintaenaceInternal(custdata.getPlantMaintaenanceInternal());
							plantinto.setCountry(custdata.getPlantCountry());
							plantinto.setIsActive(custdata.getPlantActiveInavctive());
							plantinto.setValveLocation(custdata.getPlantValveLocation());
							plantinto.setContact(custdata.getPlantContact());
							plantinto.setCustomerEmail(custdata.getPlantCustomerEmail());
							plantinto.setCity(custdata.getPlantCity());
							plantinto.setState(custdata.getPlantState());
							plantinto.setPostalCode(custdata.getPlantPostalCode());
							
							obj.getPlantData().add(plantinto);
							
							//TO add  Project Details??
							ProjectDataMaster projectinfo=new ProjectDataMaster();	
							projectinfo.setProjectId(custdata.getProjectId());
							projectinfo.setProjectName(custdata.getProjectName());
							projectinfo.setCountry(custdata.getProjectCountry());
							projectinfo.setCity(custdata.getProjectCity());
							projectinfo.setState(custdata.getProjectState());
							projectinfo.setPostalCode(custdata.getProjectPostalCode());
							projectinfo.setProjectLocation(custdata.getProjectLocation());
							projectinfo.setPlantLocation(custdata.isIsprojectPlantLocation());
							projectinfo.setPlantId(custdata.getProjectPlantId());
							
							obj.getProjectDataMaster().add(projectinfo);
							
							
						}
						
						//logger.info("Final Object"+obj);
						results.add(obj);
						 
					}

				}
				logger.info("Final "+results);
				return results;

			}
			
		catch(Exception e){
			logger.error("error",e);

		}
		return null;
	}
	

	
	private static final class CustomerDetailsforSerialMapper implements RowMapper<CustomerDetailsforSerial> {
			public CustomerDetailsforSerialMapper() {
			}
			@Override
			public CustomerDetailsforSerial mapRow(ResultSet rs, int rowNum) throws SQLException {
				
				
				
				CustomerDetailsforSerial result = new CustomerDetailsforSerial();
				
				result.setSerialNumber(rs.getString("SERIAL_NUMBER") != null ? rs.getString("SERIAL_NUMBER") : "");
				result.setLinkcustomerNmae(rs.getString("LINK_CUSTOMER_NAME") != null ? rs.getString("LINK_CUSTOMER_NAME") : "");
				result.setCustId(rs.getString("CUST_ID") != null ? rs.getString("CUST_ID") : "");
				result.setSalesOrder(rs.getString("ORDER_NUMBER") != null ? rs.getString("ORDER_NUMBER") : "");
				result.setUpdatedBy(rs.getString("UPDATED_BY") != null ? rs.getString("UPDATED_BY") : "");
				result.setRecSource(rs.getString("REC_SOURCE") != null ? rs.getString("REC_SOURCE") : "");
				result.setDunsNumber(rs.getString("DUNS_NUMBER") != null ? rs.getString("DUNS_NUMBER") : "");
				result.setLastupdateDate(rs.getString("UPDATED_DATE") != null ? rs.getString("UPDATED_DATE") : "");
				result.setPlantLocation(rs.getString("PLANT_LOCATION") != null ? rs.getString("PLANT_LOCATION") : "");
				result.setPlantId(rs.getInt("PLANT_ID"));
				result.setPlantName(rs.getString("PLANT_NAME") != null ? rs.getString("PLANT_NAME") : "");
				result.setProjectId(rs.getInt("PROJECT_ID"));
				result.setOrderId(rs.getString("ORDER_IDENTIFIER") != null ? rs.getString("ORDER_IDENTIFIER") : "");
				result.setProjectName(rs.getString("PROJECT_NAME") != null ? rs.getString("PROJECT_NAME") : "");
				//Plant
				result.setPlantContact(rs.getString("CUSTOMER_CONTACT_NAME") != null ? rs.getString("CUSTOMER_CONTACT_NAME") : "");
				result.setPlantMaintaenanceInternal(rs.getString("MAINTAENANCE_INTERNAL") != null ? rs.getString("MAINTAENANCE_INTERNAL") : "");
				result.setPlantCountry(rs.getString("PLANT_COUNTRY") != null ? rs.getString("PLANT_COUNTRY") : "");
				result.setPlantActiveInavctive(rs.getString("PLANT_ACTIVE_INACTIVE") != null ? rs.getString("PLANT_ACTIVE_INACTIVE") : "");
				result.setPlantCustomerEmail(rs.getString("CUSTOMER_EMAIL") != null ? rs.getString("CUSTOMER_EMAIL") : "");
				result.setPlantCity(rs.getString("PLANT_CITY") != null ? rs.getString("PLANT_CITY") : "");
				result.setPlantState(rs.getString("PLANT_STATE") != null ? rs.getString("PLANT_STATE") : "");
				result.setPlantPostalCode(rs.getString("PLANT_POSTAL_CODE") != null ? rs.getString("PLANT_POSTAL_CODE") : "");
				result.setPlantValveLocation(rs.getString("VALVE_LOCATION") != null ? rs.getString("VALVE_LOCATION") : "");				
				result.setIsprojectPlantLocation(rs.getBoolean("IS_PLANT_LOCATION"));
				// Project
				result.setProjectCountry(rs.getString("PROJECT_COUNTRY") != null ? rs.getString("PROJECT_COUNTRY") : "");
				result.setProjectCity(rs.getString("PROJECT_CITY") != null ? rs.getString("PROJECT_CITY") : "");
				result.setProjectState(rs.getString("PROJECT_STATE") != null ? rs.getString("PROJECT_STATE") : "");
				result.setProjectPostalCode(rs.getString("PROJECT_POSTAL_CODE") != null ? rs.getString("PROJECT_POSTAL_CODE") : "");
				result.setProjectLocation(rs.getString("PROJECT_LOCATION") != null ? rs.getString("PROJECT_LOCATION") : "");
				result.setProjectPlantId(rs.getInt("PROJECT_PLANT_ID"));
				//Cust
				result.setCustEuCustomerName(rs.getString("CUSTOMER_NAME") != null ? rs.getString("CUSTOMER_NAME") : "");
				result.setCustEuIndustry(rs.getString("END_USER_INDUSTRY") != null ? rs.getString("END_USER_INDUSTRY") : "");
				result.setCustEuCountry(rs.getString("END_USER_COUNTRY") != null ? rs.getString("END_USER_COUNTRY") : "");
				result.setCustEuState(rs.getString("END_USER_STATE") != null ? rs.getString("END_USER_STATE") : "");
				result.setCustEuCity(rs.getString("END_USER_CITY") != null ? rs.getString("END_USER_CITY") : "");
				result.setCustEuPostalCode(rs.getString("END_USER_POSTAL_CODE") != null ? rs.getString("END_USER_POSTAL_CODE") : "");
				result.setCustEuActiveInactive(rs.getString("CUST_ACTIVE_INACTIVE") != null ? rs.getString("CUST_ACTIVE_INACTIVE") : "NO");
				return result;
			
			}
			}



}
