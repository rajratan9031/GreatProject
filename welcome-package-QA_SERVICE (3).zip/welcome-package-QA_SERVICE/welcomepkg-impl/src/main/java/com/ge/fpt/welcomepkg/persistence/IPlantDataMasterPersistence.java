package com.ge.fpt.welcomepkg.persistence;

import java.util.List;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ge.fpt.welcomepkg.api.PlantData;
import com.ge.fpt.welcomepkg.api.PlantDataMaster;
import com.ge.fpt.welcomepkg.api.StatusInfo;

public interface IPlantDataMasterPersistence {
	@Transactional(propagation=Propagation.REQUIRED)
	StatusInfo deleteplantMaster(String sso, String customerId);
	
	@Transactional(propagation=Propagation.REQUIRED)
	public List<PlantDataMaster> getplantMaster(String custId );

	@Transactional(propagation=Propagation.REQUIRED)
	PlantDataMaster getplantMasterById(int plantId);
}
