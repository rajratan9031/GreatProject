package com.ge.fpt.welcomepkg.persistence;

import java.util.List;
import java.util.Map;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ge.fpt.welcomepkg.api.CartData;
import com.ge.fpt.welcomepkg.api.OrderInfo;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.api.VKCustOrderInfoSpeqT;
import com.ge.fpt.welcomepkg.api.VKOrderDocument;
import com.ge.fpt.welcomepkg.api.VKSTGReportData;
import com.ge.fpt.welcomepkg.api.ValveKeepPushData;
import com.ge.fpt.welcomepkg.api.ValvekeepUploadData;

public interface IValveKeepSTGPersistance {
	
	@Transactional(propagation = Propagation.REQUIRED)
	public List<VKSTGReportData> getVKSTGReportData(Map param);

	@Transactional(propagation = Propagation.REQUIRED)
	public StatusInfo valveKeepXMLDataSync(List<String[]> xmlData);

	@Transactional(propagation = Propagation.REQUIRED)
	public StatusInfo saveFilePathValvekeep(ValvekeepUploadData vkUploadData);

	@Transactional(propagation = Propagation.REQUIRED)
	public List<ValveKeepPushData> getDocData(List<CartData> cartData);

	/*@Transactional(propagation = Propagation.REQUIRED)
	public List<VKOrderDocument> getVkOrderDocument(List<CartData> vkStgReport);*/

	@Transactional(propagation = Propagation.REQUIRED)
	public List<VKCustOrderInfoSpeqT> getVkCustOrderInfoSpeqT(List<CartData> uniqueOrderList);

	@Transactional(propagation = Propagation.REQUIRED)
	public List<CartData> getcartData(Map postData);

	@Transactional(propagation = Propagation.REQUIRED)
	public String getDocName(String documentName);
	
	@Transactional(propagation = Propagation.REQUIRED)
	public String getDocmntName(String documentName);

	@Transactional(propagation = Propagation.REQUIRED)
	public StatusInfo removeDuplicateSOValveKeep(String orderNumber);

	@Transactional(propagation = Propagation.REQUIRED)
	public List<OrderInfo> validateSO(String orderNumber);

}
