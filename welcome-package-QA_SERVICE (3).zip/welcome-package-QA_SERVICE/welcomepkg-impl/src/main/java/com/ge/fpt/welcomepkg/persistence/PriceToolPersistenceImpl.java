package com.ge.fpt.welcomepkg.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.fpt.welcomepkg.api.PriceToolData;
import com.ge.fpt.welcomepkg.api.PriceToolSearchCriteria;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;

public class PriceToolPersistenceImpl implements IPriceToolPersistence {
	private static final Logger logger = WelcomePackageLoggerFactory
			.getLogger(PriceToolPersistenceImpl.class);
	JdbcTemplate jdbcTemplate;
	DataSource dataSource;
	PlatformTransactionManager txManager;
	NamedParameterJdbcTemplate namedParamTemplate;

	public DataSource getDataSource() {
		return this.dataSource;
	}

	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate = new NamedParameterJdbcTemplate(ds);
	}

	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	public List<PriceToolData> getPriceToolList(PriceToolSearchCriteria map) {
		try {
			logger.info("getPriceToolList");

			String sql = "select a.part_number, "+
						" max(d.description) as description,"+
                        " a.price_list_name,"+
                        " a.price_list_rank,"+
       " c.currency_symbol || ROUND((a.list_price * c.conversion), 2) as list_price, "+
       " a.region,"+
       " c.currency_symbol || nvl(ROUND((a.cost * c.conversion), 2), 0) as cost,"+
       " a.location,"+
       " a.product_line"+
       " from ddsafm.SQT_GET_PRICE_IN_USD a,"+
       "  fptods.sqt_currency_list c,"+
       " fptods.sqt_part_info_t_master d,"+
       " (select part_number, region, min(price_list_rank) rank_id"+
       "  from ddsafm.SQT_GET_PRICE_IN_USD"+
       " group by part_number, region) b"+
       " where a.price_List_rank = b.rank_id"+
       " and a.part_number = d.item_number(+)"+
       " and a.region = b.region"+
       " and a.part_number = b.part_number";

			MapSqlParameterSource parameters = new MapSqlParameterSource();
			if ((map.getRegion() != null)
					&& (!map.getRegion().equalsIgnoreCase(""))) {
				sql = sql + " and a.region = :region";
				parameters.addValue("region", map.getRegion());
			}
			if ((map.getCurrency() != null)
					&& (!map.getCurrency().equalsIgnoreCase(""))) {
				sql = sql + " and c.To_currency = :currency";
				parameters.addValue("currency", map.getCurrency());
			}
			if (map.getPartNumber() != null) {
				sql = sql + " and a.part_number  in (:partNumber)";
				parameters.addValue("partNumber", map.getPartNumber());
			}
		String	groupByQurery="group by a.part_number, "+
          " a.price_list_name, "+
          " c.currency_symbol || ROUND((a.list_price * c.conversion), 2) ,"+
          " a.region, "+
          " c.currency_symbol || nvl(ROUND((a.cost * c.conversion), 2), 0) , "+
          " a.location, "+
          " a.product_line,"+
          " a.price_list_rank";
				sql+=groupByQurery;
			return this.namedParamTemplate.query(sql, parameters,
					new PriceToolMapper());
		} catch (Exception ex) {
			logger.error("price tool:", ex);
		}
		return null;
	}

	public static final class PriceToolMapper implements
			RowMapper<PriceToolData> {
		public PriceToolData mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			PriceToolData result = new PriceToolData();
			result.setPartNumber(rs.getString("part_number"));
			result.setDescription(rs.getString("description"));
			result.setPriceListname(rs.getString("price_List_name"));
			result.setListPrice(rs.getString("list_price"));
			result.setLocationOfcost(rs.getString("location"));
			result.setCost(rs.getString("cost"));
			result.setProductLine(rs.getString("product_line"));
			return result;
		}
	}
}
