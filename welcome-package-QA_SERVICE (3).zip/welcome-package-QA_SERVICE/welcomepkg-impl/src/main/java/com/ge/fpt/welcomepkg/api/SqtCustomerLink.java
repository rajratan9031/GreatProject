package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.List;

public class SqtCustomerLink implements Serializable{
	
		private static final long serialVersionUID = 1L;
		
		private Long orderId;
		private String orderNumber;
		private Long orderLineId;
		private String serialNumber;
		private String recSource;
		
		public SqtCustomerLink() {
			super();
			// TODO Auto-generated constructor stub
		}

		public SqtCustomerLink(Long orderId, String orderNumber, Long orderLineId, String serialNumber,
				String recSource) {
			super();
			this.orderId = orderId;
			this.orderNumber = orderNumber;
			this.orderLineId = orderLineId;
			this.serialNumber = serialNumber;
			this.recSource = recSource;
		}

		public Long getOrderId() {
			return orderId;
		}

		public void setOrderId(Long orderId) {
			this.orderId = orderId;
		}

		public String getOrderNumber() {
			return orderNumber;
		}

		public void setOrderNumber(String orderNumber) {
			this.orderNumber = orderNumber;
		}

		public Long getOrderLineId() {
			return orderLineId;
		}

		public void setOrderLineId(Long orderLineId) {
			this.orderLineId = orderLineId;
		}

		public String getSerialNumber() {
			return serialNumber;
		}

		public void setSerialNumber(String serialNumber) {
			this.serialNumber = serialNumber;
		}

		public String getRecSource() {
			return recSource;
		}

		public void setRecSource(String recSource) {
			this.recSource = recSource;
		}
		
				

}
