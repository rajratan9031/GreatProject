package com.ge.fpt.welcomepkg.util;

public class Constants {
	
	  //public static final String ISTORE_SERVICE_URL= "http://soa-ogdev.og.ge.com:80/soa-infra/services/SFDC_ISTORE/GEOGIstoreIntegration/http_client";
	 //public static final String ISTORE_SERVICE_URL="https://stage.api.ge.com/oil/welcome_package_SOA_API/v1";
	//public static final String ISTORE_SERVICE_URL="https://api.ge.com/oil/welcome_package_SOA_API/v1";
	  public static final String USER="welcomePkg";
	  public static final String PASSWORD="pass11word";
	  public static final String ISTORE_SERVICE_URL= "https://soa-ogdev.og.ge.com:443/soa-infra/services/Drilling/GEOGIstoreIntegration/http_client";
	  public static final String DOCTYPE="DATABOOK";
	  public static final String IMAGEDOCTYPE="IMAGE";
	  public static final int SUCCESS_STATUS_CODE = 1;
	  public static final int FAIL_STATUS_CODE = 1;
	  
	  public static final String MSG_CUSTOMER_ADD_SUCCESSFUL="Customer has been added sucessfully";
	  public static final String MSG_CUSTOMER_UPDATE_SUCCESSFUL="Customer has been updated sucessfully";
	  public static final String MSG_CUSTOMER_DUPLICATE="Customer has been already added by your organization";	  
}

