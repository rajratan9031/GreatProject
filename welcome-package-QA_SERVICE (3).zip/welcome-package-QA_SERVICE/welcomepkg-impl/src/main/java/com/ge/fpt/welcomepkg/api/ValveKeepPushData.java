package com.ge.fpt.welcomepkg.api;

public class ValveKeepPushData {

	private String projectNumber;
	private String salesOrderNumber;
	private String salesOrderLineNumber;
	private String productionOrderNumber;
	private String serialNumber;
	private String documentDescription;
	private String documentType;
	private String fileName;
	private String docLink;
	private String siteCode;
	private String typeFlowProject;
	private String categoryNuclearCommercial;
	private String documentLanguage;
	private String documentContentType;
	private String sourceSystem;
	private String productCode;

	public String getProjectNumber() {
		return projectNumber;
	}

	public void setProjectNumber(String projectNumber) {
		this.projectNumber = projectNumber;
	}

	public String getSalesOrderNumber() {
		return salesOrderNumber;
	}

	public void setSalesOrderNumber(String salesOrderNumber) {
		this.salesOrderNumber = salesOrderNumber;
	}

	public String getSalesOrderLineNumber() {
		return salesOrderLineNumber;
	}

	public void setSalesOrderLineNumber(String salesOrderLineNumber) {
		this.salesOrderLineNumber = salesOrderLineNumber;
	}

	public String getProductionOrderNumber() {
		return productionOrderNumber;
	}

	public void setProductionOrderNumber(String productionOrderNumber) {
		this.productionOrderNumber = productionOrderNumber;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getDocumentDescription() {
		return documentDescription;
	}

	public void setDocumentDescription(String documentDescription) {
		this.documentDescription = documentDescription;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getDocLink() {
		return docLink;
	}

	public void setDocLink(String docLink) {
		this.docLink = docLink;
	}

	public String getSiteCode() {
		return siteCode;
	}

	public void setSiteCode(String siteCode) {
		this.siteCode = siteCode;
	}

	public String getTypeFlowProject() {
		return typeFlowProject;
	}

	public void setTypeFlowProject(String typeFlowProject) {
		this.typeFlowProject = typeFlowProject;
	}

	public String getCategoryNuclearCommercial() {
		return categoryNuclearCommercial;
	}

	public void setCategoryNuclearCommercial(String categoryNuclearCommercial) {
		this.categoryNuclearCommercial = categoryNuclearCommercial;
	}

	public String getDocumentLanguage() {
		return documentLanguage;
	}

	public void setDocumentLanguage(String documentLanguage) {
		this.documentLanguage = documentLanguage;
	}

	public String getDocumentContentType() {
		return documentContentType;
	}

	public void setDocumentContentType(String documentContentType) {
		this.documentContentType = documentContentType;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

}
