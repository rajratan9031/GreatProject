package com.ge.fpt.welcomepkg.api;

import java.sql.Date;

public class DigitalEquipmentData {
	

	private static final long serialVersionUID = 1L;
	private String productCode;
	private String partNumber;
	private String partDescription;
	private String tagNumber;
	private String serialNumber;
	private Date actualShipDate;
	private String QuantityShipped;
	
	public DigitalEquipmentData(){
		super();
	}
	
	
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getPartDescription() {
		return partDescription;
	}
	public void setPartDescription(String partDescription) {
		this.partDescription = partDescription;
	}
	public String getTagNumber() {
		return tagNumber;
	}
	public void setTagNumber(String tagNumber) {
		this.tagNumber = tagNumber;
	}
	public DigitalEquipmentData(String productCode, String partNumber, String partDescription, String tagNumber,
			String serialNumber) {
		super();
		this.productCode = productCode;
		this.partNumber = partNumber;
		this.partDescription = partDescription;
		this.tagNumber = tagNumber;
		this.serialNumber = serialNumber;
	}


	public Date getActualShipDate() {
		return actualShipDate;
	}


	public void setActualShipDate(Date actualShipDate) {
		this.actualShipDate = actualShipDate;
	}


	public String getQuantityShipped() {
		return QuantityShipped;
	}


	public void setQuantityShipped(String quantityShipped) {
		QuantityShipped = quantityShipped;
	}

	
}
