/**
 * 
 */

package com.ge.fpt.welcomepkg.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.api.UserData;
import com.ge.fpt.welcomepkg.api.UserSettings;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;

/**
 * @author 204060632
 *
 */
public class UserDataPersistenceImpl implements IUserDataPersistence {
	@SuppressWarnings("javadoc")
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory
			.getLogger(UserDataPersistenceImpl.class);

	static final int SQL_RETURN_RECORD_LIMIT = 25;

	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;

	/**
	 * Data source for the JDBC
	 */
	DataSource dataSource;

	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;

	/**
	 * @return the dataSource
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}

	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	/**
	 * 
	 */
	public UserDataPersistenceImpl() {
		// TODO Auto-generated constructor stub
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ge.fpt.welcomepkg.persistence.IUserDataPersistence#loadUserSettings
	 * (java.lang.String)
	 */
	@SuppressWarnings("nls")
	@Override
	public UserSettings loadUserSettings(String sso) {
		try {
			String upperCaseSSO = sso.toUpperCase();
			String sql = "SELECT GE_BUSINESS, P_L, REGION, PRODUCT, CURRENCY, DAYS, EMAIL_OPTION, ATT3,INTERCOMPANY_ORDER "
					+ "FROM FPTODS.SQT_CHANNEL_SETTINGS "
					+ "WHERE UPPER(USER_NAME) = ?";

			List<UserSettings> resultSet = this.jdbcTemplate.query(sql,
					new Object[] { upperCaseSSO }, new UserSettingsMapper());

			UserSettings result = resultSet.size() > 0 ? resultSet.get(0)
					: null;

			return result;

		} catch (Exception ex) {
			logger.error("Load settings error: ", ex);
			return null;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ge.fpt.welcomepkg.persistence.IUserDataPersistence#saveUserSettings
	 * (java.lang.String, com.ge.fpt.welcomepkg.api.UserSettings)
	 */
	@SuppressWarnings("nls")
	@Override
	public StatusInfo saveUserSettings(String sso, UserSettings saveData) {

		StatusInfo result = new StatusInfo();

		try {
			/*
			 * String sql =
			 * "DELETE FROM FPTODS.SQT_CHANNEL_SETTINGS WHERE USER_NAME = ?";
			 * this.jdbcTemplate.update(sql, new Object[] { sso });
			 * 
			 * sql =
			 * "INSERT INTO FPTODS.SQT_CHANNEL_SETTINGS (USER_NAME, GE_BUSINESS, P_L, REGION, PRODUCT, CURRENCY, DAYS, EMAIL_OPTION) "
			 * + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
			 */
			String upperCaseSSO = sso.toUpperCase();
			String sql = "SELECT Count(*) FROM FPTODS.SQT_CHANNEL_SETTINGS  WHERE UPPER(USER_NAME) = ?";
			int count = this.jdbcTemplate
					.queryForInt(sql, new Object[] { upperCaseSSO });
			if (count == 0) {
				sql = "INSERT INTO FPTODS.SQT_CHANNEL_SETTINGS (USER_NAME, GE_BUSINESS, P_L, REGION, PRODUCT, CURRENCY, DAYS, EMAIL_OPTION,interCompany_order) "
						+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?,?)";
				Object[] params = new Object[] { sso, saveData.getBusiness(),
						saveData.getPl(), saveData.getRegion(),
						saveData.getBrand(), saveData.getCurrency(),
						Integer.parseInt(saveData.getDateRange()),
						saveData.getEmailMe() ? "Y" : "N",
						saveData.getInterCompany() };
				this.jdbcTemplate.update(sql, params);
			} else {
				sql = "UPDATE FPTODS.SQT_CHANNEL_SETTINGS  SET GE_BUSINESS=?, P_L = ? , REGION =?, PRODUCT= ?, CURRENCY=?, DAYS=?, EMAIL_OPTION=?,interCompany_order=? "
						+ " WHERE USER_NAME= ?";
				this.jdbcTemplate.update(
						sql,
						new Object[] { saveData.getBusiness(),
								saveData.getPl(), saveData.getRegion(),
								saveData.getBrand(), saveData.getCurrency(),
								Integer.parseInt(saveData.getDateRange()),
								saveData.getEmailMe() ? "Y" : "N",
								saveData.getInterCompany(), sso });

			}

			result.setStatusCode(0);
			result.setStatusMessage("User settings updated successfully.");

			return result;
		} catch (Exception ex) {
			logger.error("Save settings error: ", ex);

			result.setStatusCode(-1);
			result.setStatusMessage(ex.getMessage());

			return result;
		}

	}

	private static final class UserSettingsMapper implements
			RowMapper<UserSettings> {
		public UserSettingsMapper() {

		}

		@Override
		public UserSettings mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			UserSettings result = new UserSettings();
			Boolean isAdmin = false;
			try {
				result.setBusiness(rs.getString("GE_BUSINESS"));
				result.setPl(rs.getString("P_L"));
				result.setRegion(rs.getString("REGION"));
				result.setBrand(rs.getString("PRODUCT"));
				result.setCurrency(rs.getString("CURRENCY"));
				result.setDateRange(rs.getString("DAYS"));
				result.setEmailMe(rs.getString("EMAIL_OPTION").trim()
						.toUpperCase().equals("Y"));
				result.setInterCompany(rs.getString("INTERCOMPANY_ORDER"));
				String isAdminStr = rs.getString("ATT3");

				if (isAdminStr != null && isAdminStr.equalsIgnoreCase("Y")) {
					isAdmin = true;
				} else {
					isAdmin = false;
				}
				result.setIsAdmin(isAdmin);
			} catch (Exception ex) {
				logger.error("UserSettings Mapper error: ", ex);
			}

			return result;
		}
	}

	public boolean getValidAdminUser(String sso) {
		boolean isAdmin = false;
		String sql = "select Att3 from FPTODS.SQT_CHANNEL_SETTINGS where USER_NAME=?";

		try {
			String result = this.jdbcTemplate.queryForObject(sql,
					new Object[] { sso }, String.class);

			if (result != null && result.equalsIgnoreCase("Y")) {
				isAdmin = true;
			}
		} catch (EmptyResultDataAccessException ex) { // queryForObject throws
														// this exception if
														// record not found
			return false;
		} catch (Exception ex) {
			logger.error("getValidAdminUser error: ", ex);
		}
		return isAdmin;
	}

	public boolean getValidPriceToolUser(String sso) {
		boolean isPriceToolUser = false;
		String upperCaseSSO = sso.toUpperCase();
		String sql = "select Count(*) from FPTODS.SQT_PRICETOOL_USER where UPPER(sso)=?";
		int result = this.jdbcTemplate.queryForInt(sql, new Object[] { upperCaseSSO });
		if (result > 0) {
			isPriceToolUser = true;
		}
		return isPriceToolUser;
	}

	public UserData getUserData(String sso) {
		UserData result = null;
		String ssoUpperCase=sso.toUpperCase();
		logger.info("SSO:"+ ssoUpperCase);
		try {

			String sql = "SELECT SSO_ID, USER_NAME, COMPANY, EMAIL, DUNS_NUMBER FROM FPTODS.SQT_CHANNEL_SSO WHERE UPPER(SSO_ID) = ?";

			List<UserData> resultSet = this.jdbcTemplate.query(sql,
					new Object[] { ssoUpperCase }, new UserDataMapper());

			result = resultSet != null && resultSet.size() > 0 ? resultSet
					.get(0) : null;

		} catch (Exception ex) {
			logger.error("getUserData error: ", ex);
		}

		return result;
	}

	public boolean getValidEnggAdminUser(String sso) {
		boolean isEnggAdmin = false;
		String sql = "select Att5 from FPTODS.SQT_CHANNEL_SETTINGS where USER_NAME=?";

		try {
			String result = this.jdbcTemplate.queryForObject(sql,
					new Object[] { sso }, String.class);
			if (result != null && result.equalsIgnoreCase("Y")) {

				isEnggAdmin = true;
			}
		} catch (EmptyResultDataAccessException ex) { // queryForObject throws
			return false;
		} catch (Exception ex) {
			logger.error("getValidEnggAdminUser error: ", ex);
		}
		logger.info("isEnggAdmin == " + isEnggAdmin);
		return isEnggAdmin;
	}

	private static final class UserDataMapper implements RowMapper<UserData> {
		public UserDataMapper() {

		}

		@Override
		public UserData mapRow(ResultSet rs, int rowNum) throws SQLException {
			UserData result = new UserData();
			try {
				result.setUserId(rs.getString("SSO_ID"));
				result.setEmail(rs.getString("EMAIL"));
				result.setCompany(rs.getString("COMPANY"));
				result.setDuns(rs.getString("DUNS_NUMBER"));

				String[] userNameParts = rs.getString("USER_NAME")
						.split(",", 2);

				if (userNameParts.length > 0) {
					result.setLastName(userNameParts[0].trim());

					if (userNameParts.length > 1) {
						result.setFirstName(userNameParts[1].trim());
					}
				}

				result.setAppName("");
				result.setAppId("");

			} catch (Exception ex) {
				logger.error("UserData Mapper error: ", ex);
			}

			return result;
		}
	}

	public static boolean isInternalUser(String sso) {
		return sso.matches("\\d{9}");
	}

	public boolean getValidInventoryUser(String sso) {
		boolean isInventoryUser = false;
		String upperCaseSSO = sso.toUpperCase();
		String sql = "select Count(*) from FPTODS.SQT_Inventory_USER where UPPER(sso)=?";
		int result = this.jdbcTemplate.queryForInt(sql, new Object[] { upperCaseSSO });
		if (result > 0) {
			isInventoryUser = true;
		}
		return isInventoryUser;
	}

	public boolean getValidUpgradeMgmtUser(String sso) {
		boolean isUpgradeMgmtUser = false;
		String sql = "select ATT6 from FPTODS.SQT_CHANNEL_SETTINGS where USER_NAME=?";

		try {
			String result = this.jdbcTemplate.queryForObject(sql,
					new Object[] { sso }, String.class);

			if (result != null && result.equalsIgnoreCase("Y")) {
				isUpgradeMgmtUser = true;
			}
		} catch (EmptyResultDataAccessException ex) { // queryForObject throws
														// this exception if
														// record not found
			return false;
		} catch (Exception ex) {
			logger.error("getValidUpgradeMgmtUser error: ", ex);
		}
		return isUpgradeMgmtUser;
	}
	
	public boolean getValidRCAccountMgmtUser(String sso) {
		boolean isRCAccountMgmtUser = false;
		String sql = "select ATT8AM from FPTODS.SQT_CHANNEL_SETTINGS where USER_NAME=?";

		try {
			String result = this.jdbcTemplate.queryForObject(sql,
					new Object[] { sso }, String.class);

			if (result != null && result.equalsIgnoreCase("Y")) {
				isRCAccountMgmtUser = true;
			}
		} catch (EmptyResultDataAccessException ex) { 
			return false;
		} catch (Exception ex) {
			logger.error("getValidRCAccountMgmtUser error: ", ex);
		}
		return isRCAccountMgmtUser;
	}
	
	public boolean getValidRCCustomerMgmtUser(String sso) {
		boolean isRCCustomerMgmtUser = false;
		String sql = "select ATT9PM from FPTODS.SQT_CHANNEL_SETTINGS where USER_NAME=?";

		try {
			String result = this.jdbcTemplate.queryForObject(sql,
					new Object[] { sso }, String.class);

			if (result != null && result.equalsIgnoreCase("Y")) {
				isRCCustomerMgmtUser = true;
			}
		} catch (EmptyResultDataAccessException ex) { 
			return false;
		} catch (Exception ex) {
			logger.error("getValidRCCustomerMgmtUser error: ", ex);
		}
		return isRCCustomerMgmtUser;
	}
	
	public boolean getValidRCProductMgmtUser(String sso) {
		boolean isRCProductMgmtUser = false;
		String sql = "select ATT10CM from FPTODS.SQT_CHANNEL_SETTINGS where USER_NAME=?";

		try {
			String result = this.jdbcTemplate.queryForObject(sql,
					new Object[] { sso }, String.class);

			if (result != null && result.equalsIgnoreCase("Y")) {
				isRCProductMgmtUser = true;
			}
		} catch (EmptyResultDataAccessException ex) { 
			return false;
		} catch (Exception ex) {
			logger.error("getValidRCCustomerMgmtUser error: ", ex);
		}
		return isRCProductMgmtUser;
	}
	
	
	/*public boolean getRcUser(String sso) {
		boolean isRcUser = false;
		String sql = "select ATT7 from FPTODS.SQT_CHANNEL_SETTINGS where USER_NAME=?";

		try {
			String result = this.jdbcTemplate.queryForObject(sql,
					new Object[] { sso }, String.class);

			if (result != null && result.equalsIgnoreCase("Y")) {
				isRcUser = true;
			}
		} catch (EmptyResultDataAccessException ex) { // queryForObject throws
														// this exception if
														// record not found
			return false;
		} catch (Exception ex) {
			logger.error("getValidUpgradeMgmtUser error: ", ex);
		}
		return isRcUser;
	}*/
	
}
