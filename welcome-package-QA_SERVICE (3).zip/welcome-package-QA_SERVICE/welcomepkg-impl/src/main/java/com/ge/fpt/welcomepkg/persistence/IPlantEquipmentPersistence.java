package com.ge.fpt.welcomepkg.persistence;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ge.fpt.welcomepkg.api.PlantEquipment;
import com.ge.fpt.welcomepkg.api.StatusInfo;

public interface IPlantEquipmentPersistence {

	@Transactional(propagation = Propagation.REQUIRED)
	List<String> getEquipments(String serailNumber);
	
	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo savePlantEquipment(PlantEquipment equipment);
	
	@Transactional(propagation = Propagation.REQUIRED)
	int getEquipmentCountinPlant(PlantEquipment equipment);
	    
	@Transactional(propagation = Propagation.REQUIRED)
	List<PlantEquipment> getEquipmentinPlant(int pageNo,int rowperpage,PlantEquipment equipment);
	    
	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo deleteEquipment(PlantEquipment equipment);
	
	@Transactional(propagation = Propagation.REQUIRED)
	List<String> getRecSources(String serialNumber);
	
	@Transactional(propagation = Propagation.REQUIRED)
	Map<String, String> getShippingDates(String recSource, String serialNumber);
}
