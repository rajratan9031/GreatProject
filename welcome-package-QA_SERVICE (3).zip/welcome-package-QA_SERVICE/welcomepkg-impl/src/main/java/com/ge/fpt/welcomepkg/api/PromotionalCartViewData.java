package com.ge.fpt.welcomepkg.api;

public class PromotionalCartViewData {
	

	private String optionName;
	private String optionDescription;
    private String partNumber;
	private int quantity;
	private int optionId;
	private int upgradeId;
	private String indicator;
	public String getOptionName() {
		return optionName;
	}
	public void setOptionName(String optionName) {
		this.optionName = optionName;
	}
	public String getOptionDescription() {
		return optionDescription;
	}
	public void setOptionDescription(String optionDescription) {
		this.optionDescription = optionDescription;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	/**
	 * @return the optionId
	 */
	public int getOptionId() {
		return optionId;
	}
	/**
	 * @param optionId the optionId to set
	 */
	public void setOptionId(int optionId) {
		this.optionId = optionId;
	}
	public String getIndicator() {
		return indicator;
	}
	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}
	public int getUpgradeId() {
		return upgradeId;
	}
	public void setUpgradeId(int upgradeId) {
		this.upgradeId = upgradeId;
	}
	
	
	@Override
	public String toString() {
		return "PromotionalCartViewData [optionId=" + optionId + ",optionName=" + optionName + ", optionDescription=" + optionDescription
				+ ", partNumber=" + partNumber + ", quantity=" + quantity + ",upgradeId=" + upgradeId + ",indicator=" + indicator + "]";
	}

	
	

}
