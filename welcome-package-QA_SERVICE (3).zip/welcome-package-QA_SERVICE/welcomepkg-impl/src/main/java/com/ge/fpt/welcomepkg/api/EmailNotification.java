package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class EmailNotification implements Serializable {
	
	private static final long serialVersionUID = 1L;
	

	private Date lastUpdateDate;
	private Date creationDate;
	private String email;
	private String endUser;
	private String endUserIndustry;
	private String salesOrder;
	private String customerPo;
	private String soldToCustName;
	private String sso;
	private String sourceSystem;
	private String productCode;
	private Integer valveCnt;
	
	
	public String getSourceSystem() {
		return sourceSystem;
	}


	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}


	public String getProductCode() {
		return productCode;
	}


	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}


	
	public String getSso() {
		return sso;
	}


	public void setSso(String sso) {
		this.sso = sso;
	}


	public EmailNotification() {
		super();
	}
	
	
	public EmailNotification(Date lastUpdateDate, Date creationDate, String email) {
		super();
		this.lastUpdateDate = lastUpdateDate;
		this.creationDate = creationDate;
		this.email = email;
	}
	
	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}
	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getEndUser() {
		return endUser;
	}


	public void setEndUser(String endUser) {
		this.endUser = endUser;
	}


	public String getEndUserIndustry() {
		return endUserIndustry;
	}


	public void setEndUserIndustry(String endUserIndustry) {
		this.endUserIndustry = endUserIndustry;
	}


	public String getSalesOrder() {
		return salesOrder;
	}


	public void setSalesOrder(String salesOrder) {
		this.salesOrder = salesOrder;
	}


	public String getCustomerPo() {
		return customerPo;
	}


	public void setCustomerPo(String customerPo) {
		this.customerPo = customerPo;
	}


	public String getSoldToCustName() {
		return soldToCustName;
	}


	public void setSoldToCustName(String soldToCustName) {
		this.soldToCustName = soldToCustName;
	}


	public Integer getValveCnt() {
		return valveCnt;
	}


	public void setValveCnt(Integer valveCnt) {
		this.valveCnt = valveCnt;
	}




	}
