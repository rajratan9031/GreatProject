/**
 * 
 */
package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author 204060632
 *
 */
@XmlRootElement
public class EquipLookupData implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/**
	 * 
	 */
	public EquipLookupData() {
	}
	
	private String salesOrder;
	private String serialNumber;
	private String recSource;

	/**
	 * @return the salesOrder
	 */
	public String getSalesOrder() {
		return salesOrder;
	}

	/**
	 * @param salesOrder the salesOrder to set
	 */
	public void setSalesOrder(String salesOrder) {
		this.salesOrder = salesOrder;
	}

	/**
	 * @return the serialNumber
	 */
	public String getSerialNumber() {
		return serialNumber;
	}

	/**
	 * @param serialNumber the serialNumber to set
	 */
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	/**
	 * @return the recSource
	 */
	public String getRecSource() {
		return recSource;
	}

	/**
	 * @param recSource the recSource to set
	 */
	public void setRecSource(String recSource) {
		this.recSource = recSource;
	}

}
