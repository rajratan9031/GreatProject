package com.ge.fpt.welcomepkg.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.IOUtils;

import com.ge.fpt.welcomepkg.api.Report;
import com.ge.fpt.welcomepkg.api.ReportData;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;
import com.ge.fpt.welcomepkg.impl.WelcomePkgServiceImpl;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.html.WebColors;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class PDFExport {

	@SuppressWarnings("javadoc")
	public static final org.slf4j.Logger LOGGER = WelcomePackageLoggerFactory.getLogger(PDFExport.class);
	
	public static final int SMALL_FONT_SIZE=10;
	public static final int HEADER_FONT_SIZE=12;
	public static final int LARGE_FONT_SIZE=20;
	public static final int LOGO_FONT_SIZE=15;
	public static final int FONT_TYPE=1;
	public static final String LOGO_LINK="/WEB-INF/images/new-logo.jpg";
	
	public byte[] generatePDF(List<Report> data, ReportData reportParam, String currencySymbol,String sso) {

		if ("4".equals(reportParam.getReportType())) {
			return generateSPIRReport(data);
		}if ("5".equals(reportParam.getReportType())) {
			return generateRSPValveReport(data);
		}if ("6".equals(reportParam.getReportType())) {
			return generateBOMValveReport(data);
		}if ("7".equals(reportParam.getReportType())) {
			return generateRSPQuoteReport(data,currencySymbol,sso);
		}
		return null;
	}
	
	public byte[] generateBOMValveReport(List<Report> list) {
		Document document = new Document();
		document.setPageSize(PageSize.A4.rotate());
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		
		List<String> factoryList=getFactoryList(list);
		
		Font smallfont = new Font(FontFamily.TIMES_ROMAN, SMALL_FONT_SIZE,FONT_TYPE);
		Font smallfontbold = new Font(FontFamily.TIMES_ROMAN, SMALL_FONT_SIZE,FONT_TYPE);
		Font smallfontitalic = new Font(FontFamily.TIMES_ROMAN, SMALL_FONT_SIZE);
		Font smallDatafont = new Font(FontFamily.TIMES_ROMAN, SMALL_FONT_SIZE,FONT_TYPE);
		// 1 stands for Bold 2 Italic
		Font headerFont = new Font(FontFamily.TIMES_ROMAN, HEADER_FONT_SIZE, FONT_TYPE);
		Font largefont = new Font(FontFamily.TIMES_ROMAN, LARGE_FONT_SIZE, FONT_TYPE);
		Font logoFont = new Font(FontFamily.TIMES_ROMAN, LOGO_FONT_SIZE, FONT_TYPE);

		Set<String> salesOrders = new HashSet<String>();
		Set<String> soldToCustomers = new HashSet<String>();
		Set<String> pos = new HashSet<String>();
		Set<String> factories = new HashSet<String>();
		Set<String> representatives = new HashSet<String>();

		for (Report temp : list) {
			salesOrders.add(temp.getSalesOrder());
			soldToCustomers.add(temp.getSoldToCustomerName() + " ,"
					+ temp.getSoldToCity() + " ," + temp.getSoldToState()
					+ " ," + temp.getEndUserCountry());
			pos.add(temp.getPurchaseOrderNumber());
			factories.add(temp.getSourceSystem());
			representatives.add(temp.getRepName());
		}

		String salesOrder = "";
		String soldToCustomer = "";
		String po = "";
		String factory = "";
		String representative = "";
		if (salesOrders.size()> 0) {
			for (String temp : salesOrders) {
				salesOrder = salesOrder + temp + ",";
			}
			salesOrder = salesOrder.substring(0, salesOrder.length() - 1);
		}
		if (soldToCustomers.size() >0) {
			for (String temp : soldToCustomers) {
				soldToCustomer = soldToCustomer + temp + " \n";
			}
		}
		if (pos.size() > 0) {
			for (String temp : pos) {
				po = po + temp + ",";
			}
			po = po.substring(0, po.length() - 1);
		}
		if (factories.size() > 0) {
			for (String temp : factories) {
				factory = factory + temp + ",";
			}
			factory = factory.substring(0, factory.length() - 1);
		}
		if (representatives.size()> 0) {
			for (String temp : representatives) {
				representative = representative + temp + " \n";
			}
			
		}
		try {
			PdfWriter.getInstance(document, baos);
			document.open();

			Image image1 = Image.getInstance(IOUtils.toByteArray(this
					.getClass().getResourceAsStream(LOGO_LINK)));
			image1.setAbsolutePosition(0f, 0f);
			image1.scaleAbsolute(90, 40);

			PdfPTable table = new PdfPTable(6);
			table.setWidthPercentage(100);
			table.setWidths(new float[] { 0.5f, 1,1, 0.5f, 1, 1 });

			// first row
			PdfPCell cell = new PdfPCell(image1);
			cell.setColspan(2);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setFixedHeight(50);
			table.addCell(cell);

			cell = new PdfPCell(new Phrase(
					"Bill of Material Report By Valve", largefont));
			cell.setColspan(5);
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell.setVerticalAlignment(Element.ALIGN_CENTER);
			cell.setFixedHeight(50);
			table.addCell(cell);

			cell = new PdfPCell(new Phrase("", logoFont));
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setColspan(2);
			table.addCell(cell);
			addEmptyCells(3, table);

			Date date = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,YYYY");
			cell = new PdfPCell(new Phrase("Date:" + sdf.format(date),
					smallfont));
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);

			cell = new PdfPCell(new Phrase("Flow and process Technologies",
					smallfont));
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setColspan(2);
			cell.setMinimumHeight(20);
			table.addCell(cell);

			addEmptyCells(4, table);

			cell = new PdfPCell(new Phrase("Sales Order:", smallfont));
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase(salesOrder, smallDatafont));
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setColspan(2);
			table.addCell(cell);

			cell = new PdfPCell(new Phrase("Customer:", smallfont));
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);

			cell = new PdfPCell(new Phrase(soldToCustomer, smallDatafont));
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setColspan(2);
			table.addCell(cell);

			// second Row
			cell = new PdfPCell(new Phrase("Customer PO:", smallfont));
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase(po, smallDatafont));
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setColspan(2);
			table.addCell(cell);
			addEmptyCells(3, table);

			// third row
			cell = new PdfPCell(new Phrase("Factory:", smallfont));
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase(factory, smallDatafont));
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setColspan(2);
			table.addCell(cell);
			addEmptyCells(3, table);

			// fourth row
			cell = new PdfPCell(new Phrase("Rep:", smallfont));
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setFixedHeight(30);
			table.addCell(cell);

			cell = new PdfPCell(new Phrase(representative, smallDatafont));
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setFixedHeight(20f);
			cell.setColspan(2);
			table.addCell(cell);
			addEmptyCells(3, table);

			document.add(table);

			table = new PdfPTable(9);
			table.setWidthPercentage(100);
			table.setWidths(new float[] { 0.75f,1.5f, 1.5f, 2f, 2f, 1f, 0.75f,
					0.75f, 0.75f });
			BaseColor myColor = WebColors.getRGBColor("#fff");
			cell = new PdfPCell(new Phrase("Sales Order Line", headerFont));
			cell.setBackgroundColor(myColor);
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase("Serial Number", headerFont));
			cell.setBackgroundColor(myColor);
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase("Tag Number", headerFont));
			cell.setBackgroundColor(myColor);
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase("Part Number", headerFont));
			cell.setBackgroundColor(myColor);
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase("Description", headerFont));
			cell.setBackgroundColor(myColor);
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase("Legacy Part Number", headerFont));
			cell.setBackgroundColor(myColor);
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase("Quantity", headerFont));
			cell.setBackgroundColor(myColor);
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase("Spare Indicator", headerFont));
			cell.setBackgroundColor(myColor);
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase("Lead Time (WEEKS)", headerFont));
			cell.setBackgroundColor(myColor);
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			table.setHeaderRows(1);
			
			String serialNumber = "";
			String soLine = "";
			String tagNo = "";
			for(int i=0;i<factoryList.size();i++){
			for (Report bean : list) {
				boolean isFirstRow= false;
				if(factoryList.get(i).equalsIgnoreCase(bean.getSourceSystem())){
					if(!bean.getValveSerialNumber().equalsIgnoreCase(serialNumber)
						|| !bean.getTagNumber().equalsIgnoreCase(tagNo)	
						|| !bean.getSalesOrderLine().equalsIgnoreCase(soLine)){
						isFirstRow = true;
					}
					if (isFirstRow) {
					cell = new PdfPCell(new Phrase(
							bean.getSalesOrderLine(), smallfontbold));
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					cell = new PdfPCell(new Phrase(
							bean.getValveSerialNumber(), smallfontbold));
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					cell = new PdfPCell(new Phrase(
							bean.getTagNumber(), smallfontbold));
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					cell = new PdfPCell(new Phrase(
							bean.getValvePartNumber(), smallfontbold));
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					cell = new PdfPCell(new Phrase(
							bean.getValveDescription(), smallfontbold));
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					cell = new PdfPCell(new Phrase(
							"", smallfontbold));
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					cell = new PdfPCell(new Phrase(
							"", smallfontbold));
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					cell = new PdfPCell(new Phrase(
							"", smallfontbold));
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					cell = new PdfPCell(new Phrase(
							"", smallfontbold));
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
				}
					cell = new PdfPCell();
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					cell = new PdfPCell();
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					cell = new PdfPCell();
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					cell = new PdfPCell(new Phrase(
							bean.getComponentItemNumber(), smallfontitalic));
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					cell = new PdfPCell(new Phrase(
							bean.getComponentDescription(), smallfontitalic));
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					cell = new PdfPCell(new Phrase(
							bean.getLegacyPartNumber(), smallfontitalic));
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					cell = new PdfPCell(new Phrase(
							bean.getQuantity()+"", smallfontitalic));
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					cell = new PdfPCell(new Phrase(
							bean.getSpareIndicator(), smallfontitalic));
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					cell = new PdfPCell(new Phrase(
							bean.getLeadTime(), smallfontitalic));
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
				}
				serialNumber=bean.getValveSerialNumber();
				soLine=bean.getSalesOrderLine();
				tagNo=bean.getTagNumber();
				}
			}
			document.add(table);
			document.close();
			byte[] pdfBytes = baos.toByteArray();
			baos.close();
			return pdfBytes;
			}catch(Exception e){
				LOGGER.info("Exception in generateBOMValveReport: " + e);
				return null;
			}
	}
	
	List<String> getFactoryList(List<Report> list){
		List<String> factoryList=new ArrayList<String>();
		for(Report bean : list ){
			if(bean.getSourceSystem()!=null && !factoryList.contains(bean.getSourceSystem())){
				factoryList.add(bean.getSourceSystem());
			}
		}
		return factoryList;
	}
	public byte[] generateRSPValveReport(List<Report> list) {
		Document document = new Document();
		document.setPageSize(PageSize.A4.rotate());
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		Font smallfont = new Font(FontFamily.TIMES_ROMAN, SMALL_FONT_SIZE);
		Font smallDatafont = new Font(FontFamily.TIMES_ROMAN, SMALL_FONT_SIZE,FONT_TYPE);
		// 1 stands for Bold 2 Italic
		Font headerFont = new Font(FontFamily.TIMES_ROMAN, HEADER_FONT_SIZE, FONT_TYPE);
		Font largefont = new Font(FontFamily.TIMES_ROMAN, LARGE_FONT_SIZE, FONT_TYPE);
		Font logoFont = new Font(FontFamily.TIMES_ROMAN, LOGO_FONT_SIZE, FONT_TYPE);

		Set<String> salesOrders = new HashSet<String>();
		Set<String> soldToCustomers = new HashSet<String>();
		Set<String> pos = new HashSet<String>();
		Set<String> factories = new HashSet<String>();
		Set<String> representatives = new HashSet<String>();

		for (Report temp : list) {
			salesOrders.add(temp.getSalesOrder());
			soldToCustomers.add(temp.getSoldToCustomerName() + " ,"
					+ temp.getSoldToCity() + " ," + temp.getSoldToState()
					+ " ," + temp.getEndUserCountry());
			pos.add(temp.getPurchaseOrderNumber());
			factories.add(temp.getSourceSystem());
			representatives.add(temp.getRepName());
		}

		String salesOrder = "";
		String soldToCustomer = "";
		String po = "";
		String factory = "";
		String representative = "";
		if (salesOrders.size() != 0) {
			for (String temp : salesOrders) {
				salesOrder = salesOrder + temp + ",";
			}
			salesOrder = salesOrder.substring(0, salesOrder.length() - 1);
		}
		if (soldToCustomers.size() != 0) {
			for (String temp : soldToCustomers) {
				soldToCustomer = soldToCustomer + temp + " \n";
			}
			// soldToCustomer=soldToCustomer.substring(0,
			// soldToCustomer.length()-1);
		}
		if (pos.size() != 0) {
			for (String temp : pos) {
				po = po + temp + ",";
			}
			po = po.substring(0, po.length() - 1);
		}
		if (factories.size() != 0) {
			for (String temp : factories) {
				factory = factory + temp + ",";
			}
			factory = factory.substring(0, factory.length() - 1);
		}
		if (representatives.size() != 0) {
			for (String temp : representatives) {
				representative = representative + temp + " \n";
			}
			// representative=representative.substring(0,
			// representative.length()-1);
		}
		try {
		PdfWriter.getInstance(document, baos);
		document.open();

		Image image1 = Image.getInstance(IOUtils.toByteArray(this
				.getClass().getResourceAsStream(LOGO_LINK)));
		image1.setAbsolutePosition(0f, 0f);
		image1.scaleAbsolute(90, 40);

		PdfPTable table = new PdfPTable(6);
		table.setWidthPercentage(100);
		table.setWidths(new float[] { 0.5f, 1,1, 0.5f, 1, 1 });

		// first row
		PdfPCell cell = new PdfPCell(image1);
		cell.setColspan(2);
		cell.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setFixedHeight(50);
		table.addCell(cell);
		cell = new PdfPCell(new Phrase(
				"Recommended Spares Report By Valve", largefont));
		cell.setColspan(5);
		// cell.setRowspan(3);
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell.setVerticalAlignment(Element.ALIGN_CENTER);
		cell.setFixedHeight(50);
		table.addCell(cell);

		cell = new PdfPCell(new Phrase("", logoFont));
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setColspan(2);
		table.addCell(cell);
		addEmptyCells(3, table);

		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,YYYY");
		cell = new PdfPCell(new Phrase("Date:" + sdf.format(date),
				smallfont));
		cell.setBorder(Rectangle.NO_BORDER);
		table.addCell(cell);

		cell = new PdfPCell(new Phrase("Flow and process Technologies",
				smallfont));
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setColspan(2);
		cell.setMinimumHeight(20);
		table.addCell(cell);

		addEmptyCells(4, table);

		cell = new PdfPCell(new Phrase("Sales Order:", smallfont));
		cell.setBorder(Rectangle.NO_BORDER);
		table.addCell(cell);
		cell = new PdfPCell(new Phrase(salesOrder, smallDatafont));
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setColspan(2);
		table.addCell(cell);

		cell = new PdfPCell(new Phrase("Customer:", smallfont));
		cell.setBorder(Rectangle.NO_BORDER);
		table.addCell(cell);

		cell = new PdfPCell(new Phrase(soldToCustomer, smallDatafont));
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setColspan(2);
		table.addCell(cell);

		// second Row
		cell = new PdfPCell(new Phrase("Customer PO:", smallfont));
		cell.setBorder(Rectangle.NO_BORDER);
		table.addCell(cell);
		cell = new PdfPCell(new Phrase(po, smallDatafont));
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setColspan(2);
		table.addCell(cell);
		addEmptyCells(3, table);

		// third row
		cell = new PdfPCell(new Phrase("Factory:", smallfont));
		cell.setBorder(Rectangle.NO_BORDER);
		table.addCell(cell);
		cell = new PdfPCell(new Phrase(factory, smallDatafont));
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setColspan(2);
		table.addCell(cell);
		addEmptyCells(3, table);

		// fourth row
		cell = new PdfPCell(new Phrase("Rep:", smallfont));
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setFixedHeight(30);
		table.addCell(cell);

		cell = new PdfPCell(new Phrase(representative, smallDatafont));
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setFixedHeight(20f);
		cell.setColspan(2);
		table.addCell(cell);
		addEmptyCells(3, table);

		document.add(table);
		
		table = new PdfPTable(12);
		table.setWidthPercentage(100);
		table.setWidths(new float[] { 0.5f, 1.5f, 1.5f, 1f, 1.5f, 1.5f, 1f,
				0.75f, 0.75f,0.75f,0.75f,0.75f });
		BaseColor myColor = WebColors.getRGBColor("#fff");

		cell = new PdfPCell(new Phrase("Sales Order Line", headerFont));
		cell.setBackgroundColor(myColor);
		cell.setBorder(Rectangle.NO_BORDER);
		table.addCell(cell);
		cell = new PdfPCell(new Phrase("Serial Number", headerFont));
		cell.setBackgroundColor(myColor);
		cell.setBorder(Rectangle.NO_BORDER);
		table.addCell(cell);
		cell = new PdfPCell(new Phrase("Tag Number", headerFont));
		cell.setBackgroundColor(myColor);
		cell.setBorder(Rectangle.NO_BORDER);
		table.addCell(cell);
		cell = new PdfPCell(new Phrase("Ship Date", headerFont));
		cell.setBackgroundColor(myColor);
		cell.setBorder(Rectangle.NO_BORDER);
		table.addCell(cell);
		cell = new PdfPCell(new Phrase("Part Number", headerFont));
		cell.setBackgroundColor(myColor);
		cell.setBorder(Rectangle.NO_BORDER);
		table.addCell(cell);
		cell = new PdfPCell(new Phrase("Description", headerFont));
		cell.setBackgroundColor(myColor);
		cell.setBorder(Rectangle.NO_BORDER);
		table.addCell(cell);
		cell = new PdfPCell(new Phrase("Legacy Part Number", headerFont));
		cell.setBackgroundColor(myColor);
		cell.setBorder(Rectangle.NO_BORDER);
		table.addCell(cell);
		cell = new PdfPCell(new Phrase("Spare Type", headerFont));
		cell.setBackgroundColor(myColor);
		cell.setBorder(Rectangle.NO_BORDER);
		table.addCell(cell);
		cell = new PdfPCell(new Phrase("Stock Type", headerFont));
		cell.setBackgroundColor(myColor);
		cell.setBorder(Rectangle.NO_BORDER);
		table.addCell(cell);
		cell = new PdfPCell(new Phrase("Quantity", headerFont));
		cell.setBackgroundColor(myColor);
		cell.setBorder(Rectangle.NO_BORDER);
		table.addCell(cell);
		cell = new PdfPCell(new Phrase("List Price("
				+ list.get(0).getCurrencyUnit() + ")", headerFont));
		cell.setBackgroundColor(myColor);
		cell.setBorder(Rectangle.NO_BORDER);
		table.addCell(cell);
		cell = new PdfPCell(new Phrase("Lead Time(Weeks)", headerFont));
		cell.setBackgroundColor(myColor);
		cell.setBorder(Rectangle.NO_BORDER);
		table.addCell(cell);
		table.setHeaderRows(1);
		
		String soLine = "";
		String serialNumber = "";
		String tagNumber="";
		
		for (Report bean : list) {
			if(!bean.getValveSerialNumber().equalsIgnoreCase(serialNumber)){
				cell = new PdfPCell(new Phrase(
						bean.getSalesOrderLine(), smallfont));
				cell.setBorder(Rectangle.NO_BORDER);
				table.addCell(cell);
				cell = new PdfPCell(new Phrase(
						bean.getValveSerialNumber(), smallfont));
				cell.setBorder(Rectangle.NO_BORDER);
				table.addCell(cell);
				cell = new PdfPCell(new Phrase(
						bean.getTagNumber(), smallfont));
				cell.setBorder(Rectangle.NO_BORDER);
				table.addCell(cell);
			}else{
				cell = new PdfPCell();
				cell.setBorder(Rectangle.NO_BORDER);
				table.addCell(cell);
				cell = new PdfPCell();
				cell.setBorder(Rectangle.NO_BORDER);
				table.addCell(cell);
				cell = new PdfPCell();
				cell.setBorder(Rectangle.NO_BORDER);
				table.addCell(cell);
			}
			cell = new PdfPCell(new Phrase(bean.getActualShippedDate()+"", smallfont));
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase(
					bean.getComponentItemNumber(), smallfont));
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase(
					bean.getComponentDescription(), smallfont));
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase(
					bean.getLegacyPartNumber(), smallfont));
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase(
					bean.getSpareIndicator(), smallfont));
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase(
					bean.getStockType(), smallfont));
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase(
					bean.getQuantity()+"", smallfont));
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase(
					bean.getListPrice()+"", smallfont));
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase(
					bean.getLeadTime(), smallfont));
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			
			soLine=bean.getSalesOrderLine();
			serialNumber=bean.getValveSerialNumber();
			tagNumber=bean.getTagNumber();
		}
		document.add(table);
		document.close();
		byte[] pdfBytes = baos.toByteArray();
		baos.close();
		return pdfBytes;
		}catch(Exception e){
			document.close();
			LOGGER.info("Exception in generateRSPValveReport: " + e.getMessage());
			return null;
		}
		
	}

	public byte[] generateSPIRReport(List<Report> list) {
		Document document = new Document();
		document.setPageSize(PageSize.A4.rotate());
		ByteArrayOutputStream baos = new ByteArrayOutputStream();

		Font smallfont = new Font(FontFamily.TIMES_ROMAN, SMALL_FONT_SIZE);
		Font smallDatafont = new Font(FontFamily.TIMES_ROMAN, SMALL_FONT_SIZE,FONT_TYPE);
		// 1 stands for Bold 2 Italic
		Font headerFont = new Font(FontFamily.TIMES_ROMAN, HEADER_FONT_SIZE, FONT_TYPE);
		Font largefont = new Font(FontFamily.TIMES_ROMAN, LARGE_FONT_SIZE, FONT_TYPE);
		Font logoFont = new Font(FontFamily.TIMES_ROMAN, LOGO_FONT_SIZE, FONT_TYPE);

		Set<String> salesOrders = new HashSet<String>();
		Set<String> soldToCustomers = new HashSet<String>();
		Set<String> pos = new HashSet<String>();
		Set<String> factories = new HashSet<String>();
		Set<String> representatives = new HashSet<String>();

		for (Report temp : list) {
			salesOrders.add(temp.getSalesOrder());
			soldToCustomers.add(temp.getSoldToCustomerName() + " ,"
					+ temp.getSoldToCity() + " ," + temp.getSoldToState()
					+ " ," + temp.getEndUserCountry());
			pos.add(temp.getPurchaseOrderNumber());
			factories.add(temp.getSourceSystem());
			representatives.add(temp.getRepName());
		}

		String salesOrder = "";
		String soldToCustomer = "";
		String po = "";
		String factory = "";
		String representative = "";
		if (salesOrders.size() != 0) {
			for (String temp : salesOrders) {
				salesOrder = salesOrder + temp + ",";
			}
			salesOrder = salesOrder.substring(0, salesOrder.length() - 1);
		}
		if (soldToCustomers.size() != 0) {
			for (String temp : soldToCustomers) {
				soldToCustomer = soldToCustomer + temp + " \n";
			}
			// soldToCustomer=soldToCustomer.substring(0,
			// soldToCustomer.length()-1);
		}
		if (pos.size() != 0) {
			for (String temp : pos) {
				po = po + temp + ",";
			}
			po = po.substring(0, po.length() - 1);
		}
		if (factories.size() != 0) {
			for (String temp : factories) {
				factory = factory + temp + ",";
			}
			factory = factory.substring(0, factory.length() - 1);
		}
		if (representatives.size() != 0) {
			for (String temp : representatives) {
				representative = representative + temp + " \n";
			}
			// representative=representative.substring(0,
			// representative.length()-1);
		}
		try {
			PdfWriter.getInstance(document, baos);
			document.open();

			Image image1 = Image.getInstance(IOUtils.toByteArray(this
					.getClass().getResourceAsStream(LOGO_LINK)));
			image1.setAbsolutePosition(0f, 0f);
			image1.scaleAbsolute(90, 40);

			PdfPTable table = new PdfPTable(6);
			table.setWidthPercentage(100);
			table.setWidths(new float[] { 0.5f, 1,1, 0.5f, 1, 1 });

			// first row
			PdfPCell cell = new PdfPCell(image1);
			cell.setColspan(2);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setFixedHeight(50);
			table.addCell(cell);

			cell = new PdfPCell(new Phrase(
					"Spare Parts Interchangeability Report (SPIR)", largefont));
			cell.setColspan(5);
			// cell.setRowspan(3);
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell.setVerticalAlignment(Element.ALIGN_CENTER);
			cell.setFixedHeight(50);
			table.addCell(cell);

			cell = new PdfPCell(new Phrase("", logoFont));
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setColspan(2);
			table.addCell(cell);
			addEmptyCells(3, table);

			Date date = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,YYYY");
			cell = new PdfPCell(new Phrase("Date:" + sdf.format(date),
					smallfont));
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);

			cell = new PdfPCell(new Phrase("Flow and process Technologies",
					smallfont));
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setColspan(2);
			cell.setMinimumHeight(20);
			table.addCell(cell);

			addEmptyCells(4, table);

			cell = new PdfPCell(new Phrase("Sales Order:", smallfont));
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase(salesOrder, smallDatafont));
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setColspan(2);
			table.addCell(cell);

			cell = new PdfPCell(new Phrase("Customer:", smallfont));
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);

			cell = new PdfPCell(new Phrase(soldToCustomer, smallDatafont));
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setColspan(2);
			table.addCell(cell);

			// second Row
			cell = new PdfPCell(new Phrase("Customer PO:", smallfont));
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase(po, smallDatafont));
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setColspan(2);
			table.addCell(cell);
			addEmptyCells(3, table);

			// third row
			cell = new PdfPCell(new Phrase("Factory:", smallfont));
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase(factory, smallDatafont));
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setColspan(2);
			table.addCell(cell);
			addEmptyCells(3, table);

			// fourth row
			cell = new PdfPCell(new Phrase("Rep:", smallfont));
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setFixedHeight(30);
			table.addCell(cell);

			cell = new PdfPCell(new Phrase(representative, smallDatafont));
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setFixedHeight(20f);
			cell.setColspan(2);
			table.addCell(cell);
			addEmptyCells(3, table);

			document.add(table);

			table = new PdfPTable(9);
			table.setWidthPercentage(100);
			table.setWidths(new float[] { 1.5f, 2f, 1f, 0.75f, 1.5f, 1.2f, 1f,
					0.75f, 0.75f });
			BaseColor myColor = WebColors.getRGBColor("#fff");

			cell = new PdfPCell(new Phrase("Item Number", headerFont));
			cell.setBackgroundColor(myColor);
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase("Description", headerFont));
			cell.setBackgroundColor(myColor);
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase("Spares Category", headerFont));
			cell.setBackgroundColor(myColor);
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase("Quantity", headerFont));
			cell.setBackgroundColor(myColor);
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase("Tag Number", headerFont));
			cell.setBackgroundColor(myColor);
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase("Serial Number", headerFont));
			cell.setBackgroundColor(myColor);
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase("Recommended Quantity", headerFont));
			cell.setBackgroundColor(myColor);
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase("List Price("
					+ list.get(0).getCurrencyUnit() + ")", headerFont));
			cell.setBackgroundColor(myColor);
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			cell = new PdfPCell(new Phrase("Extended Price("
					+ list.get(0).getCurrencyUnit() + ")", headerFont));
			cell.setBackgroundColor(myColor);
			cell.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell);
			table.setHeaderRows(1);

			String tempComponentItemNumber = "";

			for (Report bean : list) {
				if (!tempComponentItemNumber.equals(bean
						.getComponentItemNumber())
						|| "".equals(tempComponentItemNumber)) {
					document.add(table);
					if (!tempComponentItemNumber.equals("")) {
						document.newPage();
						table = new PdfPTable(9);
						table.setWidthPercentage(100);
						table.setWidths(new float[] { 1.5f, 2f, 1f, 0.75f,
								1.5f, 1.2f, 1f, 0.75f, 0.75f });

						cell = new PdfPCell(new Phrase("Item Number",
								headerFont));
						cell.setBackgroundColor(myColor);
						cell.setBorder(Rectangle.NO_BORDER);
						table.addCell(cell);
						cell = new PdfPCell(new Phrase("Description",
								headerFont));
						cell.setBackgroundColor(myColor);
						cell.setBorder(Rectangle.NO_BORDER);
						table.addCell(cell);
						cell = new PdfPCell(new Phrase("Spares Category",
								headerFont));
						cell.setBackgroundColor(myColor);
						cell.setBorder(Rectangle.NO_BORDER);
						table.addCell(cell);
						cell = new PdfPCell(new Phrase("Quantity", headerFont));
						cell.setBackgroundColor(myColor);
						cell.setBorder(Rectangle.NO_BORDER);
						table.addCell(cell);
						cell = new PdfPCell(
								new Phrase("Tag Number", headerFont));
						cell.setBackgroundColor(myColor);
						cell.setBorder(Rectangle.NO_BORDER);
						table.addCell(cell);
						cell = new PdfPCell(new Phrase("Serial Number",
								headerFont));
						cell.setBackgroundColor(myColor);
						cell.setBorder(Rectangle.NO_BORDER);
						table.addCell(cell);
						cell = new PdfPCell(new Phrase("Recommended Quantity",
								headerFont));
						cell.setBackgroundColor(myColor);
						cell.setBorder(Rectangle.NO_BORDER);
						table.addCell(cell);
						cell = new PdfPCell(new Phrase("List Price("
								+ list.get(0).getCurrencyUnit() + ")",
								headerFont));
						cell.setBackgroundColor(myColor);
						cell.setBorder(Rectangle.NO_BORDER);
						table.addCell(cell);
						cell = new PdfPCell(new Phrase("Extended Price ("
								+ list.get(0).getCurrencyUnit() + ")",
								headerFont));
						cell.setBackgroundColor(myColor);
						cell.setBorder(Rectangle.NO_BORDER);
						table.addCell(cell);
						table.setHeaderRows(1);

					}
					tempComponentItemNumber = bean.getComponentItemNumber();
					cell = new PdfPCell(new Phrase(
							bean.getComponentItemNumber(), smallfont));
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					cell = new PdfPCell(new Phrase(
							bean.getComponentDescription(), smallfont));
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					cell = new PdfPCell(new Phrase(bean.getSpareCategory(),
							smallfont));
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);

					int quantity = 0;
					for (Report temp : list) {
						if (tempComponentItemNumber.equals(temp
								.getComponentItemNumber())) {
							quantity += temp.getQuantity();
						} 
					}

					cell = new PdfPCell(new Phrase(quantity + "", smallfont));
					cell.setHorizontalAlignment(PdfPCell.ALIGN_CENTER);
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);

					addEmptyCells(2, table);
					/*double recomendedQty = Math.ceil(quantity
							* bean.getDefaultPercent());*/
					int recomendedQty=bean.getRecomendedQty();
					cell = new PdfPCell(new Phrase(recomendedQty + "",
							smallfont));
					cell.setHorizontalAlignment(PdfPCell.ALIGN_CENTER);
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					cell = new PdfPCell(new Phrase(bean.getListPrice() + "",
							smallfont));
					cell.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					double extLP = recomendedQty * bean.getListPrice();
					cell = new PdfPCell(new Phrase(extLP + "", smallfont));
					cell.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);

					addEmptyCells(3, table);
					cell = new PdfPCell(new Phrase(bean.getQuantity() + "",
							smallfont));
					cell.setHorizontalAlignment(PdfPCell.ALIGN_CENTER);
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					cell = new PdfPCell(new Phrase(bean.getTagNumber(),
							smallfont));
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					cell = new PdfPCell(new Phrase(bean.getValveSerialNumber(),
							smallfont));
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					addEmptyCells(3, table);
					} else {

					addEmptyCells(3, table);
					cell = new PdfPCell(new Phrase(bean.getQuantity() + "",
							smallfont));
					cell.setHorizontalAlignment(PdfPCell.ALIGN_CENTER);
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					cell = new PdfPCell(new Phrase(bean.getTagNumber(),
							smallfont));
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					cell = new PdfPCell(new Phrase(bean.getValveSerialNumber(),
							smallfont));
					cell.setBorder(Rectangle.NO_BORDER);
					table.addCell(cell);
					addEmptyCells(3, table);
					//document.add(table);
				}
				//tempComponentItemNumber = bean.getComponentItemNumber();
			}
			document.add(table);
			document.close();
			byte[] pdfBytes = baos.toByteArray();
			baos.close();
			return pdfBytes;
		} catch (Exception e) {
			document.close();
			LOGGER.info("Exception in generateSPIRReport: " + e.getMessage());
			return null;
		}
	}
	
	public byte[] generateRSPQuoteReport(List<Report> list,String currencySymbol,String sso) {
		boolean isInternal = WelcomePkgServiceImpl.isInternalUser(sso);
		Document document = new Document();
		document.setPageSize(PageSize.A4.rotate());
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		Font smallfont = new Font(FontFamily.TIMES_ROMAN, SMALL_FONT_SIZE);
		Font smallfontitalic = new Font(FontFamily.TIMES_ROMAN, SMALL_FONT_SIZE,Font.ITALIC);
		Font smallDatafont = new Font(FontFamily.TIMES_ROMAN, SMALL_FONT_SIZE,FONT_TYPE);
		// 1 stands for Bold 2 Italic
		Font headerFont = new Font(FontFamily.TIMES_ROMAN, HEADER_FONT_SIZE, FONT_TYPE);
		Font largefont = new Font(FontFamily.TIMES_ROMAN, LARGE_FONT_SIZE, FONT_TYPE);
		Font logoFont = new Font(FontFamily.TIMES_ROMAN, LOGO_FONT_SIZE, FONT_TYPE);
		//List<Report> listdata=processQuoteData(list);
			try {
			PdfWriter.getInstance(document, baos);
			document.open();
			Image image1 = Image.getInstance(IOUtils.toByteArray(this
					.getClass().getResourceAsStream(LOGO_LINK)));
			image1.setAbsolutePosition(0f, 0f);
			image1.scaleAbsolute(90, 40);

			PdfPTable tabletop = new PdfPTable(7);
			tabletop.setWidthPercentage(100);
			tabletop.setWidths(new float[] { 1.5f, 1,5f, 1.5f, 1f, 1f ,1.5f});

			// first row
			PdfPCell cell = new PdfPCell(image1);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setFixedHeight(40);
			tabletop.addCell(cell);

			cell = new PdfPCell(new Phrase(
					"Spare Part Quote Report", largefont));
			cell.setColspan(5);
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell.setVerticalAlignment(Element.ALIGN_CENTER);
			cell.setFixedHeight(40);
			tabletop.addCell(cell);
			
			cell = new PdfPCell(new Phrase(""));
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell.setVerticalAlignment(Element.ALIGN_CENTER);
			cell.setFixedHeight(40);
			tabletop.addCell(cell);

			//second row
			cell = new PdfPCell(new Phrase("", logoFont));
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setColspan(2);
			tabletop.addCell(cell);
			addEmptyCells(3, tabletop);

			Date date = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,YYYY");
			cell = new PdfPCell(new Phrase("Date:" + sdf.format(date),
					smallfont));
			cell.setColspan(2);
			cell.setBorder(Rectangle.NO_BORDER);
			tabletop.addCell(cell);

			//3rd row
			cell = new PdfPCell(new Phrase("Flow and process Technologies",
					smallfontitalic));
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setColspan(2);
			cell.setMinimumHeight(20);
			tabletop.addCell(cell);

			addEmptyCells(5, tabletop);
			document.add(tabletop);
       			PdfPTable table=new PdfPTable(4);
			
			List<Report>headerList=processQuoteHeaderList(list,isInternal);
		//	LOGGER.info("quote report list size---->> " +headerList.size());
			String serialNumber="";
			String tagNo="";
			String so="";
			for(int i=0;i<headerList.size();i++){
				if((!headerList.get(i).getValveSerialNumber().equalsIgnoreCase(serialNumber)
						&&!("").equals(serialNumber))
						||( !headerList.get(i).getTagNumber().equalsIgnoreCase(tagNo)
								&& !"".equals(tagNo)) 
						||(!headerList.get(i).getSalesOrder().equalsIgnoreCase(so)
								&& !"".equals(so))){
					document.newPage();
				}
				if((!headerList.get(i).getValveSerialNumber().equalsIgnoreCase(serialNumber)
						|| ("").equals(serialNumber))
						|| (!headerList.get(i).getTagNumber().equalsIgnoreCase(tagNo)
								||("").equals(tagNo))
						|| (!headerList.get(i).getSalesOrder().equalsIgnoreCase(so)
								|| ("").equals(so))){
					  //document.add(table);
					 table = new PdfPTable(5);
					 table.setWidthPercentage(100);
					 table.setWidths(new float[] { 1.5f, 1.5f,1.5f, 1f, 3f});
					BaseColor myColor = WebColors.getRGBColor("#fff");
					
					
					PdfPTable table1 = new PdfPTable(7);
					table1.setWidthPercentage(100);
					table1.setWidths(new float[] { 1.5f, 1,5f, 1.5f, 1f, 1f ,1.5f});
					cell = new PdfPCell(new Phrase("Channel Partner:", smallfont));
					cell.setBorder(Rectangle.NO_BORDER);
					table1.addCell(cell);
					
					cell = new PdfPCell(new Phrase(headerList.get(i).getChannelPartner(), smallDatafont));
					cell.setBorder(Rectangle.NO_BORDER);
					cell.setColspan(2);
					table1.addCell(cell);
					addEmptyCells(1, table1);
					cell = new PdfPCell(new Phrase("Quote:", smallfont));
					cell.setBorder(Rectangle.NO_BORDER);
					table1.addCell(cell);

					cell = new PdfPCell(new Phrase(headerList.get(i).getSpareQuotes(), smallDatafont));
					cell.setBorder(Rectangle.NO_BORDER);
					cell.setColspan(2);
					table1.addCell(cell);

					// 5th Row
					cell = new PdfPCell(new Phrase("End User Name:", smallfont));
					cell.setBorder(Rectangle.NO_BORDER);
					table1.addCell(cell);
					cell = new PdfPCell(new Phrase(headerList.get(i).getEndUserName(), smallDatafont));
					cell.setBorder(Rectangle.NO_BORDER);
					cell.setColspan(2);
					table1.addCell(cell);
					addEmptyCells(4, table1);
					
					// second Row
					cell = new PdfPCell(new Phrase("End User Location:", smallfont));
					cell.setFixedHeight(30);
					cell.setBorder(Rectangle.NO_BORDER);
					table1.addCell(cell);
					cell = new PdfPCell(new Phrase(headerList.get(i).getEndUserLocation(), smallDatafont));
					cell.setBorder(Rectangle.NO_BORDER);
					cell.setColspan(2);
					table1.addCell(cell);
					addEmptyCells(4, table1);
					
					addEmptyCells(7, table1);
					document.add(table1);	

					
					cell = new PdfPCell(new Phrase("Shipped On",
							headerFont));
					cell.setBackgroundColor(myColor);
					cell.setBorder(Rectangle.BOX);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_CENTER);
					cell.setFixedHeight(20);
					table.addCell(cell);
					
					cell = new PdfPCell(new Phrase("Serial Number",
							headerFont));
					cell.setBackgroundColor(myColor);
					cell.setBorder(Rectangle.BOX);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_CENTER);
					cell.setFixedHeight(20);
					table.addCell(cell);
					
					cell = new PdfPCell(new Phrase("Tag Number",
							headerFont));
					cell.setBackgroundColor(myColor);
					cell.setBorder(Rectangle.BOX);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_CENTER);
					cell.setFixedHeight(20);
					table.addCell(cell);
					
					cell = new PdfPCell(new Phrase("Sales Order #",
							headerFont));
					cell.setBackgroundColor(myColor);
					cell.setBorder(Rectangle.BOX);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_CENTER);
					cell.setFixedHeight(20);
					table.addCell(cell);
					
					cell = new PdfPCell(new Phrase("Valve Type",
							headerFont));
					cell.setBackgroundColor(myColor);
					cell.setBorder(Rectangle.BOX);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_CENTER);
					cell.setFixedHeight(20);
					table.addCell(cell);
					
					cell = new PdfPCell(new Phrase(headerList.get(i).getActualShippedDate()+"",
							smallfont));
					cell.setBackgroundColor(myColor);
					cell.setBorder(Rectangle.BOX);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_CENTER);
					cell.setFixedHeight(20);
					table.addCell(cell);
					
					cell = new PdfPCell(new Phrase(headerList.get(i).getValveSerialNumber(),
							smallfont));
					cell.setBackgroundColor(myColor);
					cell.setBorder(Rectangle.BOX);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_CENTER);
					cell.setFixedHeight(20);
					table.addCell(cell);
					
					cell = new PdfPCell(new Phrase(headerList.get(i).getTagNumber(),
							smallfont));
					cell.setBackgroundColor(myColor);
					cell.setBorder(Rectangle.BOX);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_CENTER);
					cell.setFixedHeight(20);
					table.addCell(cell);
					
					cell = new PdfPCell(new Phrase(headerList.get(i).getSalesOrder(),
							smallfont));
					cell.setBackgroundColor(myColor);
					cell.setBorder(Rectangle.BOX);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_CENTER);
					cell.setFixedHeight(20);
					table.addCell(cell);
					
					cell = new PdfPCell(new Phrase(headerList.get(i).getValveDescription(),
							smallfont));
					cell.setBackgroundColor(myColor);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_CENTER);
					cell.setFixedHeight(20);
					cell.setBorder(Rectangle.BOX);
					table.addCell(cell);
					document.add(table);
					
					Phrase emptyphrase=new Phrase("\n");
					document.add(emptyphrase);
					// body table
					table = new PdfPTable(6);
					table.setWidthPercentage(100);
					table.setWidths(new float[] { 1.5f, 3f, 1f, 1f, 1f,1f});
					BaseColor headerColor = WebColors.getRGBColor("#428bca");
					
					cell = new PdfPCell(new Phrase("Part Number",
							headerFont));
					cell.setBackgroundColor(headerColor);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_CENTER);
					cell.setFixedHeight(20);
					cell.setBorder(Rectangle.BOX);
					table.addCell(cell);
					
					cell = new PdfPCell(new Phrase("Description",
							headerFont));
					cell.setBackgroundColor(headerColor);
					cell.setBorder(Rectangle.BOX);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_CENTER);
					cell.setFixedHeight(20);
					table.addCell(cell);
					
					cell = new PdfPCell(new Phrase("Quantity",
							headerFont));
					cell.setBackgroundColor(headerColor);
					cell.setBorder(Rectangle.BOX);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_CENTER);
					cell.setFixedHeight(20);
					table.addCell(cell);
					
					cell = new PdfPCell(new Phrase("List Price",
							headerFont));
					cell.setBackgroundColor(headerColor);
					cell.setBorder(Rectangle.BOX);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_CENTER);
					cell.setFixedHeight(20);
					table.addCell(cell);
					
					cell = new PdfPCell(new Phrase("Total",
							headerFont));
					cell.setBackgroundColor(headerColor);
					cell.setBorder(Rectangle.BOX);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_CENTER);
					cell.setFixedHeight(20);
					table.addCell(cell);
					
					cell = new PdfPCell(new Phrase("Lead Time (wk)",
							headerFont));
					cell.setBackgroundColor(headerColor);
					cell.setBorder(Rectangle.BOX);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_CENTER);
					cell.setFixedHeight(20);
					table.addCell(cell);
					table.setHeaderRows(1);
				}
					//document.add(table);
				  	double totalofTotalPrice=0.0;
					for(int k=0;k<list.size();k++){
				 if(list.get(k).getValveSerialNumber().equalsIgnoreCase(headerList.get(i).getValveSerialNumber())
						 && list.get(k).getTagNumber().equalsIgnoreCase(headerList.get(i).getTagNumber())
						 && list.get(k).getSalesOrder().equalsIgnoreCase(headerList.get(i).getSalesOrder())){
					
					
					BaseColor bodyColor = WebColors.getRGBColor("#fff");	
					cell = new PdfPCell(new Phrase(list.get(k).getComponentItemNumber(),
							smallfont));
					cell.setBackgroundColor(bodyColor);
					cell.setBorder(Rectangle.BOX);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_CENTER);
					cell.setFixedHeight(20);
					
					table.addCell(cell);
					cell = new PdfPCell(new Phrase(list.get(k).getComponentDescription(),
							smallfont));
					cell.setBackgroundColor(bodyColor);
					cell.setBorder(Rectangle.BOX);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_CENTER);
					cell.setFixedHeight(20);
					table.addCell(cell);
					
					cell = new PdfPCell(new Phrase(list.get(k).getQuantity()+"",
							smallfont));
					cell.setBackgroundColor(bodyColor);
					cell.setBorder(Rectangle.BOX);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_CENTER);
					cell.setFixedHeight(20);
					table.addCell(cell);
					
					double lp=list.get(k).getListPrice();
					if(lp==0.0){
					cell = new PdfPCell(new Phrase("CF",
							smallfont));
					}else{
						cell = new PdfPCell(new Phrase(new DecimalFormat(currencySymbol+"##.##").format(lp)+"",
								smallfont));
					}
					cell.setBackgroundColor(bodyColor);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_CENTER);
					cell.setFixedHeight(20);
					cell.setBorder(Rectangle.BOX);
					table.addCell(cell);
					
					double totalPrice=list.get(k).getQuantity()*list.get(k).getListPrice();
					if(totalPrice==0.0){
					cell = new PdfPCell(new Phrase("CF",
							smallfont));
				//	totalofTotalPrice=-1;
					}else{
						cell = new PdfPCell(new Phrase(new DecimalFormat(currencySymbol+"##.##").format(totalPrice) +"",
								smallfont));
					}
					cell.setBackgroundColor(bodyColor);
					cell.setBorder(Rectangle.BOX);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_CENTER);
					cell.setFixedHeight(20);
					table.addCell(cell);
					if(totalofTotalPrice!=-1){
					totalofTotalPrice+=totalPrice;
					}
					cell = new PdfPCell(new Phrase(list.get(k).getLeadTime(),
							smallfont));
					cell.setBackgroundColor(bodyColor);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_CENTER);
					cell.setFixedHeight(20);
					cell.setBorder(Rectangle.BOX);
					table.addCell(cell);
					//document.add(bodyTable);
				 	}
				 }
					cell = new PdfPCell(new Phrase("Total",headerFont));
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_CENTER);
					cell.setColspan(4);
					table.addCell(cell);
					if(totalofTotalPrice==-1||totalofTotalPrice==0.0){
						cell = new PdfPCell(new Phrase("CF",
								smallfont));
						}else{
							cell = new PdfPCell(new Phrase(new DecimalFormat(currencySymbol+"##.##").format(totalofTotalPrice) +"",
									smallfont));
						}
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					cell.setVerticalAlignment(Element.ALIGN_CENTER);
					table.addCell(cell);
					addEmptyBorderCells(1,table);
				document.add(table);
				serialNumber= list.get(i).getValveSerialNumber();
				tagNo=list.get(i).getTagNumber();
				so=list.get(i).getSalesOrder();
				
			}
			 Paragraph paragraph = new Paragraph();
			 paragraph.setAlignment(Element.ALIGN_CENTER);
			 Chunk chunk1 = new Chunk("All information on this quote subject to change; "
			 		+ "consult GE's iSTORE for List Price information. \n",smallfont);
			 Chunk chunk2 = new Chunk("Quote valid for 90 days from issuance. \n\n",smallfont); 
			 Chunk chunk3 = new Chunk("GE PROPRIETARY AND CONFIDENTIAL INFORMATION. \n",headerFont);
			 Chunk chunk4 = new Chunk("© 2016 General Electric Company, All rights reserved. \n",headerFont);
			 
			 paragraph.add(chunk1);
			 paragraph.add(chunk2);
			 paragraph.add(chunk3);
			 paragraph.add(chunk4);
			document.add(paragraph);
			document.close();
			byte[] pdfBytes = baos.toByteArray();
			baos.close();
			return pdfBytes;
			
		}catch(Exception ex ){
			document.close();
			LOGGER.info("Exception in generateRSPQuoteReport: " + ex);
			
			return null;
		}

		
	}
	
	public List<Report> processQuoteHeaderList(List<Report> list,boolean isInternal) {
		String serialNumber = "";
		String tagNo="";
		String so="";
		List<Report> headerList = new ArrayList<Report>();
		for (int i = 0; i < list.size(); i++) {
			if (!list.get(i).getValveSerialNumber().equalsIgnoreCase(serialNumber)
				|| !list.get(i).getTagNumber().equalsIgnoreCase(tagNo)
				|| !list.get(i).getSalesOrder().equalsIgnoreCase(so)) {
				Report rpt = new Report();
				if(isInternal){
					rpt.setChannelPartner("GE Oil & Gas");
				}
				else{
					rpt.setChannelPartner(list.get(i).getChannelPartner());	
				}
				rpt.setEndUserName(list.get(i).getEndUserName());
				rpt.setEndUserLocation(list.get(i).getEndUserLocation());
				rpt.setSpareQuotes(list.get(i).getSpareQuotes());
				rpt.setActualShippedDate(list.get(i).getActualShippedDate());
				rpt.setValveSerialNumber(list.get(i).getValveSerialNumber());
				rpt.setTagNumber(list.get(i).getTagNumber());
				rpt.setSalesOrder(list.get(i).getSalesOrder());
				rpt.setValveDescription(list.get(i).getValveDescription());
				headerList.add(rpt);
			}
			serialNumber = list.get(i).getValveSerialNumber();
			tagNo=list.get(i).getTagNumber();
			so=list.get(i).getSalesOrder();
		}
		return headerList;

	}

	public static void addEmptyCells(int numOfCells, PdfPTable table) {
		PdfPCell cell = new PdfPCell();
		cell.setBorder(Rectangle.NO_BORDER);

		for (int i = 0; i < numOfCells; i++) {
			table.addCell(cell);
		}

	}
	
	public static void addEmptyBorderCells(int numOfCells, PdfPTable table) {
		PdfPCell cell = new PdfPCell();
		for (int i = 0; i < numOfCells; i++) {
			table.addCell(cell);
		}

	}

}
