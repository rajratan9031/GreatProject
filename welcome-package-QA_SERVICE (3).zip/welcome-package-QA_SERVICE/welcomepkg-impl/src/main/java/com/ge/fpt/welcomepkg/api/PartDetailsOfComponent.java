package com.ge.fpt.welcomepkg.api;

public class PartDetailsOfComponent {
	private static final long serialVersionUID = -5579175197980496818L;

	private String partId;
	private String partDesc;
	private String componentId;
	private String componentDescription;

	public String getComponentDescription() {
		return componentDescription;
	}

	public void setComponentDescription(String componentDescription) {
		this.componentDescription = componentDescription;
	}

	public String getComponentId() {
		return componentId;
	}

	public void setComponentId(String componentId) {
		this.componentId = componentId;
	}

	public String getPartId() {
		return partId;
	}

	public void setPartId(String partId) {
		this.partId = partId;
	}

	public String getPartDesc() {
		return partDesc;
	}

	public void setPartDesc(String partDesc) {
		this.partDesc = partDesc;
	}

	public PartDetailsOfComponent() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PartDetailsOfComponent(String PartId, String PartDesc,
			String componentId, String componentDescription) {
		super();
		this.partId = PartId;
		this.partDesc = PartDesc;
		this.componentId = componentId;
		this.componentDescription = componentDescription;
	}
}
