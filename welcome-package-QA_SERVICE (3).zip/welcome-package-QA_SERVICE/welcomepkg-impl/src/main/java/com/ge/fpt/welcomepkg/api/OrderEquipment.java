/*
 * Copyright (c) 2013 GE Global Research. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Global Research. The software may be used and/or copied only
 * with the written permission of GE Global Research or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author 212414241
 * 
 */

@XmlRootElement
public class OrderEquipment implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String recSource;
	private String salesOrder;
	private String salesOrderLine;
	private String customerPo;
	private String soldToCustomerName;
	private String soldToCountry;
	private String soldToState;
	private String soldToProvince;
	private String soldToCity;
	private String repName;
	private String orderedItemNumber;
	private Long quantityShipped;
	private Double unitSellingPrice;
	private Date actualShipDate;
	private String serialNumber;
	private String valvePartNumber;
	private String valveDescription;
	private String tagNumber;
	private String sourceSystem;
	private Long valveInfoId;
	private String filePath;
	private String fileName;
	private String productCode;
	private String productModel;
	
	private String serialNumberValveSeg;
	private String valvesSku;
	private String notes;
	private String invoiceNo;
	private String setPressure;
	private String cds;
	private String backPressure;
	private String temperature;
	private String capacity;
	private String service;
	private String capCode;
	private String springType;
	private String spring;
	private String asme;
	private String size;
	private String bellows;
	private String specialFeatures;
	private String orifice;
	private String productCommodity;
	private String billOfMaterialNo;
	private String orderIdentifier;
	private String custId;
	private String serializable;
	private String engineeredValve;
	private String link_Customer_Name;
	private String Duns_Number;

	
	
	public String getDuns_Number() {
		return Duns_Number;
	}

	public void setDuns_Number(String duns_Number) {
		Duns_Number = duns_Number;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getOrderIdentifier() {
		return orderIdentifier;
	}

	public void setOrderIdentifier(String orderIdentifier) {
		this.orderIdentifier = orderIdentifier;
	}

	
	

	public String getLink_Customer_Name() {
		return link_Customer_Name;
	}

	public void setLink_Customer_Name(String link_Customer_Name) {
		this.link_Customer_Name = link_Customer_Name;
	}

	public String getSerializable() {
		return serializable;
	}

	public void setSerializable(String serializable) {
		this.serializable = serializable;
	}

	public String getEngineeredValve() {
		return engineeredValve;
	}

	public void setEngineeredValve(String engineeredValve) {
		this.engineeredValve = engineeredValve;
	}

	public String getSerialNumberValveSeg() {
		return serialNumberValveSeg;
	}

	public void setSerialNumberValveSeg(String serialNumberValveSeg) {
		this.serialNumberValveSeg = serialNumberValveSeg;
	}

	public String getValvesSku() {
		return valvesSku;
	}

	public void setValvesSku(String valvesSku) {
		this.valvesSku = valvesSku;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getSetPressure() {
		return setPressure;
	}

	public void setSetPressure(String setPressure) {
		this.setPressure = setPressure;
	}

	public String getCds() {
		return cds;
	}

	public void setCds(String cds) {
		this.cds = cds;
	}

	public String getBackPressure() {
		return backPressure;
	}

	public void setBackPressure(String backPressure) {
		this.backPressure = backPressure;
	}

	public String getTemperature() {
		return temperature;
	}

	public void setTemperature(String temperature) {
		this.temperature = temperature;
	}

	public String getCapacity() {
		return capacity;
	}

	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public String getCapCode() {
		return capCode;
	}

	public void setCapCode(String capCode) {
		this.capCode = capCode;
	}

	public String getSpringType() {
		return springType;
	}

	public void setSpringType(String springType) {
		this.springType = springType;
	}

	public String getSpring() {
		return spring;
	}

	public void setSpring(String spring) {
		this.spring = spring;
	}

	public String getAsme() {
		return asme;
	}

	public void setAsme(String asme) {
		this.asme = asme;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getBellows() {
		return bellows;
	}

	public void setBellows(String bellows) {
		this.bellows = bellows;
	}

	public String getSpecialFeatures() {
		return specialFeatures;
	}

	public void setSpecialFeatures(String specialFeatures) {
		this.specialFeatures = specialFeatures;
	}

	public String getOrifice() {
		return orifice;
	}

	public void setOrifice(String orifice) {
		this.orifice = orifice;
	}

	public String getProductCommodity() {
		return productCommodity;
	}

	public void setProductCommodity(String productCommodity) {
		this.productCommodity = productCommodity;
	}

	public String getBillOfMaterialNo() {
		return billOfMaterialNo;
	}

	public void setBillOfMaterialNo(String billOfMaterialNo) {
		this.billOfMaterialNo = billOfMaterialNo;
	}

	/**
	 * 
	 */
	public OrderEquipment() {
		super();
	}

	/**
	 * @param recSource
	 * @param salesOrder
	 * @param salesOrderLine
	 * @param customerPo
	 * @param soldToCustomerName
	 * @param soldToCountry
	 * @param soldToState
	 * @param soldToProvince
	 * @param soldToCity
	 * @param repName
	 * @param orderedItemNumber
	 * @param quantityShipped
	 * @param unitSellingPrice
	 * @param actualShipDate
	 * @param serialNumber
	 * @param valvePartNumber
	 * @param valveDescription
	 * @param tagNumber
	 * @param sourceSystem
	 */

	

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductModel() {
		return productModel;
	}

	public void setProductModel(String productModel) {
		this.productModel = productModel;
	}

	/**
	 * @return the recSource
	 */
	public String getRecSource() {
		return recSource;
	}

	/**
	 * @param recSource
	 *            the recSource to set
	 */
	public void setRecSource(String recSource) {
		this.recSource = recSource;
	}

	/**
	 * @return the salesOrder
	 */
	public String getSalesOrder() {
		return salesOrder;
	}

	/**
	 * @param salesOrder
	 *            the salesOrder to set
	 */
	public void setSalesOrder(String salesOrder) {
		this.salesOrder = salesOrder;
	}

	/**
	 * @return the salesOrderLine
	 */
	public String getSalesOrderLine() {
		return salesOrderLine;
	}

	/**
	 * @param salesOrderLine
	 *            the salesOrderLine to set
	 */
	public void setSalesOrderLine(String salesOrderLine) {
		this.salesOrderLine = salesOrderLine;
	}

	/**
	 * @return the customerPo
	 */
	public String getCustomerPo() {
		return customerPo;
	}

	/**
	 * @param customerPo
	 *            the customerPo to set
	 */
	public void setCustomerPo(String customerPo) {
		this.customerPo = customerPo;
	}

	/**
	 * @return the soldToCustomerName
	 */
	public String getSoldToCustomerName() {
		return soldToCustomerName;
	}

	/**
	 * @param soldToCustomerName
	 *            the soldToCustomerName to set
	 */
	public void setSoldToCustomerName(String soldToCustomerName) {
		this.soldToCustomerName = soldToCustomerName;
	}

	/**
	 * @return the soldToCountry
	 */
	public String getSoldToCountry() {
		return soldToCountry;
	}

	/**
	 * @param soldToCountry
	 *            the soldToCountry to set
	 */
	public void setSoldToCountry(String soldToCountry) {
		this.soldToCountry = soldToCountry;
	}

	/**
	 * @return the soldToState
	 */
	public String getSoldToState() {
		return soldToState;
	}

	/**
	 * @param soldToState
	 *            the soldToState to set
	 */
	public void setSoldToState(String soldToState) {
		this.soldToState = soldToState;
	}

	/**
	 * @return the soldToProvince
	 */
	public String getSoldToProvince() {
		return soldToProvince;
	}

	/**
	 * @param soldToProvince
	 *            the soldToProvince to set
	 */
	public void setSoldToProvince(String soldToProvince) {
		this.soldToProvince = soldToProvince;
	}

	/**
	 * @return the soldToCity
	 */
	public String getSoldToCity() {
		return soldToCity;
	}

	/**
	 * @param soldToCity
	 *            the soldToCity to set
	 */
	public void setSoldToCity(String soldToCity) {
		this.soldToCity = soldToCity;
	}

	/**
	 * @return the repName
	 */
	public String getRepName() {
		return repName;
	}

	/**
	 * @param repName
	 *            the repName to set
	 */
	public void setRepName(String repName) {
		this.repName = repName;
	}

	/**
	 * @return the orderedItemNumber
	 */
	public String getOrderedItemNumber() {
		return orderedItemNumber;
	}

	/**
	 * @param orderedItemNumber
	 *            the orderedItemNumber to set
	 */
	public void setOrderedItemNumber(String orderedItemNumber) {
		this.orderedItemNumber = orderedItemNumber;
	}

	/**
	 * @return the quantityShipped
	 */
	public Long getQuantityShipped() {
		return quantityShipped;
	}

	/**
	 * @param quantityShipped
	 *            the quantityShipped to set
	 */
	public void setQuantityShipped(Long quantityShipped) {
		this.quantityShipped = quantityShipped;
	}

	/**
	 * @return the unitSellingPrice
	 */
	public Double getUnitSellingPrice() {
		return unitSellingPrice;
	}

	/**
	 * @param unitSellingPrice
	 *            the unitSellingPrice to set
	 */
	public void setUnitSellingPrice(Double unitSellingPrice) {
		this.unitSellingPrice = unitSellingPrice;
	}

	/**
	 * @return the actualShipDate
	 */
	public Date getActualShipDate() {
		return actualShipDate;
	}

	/**
	 * @param actualShipDate
	 *            the actualShipDate to set
	 */
	public void setActualShipDate(Date actualShipDate) {
		this.actualShipDate = actualShipDate;
	}

	/**
	 * @return the serialNumber
	 */
	public String getSerialNumber() {
		return serialNumber;
	}

	/**
	 * @param serialNumber
	 *            the serialNumber to set
	 */
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	/**
	 * @return the valvePartNumber
	 */
	public String getValvePartNumber() {
		return valvePartNumber;
	}

	/**
	 * @param valvePartNumber
	 *            the valvePartNumber to set
	 */
	public void setValvePartNumber(String valvePartNumber) {
		this.valvePartNumber = valvePartNumber;
	}

	/**
	 * @return the valveDescription
	 */
	public String getValveDescription() {
		return valveDescription;
	}

	/**
	 * @param valveDescription
	 *            the valveDescription to set
	 */
	public void setValveDescription(String valveDescription) {
		this.valveDescription = valveDescription;
	}

	/**
	 * @return the tagNumber
	 */
	public String getTagNumber() {
		return tagNumber;
	}

	/**
	 * @param tagNumber
	 *            the tagNumber to set
	 */
	public void setTagNumber(String tagNumber) {
		this.tagNumber = tagNumber;
	}

	/**
	 * @return the sourceSystem
	 */
	public String getSourceSystem() {
		return sourceSystem;
	}

	/**
	 * @param sourceSystem
	 *            the sourceSystem to set
	 */
	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	/**
	 * @return the valveInfoId
	 */
	public Long getValveInfoId() {
		return valveInfoId;
	}

	/**
	 * @param valveInfoId the valveInfoId to set
	 */
	public void setValveInfoId(Long valveInfoId) {
		this.valveInfoId = valveInfoId;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public OrderEquipment(String recSource, String salesOrder, String salesOrderLine, String customerPo,
			String soldToCustomerName, String soldToCountry, String soldToState, String soldToProvince,
			String soldToCity, String repName, String orderedItemNumber, Long quantityShipped, Double unitSellingPrice,
			Date actualShipDate, String serialNumber, String valvePartNumber, String valveDescription, String tagNumber,
			String sourceSystem, Long valveInfoId, String filePath, String fileName, String productCode,
			String productModel, String serialNumberValveSeg, String valvesSku, String notes, String invoiceNo,
			String setPressure, String cds, String backPressure, String temperature, String capacity, String service,
			String capCode, String springType, String spring, String asme, String size, String bellows,
			String specialFeatures, String orifice, String productCommodity, String billOfMaterialNo,
			String orderIdentifier, String custId, String serializable, String engineeredValve,
			String link_Customer_Name, String duns_Number) {
		super();
		this.recSource = recSource;
		this.salesOrder = salesOrder;
		this.salesOrderLine = salesOrderLine;
		this.customerPo = customerPo;
		this.soldToCustomerName = soldToCustomerName;
		this.soldToCountry = soldToCountry;
		this.soldToState = soldToState;
		this.soldToProvince = soldToProvince;
		this.soldToCity = soldToCity;
		this.repName = repName;
		this.orderedItemNumber = orderedItemNumber;
		this.quantityShipped = quantityShipped;
		this.unitSellingPrice = unitSellingPrice;
		this.actualShipDate = actualShipDate;
		this.serialNumber = serialNumber;
		this.valvePartNumber = valvePartNumber;
		this.valveDescription = valveDescription;
		this.tagNumber = tagNumber;
		this.sourceSystem = sourceSystem;
		this.valveInfoId = valveInfoId;
		this.filePath = filePath;
		this.fileName = fileName;
		this.productCode = productCode;
		this.productModel = productModel;
		this.serialNumberValveSeg = serialNumberValveSeg;
		this.valvesSku = valvesSku;
		this.notes = notes;
		this.invoiceNo = invoiceNo;
		this.setPressure = setPressure;
		this.cds = cds;
		this.backPressure = backPressure;
		this.temperature = temperature;
		this.capacity = capacity;
		this.service = service;
		this.capCode = capCode;
		this.springType = springType;
		this.spring = spring;
		this.asme = asme;
		this.size = size;
		this.bellows = bellows;
		this.specialFeatures = specialFeatures;
		this.orifice = orifice;
		this.productCommodity = productCommodity;
		this.billOfMaterialNo = billOfMaterialNo;
		this.orderIdentifier = orderIdentifier;
		this.custId = custId;
		this.serializable = serializable;
		this.engineeredValve = engineeredValve;
		this.link_Customer_Name = link_Customer_Name;
		Duns_Number = duns_Number;
	}

	@Override
	public String toString() {
		return "OrderEquipment [recSource=" + recSource + ", salesOrder=" + salesOrder + ", salesOrderLine="
				+ salesOrderLine + ", customerPo=" + customerPo + ", soldToCustomerName=" + soldToCustomerName
				+ ", soldToCountry=" + soldToCountry + ", soldToState=" + soldToState + ", soldToProvince="
				+ soldToProvince + ", soldToCity=" + soldToCity + ", repName=" + repName + ", orderedItemNumber="
				+ orderedItemNumber + ", quantityShipped=" + quantityShipped + ", unitSellingPrice=" + unitSellingPrice
				+ ", actualShipDate=" + actualShipDate + ", serialNumber=" + serialNumber + ", valvePartNumber="
				+ valvePartNumber + ", valveDescription=" + valveDescription + ", tagNumber=" + tagNumber
				+ ", sourceSystem=" + sourceSystem + ", valveInfoId=" + valveInfoId + ", filePath=" + filePath
				+ ", fileName=" + fileName + ", productCode=" + productCode + ", productModel=" + productModel
				+ ", serialNumberValveSeg=" + serialNumberValveSeg + ", valvesSku=" + valvesSku + ", notes=" + notes
				+ ", invoiceNo=" + invoiceNo + ", setPressure=" + setPressure + ", cds=" + cds + ", backPressure="
				+ backPressure + ", temperature=" + temperature + ", capacity=" + capacity + ", service=" + service
				+ ", capCode=" + capCode + ", springType=" + springType + ", spring=" + spring + ", asme=" + asme
				+ ", size=" + size + ", bellows=" + bellows + ", specialFeatures=" + specialFeatures + ", orifice="
				+ orifice + ", productCommodity=" + productCommodity + ", billOfMaterialNo=" + billOfMaterialNo
				+ ", orderIdentifier=" + orderIdentifier + ", custId=" + custId + ", serializable=" + serializable
				+ ", engineeredValve=" + engineeredValve + ", link_Customer_Name=" + link_Customer_Name
				+ ", Duns_Number=" + Duns_Number + "]";
	}

	
	
	

	


	
	
	
}
