package com.ge.fpt.welcomepkg.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.sql.DataSource;

import org.apache.commons.lang.StringUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.fpt.welcomepkg.api.County;
import com.ge.fpt.welcomepkg.api.GeoMapping;
import com.ge.fpt.welcomepkg.api.HeatMapOverlayData;
import com.ge.fpt.welcomepkg.api.InstallBaseFilter;
import com.ge.fpt.welcomepkg.api.InstallBaseLoc;
import com.ge.fpt.welcomepkg.api.InstalledBaseWithDuns;
import com.ge.fpt.welcomepkg.api.InstalledValveInfo;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;

public class InstalledBasePersistenceImpl implements IInstalledBasePersistence {

	@SuppressWarnings("javadoc")
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory.getLogger(InstalledBasePersistenceImpl.class);
	
	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;

	/**
	 * Data source for the JDBC
	 */
	DataSource dataSource;

	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;
	
	NamedParameterJdbcTemplate namedParamTemplate;

	/**
	 * @return the dataSource
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}
	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate = new NamedParameterJdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}
	public  Map<String, String> setFilterParams(InstallBaseFilter filter){
		Map<String, String> result = new HashMap<String, String>();
		result.put("productModel", filter.getProductModel() == null ? "" : filter.getProductModel().toUpperCase());
		result.put("channel", filter.getChannel() == null ? "" : filter.getChannel().toUpperCase());
		result.put("productCode", filter.getProductCode() == null ? "" : filter.getProductCode().toUpperCase());
		result.put("country", filter.getCountry() == null ? "" : filter.getCountry().toUpperCase());
		result.put("state", filter.getState() == null ? "" : filter.getState().toUpperCase());
		return result;
	}
	
	
	
	public String getFilterClause(InstallBaseFilter baseFilter){
		String filter="";
		List<String> conditions = new ArrayList<String>();
		if(baseFilter!=null){
			if(baseFilter.getProductModel()!=null && !baseFilter.getProductModel().isEmpty()){
				conditions.add(" UPPER(PRODUCT_MODEL) LIKE '%' || :productModel || '%'");
				}
			if(baseFilter.getChannel()!=null && !baseFilter.getChannel().isEmpty()){
				conditions.add(" UPPER(CHANNEL) LIKE '%' || :channel || '%'");
				}
			if(baseFilter.getProductCode()!=null && !baseFilter.getProductCode().isEmpty()){
				conditions.add(" UPPER(PRODUCT_CODE) LIKE '%' || :productCode || '%'");
				}
			if(baseFilter.getCountry()!=null && !baseFilter.getCountry().isEmpty()){
				conditions.add(" UPPER(SOLD_TO_COUNTRY) LIKE '%' || :country || '%'");
				}
			if(baseFilter.getState()!=null && !baseFilter.getState().isEmpty()){
				conditions.add(" UPPER(SOLD_TO_STATE) LIKE '%' || :state || '%'");
				}
		}
		if (conditions.size() > 0) {
			String condStr = "";
			
			for (int i = 0; i < conditions.size(); i++) {
				condStr += ( " AND " + conditions.get(i));
			}
			
			filter = condStr;
		}
		return filter;
	}
	public  Map<String, String> setFilterParamsForChannel(InstallBaseFilter filter){
		Map<String, String> result = new HashMap<String, String>();
		//result.put("productModel", filter.getProductModel() == null ? "" : filter.getProductModel().toUpperCase());
		result.put("channel", filter.getChannel() == null ? "" : filter.getChannel().toUpperCase());
		//result.put("productCode", filter.getProductCode() == null ? "" : filter.getProductCode().toUpperCase());
		result.put("country", filter.getCountry() == null ? "" : filter.getCountry().toUpperCase());
		result.put("state", filter.getState() == null ? "" : filter.getState().toUpperCase());
		return result;
	}
	
	
	
	public String getFilterClauseForChannel(InstallBaseFilter baseFilter){
		String filter="";
		List<String> conditions = new ArrayList<String>();
		if(baseFilter!=null){
			
			if(baseFilter.getChannel()!=null && !baseFilter.getChannel().isEmpty()){
				conditions.add("UPPER(COMPANY) LIKE '%' || :channel || '%'");
				}
			if(baseFilter.getCountry()!=null && !baseFilter.getCountry().isEmpty()){
				conditions.add(" UPPER(COUNTRY) LIKE '%' || :country || '%'");
				}
			if(baseFilter.getState()!=null && !baseFilter.getState().isEmpty()){
				conditions.add(" UPPER(STATE) LIKE '%' || :state || '%'");
				}
		}
		if (conditions.size() > 0) {
			String condStr = "";
			
			for (int i = 0; i < conditions.size(); i++) {
				condStr += ( " AND " + conditions.get(i));
			}
			
			filter = condStr;
		}
		return filter;
	}

	private static final class GeoMappingMapper implements RowMapper<GeoMapping> {
		public GeoMappingMapper() {
		}

		@Override
		public GeoMapping mapRow(ResultSet rs, int rowNum) throws SQLException {
			GeoMapping result = new GeoMapping();
			result.setLatitude(rs.getString("LATITUDE"));
			result.setLongitude(rs.getString("LONGITUDE"));
			result.setCount(rs.getInt("VALVES"));
			result.setZipCode(rs.getString("SOLD_TO_ZIP"));
			/*result.setCountry(rs.getString("SOLD_TO_COUNTRY"));
			result.setState(rs.getString("SOLD_TO_STATE"));
			
			result.setCity(rs.getString("SOLD_TO_CITY"));
			result.setChannel(rs.getString("CHANNEL"));
			result.setDuns(rs.getString("DUNS"));*/
			return result;
		}
	}
	
	
	
	public  Map<String, String> setFilterParamsValveInfo(InstalledValveInfo info){
		Map<String, String> result = new HashMap<String, String>();
		result.put("salesOrder", info.getSalesOrder() == null ? "" : info.getSalesOrder().toUpperCase());
		result.put("customerPo", info.getCustomerPo() == null ? "" : info.getCustomerPo().toUpperCase());
		result.put("soldToProvince", info.getSoldToProvince() == null ? "" : info.getSoldToProvince().toUpperCase());
		result.put("rep_name", info.getRep_name() == null ? "" : info.getRep_name().toUpperCase());
		result.put("sourceSys", info.getSourceSys() == null ? "" : info.getSourceSys().toUpperCase());
		result.put("endUser", info.getEndUser() == null ? "" : info.getEndUser().toUpperCase());
		result.put("productCode", info.getProductCode() == null ? "" : info.getProductCode().toUpperCase());
		result.put("interCompany", info.getInterCompany() == null ? "" : info.getInterCompany().toUpperCase());
		result.put("soldToZip", info.getSoldToZip() == null ? "" : info.getSoldToZip().toUpperCase());
		result.put("serialNumber", info.getSerialNumber() == null ? "" : info.getSerialNumber().toUpperCase());
		result.put("tagNumber", info.getTagNumber() == null ? "" : info.getTagNumber().toUpperCase());
		result.put("itemNumber", info.getItemNumber() == null ? "" : info.getItemNumber().toUpperCase());
		result.put("description", info.getDescription() == null ? "" : info.getDescription().toUpperCase());
		result.put("productModel", info.getProductModel() == null ? "" : info.getProductModel().toUpperCase());
		result.put("channel", info.getChannel() == null ? "" : info.getChannel().toUpperCase());
		result.put("country", info.getCountry() == null ? "" : info.getCountry().toUpperCase());
		result.put("state", info.getState() == null ? "" : info.getState().toUpperCase());
		result.put("duns", info.getDuns() == null ? "" : info.getDuns().toUpperCase());
		return result;
	}
	public String getFilterClauseValveInfo(InstalledValveInfo info){
		String filter="";
		List<String> conditions = new ArrayList<String>();
		if(info!=null){
			if(info.getSalesOrder()!=null && !info.getSalesOrder().isEmpty()){
				conditions.add(" UPPER(SALES_ORDER) LIKE '%' || :salesOrder || '%'");
				}
			if(info.getCustomerPo()!=null && !info.getCustomerPo().isEmpty()){
				conditions.add(" UPPER(CUSTOMER_PO) LIKE '%' || :customerPo || '%'");
				}
			if(info.getSoldToProvince()!=null && !info.getSoldToProvince().isEmpty()){
				conditions.add(" UPPER(SOLD_TO_PROVINCE) LIKE '%' || :soldToProvince || '%'");
				}
			if(info.getRep_name()!=null && !info.getRep_name().isEmpty()){
				conditions.add(" UPPER(REP_NAME) LIKE '%' || :rep_name || '%'");
				}
			if(info.getSourceSys()!=null && !info.getSourceSys().isEmpty()){
				conditions.add(" UPPER(SOURCESYSTEM) LIKE '%' || :sourceSys || '%'");
				}
			if(info.getEndUser()!=null && !info.getEndUser().isEmpty()){
				conditions.add(" UPPER(END_USER) LIKE '%' || :endUser || '%'");
				}
			if(info.getProductCode()!=null && !info.getProductCode().isEmpty()){
				conditions.add(" UPPER(PRODUCT_CODE) LIKE '%' || :productCode || '%'");
				}
			if(info.getInterCompany()!=null && !info.getInterCompany().isEmpty()){
				conditions.add(" UPPER(INTER_COMPANY) LIKE '%' || :interCompany || '%'");
				}
			if(info.getSoldToZip()!=null && !info.getSoldToZip().isEmpty()){
				conditions.add(" UPPER(SOLD_TO_ZIP) LIKE '%' || :sourceSys || '%'");
				}
			if(info.getSerialNumber()!=null && !info.getSerialNumber().isEmpty()){
				conditions.add(" UPPER(SERIAL_NUMBER) LIKE '%' || :serialNumber || '%'");
				}
			if(info.getTagNumber()!=null && !info.getTagNumber().isEmpty()){
				conditions.add(" UPPER(TAG_NUMBER) LIKE '%' || :tagNumber || '%'");
				}
			if(info.getItemNumber()!=null && !info.getItemNumber().isEmpty()){
				conditions.add(" UPPER(ITEM_NUMBER) LIKE '%' || :itemNumber || '%'");
				}
			if(info.getDescription()!=null && !info.getDescription().isEmpty()){
				conditions.add(" UPPER(DESCRIPTION) LIKE '%' || :description || '%'");
				}
			if(info.getProductModel()!=null && !info.getProductModel().isEmpty()){
				conditions.add(" UPPER(PRODUCT_MODEL) LIKE '%' || :productModel || '%'");
				}
			if(info.getDuns()!=null && !info.getDuns().isEmpty()){
				conditions.add(" UPPER(DUNS) LIKE '%' || :duns || '%'");
				}
			if(info.getChannel()!=null && !info.getChannel().isEmpty()){
				conditions.add(" UPPER(CHANNEL) LIKE '%' || :channel || '%'");
				}
			if(info.getCountry()!=null && !info.getCountry().isEmpty()){
				conditions.add(" UPPER(SOLD_TO_COUNTRY) LIKE '%' || :country || '%'");
				}
			if(info.getState()!=null && !info.getState().isEmpty()){
				conditions.add(" UPPER(SOLD_TO_STATE) LIKE '%' || :state || '%'");
				}
		}
		if (conditions.size() > 0) {
			String condStr = "";
			
			for (int i = 0; i < conditions.size(); i++) {
				condStr += ( " AND " + conditions.get(i));
			}
			
			filter = condStr;
		}
		return filter;
	}
	private static final class InstalledValveInfoMapper implements RowMapper<InstalledValveInfo> {
		public InstalledValveInfoMapper() {
		}

		@Override
		public InstalledValveInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
			InstalledValveInfo result = new InstalledValveInfo();
			result.setCustomerPo(rs.getString("CUSTOMER_PO"));
			result.setDescription(rs.getString("DESCRIPTION"));
			result.setDuns(rs.getString("DUNS"));
			result.setChannel(rs.getString("CHANNEL"));
			result.setEndUser(rs.getString("END_USER"));
			result.setInterCompany(rs.getString("INTER_COMPANY"));
			result.setItemNumber(rs.getString("ITEM_NUMBER"));
			result.setSalesOrder(rs.getString("SALES_ORDER"));
			//result.setProductCode(rs.getString("PRODUCT_CODE"));
			//result.setProductModel(rs.getString("PRODUCT_MODEL"));
			result.setRep_name(rs.getString("REP_NAME"));
			result.setSerialNumber(rs.getString("SERIAL_NUMBER"));
			result.setSoldToProvince(rs.getString("SOLD_TO_PROVINCE"));
			result.setSoldToZip(rs.getString("SOLD_TO_ZIP"));
			result.setSourceSys(rs.getString("SOURCESYSTEM"));
			result.setTagNumber(rs.getString("TAG_NUMBER"));
			
			return result;
		}
	}
	private static final class InstalledBaseWithDunsMapper implements RowMapper<InstalledBaseWithDuns> {
		public InstalledBaseWithDunsMapper() {
		}
		InstalledBaseWithDuns result;
		@Override
		public InstalledBaseWithDuns mapRow(ResultSet rs, int rowNum) throws SQLException {
			try{
			if (result == null) {
				this.result = new InstalledBaseWithDuns();
				result.setChannel(rs.getString("CHANNEL"));
			}
			
			InstallBaseLoc loc = new InstallBaseLoc();
			loc.setLat(Float.parseFloat(rs.getString("LATITUDE")));
			loc.setLng(Float.parseFloat(rs.getString("LONGITUDE")));
			this.result.addLocation(loc);
			}catch(Exception e){
				logger.error(e.toString());
			}
			return null;
		}

		public final InstalledBaseWithDuns getResult() {
			return result;
		}
	}
	private static final class InstalledValveMapper implements RowMapper<InstalledValveInfo> {
		public InstalledValveMapper() {
		}

		@Override
		public InstalledValveInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
			InstalledValveInfo result = new InstalledValveInfo();
			//result.setLatitude(rs.getString("USER_NAME"));
			return result;
		}
	}
	@Override
	public HeatMapOverlayData getInstallBaseGeoLoc(InstallBaseFilter baseFilter) {
		HeatMapOverlayData result = new HeatMapOverlayData();
		logger.info("started fetching installbase"+baseFilter);
		try{
		/*String sql = "select * from "+" "
				+ "(select * from SQT_ZIPCODE_LOOKUP lookup , (SELECT SOLD_TO_CITY,SOLD_TO_STATE,SOLD_TO_COUNTRY,CHANNEL,DUNS,REGEXP_SUBSTR (SOLD_TO_ZIP, '^[^-]*') SOLD_TO_ZIP,COUNT(*) As Valves"+
" FROM SQT_HEAT_MAP_DATA where 1=1";*/
		String sql = "select * from DDSAFM.SQT_HEAT_MAP_DATA_SUMMARY where SOLD_TO_COUNTRY=? AND PRODUCT_CODE=?";
		
		Object[] parameters = new Object[2];
		parameters[0] = baseFilter.getCountry();
		parameters[1] = baseFilter.getProductCode();
		
		if(null!=baseFilter.getChannel()&&!(baseFilter.getChannel().isEmpty())){
			sql+=" AND CHANNEL LIKE '%"+baseFilter.getChannel()+"%'";
			//parameters[++index] = baseFilter.getChannel();
		}
		if(null!=baseFilter.getState()&&!(baseFilter.getState().isEmpty())){
		sql+=" AND SOLD_TO_STATE LIKE '%"+baseFilter.getState()+"%'";
		//parameters[++index] = baseFilter.getState();
		}
	
		/*MapSqlParameterSource parameters = new MapSqlParameterSource(setFilterParams(baseFilter));
		
		if(baseFilter!=null){
			String filter=getFilterClause(baseFilter);
			sql=sql+filter;
		}*/
		logger.info("SQL"+sql);
		//sql+=" GROUP BY SOLD_TO_CITY,SOLD_TO_STATE,SOLD_TO_COUNTRY,CHANNEL,DUNS,SOLD_TO_ZIP) heat where lookup.zipcode in heat.SOLD_TO_ZIP)";
		long currMilliSeconds = System.currentTimeMillis();
		//System.out.println("Query execution started"+new Date());
		//this.jdbcTemplate.execute(sql);
	/*result.setHeatMapData(this.namedParamTemplate.query(sql, parameters,
				new HeatMapResultSet()));*/
		this.jdbcTemplate.setFetchSize(1000);
		result.setGeoMappingList(this.jdbcTemplate.query(sql, parameters, new GeoMappingMapper()));
		//this.namedParamTemplate.setCacheLimit(1000);
		/*result.setGeoMappingList(this.namedParamTemplate.query(sql, parameters,
				new GeoMappingMapper()));	*/
		logger.info("found the data");
		System.out.println((System.currentTimeMillis()/1000)-(currMilliSeconds/1000)+"Total time taken");
	//result.setGeoMappingList(new ArrayList<GeoMapping>());
	
	Map<String,List<Map<String,List<InstallBaseLoc>>>> locWithDuns = new HashMap<String, List<Map<String,List<InstallBaseLoc>>>>();
	Map<String,List<Map<String,List<InstallBaseLoc>>>> locWithDuns1 = new HashMap<String,List<Map<String,List<InstallBaseLoc>>>>();
	//List<String> locWithDuns1 = new ArrayList<>();
	String sqlForChannels = "select * from (select distinct(county),company,state from DDSAFM.sqt_channel_region where 1=1";
	MapSqlParameterSource params = new MapSqlParameterSource(setFilterParamsForChannel(baseFilter));
	
	if(baseFilter!=null){
		String filter=getFilterClauseForChannel(baseFilter);
		sqlForChannels=sqlForChannels+filter;
	}
	String stateFilter = " where UPPER(STATE) LIKE '%"+baseFilter.getState()+"%'";
	sqlForChannels+=") channel,(select COUNTY,LATITUDE,LONGITUDE,STATE from DDSAFM.SQT_COUNTY_BOUNDARIES"+stateFilter+") lookup where channel.county=lookup.county and channel.state = lookup.state";
	String sqlCounty = "select LATITUDE,LONGITUDE,STATE,COUNTY from DDSAFM.sqt_county_boundaries"+stateFilter;
	
	String sqlChannel = "select company,state from DDSAFM.sqt_channel_region where country='US' AND COMPANY_TYPE IN('MN') group by company,STATE";
	Map<String,List<County>> channelMap = new HashMap<>();
	//channelMap = this.namedParamTemplate.query(sqlChannel, params,new ChannelsResultSet());
	//locWithDuns = this.namedParamTemplate.query(sqlCounty, params,new ChannelMapResultSet());
	//logger.info("Filter"+baseFilter);
	//logger.info("SQL FOR COUNTY Boundaries"+sqlForChannels);
	//locWithDuns1 = this.namedParamTemplate.query(sqlForChannels, params,new ChannelMapResultSetCounty());
	//locWithDuns1 = this.namedParamTemplate.queryForList(sqlForChannels, params,String.class);
	/*Map<String,List<InstallBaseLoc>> locWithDuns = new HashMap<String, List<InstallBaseLoc>>();
	 * 
		for(GeoMapping g:result.getGeoMappingList()){
					
				ChannelInfo info = new ChannelInfo();
				info.setChannel(g.getChannel());
				info.setCount(g.getCount());
				info.setDuns(g.getDuns());
				List<InstallBaseLoc> locList = new ArrayList<>();
				InstallBaseLoc loc = new InstallBaseLoc();
				loc.setLat(g.getLatitude()!=null?Float.parseFloat(g.getLatitude()):0);
				loc.setLng(g.getLatitude()!=null?Float.parseFloat(g.getLongitude()):0);
				if(locWithDuns.get(g.getDuns())!=null){
					locWithDuns.get(g.getDuns()).add(loc);
				}else{
					locList.add(loc);
					locWithDuns.put(g.getDuns(), locList);
				}
			
		}*/
	//result.setChannels(channelMap);
		//result.setLocWithDuns(locWithDuns1);
		//result.setCountyMap(locWithDuns);
		}catch(Exception e){
			logger.info(e.toString());
		}
		
		return result;
	}
	

	@Override
	public List<InstalledValveInfo> getValveInfo(int pageNo,int rowperpage,InstalledValveInfo installedValveInfo) {
	
		String sql= "select * from (select rownum as rnum, a.* from ddsafm.sqt_heat_map_data a where 1=1";
		List<InstalledValveInfo> result = null;
		try{
		MapSqlParameterSource parameters = new MapSqlParameterSource(setFilterParamsValveInfo(installedValveInfo));
		
		if(installedValveInfo!=null){
			String filter=getFilterClauseValveInfo(installedValveInfo);
			sql=sql+filter;
		}
		sql+=")";
		if (rowperpage > 0) {
			int lowerLimit = rowperpage * pageNo;
			int upperLimit = lowerLimit + rowperpage;
			
			String pageLimitClause= " where rnum >:lowerLimit AND rnum <=:upperLimit";
			parameters.addValue("lowerLimit", lowerLimit);
			parameters.addValue("upperLimit", upperLimit);
			sql+=pageLimitClause;
		}
		
		result=this.namedParamTemplate.query(sql, parameters,
				new InstalledValveInfoMapper());
		}catch(Exception e){
			logger.error("Unable to pull Valve info:"+e.getLocalizedMessage());
		}
		return result;
	}

	@Override
	public InstalledBaseWithDuns getInstallBaseGeoLocWithDuns(InstallBaseFilter baseFilter) {
InstalledBaseWithDuns result = null;
		
		try{
		String sql = "select * from "+" "
				+ "(select * from DDSAFM.SQT_ZIPCODE_LOOKUP lookup RIGHT OUTER JOIN (SELECT SOLD_TO_CITY,SOLD_TO_STATE,SOLD_TO_COUNTRY,CHANNEL,SOLD_TO_ZIP,COUNT(*) As Valves"+
" FROM DDSAFM.SQT_HEAT_MAP_DATA where 1=1";
		MapSqlParameterSource parameters = new MapSqlParameterSource(setFilterParams(baseFilter));
		
		if(baseFilter!=null){
			String filter=getFilterClause(baseFilter);
			sql=sql+filter;
		}
		sql+=" GROUP BY SOLD_TO_CITY,SOLD_TO_STATE,SOLD_TO_COUNTRY,CHANNEL,SOLD_TO_ZIP) heat on lookup.zipcode in heat.SOLD_TO_ZIP)";
	InstalledBaseWithDunsMapper mapper = new InstalledBaseWithDunsMapper();	
	this.namedParamTemplate.query(sql, parameters,
				mapper);
	result = mapper.getResult();
		
		}catch(Exception e){
			logger.info(e.toString());
		}
		
		return result;
	}

	@Override
	public int getValveInfoCount(InstalledValveInfo installedValveInfo) {
		String sql="select count(*) from ddsafm.sqt_heat_map_data a where 1=1 ";
		MapSqlParameterSource parameters = new MapSqlParameterSource(setFilterParamsValveInfo(installedValveInfo));
		if(installedValveInfo!=null){
			String filter=getFilterClauseValveInfo(installedValveInfo);
			
			sql=sql+filter;
			
		}
		return this.namedParamTemplate.queryForInt(sql, parameters);
	}
	
	private static final class HeatMapResultSet implements ResultSetExtractor<Map<String,List<GeoMapping>>>{
		@Override
		public Map<String, List<GeoMapping>> extractData(ResultSet rs) throws SQLException, DataAccessException {
		Map<String,List<GeoMapping>> heatMapData = new HashMap<>();
		while(rs.next()){ 
			if(rs.getString("SOLD_TO_STATE")==null)
				continue;
			GeoMapping loc = new GeoMapping();
			loc.setLatitude(rs.getString("LATITUDE"));
			loc.setLongitude(rs.getString("LONGITUDE"));
			loc.setZipCode(rs.getString("SOLD_TO_ZIP"));
			loc.setCount(rs.getInt("VALVES"));
			//loc.setState(rs.getString("STATE"));
			//logger.info("COMPANY NAME:"+rs.getString("COMPANY"));
			if(heatMapData.get(rs.getString("SOLD_TO_STATE"))!=null)
				heatMapData.get(rs.getString("SOLD_TO_STATE")).add(loc);
			else{
				List<GeoMapping> installBaseLocs = new ArrayList<>();
				installBaseLocs.add(loc);
				heatMapData.put(rs.getString("SOLD_TO_STATE"), installBaseLocs);
			}
		}
		return heatMapData;
		}
		}
	
	private static final class ChannelsResultSet implements ResultSetExtractor<Map<String,List<County>>>{
	@Override
	public Map<String, List<County>> extractData(ResultSet rs) throws SQLException, DataAccessException {
	Map<String,List<County>> channelMap = new HashMap<>();
	while(rs.next()){ 
		if(rs.getString("COMPANY")==null)
			continue;
		County loc = new County();
		//loc.setName(rs.getString("COUNTY"));
		loc.setState(rs.getString("STATE"));
		//loc.setState(rs.getString("STATE"));
		//logger.info("COMPANY NAME:"+rs.getString("COMPANY"));
		if(channelMap.get(rs.getString("COMPANY"))!=null)
			channelMap.get(rs.getString("COMPANY")).add(loc);
		else{
			List<County> installBaseLocs = new ArrayList<>();
			installBaseLocs.add(loc);
			channelMap.put(rs.getString("COMPANY"), installBaseLocs);
		}
	}
	return channelMap;
	}
	}
	private static final class ChannelMapResultSet implements ResultSetExtractor<Map<String,List<Map<String,List<InstallBaseLoc>>>>>{
	@Override
	public Map<String,List<Map<String,List<InstallBaseLoc>>>> extractData(ResultSet rs) throws SQLException, DataAccessException {
		Map<String,List<Map<String,List<InstallBaseLoc>>>> channelMap = new HashMap<>();
		while(rs.next()){
			InstallBaseLoc loc = new InstallBaseLoc();
			String county = rs.getString("COUNTY");
			loc.setLat(Float.parseFloat(rs.getString("LATITUDE")));
			loc.setLng(Float.parseFloat(rs.getString("LONGITUDE")));
			//logger.info("COMPANY NAME:"+rs.getString("COMPANY"));
			boolean va = false;
			if(channelMap.get(rs.getString("STATE"))!=null){
				//if(channelMap.get(rs.getString("COMPANY")).size()<1){
				for (Map<String,List<InstallBaseLoc>> countyMap: channelMap.get(rs.getString("STATE"))) {
					if(countyMap.get(county)!=null){
						countyMap.get(county).add(loc);
						va = true;
					}
				}
				if(va==false){
					Map<String,List<InstallBaseLoc>> countyMap1 = new HashMap<>();
					List<InstallBaseLoc> locList = new ArrayList<>();
					locList.add(loc);
					countyMap1.put(county, locList);
					channelMap.get(rs.getString("STATE")).add(countyMap1);
					
				}
			//}
			}else{
				Map<String,List<InstallBaseLoc>> countyMap = new HashMap<>();
				List<InstallBaseLoc> installBaseLocs = new CopyOnWriteArrayList<>();
				installBaseLocs.add(loc);
				countyMap.put(county, installBaseLocs);
				List<Map<String,List<InstallBaseLoc>>> counties = new CopyOnWriteArrayList<>();
				counties.add(countyMap);
				channelMap.put(rs.getString("STATE"), counties);
			}
		}
		return channelMap;
	}
	}
	
	private static final class ChannelMapResultSetCounty implements ResultSetExtractor<Map<String,List<Map<String,List<InstallBaseLoc>>>>>{
		@Override
		public Map<String, List<Map<String,List<InstallBaseLoc>>>> extractData(ResultSet rs) throws SQLException, DataAccessException {
			Map<String,List<Map<String,List<InstallBaseLoc>>>> channelMap = new HashMap<>();
		while(rs.next()){
			InstallBaseLoc loc = new InstallBaseLoc();
			String county = rs.getString("COUNTY");
			loc.setLat(Float.parseFloat(rs.getString("LATITUDE")));
			loc.setLng(Float.parseFloat(rs.getString("LONGITUDE")));
			//logger.info("COMPANY NAME:"+rs.getString("COMPANY"));
			boolean va = false;
			if(channelMap.get(rs.getString("COMPANY"))!=null){
				//if(channelMap.get(rs.getString("COMPANY")).size()<1){
				for (Map<String,List<InstallBaseLoc>> countyMap: channelMap.get(rs.getString("COMPANY"))) {
					if(countyMap.get(county)!=null){
						countyMap.get(county).add(loc);
						va = true;
					}
				}
				if(va==false){
					Map<String,List<InstallBaseLoc>> countyMap1 = new HashMap<>();
					List<InstallBaseLoc> locList = new ArrayList<>();
					locList.add(loc);
					countyMap1.put(county, locList);
					channelMap.get(rs.getString("COMPANY")).add(countyMap1);
					
				}
			//}
			}else{
				Map<String,List<InstallBaseLoc>> countyMap = new HashMap<>();
				List<InstallBaseLoc> installBaseLocs = new CopyOnWriteArrayList<>();
				installBaseLocs.add(loc);
				countyMap.put(county, installBaseLocs);
				List<Map<String,List<InstallBaseLoc>>> counties = new CopyOnWriteArrayList<>();
				counties.add(countyMap);
				channelMap.put(rs.getString("COMPANY"), counties);
			}
		}
		return channelMap;
		}
		}
}
