package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.Date;

public class Report implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2269913721114321250L;

	private String recSource;
	private String salesOrder;
	private String purchaseOrderNumber;
	private String endUserCountry;
	private String soldToCustomerName;
	private String endUserName;
	private String endUserLocation;
	private String soldToProvince;
	private String soldToState;
	private String soldToCity;
	private String repName;
	private String valvePartNumber;
	private String valveSerialNumber;
	private String valveDescription;
	private String componentItemNumber;
	private String componentDescription;
	private String tagNumber;
	private String partNumber;
	private String description;
	private String legacyPartNumber;
	private double listPrice;
	private double extendedListPrice;
	private String leadTime;
	private int quantity;
	private double recommendedQuantity;
	private String spareIndicator;
	private String spareCategory;
	private String stockType;
	private double defaultPercent;
	private String userName;
	private String region;
	private String factory;
	private String sourceSystem;
	private String salesOrderLine;
	private String orderedItemNumber;
	private int quantityShipped;
	private String unitSellingPrice;
	private Date actualShippedDate;
	private String spareQuotes;
	private String spareType;
	private String currencyUnit;
	private String channelPartner;
	private int recomendedQty;

	public int getRecomendedQty() {
		return recomendedQty;
	}

	public void setRecomendedQty(int recomendedQty) {
		this.recomendedQty = recomendedQty;
	}

	public String getCurrencyUnit() {
		return currencyUnit;
	}

	public void setCurrencyUnit(String currencyUnit) {
		this.currencyUnit = currencyUnit;
	}

	public String getRecSource() {
		return recSource;
	}

	public void setRecSource(String recSource) {
		this.recSource = recSource;
	}

	public String getSalesOrder() {
		return salesOrder;
	}

	public void setSalesOrder(String salesOrder) {
		this.salesOrder = salesOrder;
	}

	public String getPurchaseOrderNumber() {
		return purchaseOrderNumber;
	}

	public void setPurchaseOrderNumber(String purchaseOrderNumber) {
		this.purchaseOrderNumber = purchaseOrderNumber;
	}

	public String getEndUserCountry() {
		return endUserCountry;
	}

	public void setEndUserCountry(String endUserCountry) {
		this.endUserCountry = endUserCountry;
	}

	public String getSoldToCustomerName() {
		return soldToCustomerName;
	}

	public void setSoldToCustomerName(String soldToCustomerName) {
		this.soldToCustomerName = soldToCustomerName;
	}

	public String getEndUserName() {
		return endUserName;
	}

	public void setEndUserName(String endUserName) {
		this.endUserName = endUserName;
	}

	public String getEndUserLocation() {
		return endUserLocation;
	}

	public void setEndUserLocation(String endUserLocation) {
		this.endUserLocation = endUserLocation;
	}

	public String getSoldToProvince() {
		return soldToProvince;
	}

	public void setSoldToProvince(String soldToProvince) {
		this.soldToProvince = soldToProvince;
	}

	public String getSoldToState() {
		return soldToState;
	}

	public void setSoldToState(String soldToState) {
		this.soldToState = soldToState;
	}

	public String getSoldToCity() {
		return soldToCity;
	}

	public void setSoldToCity(String soldToCity) {
		this.soldToCity = soldToCity;
	}

	public String getRepName() {
		return repName;
	}

	public void setRepName(String repName) {
		this.repName = repName;
	}

	public String getValvePartNumber() {
		return valvePartNumber;
	}

	public void setValvePartNumber(String valvePartNumber) {
		this.valvePartNumber = valvePartNumber;
	}

	public String getValveSerialNumber() {
		return valveSerialNumber;
	}

	public void setValveSerialNumber(String valveSerialNumber) {
		this.valveSerialNumber = valveSerialNumber;
	}

	public String getValveDescription() {
		return valveDescription;
	}

	public void setValveDescription(String valveDescription) {
		this.valveDescription = valveDescription;
	}

	public String getComponentItemNumber() {
		return componentItemNumber;
	}

	public void setComponentItemNumber(String componentItemNumber) {
		this.componentItemNumber = componentItemNumber;
	}

	public String getComponentDescription() {
		return componentDescription;
	}

	public void setComponentDescription(String componentDescription) {
		this.componentDescription = componentDescription;
	}

	public String getTagNumber() {
		return tagNumber;
	}

	public void setTagNumber(String tagNumber) {
		this.tagNumber = tagNumber;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLegacyPartNumber() {
		return legacyPartNumber;
	}

	public void setLegacyPartNumber(String legacyPartNumber) {
		this.legacyPartNumber = legacyPartNumber;
	}

	public double getListPrice() {
		return listPrice;
	}

	public void setListPrice(double listPrice) {
		this.listPrice = listPrice;
	}

	public double getExtendedListPrice() {
		return extendedListPrice;
	}

	public void setExtendedListPrice(double extendedListPrice) {
		this.extendedListPrice = extendedListPrice;
	}

	public String getLeadTime() {
		return leadTime;
	}

	public void setLeadTime(String leadTime) {
		this.leadTime = leadTime;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getRecommendedQuantity() {
		return recommendedQuantity;
	}

	public void setRecommendedQuantity(double recommendedQuantity) {
		this.recommendedQuantity = recommendedQuantity;
	}

	public String getSpareIndicator() {
		return spareIndicator;
	}

	public void setSpareIndicator(String spareIndicator) {
		this.spareIndicator = spareIndicator;
	}

	public String getSpareCategory() {
		return spareCategory;
	}

	public void setSpareCategory(String spareCategory) {
		this.spareCategory = spareCategory;
	}

	public String getStockType() {
		return stockType;
	}

	public void setStockType(String stockType) {
		this.stockType = stockType;
	}

	public double getDefaultPercent() {
		return defaultPercent;
	}

	public void setDefaultPercent(double defaultPercent) {
		this.defaultPercent = defaultPercent;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getFactory() {
		return factory;
	}

	public void setFactory(String factory) {
		this.factory = factory;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public String getSalesOrderLine() {
		return salesOrderLine;
	}

	public void setSalesOrderLine(String salesOrderLine) {
		this.salesOrderLine = salesOrderLine;
	}

	public String getOrderedItemNumber() {
		return orderedItemNumber;
	}

	public void setOrderedItemNumber(String orderedItemNumber) {
		this.orderedItemNumber = orderedItemNumber;
	}

	public int getQuantityShipped() {
		return quantityShipped;
	}

	public void setQuantityShipped(int quantityShipped) {
		this.quantityShipped = quantityShipped;
	}

	public String getUnitSellingPrice() {
		return unitSellingPrice;
	}

	public void setUnitSellingPrice(String unitSellingPrice) {
		this.unitSellingPrice = unitSellingPrice;
	}

	public Date getActualShippedDate() {
		return actualShippedDate;
	}

	public void setActualShippedDate(Date actualShippedDate) {
		this.actualShippedDate = actualShippedDate;
	}

	public String getSpareQuotes() {
		return spareQuotes;
	}

	public void setSpareQuotes(String spareQuotes) {
		this.spareQuotes = spareQuotes;
	}

	public String getSpareType() {
		return spareType;
	}

	public void setSpareType(String spareType) {
		this.spareType = spareType;
	}

	public String getChannelPartner() {
		return channelPartner;
	}

	public void setChannelPartner(String channelPartner) {
		this.channelPartner = channelPartner;
	}
	
	public Report() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Report(String recSource, String salesOrder,
			String purchaseOrderNumber, String endUserCountry,
			String soldToCustomerName, String endUserName,
			String endUserLocation, String soldToProvince, String soldToState,
			String soldToCity, String repName, String valvePartNumber,
			String valveSerialNumber, String valveDescription,
			String componentItemNumber, String componentDescription,
			String tagNumber, String partNumber, String description,
			String legacyPartNumber, double listPrice,
			double extendedListPrice, String leadTime, int quantity,
			double recommendedQuantity, String spareIndicator,
			String spareCategory, String stockType, double defaultPercent,
			String userName, String region, String factory,
			String sourceSystem, String salesOrderLine,
			String orderedItemNumber, int quantityShipped,
			String unitSellingPrice, Date actualShippedDate,
			String spareQuotes, String spareType,String currencyUnit,String channelPartner) {
		super();
		this.recSource = recSource;
		this.salesOrder = salesOrder;
		this.purchaseOrderNumber = purchaseOrderNumber;
		this.endUserCountry = endUserCountry;
		this.soldToCustomerName = soldToCustomerName;
		this.endUserName = endUserName;
		this.endUserLocation = endUserLocation;
		this.soldToProvince = soldToProvince;
		this.soldToState = soldToState;
		this.soldToCity = soldToCity;
		this.repName = repName;
		this.valvePartNumber = valvePartNumber;
		this.valveSerialNumber = valveSerialNumber;
		this.valveDescription = valveDescription;
		this.componentItemNumber = componentItemNumber;
		this.componentDescription = componentDescription;
		this.tagNumber = tagNumber;
		this.partNumber = partNumber;
		this.description = description;
		this.legacyPartNumber = legacyPartNumber;
		this.listPrice = listPrice;
		this.extendedListPrice = extendedListPrice;
		this.leadTime = leadTime;
		this.quantity = quantity;
		this.recommendedQuantity = recommendedQuantity;
		this.spareIndicator = spareIndicator;
		this.spareCategory = spareCategory;
		this.stockType = stockType;
		this.defaultPercent = defaultPercent;
		this.userName = userName;
		this.region = region;
		this.factory = factory;
		this.sourceSystem = sourceSystem;
		this.salesOrderLine = salesOrderLine;
		this.orderedItemNumber = orderedItemNumber;
		this.quantityShipped = quantityShipped;
		this.unitSellingPrice = unitSellingPrice;
		this.actualShippedDate = actualShippedDate;
		this.spareQuotes = spareQuotes;
		this.spareType = spareType;
		this.currencyUnit=currencyUnit;
		this.channelPartner=channelPartner;
	}

}
