package com.ge.fpt.welcomepkg.api;

import java.util.Date;

public class SerialNoDetails {


private static final long serialVersionUID = 1L;
	
	private Date actualShipDate;
	private String serialNumber;
	private String valvePartNumber;
	private String valveDescription;
	private String tagNumber;
	private String sourceSystem;
	private Long quantityShipped;
	private String salesOrder;
	private String PO;
	
	public SerialNoDetails() {
		super();
	}
	
	public SerialNoDetails(Date actualShipDate, String serialNumber, String valvePartNumber, String valveDescription,
			String tagNumber, String sourceSystem, Long quantityShipped, String salesOrder, String pO) {
		super();
		this.actualShipDate = actualShipDate;
		this.serialNumber = serialNumber;
		this.valvePartNumber = valvePartNumber;
		this.valveDescription = valveDescription;
		this.tagNumber = tagNumber;
		this.sourceSystem = sourceSystem;
		this.quantityShipped = quantityShipped;
		this.salesOrder = salesOrder;
		PO = pO;
	}
	
	public Date getActualShipDate() {
		return actualShipDate;
	}
	public void setActualShipDate(Date actualShipDate) {
		this.actualShipDate = actualShipDate;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getValvePartNumber() {
		return valvePartNumber;
	}
	public void setValvePartNumber(String valvePartNumber) {
		this.valvePartNumber = valvePartNumber;
	}
	public String getValveDescription() {
		return valveDescription;
	}
	public void setValveDescription(String valveDescription) {
		this.valveDescription = valveDescription;
	}
	public String getTagNumber() {
		return tagNumber;
	}
	public void setTagNumber(String tagNumber) {
		this.tagNumber = tagNumber;
	}
	public String getSourceSystem() {
		return sourceSystem;
	}
	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}
	public Long getQuantityShipped() {
		return quantityShipped;
	}
	public void setQuantityShipped(Long quantityShipped) {
		this.quantityShipped = quantityShipped;
	}



	public String getSalesOrder() {
		return salesOrder;
	}

	public void setSalesOrder(String salesOrder) {
		this.salesOrder = salesOrder;
	}

	public String getPO() {
		return PO;
	}

	public void setPO(String pO) {
		PO = pO;
	}

	
}
