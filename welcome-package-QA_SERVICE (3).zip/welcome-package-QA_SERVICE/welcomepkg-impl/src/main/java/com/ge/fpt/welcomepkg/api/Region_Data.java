package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Region_Data implements Serializable{
	private static final long serialVersionUID = 1L;

	private String region;
	private List<Country_Data> country_Data=new ArrayList<Country_Data>();

	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}


	/**
	 * @return the country_Data
	 */
	 public List<Country_Data> getCountry_Data() {
		 return country_Data;
	 }
	 /**
	  * @param country_Data the country_Data to set
	  */
	  public void setCountry_Data(List<Country_Data> country_Data) {
		  this.country_Data = country_Data;
	  }
	  @Override
	  public String toString() {
		  return "GeCountry [region=" + region + ", country_Data=" + country_Data + "]";
	  }



}
