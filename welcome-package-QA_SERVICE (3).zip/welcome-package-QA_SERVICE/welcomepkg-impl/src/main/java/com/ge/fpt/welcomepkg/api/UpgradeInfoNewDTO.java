package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.List;

public class UpgradeInfoNewDTO implements Serializable {
	private static final long serialVersionUID =1L;
	
	private List<String> upgradeId;
	
	public List<String> getUpgradeId() {
		return upgradeId;
	}
	public void setUpgradeId(List<String> upgradeId) {
		this.upgradeId = upgradeId;
	}
}
