package com.ge.fpt.welcomepkg.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.fpt.welcomepkg.api.InventoryUser;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;

public class InventoryUserPersistenceImpl implements IInventoryUserPersistence {
	private static final Logger logger = WelcomePackageLoggerFactory
			.getLogger(InventoryUserPersistenceImpl.class);
	JdbcTemplate jdbcTemplate;
	DataSource dataSource;
	PlatformTransactionManager txManager;

	public DataSource getDataSource() {
		return this.dataSource;
	}

	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
	}

	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ge.fpt.welcomepkg.persistence.IpriceToolUserPersistence#getPriceToolUser
	 * ()
	 */
	/* (non-Javadoc)
	 * @see com.ge.fpt.welcomepkg.persistence.IInventoryUserPersistence#getInventoryUser()
	 */
	
	@Override
	public List<InventoryUser> getInventoryUser() {

		String sql = "select  distinct a.sso,a.createdBy,a.createdDate,a.UpdatedBy,a.updatedDate from fptOds.SQT_Inventory_User a ";
		 return this.jdbcTemplate.query(sql, new InventoryUserMapper());
	}

	public static final class InventoryUserMapper implements
			RowMapper<InventoryUser> {
		public InventoryUser mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			InventoryUser result = new InventoryUser();
			result.setSso(rs.getString("sso"));
			result.setCreatedBy(rs.getString("createdBy"));
			result.setUpdatedBy(rs.getString("updatedBy"));
			result.setCreatedDate(rs.getDate("createdDate"));
			result.setUpdatedDate(rs.getDate("updatedDate"));
			
			return result;
		}
	}

	/* (non-Javadoc)
	 * @see com.ge.fpt.welcomepkg.persistence.IInventoryUserPersistence#saveInventoryUser(java.lang.String, com.ge.fpt.welcomepkg.api.InventoryUser)
	 */
	@Override
	public StatusInfo saveInventoryUser(String user, InventoryUser inventoryUser) {
		StatusInfo statusInfo=new StatusInfo();
		String sso = inventoryUser.getSso();
		
		int count =0;
		String sqlCount = "select count(*) as userCount from fptods.SQT_inventory_User where 1=1 "
				+ " and  sso= ? ";
		 count = this.jdbcTemplate.queryForInt(sqlCount, new Object[] { sso });
		
		if (count > 0) {
			String sqlDelete = "delete from  fptods.SQT_inventory_User where 1=1 "
					+ "and  sso= ?";
			 this.jdbcTemplate.update(sqlDelete, new Object[] { sso });	
			}
		
		String sqlInsert = "insert into fptods.SQT_Inventory_User (sso,createdby,updatedby,createddate,updatedDate) "
				+ "values(?,?,?,sysdate,sysdate)";
		this.jdbcTemplate.update(sqlInsert, new Object[] { sso, user,
				user });

		statusInfo.setStatusCode(0);
		statusInfo.setStatusMessage("Data Saved Successfully!!");
		return statusInfo;
	}

	/* (non-Javadoc)
	 * @see com.ge.fpt.welcomepkg.persistence.IInventoryUserPersistence#deleteInventoryUser(com.ge.fpt.welcomepkg.api.InventoryUser)
	 */
	@Override
	public StatusInfo deleteInventoryUser(InventoryUser inventoryUser) {
		StatusInfo statusInfo=new StatusInfo();
		String sso = inventoryUser.getSso();
		String sqlDelete = "delete from  fptods.SQT_Inventory_User where 1=1 "
				+ "and  sso= ?";
		this.jdbcTemplate.update(sqlDelete, new Object[] { sso  });
		statusInfo.setStatusCode(0);
		statusInfo.setStatusMessage("Data Deleted Successfully!!");
		return statusInfo;

	}
}
