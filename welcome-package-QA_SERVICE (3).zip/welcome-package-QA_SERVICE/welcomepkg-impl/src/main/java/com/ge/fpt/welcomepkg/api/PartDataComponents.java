package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;

public class PartDataComponents  implements Serializable{

	private static final long serialVersionUID = -5579175197980496818L;
	
	private String partId;
	private String componentId;
	private String componentDesc;
	private String quantity;
	private String valveIndicator; 
	private String spareIndicator;
	private String partDescription;
	
	public String getPartDescription() {
		return partDescription;
	}

	public void setPartDescription(String partDescription) {
		this.partDescription = partDescription;
	}

	public String getSpareIndicator() {
		return spareIndicator;
	}

	public void setSpareIndicator(String spareIndicator) {
		this.spareIndicator = spareIndicator;
	}

	public String getValveIndicator() {
	return valveIndicator;
	}

	public void setValveIndicator(String valveIndicator) {
	this.valveIndicator = valveIndicator;
	} 

	
	public String getPartId() {
		return partId;
	}

	public void setPartId(String partId) {
		this.partId = partId;
	}
	
	public String getComponentId() {
		return componentId;
	}

	public void setComponentId(String componentId) {
		this.componentId = componentId;
	}

	public String getComponentDesc() {
		return componentDesc;
	}

	public void setComponentDesc(String componentDesc) {
		this.componentDesc = componentDesc;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public PartDataComponents() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public PartDataComponents(String componentId, String componentDesc, 
			String quantity, String partId,String valveIndicator,String spareIndicator,
			String partDescription) {
		super();
		this.componentId = componentId;
		this.componentDesc = componentDesc;
		this.quantity = quantity;
		this.partId = partId;
		this.valveIndicator = valveIndicator;
		this.spareIndicator= spareIndicator;
		this.partDescription=partDescription;
	}
}
