package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.Date;

public class CustomerLinkMaster implements Serializable{
	private static final long serialVersionUID = 1L;

	private String orderId;
	private String orderNumber;
	private String orderLineId;
	private String serialNumber;
	private String recSource;
	private String customerName;
	private String custId;
	private String linkCustomerName;
	private String plantId;
	private String plantLocation;
	private String dunsNumber;
	private Date createdDate;
	private Date updatedDate;
	private String updatedBy;
	private String createdBy;
	
	
	
	public String getCustId() {
		return custId;
	}



	public void setCustId(String custId) {
		this.custId = custId;
	}



	public CustomerLinkMaster() {
		super();
		// TODO Auto-generated constructor stub
	}



	/*public CustomerLinkMaster(String orderId, String orderNumber, String orderLineId, String serialNumber,
			String recSource, String customerName, String customerId, String linkCustomerName, String plantId,
			String plantName, String plantLocation) {
		super();
		this.orderId = orderId;
		this.orderNumber = orderNumber;
		this.orderLineId = orderLineId;
		this.serialNumber = serialNumber;
		this.recSource = recSource;
		this.customerName = customerName;
		this.customerId = customerId;
		this.linkCustomerName = linkCustomerName;
		this.plantId = plantId;
		this.plantName = plantName;
		this.plantLocation = plantLocation;
	}*/



	public String getOrderId() {
		return orderId;
	}



	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}



	public String getOrderNumber() {
		return orderNumber;
	}



	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}



	public String getOrderLineId() {
		return orderLineId;
	}



	public void setOrderLineId(String orderLineId) {
		this.orderLineId = orderLineId;
	}



	public String getSerialNumber() {
		return serialNumber;
	}



	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}



	public String getRecSource() {
		return recSource;
	}



	public void setRecSource(String recSource) {
		this.recSource = recSource;
	}



	public String getCustomerName() {
		return customerName;
	}



	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getLinkCustomerName() {
		return linkCustomerName;
	}



	public void setLinkCustomerName(String linkCustomerName) {
		this.linkCustomerName = linkCustomerName;
	}



	public String getPlantId() {
		return plantId;
	}



	public void setPlantId(String plantId) {
		this.plantId = plantId;
	}

	public String getPlantLocation() {
		return plantLocation;
	}



	public void setPlantLocation(String plantLocation) {
		this.plantLocation = plantLocation;
	}



	public String getDunsNumber() {
		return dunsNumber;
	}



	public void setDunsNumber(String dunsNumber) {
		this.dunsNumber = dunsNumber;
	}



	public Date getCreatedDate() {
		return createdDate;
	}



	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}



	public Date getUpdatedDate() {
		return updatedDate;
	}



	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}



	public String getUpdatedBy() {
		return updatedBy;
	}



	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}



	public String getCreatedBy() {
		return createdBy;
	}



	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}



	

}
