package com.ge.fpt.welcomepkg.persistence;

import java.util.List;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ge.fpt.welcomepkg.api.PriceToolUser;
import com.ge.fpt.welcomepkg.api.StatusInfo;

public abstract interface IpriceToolUserPersistence {
	@Transactional(propagation=Propagation.REQUIRED)
	public abstract List<PriceToolUser> getPriceToolUser();
	
	@Transactional(propagation=Propagation.REQUIRED)
	public abstract StatusInfo savePriceToolUser(String sso,PriceToolUser priceToolUser);
	
	
	@Transactional(propagation=Propagation.REQUIRED)
	public abstract StatusInfo deletePriceToolUser(PriceToolUser priceToolUser);

}