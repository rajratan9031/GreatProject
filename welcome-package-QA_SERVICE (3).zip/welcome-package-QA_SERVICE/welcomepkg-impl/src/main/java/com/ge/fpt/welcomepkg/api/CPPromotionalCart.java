package com.ge.fpt.welcomepkg.api;

import java.util.List;

public class CPPromotionalCart {
	
	private String sso;
	private int upgradeId;
	private String upgradeName;
	private int optionId;
	private String optionName;
	private String optionDescription;
	private String couponCode;
	private List<CPUpgradeParts> upgradePartsData;
	private String kitNumber;
	private int quantity;
	private String indicator;
	
	
	public String getSso() {
		return sso;
	}
	public void setSso(String sso) {
		this.sso = sso;
	}
	public int getUpgradeId() {
		return upgradeId;
	}
	public void setUpgradeId(int upgradeId) {
		this.upgradeId = upgradeId;
	}
	public String getUpgradeName() {
		return upgradeName;
	}
	public void setUpgradeName(String upgradeName) {
		this.upgradeName = upgradeName;
	}
	public int getOptionId() {
		return optionId;
	}
	public void setOptionId(int optionId) {
		this.optionId = optionId;
	}
	public String getOptionName() {
		return optionName;
	}
	public void setOptionName(String optionName) {
		this.optionName = optionName;
	}
	public String getOptionDescription() {
		return optionDescription;
	}
	public void setOptionDescription(String optionDescription) {
		this.optionDescription = optionDescription;
	}
	public String getCouponCode() {
		return couponCode;
	}
	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}
	public List<CPUpgradeParts> getUpgradePartsData() {
		return upgradePartsData;
	}
	public void setUpgradePartsData(List<CPUpgradeParts> upgradePartsData) {
		this.upgradePartsData = upgradePartsData;
	}
	public String getKitNumber() {
		return kitNumber;
	}
	public void setKitNumber(String kitNumber) {
		this.kitNumber = kitNumber;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	/**
	 * @return the indicator
	 */
	public String getIndicator() {
		return indicator;
	}
	/**
	 * @param indicator the indicator to set
	 */
	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}
	
	
	@Override
	public String toString() {
		return "CPPromotionalCart [sso=" + sso + ", upgradeId=" + upgradeId + ", upgradeName=" + upgradeName
				+ ", optionId=" + optionId + ", optionName=" + optionName + ", optionDescription=" + optionDescription
				+ ", couponCode=" + couponCode + ", upgradePartsData=" + upgradePartsData + ", kitNumber=" + kitNumber
				+ ", quantity=" + quantity + "]";
	}
	

}
