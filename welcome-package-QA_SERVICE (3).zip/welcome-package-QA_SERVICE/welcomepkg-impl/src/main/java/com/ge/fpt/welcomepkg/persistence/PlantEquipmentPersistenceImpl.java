package com.ge.fpt.welcomepkg.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.fpt.welcomepkg.api.PlantEquipment;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;

public class PlantEquipmentPersistenceImpl implements IPlantEquipmentPersistence {

	@SuppressWarnings("javadoc")
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory.getLogger(PlantEquipmentPersistenceImpl.class);
	
	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;

	/**
	 * Data source for the JDBC
	 */
	DataSource dataSource;

	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;
	
	NamedParameterJdbcTemplate namedParamTemplate;

	/**
	 * @return the dataSource
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}

	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate = new NamedParameterJdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}
	@Override
	public List<String> getEquipments(String serialNumber) {
		String sql = "select distinct SERIAL_NUMBER from DDSAFM.SQT_VALVE_INFO_T where SERIAL_NUMBER like :serialNumber";
		MapSqlParameterSource paramMap=new MapSqlParameterSource();
		paramMap.addValue("serialNumber", serialNumber+"%");
		logger.error("inside getEquipments()");
		return this.namedParamTemplate.queryForList(sql, paramMap,String.class);
	}

	@Override
	public StatusInfo savePlantEquipment(PlantEquipment equipment) {

		StatusInfo statusinfo= new StatusInfo();
			String saveSql="";
			 Date lastServiced=null;
			 Date shipmentDate = null;
			 	try{
					DateFormat df = new SimpleDateFormat("yyyy-MM-dd"); 
			        
					if(equipment.getIsGe().equalsIgnoreCase("N")){
					if(0==this.jdbcTemplate.queryForInt("select count(*) from ddsafm.sqt_valve_info_t where serial_number=?", new Object[]{equipment.getSerialNumber()})){
						logger.info("saving the Equipment in valve_info_t table:"+equipment);
						String order_line_id  = this.jdbcTemplate.queryForObject("select order_line_id from (select order_id from ddsafm.sqt_order_info_t where SALESREP_NAME='NON-GE') s,sqt_order_line_info_t line_info where s.order_id=line_info.order_id",String.class);
						long valve_id = this.jdbcTemplate.queryForObject("select max(valve_info_id) from ddsafm.sqt_valve_info_t",Long.class);
						valve_id = ++valve_id;
					this.jdbcTemplate.update("insert into ddsafm.sqt_valve_info_t (valve_info_id,rec_source,serial_number,order_line_id,description,TAG_NUMBER) values(?,?,?,?,?,?)", new Object[]{valve_id,equipment.getRecSource(),equipment.getSerialNumber(),order_line_id,equipment.getDescription(),equipment.getTagNumber()});
					equipment.setValveId(Long.toString(valve_id));
					saveOrUpdateEquipment(equipment, lastServiced, df);
					}else{
						saveOrUpdateEquipment(equipment, lastServiced, df);
					}
					}else{
					saveOrUpdateEquipment(equipment, lastServiced, df);
			 	}
					 statusinfo.setStatusCode(1);
					 logger.info("Data saved successfully");
					 statusinfo.setStatusMessage("Data saved Successfully");
			 	}catch(Exception e){
			 		statusinfo.setStatusCode(500);
					 statusinfo.setStatusMessage("Internal Server ERROR: Unable to save the equipment");
			 		logger.error("exception while saving the equipment"+e.getLocalizedMessage());
			 	}
				 return statusinfo;
		
	}

	private void saveOrUpdateEquipment(PlantEquipment equipment, Date lastServiced, DateFormat df)
			throws ParseException {
		
		String saveSql;
		Date shipmentDate;
		try{
			lastServiced = this.jdbcTemplate.query("select MODIFIED_DATE from ddsafm.ODS_BOM_CHANGES_T where serial_number=?",new Object[]{equipment.getSerialNumber()}, new ResultSetExtractor<Date>() {
		        @Override
		        public Date extractData(ResultSet rs) throws SQLException,
		                                                       DataAccessException {
		            return rs.next() ? rs.getDate("MODIFIED_DATE") : null;
		        }
		    });

			isServiceNeeded(equipment, lastServiced, df);
		if(checkIsSerialNumberexists(equipment)){
			logger.info("updating the equipment details"+equipment);
		 saveSql="update FPTODS.VALVE_INFO_OUTAGE set is_ge=?,manufacturer_name=?,priority_level=?,cp_loc_id=?,is_service_needed=?, date_last_service=? where serial_number=? and plant_id=?"	;
		 this.jdbcTemplate.update(saveSql, new Object[]{equipment.getIsGe(),equipment.getManufacturerName(),equipment.getIsPriority(),equipment.getCpLocId(),equipment.getIsServiceNeed(),lastServiced,equipment.getSerialNumber(),equipment.getPlantId()});
		}else{
			logger.info("inserting new equipment in plant:"+equipment.getPlantId());
			Object[] param={equipment.getIsGe(),
			  		  equipment.getManufacturerName(),
			  		equipment.getIsPriority(),
			  		equipment.getPlantId(),
			  		equipment.getRecSource(),
			  		equipment.getValveId(),
			  		equipment.getCpLocId(),
			  		lastServiced,
			  		equipment.getSerialNumber(),
			  		equipment.getIsServiceNeed()
			  		};
			saveSql= "insert into FPTODS.VALVE_INFO_OUTAGE (is_ge,manufacturer_name,priority_level, plant_id, rec_source, valve_id,cp_loc_id,DATE_LAST_SERVICE,serial_number,is_service_needed) values (?,?,?,?,?,?,?,?,?,?)";
			this.jdbcTemplate.update(saveSql, param);
		}}catch(Exception e){
			logger.error("unable to save/update equipment"+e.getLocalizedMessage());
		}
	}

	private void isServiceNeeded(PlantEquipment equipment, Date lastServiced, DateFormat df) throws ParseException {
		Date shipmentDate;
		long diff=0;
		Date date = new Date();
		if(lastServiced!=null){
			logger.info("calculating isServiceNeeded using lastServicedDate"+lastServiced);
			diff = (date.getTime()-lastServiced.getTime())/(24 * 60 * 60 * 1000);
		}else{
			if(null!=equipment.getShipmentDate()){
			shipmentDate = df.parse(equipment.getShipmentDate());
			
			logger.info("calculating isServiceNeeded using shipmentDate"+shipmentDate);
			diff = (date.getTime()-shipmentDate.getTime())/(24 * 60 * 60 * 1000);
			}
		}
		 logger.info(diff+"  days before valve has been serivced");
		if(diff>=1735 || diff>=1005){
			equipment.setIsServiceNeed("Y");
		}else{
			equipment.setIsServiceNeed("N");
		}
	}

	private boolean checkIsSerialNumberexists(PlantEquipment equipment) {
		if(0!=this.jdbcTemplate.queryForInt("select count(*) from fptods.valve_info_outage where serial_number=? and plant_id=?", new Object[]{equipment.getSerialNumber(), equipment.getPlantId()}))
		return true;
		return false;
	}

	@Override
	public int getEquipmentCountinPlant(PlantEquipment equipment) {
		int result=0;
		try{
		String sql="select count(*) from fptods.valve_info_outage a where plant_id =:plant ";
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("plant", equipment.getPlantId());
		if(equipment!=null){
			String filter=getFilterClause(equipment);
			
			sql=sql+filter;
			
		}
		result = this.namedParamTemplate.queryForInt(sql, parameters);
		}catch(Exception e){
			logger.error(e.getLocalizedMessage());
		}
		return result;
	}

	@Override
	public List<PlantEquipment> getEquipmentinPlant(int pageNo, int rowsPerpage, PlantEquipment equipment) {
		List<PlantEquipment> result=null;
		try{
		String sql= "select * from (select rownum as rnum,outage.REQ_SERVICE,outage.DATE_LAST_SERVICE DATE_LAST_SERVICE,outage.IS_SERVICE_NEEDED IS_SERVICE_NEEDED,outage.MANUFACTURER_NAME MANUFACTURER_NAME,"+
				"outage.REC_SOURCE REC_SOURCE, outage.CP_LOC_ID CP_LOC_ID,outage.PRIORITY_LEVEL PRIORITY_LEVEL,outage.IS_GE IS_GE,"+
				"outage.PLANT_ID PLANT_ID,outage.SERIAL_NUMBER SERIAL_NUMBER,outage.VALVE_ID VALVE_ID,loc.CP_LOCATION CP_LOCATION, "+
				"valve.order_line_id order_line_id,valve.tag_number tag_number,valve.item_number item_number,valve.description description, valve.valve_info_id valve_info_id "+
				"from (select * from fptods.valve_info_outage where plant_id =:plantId) outage, fptods.cp_location_details loc ,ddsafm.sqt_valve_info_t valve where outage.cp_loc_id=loc.cp_loc_id and outage.VALVE_ID = valve.valve_info_id";
		MapSqlParameterSource parameters = new MapSqlParameterSource(setFilterParams(equipment));
		parameters.addValue("plantId", equipment.getPlantId());
		if(equipment!=null){
			String filter=getFilterClause(equipment);
			sql=sql+filter;
		}
		sql+=")";
		if (rowsPerpage > 0) {
			int lowerLimit = rowsPerpage * pageNo;
			int upperLimit = lowerLimit + rowsPerpage;
			
			String pageLimitClause= " where rnum >:lowerLimit AND rnum <=:upperLimit";
			parameters.addValue("lowerLimit", lowerLimit);
			parameters.addValue("upperLimit", upperLimit);
			sql+=pageLimitClause;
		}
		
		result=this.namedParamTemplate.query(sql, parameters,
				new PlantEquipmentRowMaper());
		for (PlantEquipment plantEquipment : result) {
			String query = "select order_number from (select order_id from fptods.sqt_order_line_info_t where order_line_id=?) order_line, sqt_order_info_t order_info where order_line.order_id=order_info.order_id";
			String orderNumber = this.jdbcTemplate.queryForObject(query, new Object[]{plantEquipment.getOrderLineId()},String.class);
			logger.info("Order Number "+orderNumber+"for order Id"+plantEquipment.getOrderLineId());
			plantEquipment.setOrderNumber(orderNumber);
		}
		}catch(Exception e){
			logger.error("unable to fetch the equipments"+e.getLocalizedMessage());
		}
		return result;
	}

	@Override
	public StatusInfo deleteEquipment(PlantEquipment equipment) {
		logger.info("inside deleteEquipment()"+equipment);
		StatusInfo result= new StatusInfo();
		String sql = "delete from FPTODS.valve_info_outage where serial_number=? and plant_id=?";
		this.jdbcTemplate.update(sql, new Object[] {equipment.getSerialNumber(), equipment.getPlantId()});
		result.setStatusCode(1);
		result.setStatusMessage("equipment deleted successfully");
		return result;
	}

	@Override
	public List<String> getRecSources(String serialNumber) {
		logger.info("Inside getRecSources"+serialNumber);
		String sql = "select distinct REC_SOURCE from DDSAFM.SQT_VALVE_INFO_T where SERIAL_NUMBER =:serialNumber";
		MapSqlParameterSource paramMap=new MapSqlParameterSource();
		paramMap.addValue("serialNumber", serialNumber);
		return this.namedParamTemplate.queryForList(sql, paramMap,String.class);
	}

	@Override
	public Map<String, String> getShippingDates(String recSource, String serialNumber) {
		Map<String, String> shipValveMap = null;
		String sql = "select a.actual_shipment_date,b.valve_info_id from"+
				"(select actual_shipment_date,order_line_id from fptods.sqt_order_line_info_t where order_line_id in (select ORDER_LINE_ID from DDSAFM.SQT_VALVE_INFO_T where SERIAL_NUMBER =:serial and REC_SOURCE =:recSource)) a"+
				",(select valve_info_id, order_line_id from ddsafm.sqt_valve_info_t where order_line_id in (select ORDER_LINE_ID from DDSAFM.SQT_VALVE_INFO_T where SERIAL_NUMBER =:serial and REC_SOURCE =:recSource)) b where a.order_line_id=b.order_line_id order by a.actual_shipment_date desc";
		MapSqlParameterSource paramMap=new MapSqlParameterSource();
		paramMap.addValue("serial", serialNumber);
		paramMap.addValue("recSource", recSource);
		 shipValveMap = this.namedParamTemplate.query(sql, paramMap,new EquipResultSet());
		return shipValveMap;
	}
	
	public  Map<String, String> setFilterParams(PlantEquipment equipment){
		Map<String, String> result = new HashMap<String, String>();
	
		result.put("isServiceNeed", equipment.getIsServiceNeed()== null ? "" : equipment.getIsServiceNeed().toUpperCase());
		result.put("manufacturerName", equipment.getManufacturerName() == null ? "" : equipment.getManufacturerName().toUpperCase());
		result.put("recSource", equipment.getRecSource() == null ? "" : equipment.getRecSource().toUpperCase());
		result.put("isPriority", equipment.getIsPriority() == null ? "" : equipment.getIsPriority().toUpperCase());
		result.put("isGe", equipment.getIsGe() == null ? "" : equipment.getIsGe().toUpperCase());
		result.put("serialNumber", equipment.getSerialNumber() == null ? "" : equipment.getSerialNumber().toUpperCase());
		result.put("cpLocation", equipment.getCpLocation() == null ? "" : equipment.getCpLocation().toUpperCase());
		result.put("lastServiced", equipment.getLastServiced() == null ? "" : equipment.getLastServiced().toUpperCase());
		result.put("requiredService", equipment.getRequiredService() == null ? "" : equipment.getRequiredService().toUpperCase());
		return result;
	}
	
	public String getFilterClause(PlantEquipment equipment){
		String filter="";
		List<String> conditions = new ArrayList<String>();
		if(equipment!=null){
			if(equipment.getCpLocation()!=null && !equipment.getCpLocation().isEmpty()){
				conditions.add(" UPPER(CP_LOCATION) LIKE '%' || :cpLocation || '%'");
			}
			if(equipment.getIsServiceNeed()!=null && !equipment.getIsServiceNeed().isEmpty()){
				conditions.add(" UPPER(IS_SERVICE_NEEDED) LIKE '%' || :isServiceNeed || '%'");
			}
			if(equipment.getIsGe()!=null && !equipment.getIsGe().isEmpty()){
				conditions.add(" UPPER(IS_GE) LIKE '%' || :isGe || '%'");
			}
			if(equipment.getManufacturerName()!=null && !equipment.getManufacturerName().isEmpty()){
				conditions.add(" UPPER(MANUFACTURER_NAME) LIKE '%' || :manufacturerName || '%'");
			}
			if(equipment.getIsPriority()!=null && !equipment.getIsPriority().isEmpty()){
				conditions.add(" UPPER(PRIORITY_LEVEL) LIKE '%' || :isPriority || '%'");
			}
			if(equipment.getCpLocation()!=null && !equipment.getCpLocation().isEmpty()){
				conditions.add(" UPPER(CP_LOCATION) LIKE '%' || :cpLocation || '%'");
			}
			if(equipment.getSerialNumber()!=null && !equipment.getSerialNumber().isEmpty()){
				conditions.add(" UPPER(SERIAL_NUMBER) LIKE '%' || :serialNumber || '%'");
			}
			if(equipment.getRecSource()!=null && !equipment.getRecSource().isEmpty()){
				conditions.add(" UPPER(REC_SOURCE) LIKE '%' || :recSource || '%'");
			}
			if(equipment.getLastServiced()!=null && !equipment.getLastServiced().isEmpty()){
				conditions.add(" UPPER(DATE_LAST_SERVICE) LIKE '%' || :recSource || '%'");
			}
			if(equipment.getRequiredService()!=null && !equipment.getRequiredService().isEmpty()){
				conditions.add(" UPPER(REQ_SERVICE) LIKE '%' || :requiredService || '%'");
			}
			
		}
		if (conditions.size() > 0) {
			String condStr = "";
			
			for (int i = 0; i < conditions.size(); i++) {
				condStr += ( " AND " + conditions.get(i));
			}
			
			filter = condStr;
		}
		return filter;
	}
	
	private static final class PlantEquipmentRowMaper implements RowMapper<PlantEquipment>{

		@Override
		public PlantEquipment mapRow(ResultSet rs, int rowNum) throws SQLException {
			PlantEquipment equipment = new PlantEquipment();
			equipment.setCpLocation(rs.getString("CP_LOCATION"));
			equipment.setCpLocId(rs.getLong("CP_LOC_ID"));
			equipment.setIsGe(rs.getString("IS_GE"));
			equipment.setIsPriority(rs.getString("PRIORITY_LEVEL"));
			equipment.setIsServiceNeed(rs.getString("IS_SERVICE_NEEDED"));
			equipment.setLastServiced(null!=rs.getDate("DATE_LAST_SERVICE")?rs.getDate("DATE_LAST_SERVICE").toString():"");
			equipment.setManufacturerName(rs.getString("MANUFACTURER_NAME"));
			equipment.setPlantId(rs.getLong("PLANT_ID"));
			equipment.setRecSource(rs.getString("REC_SOURCE"));
			equipment.setSerialNumber(rs.getString("SERIAL_NUMBER"));
			equipment.setValveId(rs.getString("VALVE_ID"));
			equipment.setItemNumber(rs.getString("item_number"));
			equipment.setTagNumber(rs.getString("tag_number"));
			equipment.setDescription(rs.getString("description"));
			equipment.setOrderLineId(rs.getLong("order_line_id"));
			equipment.setRequiredService(rs.getString("REQ_SERVICE"));
			logger.info("got the equipment"+equipment);
			return equipment;
		}
		
	}
private static final class EquipResultSet implements ResultSetExtractor<Map<String,String>>{

	@Override
	public Map<String, String> extractData(ResultSet rs) throws SQLException, DataAccessException {
		Map<String,String> valveShipMap = new HashMap<>();
		 while(rs.next()){ 
			 valveShipMap.put(rs.getString("valve_info_id"), rs.getString("actual_shipment_date"));
		 }
		 return valveShipMap;
		 }
	}
	
}
