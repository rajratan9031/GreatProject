package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;

public class AccountData implements Serializable{ 
	
	private static final long serialVersionUID = 1L;
	String accountId;
	String accountName;
	
	
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	
	public AccountData(){
		super();
	}
	public AccountData(String accountId, String accountName) {
		super();
		this.accountId = accountId;
		this.accountName = accountName;
	}
	

}
