package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.sql.Date;

public class UpgradeInfoNew implements Serializable {
	private static final long serialVersionUID = 1L;
	private String upgradeId;
	private String upgradeName;
	private String upgradeBrand;
	private String upgradeDescription;
	private String upgradeModel;
	private String upgradePartId;
	private String couponCode;
	private String region;
	private Date validityFrom;
	private Date validityTo;
	private String promo_file;
	private String promo_name;
	private String category;
	private String equipment;
	private double discount;
	private String document_Count;
	
	public String getUpgradeId() {
		return upgradeId;
	}
	public void setUpgradeId(String upgradeId) {
		this.upgradeId = upgradeId;
	}
	public String getUpgradeName() {
		return upgradeName;
	}
	public void setUpgradeName(String upgradeName) {
		this.upgradeName = upgradeName;
	}
	public String getUpgradeBrand() {
		return upgradeBrand;
	}
	public void setUpgradeBrand(String upgradeBrand) {
		this.upgradeBrand = upgradeBrand;
	}
	public String getUpgradeDescription() {
		return upgradeDescription;
	}
	public void setUpgradeDescription(String upgradeDescription) {
		this.upgradeDescription = upgradeDescription;
	}
	public String getUpgradeModel() {
		return upgradeModel;
	}
	public void setUpgradeModel(String upgradeModel) {
		this.upgradeModel = upgradeModel;
	}
	public String getUpgradePartId() {
		return upgradePartId;
	}
	public void setUpgradePartId(String upgradePartId) {
		this.upgradePartId = upgradePartId;
	}
	public String getCouponCode() {
		return couponCode;
	}
	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public Date getValidityFrom() {
		return validityFrom;
	}
	public void setValidityFrom(Date validityFrom) {
		this.validityFrom = validityFrom;
	}
	public Date getValidityTo() {
		return validityTo;
	}
	public void setValidityTo(Date validityTo) {
		this.validityTo = validityTo;
	}
	public String getPromo_file() {
		return promo_file;
	}
	public void setPromo_file(String promo_file) {
		this.promo_file = promo_file;
	}
	public String getPromo_name() {
		return promo_name;
	}
	public void setPromo_name(String promo_name) {
		this.promo_name = promo_name;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getEquipment() {
		return equipment;
	}
	public void setEquipment(String equipment) {
		this.equipment = equipment;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	
	public String getDocument_Count() {
		return document_Count;
	}
	public void setDocument_Count(String document_Count) {
		this.document_Count = document_Count;
	}
	@Override
	public String toString() {
		return "UpgradeInfoNew [upgradeId=" + upgradeId + ", upgradeName=" + upgradeName + ", upgradeBrand="
				+ upgradeBrand + ", upgradeDescription=" + upgradeDescription + ", upgradeModel=" + upgradeModel
				+ ", upgradePartId=" + upgradePartId + ", couponCode=" + couponCode + ", region=" + region
				+ ", validityFrom=" + validityFrom + ", validityTo=" + validityTo + ", promo_file=" + promo_file
				+ ", promo_name=" + promo_name + ", category=" + category + ", equipment=" + equipment + ", discount="
				+ discount + ", document_Count=" + document_Count + "]";
	}
	

}
