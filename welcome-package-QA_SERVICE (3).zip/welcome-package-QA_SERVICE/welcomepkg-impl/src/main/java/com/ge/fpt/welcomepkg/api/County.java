package com.ge.fpt.welcomepkg.api;

public class County {
private String name;
private String state;
private String[] coordinates;
public String[] getCoordinates() {
	return coordinates;
}
public void setCoordinates(String[] coordinates) {
	this.coordinates = coordinates;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}

}
