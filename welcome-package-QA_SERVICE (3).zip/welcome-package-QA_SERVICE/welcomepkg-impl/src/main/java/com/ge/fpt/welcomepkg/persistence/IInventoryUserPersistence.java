package com.ge.fpt.welcomepkg.persistence;

import java.util.List;

import com.ge.fpt.welcomepkg.api.InventoryUser;
import com.ge.fpt.welcomepkg.api.StatusInfo;

public interface IInventoryUserPersistence {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ge.fpt.welcomepkg.persistence.IpriceToolUserPersistence#getPriceToolUser
	 * ()
	 */
	public abstract List<InventoryUser> getInventoryUser();

	public abstract StatusInfo saveInventoryUser(String user,
			InventoryUser inventoryUser);

	public abstract StatusInfo deleteInventoryUser(InventoryUser inventoryUser);
	
	
	

}