package com.ge.fpt.welcomepkg.api;

public class GeoMapping {
private String zipCode;
/*private String city;
private String state;
private String country;
private String channel;*/
private String latitude;
private String longitude;
private int count;
//private String duns;
public String getZipCode() {
	return zipCode;
}
public void setZipCode(String zipCode) {
	this.zipCode = zipCode;
}
public String getLatitude() {
	return latitude;
}
public void setLatitude(String latitude) {
	this.latitude = latitude;
}
public String getLongitude() {
	return longitude;
}
public void setLongitude(String longitude) {
	this.longitude = longitude;
}
public int getCount() {
	return count;
}
public void setCount(int count) {
	this.count = count;
}

}
