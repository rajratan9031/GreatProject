package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;

public class ChannelInfo implements Serializable{
/**
	 * 
	 */
	private static final long serialVersionUID = 29171992153309561L;
private String channel;
private String duns;
private int count;
public String getChannel() {
	return channel;
}
public void setChannel(String channel) {
	this.channel = channel;
}
public String getDuns() {
	return duns;
}
public void setDuns(String duns) {
	this.duns = duns;
}
public int getCount() {
	return count;
}
public void setCount(int count) {
	this.count = count;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((channel == null) ? 0 : channel.hashCode());
	result = prime * result + ((duns == null) ? 0 : duns.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	ChannelInfo other = (ChannelInfo) obj;
	if (channel == null) {
		if (other.channel != null)
			return false;
	} else if (!channel.equals(other.channel))
		return false;
	if (duns == null) {
		if (other.duns != null)
			return false;
	} else if (!duns.equals(other.duns))
		return false;
	return true;
}
@Override
public String toString() {
	return "ChannelInfo [channel=" + channel + ", duns=" + duns + ", count=" + count + "]";
}



}
