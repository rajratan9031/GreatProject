package com.ge.fpt.welcomepkg.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MultivaluedMap;

import com.ge.fpt.welcomepkg.api.PartDataComponents;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;

public class PartsComponentDetailsImpl implements IPartsComponentDetails{
	@SuppressWarnings("javadoc")
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory.getLogger(BomsPersistenceImpl.class);

	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;

	/**
	 * Data source for the JDBC
	 */
	DataSource dataSource;

	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;

	NamedParameterJdbcTemplate namedParamTemplate;

	/**
	 * @return the dataSource
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}

	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate = new NamedParameterJdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	public List<PartDataComponents> getComponentDetailsForPart(HashMap partData){

		//changed sqt_part_info_t to sqt_part_info_t_master
		String sql= "select max(b.description) as description,max(b.spares_indicator)as spares_indicator, a.component_item_number as component_number,a.quantity quantity, "+
				"a.valve_indicator as valve_indicator , a.parent_item_number as parent_item_number, "+
				"(select max(description) from fptods.sqt_part_info_t_master  where item_number = ?) as parent_part_description from DDSAFM.ods_subassembly_bom_t a inner join fptods.sqt_part_info_t_master b "+ 
				"on component_item_number =item_number  where parent_item_number = ? "+
				"group by a.component_item_number,a.quantity,a.valve_indicator,a.parent_item_number";
		List<PartDataComponents> partDataComponents=this.jdbcTemplate.query(sql, new Object[] {partData.get("partNumber"),partData.get("partNumber") },
				new ComponentDetailsForPartMapper());
		return partDataComponents;
	}

	public List getcomponentDesc(HashMap partAndComponentData){

		String sql= "select b.description as description from ddsafm.sqt_part_info_t b "+ 
				"where rownum =1 and item_number = '"+partAndComponentData.get("componentID")+"' ";
		List description=this.jdbcTemplate.queryForList(sql);
		return description;
	}

	public StatusInfo savePartDataComponents(List<PartDataComponents> partData){
		StatusInfo statusinfo= new StatusInfo();
		try{
			for(int i = 0;i<partData.size();i++){
				String sql= "select count(*) from ddsafm.ods_subassembly_bom_t where parent_item_number= ? and component_item_number = ?";
				String saveSql="";
				int count=this.jdbcTemplate.queryForInt(sql, new Object[]{partData.get(i).getPartId(),partData.get(i).getComponentId()});

				if(count>0){
					saveSql="update ddsafm.ods_subassembly_bom_t set parent_item_number=?,component_item_number=?,quantity=?,valve_indicator=? "+
							" where parent_item_number=? and component_item_number = ?" ; 

					Object[] param={
							partData.get(i).getPartId(),
							partData.get(i).getComponentId(),
							partData.get(i).getQuantity(),
							partData.get(i).getValveIndicator(),
							partData.get(i).getPartId(),
							partData.get(i).getComponentId()
					};
					this.jdbcTemplate.update(saveSql, param);
				}else{
					saveSql= "insert into ddsafm.ods_subassembly_bom_t(parent_item_number,component_item_number,quantity,valve_indicator) "+
							"values (?,?,?,?)";
					Object[] param={
							partData.get(i).getPartId(),
							partData.get(i).getComponentId(),
							partData.get(i).getQuantity(),
							partData.get(i).getValveIndicator()
					};
					this.jdbcTemplate.update(saveSql, param);
				}
			}
		}catch(Exception e){
			statusinfo.setStatusCode(1);
			statusinfo.setStatusMessage("An error occured while saving data");
			return statusinfo;
		}

		statusinfo.setStatusCode(0);
		statusinfo.setStatusMessage("Data saved Successfully");
		return statusinfo;
	}

	@SuppressWarnings("nls")
	@Override
	public StatusInfo getAssemblyDataToUpload(HashMap getCompleteData){
		StatusInfo result = new StatusInfo();
		List<List<String>> getCompleteExcelData = (List<List<String>>) getCompleteData.get("getExcelData");
		String ssoID = (String) getCompleteData.get("sso_id");

		String sqlCheckAdmin="select Att5 from FPTODS.SQT_CHANNEL_SETTINGS where USER_NAME=?";

		String isEnggAdmin= this.jdbcTemplate.queryForObject(sqlCheckAdmin, new Object[]{ssoID}, String.class);
		logger.info("rows count :"+ getCompleteExcelData.size() );
		List<Object[]> components=new ArrayList<>();
		List<Object[]> parameters = new ArrayList<Object[]>();
		int successCount=0;
		String sqlMasterCount="select  count(*) from fptods.sqt_part_info_t_master where item_number=? ";
		String sql= "select count(*) from ddsafm.ods_subassembly_bom_t where parent_item_number = ? and component_item_number = ?";
		String Query = "Insert into ddsafm.ods_subassembly_bom_t(parent_item_number,component_item_number,quantity,valve_indicator ) "+
				"values(?,?,?,?)";
		try{
			if(isEnggAdmin !=null && isEnggAdmin.equalsIgnoreCase("Y")){

				if(getCompleteExcelData.size() > 1){
					for(int i=1;i<getCompleteExcelData.size();i++){
						
						//check if it is present in master table
					    int masterCount=this.jdbcTemplate.queryForInt(sqlMasterCount, new Object[]{getCompleteExcelData.get(i).get(1)});		
					    if(masterCount==0){
							logger.info(getCompleteExcelData.get(i).get(1)+" is not in the master part list. Please load the part by going to admin�part management screen.");
							Object[] componentNumbers={getCompleteExcelData.get(i).get(0),getCompleteExcelData.get(i).get(1),getCompleteExcelData.get(i).get(2),getCompleteExcelData.get(i).get(3)};
							components.add(componentNumbers);
						}
					    else{
						int count=this.jdbcTemplate.queryForInt(sql, new Object[]{getCompleteExcelData.get(i).get(0),getCompleteExcelData.get(i).get(1)});
						successCount++;
						if(count==0 && !(getCompleteExcelData.get(i).get(0).equals("")) && getCompleteExcelData.get(i).get(0)!=null && !(getCompleteExcelData.get(i).get(1).equals(""))
								  && getCompleteExcelData.get(i).get(1)!=null && getCompleteExcelData.get(i).get(2)!=null){
							
							logger.info("insertion done :" +i);
							Object[]  params = new Object[] {getCompleteExcelData.get(i).get(0),getCompleteExcelData.get(i).get(1),
									getCompleteExcelData.get(i).get(2),getCompleteExcelData.get(i).get(3)};
							parameters.add(params);
							//this.jdbcTemplate.update(Query,params);
						}
					    }
					}
					logger.info("insertion start time");
					this.jdbcTemplate.batchUpdate(Query, parameters);
					logger.info("insertion end time");
					
					if(components.size()>0 && successCount>0){
					result.setStatusCode(3);
					logger.info("STATUS CODE :"+ result.getStatusCode());
					result.setData(components);
					result.setSuccessCount(successCount);
					logger.info("Number of components which are not present in master part tables :"+ components.size());
					logger.info("Number of components which are successfully uploaded :"+ result.getSuccessCount());
					result.setStatusMessage("The downloaded parts do not exist in Parts Master. Please add them through Parts Management screen in the Admin section.");
					}
					if(components.size()==0){
						result.setStatusCode(0);
						logger.info("STATUS CODE :"+ result.getStatusCode());
						result.setData(parameters);
						logger.info("data length : "+ result.getData().size());
						result.setStatusMessage("File Uploaded successfully.");	
						result.setSuccessCount(successCount);
					}
				}else{
					result.setStatusCode(1);
					logger.info("STATUS CODE :"+ result.getStatusCode());
					result.setStatusMessage("No Data found in excel to upload.");
				}
			}else{
				result.setStatusCode(2);
				logger.info("STATUS CODE :"+ result.getStatusCode());
				result.setStatusMessage("Unauthorized user.");
			}

		}catch(Exception ex){
			logger.info("File Upload Data Insertion Exception :: "+ex);
			result.setStatusCode(-1);
			logger.info("STATUS CODE :"+ result.getStatusCode());
			result.setStatusMessage(ex.getMessage());
		}
		return result;
	}


	public StatusInfo digitalDataUpload(InputStream file,HttpHeaders httpHeaders) {

		/*	logger.error("Step 1 digitalDataUpload");
		MultivaluedMap<String, String> headers=httpHeaders.getRequestHeaders();*/
		StatusInfo info= new StatusInfo();
		/*List<String> fileNameList=headers.get("fileDetails");
		String fileName=fileNameList.get(0);
		logger.error("Step 2 digitalDataUpload");
		File fileToSave = new File ("\\\\10.229.192.4\\Storage\\ImageData\\WPDigitalUpload\\"+fileName);
		try {
			FileOutputStream saveFile = new FileOutputStream(fileToSave);	
			saveFile.write(file.read());
			logger.error("Step 3 digitalDataUpload");
			info.setStatusCode(0);
		} catch (IOException e) {
			info.setStatusCode(3);
			e.printStackTrace();
			logger.error("File Upload Data error" + e.getMessage());
		}*/



		/*String user = "user:password";
		NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication(user);
		String path = "smb://my_machine_name/D/MyDev/test.txt";
		SmbFile sFile = new SmbFile(path, auth);
		SmbFileOutputStream sfos = new SmbFileOutputStream(sFile);
		sfos.write("Test".getBytes());
		sfos.close();
		 */


		/*MultivaluedMap<String, String> headers=httpHeaders.getRequestHeaders();
		List<String> fileNameList=headers.get("fileDetails");
		String fileName=fileNameList.get(0);
		logger.error("File Upload Data Step 1"+fileName);
		try {
			logger.error("File Upload Data File Read"+file.read());
			FTPClient ftpClient = new FTPClient();
			ftpClient.connect("\\\\10.229.192.4\\Storage\\", 21);
			ftpClient.login("ccuser", "O6YmciuzgLVT1Zs");
			ftpClient.enterLocalPassiveMode();
			InputStream inputStream = file;
			String remoteFilePath=fileUpLoadLink;
		    try {
		        ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
		        logger.error("File Upload Data Step 2 Before Store");
		        boolean checkFileUpload= ftpClient.storeFile(remoteFilePath, inputStream);
		        logger.error("File Upload Data Step 2 Afer Store");
		        if(checkFileUpload){
		        	info.setStatusCode(0);
		        } else {
		        	info.setStatusCode(3);
		        }
		    } finally {
		        inputStream.close();
		    }	
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("File Upload Data error" + e.getMessage());
		}*/
		return info;	
	}		


	private static final class ComponentDetailsForPartMapper implements RowMapper<PartDataComponents> {
		public ComponentDetailsForPartMapper() {
		}

		@Override
		public PartDataComponents mapRow(ResultSet rs, int rowNum) throws SQLException {
			PartDataComponents result = new PartDataComponents();
			result.setPartId(rs.getString("parent_item_number"));
			result.setPartDescription(rs.getString("parent_part_description"));
			result.setComponentId(rs.getString("component_number"));
			result.setComponentDesc(rs.getString("description"));
			result.setQuantity(rs.getString("quantity"));
			result.setValveIndicator(rs.getString("valve_indicator"));
			result.setSpareIndicator(rs.getString("spares_indicator"));

			return result;
		}
	}

	public StatusInfo deleteKitComponent(String sso, String partNo){
		StatusInfo result= new StatusInfo();
		try{
			String sqlSelect="select * from DDSAFM.ods_subassembly_bom_t where parent_item_number=?";
			String insertsql="insert into ddsafm.ods_subassem_bom_t_delete_part (parent_item_number,component_item_number,quantity,valve_indicator,created_by,created_date) values (?,?,?,?,?,sysdate) ";
			List<Map<String, Object>> data= this.jdbcTemplate.queryForList(sqlSelect, new Object[]{partNo});
			for(Map<String, Object> map :data){
				this.jdbcTemplate.update(insertsql,new Object[]{map.get("parent_item_number"),map.get("component_item_number"),map.get("quantity"),map.get("valve_indicator"),sso});	
			}
			String sql="Delete from DDSAFM.ods_subassembly_bom_t where parent_item_number=?";
			this.jdbcTemplate.update(sql, new Object[]{partNo});
			result.setStatusCode(0);
			result.setStatusMessage("Deleted Successfully!!");
			return result;
		}catch (Exception e){
			result.setStatusCode(-1);
			result.setStatusMessage("Error occurred while deleted..");
			return result;
		}

	}

	public StatusInfo saveFilePath(String serialNumber, String recSource, String fileName, String filePath) {
		StatusInfo statusinfo = new StatusInfo();
		try {
			
			String saveSql = "insert into FPTODS.IMAGE_DATA(FILE_NAME,FILE_PATH,REC_SOURCE,SERIAL_NUMBER)values (?,?,?,?)";
			Object[] param = {serialNumber, filePath, recSource, serialNumber};
			this.jdbcTemplate.update(saveSql, param);	
			
			

			String getFileNames="select FILE_PATH from FPTODS.IMAGE_DATA where SERIAL_NUMBER = "+"'"+serialNumber+"'"+"and REC_SOURCE ="+"'"+recSource+"'";
			List<String> allFiles = this.jdbcTemplate.queryForList(getFileNames, String.class); 
			StringBuilder sb= new StringBuilder();
			String infFilePath="";
			
			if(allFiles.size()>0){
				boolean flag=false;
				for(String s:allFiles){
					if(!s.equals(filePath)){
						sb.append(s+";");
					} else {
						flag=true;
					}
				}
				if(flag){
					sb.append(filePath);
				}
				infFilePath	=sb.toString();
			} else {			
				infFilePath=filePath;
			}
				
			logger.error("FileName"+fileName+"FilePath"+infFilePath+"SerialNumber"+serialNumber+"RecSource"+recSource);
			
		//	String f_name=fileName!= null && fileName.lastIndexOf(".") > 0 ? fileName.substring(0, fileName.lastIndexOf(".")) : fileName;
			
			String saveSalesOrdersInf="update FPTODS.ODS_SQT_BY_SALES_ORDER_E_MV set FILE_NAME=?,FILE_PATH=?,F_NAME=?"+
					" where SERIAL_NUMBER = ? and REC_SOURCE = ?" ;	
			Object[] paramInf={
					serialNumber,
					infFilePath,
					serialNumber.replaceAll("[^a-zA-Z0-9]", ""),
					serialNumber,
					recSource	
			};
			this.jdbcTemplate.update(saveSalesOrdersInf, paramInf);	
			statusinfo.setStatusCode(1);
			statusinfo.setStatusMessage("Data saved Successfully");
		} catch (Exception e) {
			logger.error("Error occurred while updating filePath..." + e.getMessage());
			statusinfo.setStatusCode(-1);
			statusinfo.setStatusMessage("Error occurred while updating filePath...");
		}
		return statusinfo;
	}

	@Override
	public StatusInfo getSerialExcelDataToPersist(HashMap excelData) {
		logger.error("Inside the getSerialExcelDataPersist");
		StatusInfo result = new StatusInfo();
		List<List<String>> getSerialExcelData = (List<List<String>>) excelData.get("serialFileData");
		List<List<String>> getBomFileDataExcelData = (List<List<String>>) excelData.get("bomFileData");
		String ssoID = (String) excelData.get("sso_id");			
		String orderLineId="";
		return result;
	}
	
	public int getFileImageDataCount(String serialNumber ){
		String sql= "Select count(FILE_NAME) from FPTODS.IMAGE_DATA where Serial_number=?";
		int count=this.jdbcTemplate.queryForInt(sql, new Object[]{serialNumber});
		return count ; 
	}

}
