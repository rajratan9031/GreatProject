package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.List;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class PriceToolSearchCriteria implements Serializable {
	private static final long serialVersionUID = 845999363270302935L;
	private String currency;
	private String region;
	private List<String> partNumber;

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getRegion() {
		return this.region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public List<String> getPartNumber() {
		return this.partNumber;
	}

	public void setPartNumber(List<String> partNumber) {
		this.partNumber = partNumber;
	}
}
