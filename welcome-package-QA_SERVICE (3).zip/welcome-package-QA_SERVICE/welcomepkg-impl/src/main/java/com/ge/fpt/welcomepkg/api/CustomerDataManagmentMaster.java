package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.Date;

public class CustomerDataManagmentMaster implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String custId="";
	private String customerId;
	private String customerName;
	private String country;
	private String isActive;
	private String region;
	private String dunsNumber;
	private Date createdDate;
	private Date updatedDate;
	private String updatedBy;
	private String createdBy;
	private String euIndustry;
	private String eucountry;
	private String euState;
	private String euCity;
	
	@Override
	public String toString() {
		return "CustomerDataManagmentMaster [custId=" + custId + ", customerId=" + customerId + ", customerName="
				+ customerName + ", country=" + country + ", isActive=" + isActive + ", region=" + region
				+ ", dunsNumber=" + dunsNumber + ", createdDate=" + createdDate + ", updatedDate=" + updatedDate
				+ ", updatedBy=" + updatedBy + ", createdBy=" + createdBy + ", euIndustry=" + euIndustry
				+ ", eucountry=" + eucountry + ", euState=" + euState + ", euCity=" + euCity + ", euPostalCode="
				+ euPostalCode + "]";
	}




	public CustomerDataManagmentMaster(String custId, String customerId, String customerName, String country,
			String isActive, String region, String dunsNumber, Date createdDate, Date updatedDate, String updatedBy,
			String createdBy, String euIndustry, String eucountry, String euState, String euCity, String euPostalCode) {
		super();
		this.custId = custId;
		this.customerId = customerId;
		this.customerName = customerName;
		this.country = country;
		this.isActive = isActive;
		this.region = region;
		this.dunsNumber = dunsNumber;
		this.createdDate = createdDate;
		this.updatedDate = updatedDate;
		this.updatedBy = updatedBy;
		this.createdBy = createdBy;
		this.euIndustry = euIndustry;
		this.eucountry = eucountry;
		this.euState = euState;
		this.euCity = euCity;
		this.euPostalCode = euPostalCode;
	}




	public String getEuIndustry() {
		return euIndustry;
	}




	public void setEuIndustry(String euIndustry) {
		this.euIndustry = euIndustry;
	}




	public String getEucountry() {
		return eucountry;
	}




	public void setEucountry(String eucountry) {
		this.eucountry = eucountry;
	}




	public String getEuState() {
		return euState;
	}




	public void setEuState(String euState) {
		this.euState = euState;
	}




	public String getEuCity() {
		return euCity;
	}




	public void setEuCity(String euCity) {
		this.euCity = euCity;
	}




	public String getEuPostalCode() {
		return euPostalCode;
	}




	public void setEuPostalCode(String euPostalCode) {
		this.euPostalCode = euPostalCode;
	}


	private String euPostalCode;
	


	
	
	public CustomerDataManagmentMaster() {
		super();
		// TODO Auto-generated constructor stub
	}




	public CustomerDataManagmentMaster(String custId, String customerId, String customerName, String country,
			String isActive, String region, String dunsNumber, Date createdDate, Date updatedDate, String updatedBy,
			String createdBy, String industry, String state, String city, String postalCode) {
		super();
		this.custId = custId;
		this.customerName = customerName;
		this.country = country;
		this.isActive = isActive;
		this.region = region;
		this.dunsNumber = dunsNumber;
		this.createdDate = createdDate;
		this.updatedDate = updatedDate;
		this.updatedBy = updatedBy;
		this.createdBy = createdBy;
	
	}











	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}


	public String getDunsNumber() {
		return dunsNumber;
	}


	public void setDunsNumber(String dunsNumber) {
		this.dunsNumber = dunsNumber;
	}


	public Date getCreatedDate() {
		return createdDate;
	}


	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}


	public Date getUpdatedDate() {
		return updatedDate;
	}


	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}


	public String getUpdatedBy() {
		return updatedBy;
	}


	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}


	public String getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
















	

}
