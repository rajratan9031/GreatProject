package com.ge.fpt.welcomepkg.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.fpt.welcomepkg.api.PriceToolUser;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;

public class PriceToolUserPersistenceImpl implements IpriceToolUserPersistence {
	private static final Logger logger = WelcomePackageLoggerFactory
			.getLogger(PriceToolUserPersistenceImpl.class);
	JdbcTemplate jdbcTemplate;
	DataSource dataSource;
	PlatformTransactionManager txManager;

	public DataSource getDataSource() {
		return this.dataSource;
	}

	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
	}

	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ge.fpt.welcomepkg.persistence.IpriceToolUserPersistence#getPriceToolUser
	 * ()
	 */
	@Override
	public List<PriceToolUser> getPriceToolUser() {

		String sql = "select  distinct a.sso,a.pl_region,a.createdBy,a.createdDate,a.UpdatedBy,a.updatedDate,b.region_name as regionName from fptOds.SQT_PriceTool_User a "
				+ "left  join fptods.sqt_price_logic b on a.pl_region=b.region";
		return this.jdbcTemplate.query(sql, new PriceToolUserMapper());
	}

	public static final class PriceToolUserMapper implements
			RowMapper<PriceToolUser> {
		public PriceToolUser mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			PriceToolUser result = new PriceToolUser();
			result.setSso(rs.getString("sso"));
			result.setRegion(rs.getString("pl_region"));
			result.setCreatedBy(rs.getString("createdBy"));
			result.setUpdatedBy(rs.getString("updatedBy"));
			result.setCreatedDate(rs.getDate("createdDate"));
			result.setUpdatedDate(rs.getDate("updatedDate"));
			result.setRegionName(rs.getString("regionName"));
			return result;
		}
	}

	public StatusInfo savePriceToolUser(String user, PriceToolUser priceToolUser) {
		StatusInfo statusInfo=new StatusInfo();
		String sso = priceToolUser.getSso();
		String region = priceToolUser.getRegion();
		String oldRegion=priceToolUser.getOldRegion();
		int count =0;
		String sqlCount = "select count(*) as userCount from fptods.SQT_PriceTool_User where 1=1 "
				+ " and  sso= ? and pl_region=? ";
		if(oldRegion!=null && !oldRegion.equalsIgnoreCase("")){
		 count = this.jdbcTemplate.queryForInt(sqlCount, new Object[] { sso,
				oldRegion });
		}else{
			 count = this.jdbcTemplate.queryForInt(sqlCount, new Object[] { sso,
					region });
		}
		if (count > 0) {
			String sqlDelete = "delete from  fptods.SQT_PriceTool_User where 1=1 "
					+ "and  sso= ? and pl_region=?";
			if(oldRegion!=null && !oldRegion.equalsIgnoreCase("")){
			this.jdbcTemplate.update(sqlDelete, new Object[] { sso, oldRegion });
			}else{
				this.jdbcTemplate.update(sqlDelete, new Object[] { sso, region });	
			}
		}
		String sqlInsert = "insert into fptods.SQT_PriceTool_User (sso,pl_region,createdby,updatedby,createddate,updatedDate) "
				+ "values(?,?,?,?,sysdate,sysdate)";
		this.jdbcTemplate.update(sqlInsert, new Object[] { sso, region, user,
				user });

		statusInfo.setStatusCode(0);
		statusInfo.setStatusMessage("Data Saved Successfully!!");
		return statusInfo;
	}

	public StatusInfo deletePriceToolUser(PriceToolUser priceToolUser) {
		StatusInfo statusInfo=new StatusInfo();
		String sso = priceToolUser.getSso();
		String region = priceToolUser.getRegion();
		String sqlDelete = "delete from  fptods.SQT_PriceTool_User where 1=1 "
				+ "and  sso= ? and pl_region=?";
		this.jdbcTemplate.update(sqlDelete, new Object[] { sso, region });
		statusInfo.setStatusCode(0);
		statusInfo.setStatusMessage("Data Deleted Successfully!!");
		return statusInfo;

	}
}
