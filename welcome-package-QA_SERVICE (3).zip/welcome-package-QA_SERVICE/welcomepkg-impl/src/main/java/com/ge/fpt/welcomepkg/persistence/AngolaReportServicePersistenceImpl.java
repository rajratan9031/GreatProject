package com.ge.fpt.welcomepkg.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.fpt.welcomepkg.api.AngolaReportData;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;
import com.ge.fpt.welcomepkg.util.SPIRAngolaReportUtil;

public class AngolaReportServicePersistenceImpl implements IAngolaReportServicePersistence {

	@SuppressWarnings("javadoc")
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory.getLogger(ReportServicePersistenceImpl.class);

	//static final int SQL_RETURN_RECORD_LIMIT = 25;


	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;

	/**
	 * Data source for the JDBC
	 */
	DataSource dataSource;

	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;
	
	NamedParameterJdbcTemplate namedParamTemplate;

	/**
	 * @return the dataSource
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}

	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate= new NamedParameterJdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}
	
	
	public byte[] generateExcelReportForAngola(Map reportParam,String sso){
		
		byte[] result = null;
		SPIRAngolaReportUtil angoleUtilObject = new SPIRAngolaReportUtil();
		
		List<AngolaReportData> allReportData=null;
		
	    String sql="";
	    MapSqlParameterSource paramMap = new MapSqlParameterSource();
	    sql="select * from DDSAFM.ODS_SQT_ANGOLA_SPIR_REPORT_V where user_name = ?";
	   try{
			allReportData = this.jdbcTemplate.query(sql, new Object[] {sso},
					new ReportMapper());
		}catch(Exception e){
			logger.info("Exception when running query: " + e);
		}
		return angoleUtilObject.initiateReportPreparation(allReportData);
		
	}
	
	public static final class ReportMapper implements RowMapper<AngolaReportData>
	{
		public ReportMapper() {
		}

		@Override
	    public AngolaReportData mapRow(ResultSet rs, int rowNum) throws SQLException
	    {
	      AngolaReportData result = new AngolaReportData();
	      
		  result.setEquipmentNumber(rs.getString("equipment_no"));
		  result.setInsuranceOrWear(rs.getString("insurance_or_wear"));
		  result.setManufacturerModelNumber(rs.getString("manf_model_no"));
		  result.setManufacturerSerialNumber(rs.getString("manufacturer_serial_no"));
		  result.setMaterialSpec(rs.getString("material_spec"));
		  result.setPartDescription(rs.getString("part_description"));
		  result.setPartNumber(rs.getString("part_no"));
		  result.setSalesOrder(rs.getString("sales_order"));
		  result.setSectionalDrawingNumber(rs.getString("sectional_drawing_no"));
		  result.setSheepmentInWeeks(rs.getString("shipment_in_weeks"));
		  result.setQuantity(rs.getInt("quantity"));
		  result.setRecommendedQty(rs.getInt("recommended_qty"));
		  result.setUnitPriceInUSD(rs.getDouble("unit_price_in_usd"));
		  result.setUserName(rs.getString("user_name"));
		  result.setDefaultPercent(rs.getDouble("default_percent"));
		  result.setCurrency(rs.getString("currency"));
		  result.setBubbleCode(rs.getString("bubble_code")!=null?rs.getString("bubble_code"):"");
	      return result;
	    }
	}
}
