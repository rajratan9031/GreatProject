package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.sql.Date;

public class CartData implements Serializable{
	
	private static final long serialVersionUID = 9031248384674352876L;
	
	
	private String cartName;
	private String sso;
	private Long valveInfoId;
	private Long orderLineId;
	private String recSource;
	private String serialNumber;
	private String tagNumber;
	private String itemNumber;
	private String description;
	private String productModel;
	private String productCode;
	private String salesOrder;
	private Date dateSaved;
	private Date dateATT1;
	private Date dateATT2;
	private String istore_Status;
	public String getSso() {
		return sso;
	}
	public void setSso(String sso) {
		this.sso = sso;
	}
	public String getCartName() {
		return cartName;
	}
	public void setCartName(String cartName) {
		this.cartName = cartName;
	}
	public Long getValveInfoId() {
		return valveInfoId;
	}
	public void setValveInfoId(Long valveInfoId) {
		this.valveInfoId = valveInfoId;
	}
	public Long getOrderLineId() {
		return orderLineId;
	}
	public void setOrderLineId(Long orderLineId) {
		this.orderLineId = orderLineId;
	}
	public String getRecSource() {
		return recSource;
	}
	public void setRecSource(String recSource) {
		this.recSource = recSource;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getTagNumber() {
		return tagNumber;
	}
	public void setTagNumber(String tagNumber) {
		this.tagNumber = tagNumber;
	}
	public String getItemNumber() {
		return itemNumber;
	}
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getProductModel() {
		return productModel;
	}
	public void setProductModel(String productModel) {
		this.productModel = productModel;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getSalesOrder() {
		return salesOrder;
	}
	public void setSalesOrder(String salesOrder) {
		this.salesOrder = salesOrder;
	}
	public Date getDateSaved() {
		return dateSaved;
	}
	public void setDateSaved(Date dateSaved) {
		this.dateSaved = dateSaved;
	}
	public Date getDateATT1() {
		return dateATT1;
	}
	public void setDateATT1(Date dateATT1) {
		this.dateATT1 = dateATT1;
	}
	public Date getDateATT2() {
		return dateATT2;
	}
	public void setDateATT2(Date dateATT2) {
		this.dateATT2 = dateATT2;
	}
	public String getIstore_Status() {
		return istore_Status;
	}
	public void setIstore_Status(String istore_Status) {
		this.istore_Status = istore_Status;
	}
	public CartData() {
		super();
	}
	public CartData(String sso, String cartName, Long valveInfoId, Long orderLineId, String recSource,
			String serialNumber, String tagNumber, String itemNumber, String description, String productModel,
			String productCode, String salesOrder, Date dateSaved, Date dateATT1, Date dateATT2, String istore_Status) {
		super();
		this.sso = sso;
		this.cartName = cartName;
		this.valveInfoId = valveInfoId;
		this.orderLineId = orderLineId;
		this.recSource = recSource;
		this.serialNumber = serialNumber;
		this.tagNumber = tagNumber;
		this.itemNumber = itemNumber;
		this.description = description;
		this.productModel = productModel;
		this.productCode = productCode;
		this.salesOrder = salesOrder;
		this.dateSaved = dateSaved;
		this.dateATT1 = dateATT1;
		this.dateATT2 = dateATT2;
		this.istore_Status = istore_Status;
	}



}
