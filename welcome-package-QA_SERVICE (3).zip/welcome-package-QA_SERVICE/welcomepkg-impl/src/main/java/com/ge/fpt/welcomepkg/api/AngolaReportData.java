package com.ge.fpt.welcomepkg.api;


public class AngolaReportData {

	private static final long serialVersionUID = 2269913721114321250L;
	
	private String equipmentNumber;
	private String manufacturerModelNumber;
	private String manufacturerSerialNumber;
	private String partNumber;
	private String partDescription;
	private String sectionalDrawingNumber;
	private String materialSpec;
	private String insuranceOrWear;
	private String salesOrder;
	private String sheepmentInWeeks;
	private double unitPriceInUSD;
	private int quantity;
	private int recommendedQty;
	private String userName;
	private double defaultPercent;
	private String currency;
	private String bubbleCode;
	
	
	public String getBubbleCode() {
		return bubbleCode;
	}
	public void setBubbleCode(String bubbleCode) {
		this.bubbleCode = bubbleCode;
	}
	public String getEquipmentNumber() {
		 return equipmentNumber;
	}
	public void setEquipmentNumber(String equipmentNumber) {
		this.equipmentNumber = equipmentNumber;
	}
	public String getManufacturerModelNumber() {
		return manufacturerModelNumber;
	}
	public void setManufacturerModelNumber(String manufacturerModelNumber) {
		this.manufacturerModelNumber = manufacturerModelNumber;
	}
	public String getManufacturerSerialNumber() {
		return manufacturerSerialNumber;
	}
	public void setManufacturerSerialNumber(String manufacturerSerialNumber) {
		this.manufacturerSerialNumber = manufacturerSerialNumber;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getPartDescription() {
		return partDescription;
	}
	public void setPartDescription(String partDescription) {
		this.partDescription = partDescription;
	}
	public String getSectionalDrawingNumber() {
		return sectionalDrawingNumber;
	}
	public void setSectionalDrawingNumber(String sectionalDrawingNumber) {
		this.sectionalDrawingNumber = sectionalDrawingNumber;
	}
	public String getMaterialSpec() {
		return materialSpec;
	}
	public void setMaterialSpec(String materialSpec) {
		this.materialSpec = materialSpec;
	}
	public String getInsuranceOrWear() {
		return insuranceOrWear;
	}
	public void setInsuranceOrWear(String insuranceOrWear) {
		this.insuranceOrWear = insuranceOrWear;
	}
	public String getSalesOrder() {
		return salesOrder;
	}
	public void setSalesOrder(String salesOrder) {
		this.salesOrder = salesOrder;
	}
	public String getSheepmentInWeeks() {
		return sheepmentInWeeks;
	}
	public void setSheepmentInWeeks(String sheepmentInWeeks) {
		this.sheepmentInWeeks = sheepmentInWeeks;
	}
	public double getUnitPriceInUSD() {
		return unitPriceInUSD;
	}
	public void setUnitPriceInUSD(double unitPriceInUSD) {
		this.unitPriceInUSD = unitPriceInUSD;
	}
	public int getRecommendedQty() {
		return recommendedQty;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public void setRecommendedQty(int recommendedQty) {
		this.recommendedQty = recommendedQty;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public double getDefaultPercent() {
		return defaultPercent;
	}
	public void setDefaultPercent(double defaultPercent) {
		this.defaultPercent = defaultPercent;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	
	public AngolaReportData() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public AngolaReportData(String equipmentNumber, String manufacturerModelNumber, String manufacturerSerialNumber,
			String partNumber, String partDescription, String sectionalDrawingNumber, String materialSpec,
			String insuranceOrWear, String salesOrder, String sheepmentInWeeks, double unitPriceInUSD, int quantity,
			int recommendedQty, String userName, double defaultPercent, String currency, String bubbleCode) {
		super();
		this.equipmentNumber = equipmentNumber;
		this.manufacturerModelNumber = manufacturerModelNumber;
		this.manufacturerSerialNumber = manufacturerSerialNumber;
		this.partNumber = partNumber;
		this.partDescription = partDescription;
		this.sectionalDrawingNumber = sectionalDrawingNumber;
		this.materialSpec = materialSpec;
		this.insuranceOrWear = insuranceOrWear;
		this.salesOrder = salesOrder;
		this.sheepmentInWeeks = sheepmentInWeeks;
		this.unitPriceInUSD = unitPriceInUSD;
		this.quantity = quantity;
		this.recommendedQty = recommendedQty;
		this.userName = userName;
		this.defaultPercent = defaultPercent;
		this.currency = currency;
		this.bubbleCode = bubbleCode;
	}

	
	
}
