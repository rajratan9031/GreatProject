/*
 * Copyright (c) 2012 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.fpt.welcomepkg.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.InitializingBean;

import com.ge.dsp.dsi.config.ConfigurationException;
import com.ge.dsp.dsi.config.IConfigurationAware;
import com.ge.dsp.dsi.config.IConfigurationService;
import com.ge.dsp.dsi.config.IConfigurationServiceFactory;

/**
 * @author 212414241
 * 
 */

public class FPTODSConfiguration implements InitializingBean, IConfigurationAware {

	private static org.slf4j.Logger logger;
	private static FPTODSConfiguration instance;

	private IConfigurationServiceFactory configurationServiceFactory;
	private Map<Object, Object> dbconfig = new HashMap<Object, Object>();
	private Map<String, String> appconfig = new HashMap<String, String>();

	/**
	 * default constructor
	 */
	public FPTODSConfiguration() {
		instance = this;
	}

	/**
	 * @param configurationServiceFactory
	 *            the configurationServiceFactory to set
	 */
	public void setConfigurationServiceFactory(IConfigurationServiceFactory configurationServiceFactory) {
		this.configurationServiceFactory = configurationServiceFactory;
		this.configurationServiceFactory.registerConfigurationListener(this);
	}

	@SuppressWarnings("javadoc")
	public static synchronized FPTODSConfiguration getInstance() {
		logger.debug("DspConfiguration getInstance returning " + instance); //$NON-NLS-1$
		return instance;
	}

	/* Method from ConfigurationAware */

	@Override
	public void configUpdated(Map<String, String> configMap) {
		// TODO:
		// implement this callback method if the configuration is updated by
		// other threads
	}

	/**
	 * initialize WorkConfiguration after dependencies are injected.
	 */
	@Override
	@SuppressWarnings("nls")
	public void afterPropertiesSet() throws Exception {

		this.logger = WelcomePackageLoggerFactory.getLogger(FPTODSConfiguration.class);

		IConfigurationService configurationService = this.configurationServiceFactory.getConfigurationService();
		this.appconfig = configurationService.getConfiguration();
		
		if (this.appconfig.get(ConfigConstants.LOGGER_CATEGORY) != null) {
			WelcomePackageLoggerFactory.setLevel(ConfigConstants.LOGGER_CATEGORY,
					this.appconfig.get(ConfigConstants.LOGGER_CATEGORY));
			logger.trace("loglevel is set to:" + this.appconfig.get(ConfigConstants.LOGGER_CATEGORY));
		}

		logger.debug("configurationFile.keys" + this.appconfig.keySet().toString());
		this.dbconfig.put(ConfigConstants.DB_CONNPOOL_TYPE, this.appconfig.get(ConfigConstants.DB_CONNPOOL_TYPE));
		this.dbconfig.put(ConfigConstants.DB_CONNECTION_URL, this.appconfig.get(ConfigConstants.DB_CONNECTION_URL));
		this.dbconfig.put(ConfigConstants.DB_CONNECTION_DRIVER_NAME,
				this.appconfig.get(ConfigConstants.DB_CONNECTION_DRIVER_NAME));
		this.dbconfig.put(ConfigConstants.DB_CONNECTION_USER, this.appconfig.get(ConfigConstants.DB_CONNECTION_USER));
		this.dbconfig.put(ConfigConstants.DB_CONNECTION_PASSWORD,
				this.appconfig.get(ConfigConstants.DB_CONNECTION_PASSWORD));
		this.dbconfig.put(ConfigConstants.DB_POOL_INITIALSIZE, this.appconfig.get(ConfigConstants.DB_POOL_INITIALSIZE));
		this.dbconfig.put(ConfigConstants.DB_DBCP_MAX_ACTIVE, this.appconfig.get(ConfigConstants.DB_DBCP_MAX_ACTIVE));
		this.dbconfig.put(ConfigConstants.DB_DBCP_MAX_IDEL, this.appconfig.get(ConfigConstants.DB_DBCP_MAX_IDEL));
		this.dbconfig.put(ConfigConstants.DB_DBCP_MIN_IDEL, this.appconfig.get(ConfigConstants.DB_DBCP_MIN_IDEL));
		this.dbconfig.put(ConfigConstants.DB_DBCP_MAX_WAIT, this.appconfig.get(ConfigConstants.DB_DBCP_MAX_WAIT));
		this.dbconfig.put(ConfigConstants.DB_DBCP_VALIDATION_QUERY,
				this.appconfig.get(ConfigConstants.DB_DBCP_VALIDATION_QUERY));
	}

	/**
	 * @return the dbconfig
	 */
	public Map<Object, Object> getDbconfig() {
		return this.dbconfig;
	}

	/**
	 * @param dbconfig
	 *            the dbconfig to set
	 */
	public void setDbconfig(Map<Object, Object> dbconfig) {
		this.dbconfig = dbconfig;
	}

	/**
	 * Constants definition for configuration file
	 */
	@SuppressWarnings({ "javadoc", "nls" })
	public static class ConfigConstants {

		public static String DB_CONNECTION_DRIVER_NAME = "dsp.db.ConnectionDriverName";
		public static String DB_CONNECTION_URL = "dsp.db.ConnectionURL";
		public static String DB_CONNECTION_USER = "dsp.db.ConnectionUserName";
		public static String DB_CONNECTION_PASSWORD = "dsp.db.ConnectionPassword";
		public static String DB_POOL_INITIALSIZE = "dsp.db.pool.initialSize";
		public static String DB_DBCP_MAX_ACTIVE = "dsp.db.dbcp.maxActive";
		public static String DB_DBCP_MIN_IDEL = "dsp.db.dbcp.minIdle";
		public static String DB_DBCP_MAX_IDEL = "dsp.db.dbcp.maxIdle";
		public static String DB_DBCP_MAX_WAIT = "dsp.db.dbcp.maxWait";
		public static String DB_DBCP_VALIDATION_QUERY = "dsp.db.dbcp.validationQuery";
		public static String DB_CONNPOOL_TYPE = "dsp.db.connectionPoolingType";
		public static String LOGGER_CATEGORY = "com.ge.predix";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ge.dsp.dsi.config.IConfigurationAware#validateConfig(java.util.Map)
	 */
	@Override
	public void validateConfig(Map<String, String> configMap) throws ConfigurationException {
		// TODO:
		// implement the validation logic if configuration values is
		// changed by other thread before configuration property is saved
	}

}
