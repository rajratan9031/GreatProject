package com.ge.fpt.welcomepkg.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.fpt.welcomepkg.api.AlfrescoDocumentDetail;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;

public class AlfrescoDocumentPersistenceImpl implements IAlfrescoDocumentPersistence{

	
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory
			.getLogger(AlfrescoDocumentPersistenceImpl.class);

	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;

	/**
	 * Data source for the JDBC
	 */
	DataSource dataSource;

	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;

	NamedParameterJdbcTemplate namedParamTemplate;

	/**
	 * @return the dataSource
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}

	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate = new NamedParameterJdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	@Override
	public AlfrescoDocumentDetail getDocumentsBySerialNumber(String serialNumber) {
		logger.info("inside getDocuments");
		AlfrescoDocumentDetail docs = new AlfrescoDocumentDetail();
		try{
		String docQuery= "select * from fptods.SQT_ALFRESCO_SERIAL_NUMBER_T where SERIAL_NUMBER_SAP=:serialNumber";
		logger.info("serialNumber :"+serialNumber);
			if(serialNumber!=null){
				docs=this.jdbcTemplate.queryForObject(docQuery,new Object[]{serialNumber},
					new DocumentMapper());
				logger.info("result  :"+ docs.getFileName());
				return docs;
			}
			else{
				return null;
			}
		}
		catch(Exception ex){
			logger.info("Error## :"+ ex.toString());
		}
		return docs;
	}
	
	private static final class DocumentMapper implements RowMapper<AlfrescoDocumentDetail> {
		public DocumentMapper() {
		}

		@Override
		public AlfrescoDocumentDetail mapRow(ResultSet rs, int rowNum) throws SQLException {
			AlfrescoDocumentDetail result = new AlfrescoDocumentDetail();
			result.setSiteCode(rs.getString("SITE_CODE"));
			result.setTypeFlowProject(rs.getString("TYPE_FLOW_PROJECT"));
			result.setCategoryNuclearCommercial(rs.getString("CATEGORY_NUCLEAR_COMMERCIAL"));
			result.setSalesOrderNumber(rs.getString("SALES_ORDER_NUMBER"));
			result.setSalesOrderLineNumber(rs.getString("SALES_ORDER_LINE_NUMBER"));
			result.setProductionOrderNumber(rs.getString("PRODUCTION_ORDER_NUMBER"));
			result.setSerialNumber(rs.getString("SERIAL_NUMBER_SAP"));
			result.setDocumentType(rs.getString("DOCUMENT_TYPE"));
			result.setDocDesc(rs.getString("DOCUMENT_DESCRIPTION"));
			result.setFileName(rs.getString("FILE_NAME"));
			result.setFileLink(rs.getString("FILE_LINK"));
			
			logger.info("mapper :"+result.getFileName());
			return result;

		}
	}

	@Override
	public List<AlfrescoDocumentDetail> getAllDocDetails() {
		logger.info("inside getDocuments");
		List<AlfrescoDocumentDetail> docs = new ArrayList<>();
		try{
		String docQuery= "select * from fptods.SQT_ALFRESCO_SERIAL_NUMBER_T where SERIAL_NUMBER_SAP is not null";
				docs=this.jdbcTemplate.query(docQuery,new DocumentMapper());
				logger.info("result  :"+ docs.get(0).getFileName());
				return docs;
		}
		catch(Exception ex){
			logger.info("Error## :"+ ex.toString());
		}
		return docs;
	}

}
