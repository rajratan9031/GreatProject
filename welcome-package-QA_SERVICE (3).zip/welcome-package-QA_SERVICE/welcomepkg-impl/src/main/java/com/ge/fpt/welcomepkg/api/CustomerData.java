package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;

public class CustomerData implements Serializable{ 

	private static final long serialVersionUID = 1L;
	private String customerKey;
	private String customerName;
	private String endUserName;
	private String stationLocation;
	private String geLocation;
	private String country;
	private String stateName;
 
	public String getCustomerKey() {
		return customerKey;
	}

	public void setCustomerKey(String customerKey) {
		this.customerKey = customerKey;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEndUserName() {
		return endUserName;
	}

	public void setEndUserName(String endUserName) {
		this.endUserName = endUserName;
	}

	public String getStationLocation() {
		return stationLocation;
	}

	public void setStationLocation(String stationLocation) {
		this.stationLocation = stationLocation;
	}

	public String getGeLocation() {
		return geLocation;
	}

	public void setGeLocation(String geLocation) {
		this.geLocation = geLocation;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public CustomerData(){
		super();
	}

	public CustomerData(String customerKey, String customerName, String endUserName, String stationLocation, String geLocation,
			String country, String stateName) {
		super();
		this.customerKey=customerKey;
		this.customerName = customerName;
		this.endUserName = endUserName;
		this.stationLocation = stationLocation;
		this.geLocation = geLocation;
		this.country = country;
		this.stateName = stateName;
	}



}
