/**
 * 
 */
package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;



/**
 * @author 204060632
 *
 */
@XmlRootElement
public class UserSettings implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5275669817078558947L;

	/**
	 * 
	 */
	public UserSettings() {
		// TODO Auto-generated constructor stub
	}

	private String business;
	private String pl;
	private String region;
	private String brand;
	private String currency;
	private String dateRange;
	private Boolean emailMe;
	private Boolean isAdmin;
	private String interCompany;

	


	public Boolean getIsAdmin() {
		return isAdmin;
	}

	public void setIsAdmin(Boolean isAdmin) {
		this.isAdmin = isAdmin;
	}

	/**
	 * @return the business
	 */
	public String getBusiness() {
		return business;
	}

	/**
	 * @param business the business to set
	 */
	public void setBusiness(String business) {
		this.business = business;
	}

	/**
	 * @return the pl
	 */
	public String getPl() {
		return pl;
	}

	/**
	 * @param pl the pl to set
	 */
	public void setPl(String pl) {
		this.pl = pl;
	}

	/**
	 * @return the region
	 */
	public String getRegion() {
		return region;
	}

	/**
	 * @param region the region to set
	 */
	public void setRegion(String region) {
		this.region = region;
	}

	/**
	 * @return the brand
	 */
	public String getBrand() {
		return brand;
	}

	/**
	 * @param brand the brand to set
	 */
	public void setBrand(String brand) {
		this.brand = brand;
	}

	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}

	/**
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * @return the dateRange
	 */
	public String getDateRange() {
		return dateRange;
	}

	/**
	 * @param dateRange the dateRange to set
	 */
	public void setDateRange(String dateRange) {
		this.dateRange = dateRange;
	}

	/**
	 * @return the emailMe
	 */
	public Boolean getEmailMe() {
		return emailMe;
	}

	/**
	 * @param emailMe the emailMe to set
	 */
	public void setEmailMe(Boolean emailMe) {
		this.emailMe = emailMe;
	}
	public String getInterCompany() {
		return interCompany;
	}

	public void setInterCompany(String interCompany) {
		this.interCompany = interCompany;
	}	
}
