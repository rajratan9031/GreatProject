package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;

public class RecipData implements Serializable{ 
private static final long serialVersionUID = 1L;
	
	public RecipData(){
		super();
	}
	
	private String shortEndUser;
	private String shortCustomerName;
	private String shortStationLocation;
	private String shortNotesFuturePlans;
	private String customerKey;
	private String productKey;
	private String managerKey;
	private String recordId;
	private String serialNumber;
	// new
	private String customerDunsNo;
	
	private String status;
	//new 
	private String utilization2017Current;
	private String utilization2018Projected;
	
	private String lastOverHaulDT;
	private String hrsAtLastOverHaul;
	private String nextOverHaulDT;
	private String partsProvider;
	private String fieldServiceProvider;
	// new 
	private String repairsProvider;
	
	
	private String marketSegment;
	private String noOfCyclinders;
	
	private String ratedBhp;
	private String turboCharged;
	private String serviceManager;
	private String thirdPartyPartsProvides;
	private String thirdPartyFldServProvider;
	private String thirdPartyRepairsProvides;
	
	private String notesFuturePlans;
	
	
	private String noOfActvComprsrThrows;
	private String turbochargerServiceProvider;
	
	// new
	
	
	
	private String plansToRepairReplace;
	
	private String retireDt;
	private String utilization2016HST;
	private String utilization2015HST;
	private String maintenancePratice;
	
	private String directInderct;
	
	
	
	private String accountManagerName;
	private String productName;
	private String unitType;
	private String productModel;
	private String customerName;
	private String endUserName;
	private String geRegion;
	private String country;
	private String stationLocation;
	private String usaStateName;
	private String county;
	private String selected;
	private String lastUpdateDate;
	
	// New additions
	private String turbochargerMake;
	private String turbochargerModel;
	private String designCode;
	
	

	
	
	public String getTurbochargerMake() {
		return turbochargerMake;
	}
	public void setTurbochargerMake(String turbochargerMake) {
		this.turbochargerMake = turbochargerMake;
	}
	public String getTurbochargerModel() {
		return turbochargerModel;
	}
	public void setTurbochargerModel(String turbochargerModel) {
		this.turbochargerModel = turbochargerModel;
	}
	public String getDesignCode() {
		return designCode;
	}
	public void setDesignCode(String designCode) {
		this.designCode = designCode;
	}
	public String getLastUpdateDate() {
		return lastUpdateDate;
	}
	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}
	public String getShortEndUser() {
		return shortEndUser;
	}
	public void setShortEndUser(String shortEndUser) {
		this.shortEndUser = shortEndUser;
	}
	public String getShortCustomerName() {
		return shortCustomerName;
	}
	public void setShortCustomerName(String shortCustomerName) {
		this.shortCustomerName = shortCustomerName;
	}
	public String getShortStationLocation() {
		return shortStationLocation;
	}
	public void setShortStationLocation(String shortStationLocation) {
		this.shortStationLocation = shortStationLocation;
	}
	public String getShortNotesFuturePlans() {
		return shortNotesFuturePlans;
	}
	public void setShortNotesFuturePlans(String shortNotesFuturePlans) {
		this.shortNotesFuturePlans = shortNotesFuturePlans;
	}
	public String getSelected() {
		return selected;
	}
	public void setSelected(String selected) {
		this.selected = selected;
	}
	public String getCounty() {
		return county;
	}
	public void setCounty(String county) {
		this.county = county;
	}
	public String getCustomerDunsNo() {
		return customerDunsNo;
	}
	public void setCustomerDunsNo(String customerDunsNo) {
		this.customerDunsNo = customerDunsNo;
	}
	public String getUtilization2017Current() {
		return utilization2017Current;
	}
	public void setUtilization2017Current(String utilization2017Current) {
		this.utilization2017Current = utilization2017Current;
	}
	public String getUtilization2018Projected() {
		return utilization2018Projected;
	}
	public void setUtilization2018Projected(String utilization2018Projected) {
		this.utilization2018Projected = utilization2018Projected;
	}
	public String getRepairsProvider() {
		return repairsProvider;
	}
	public void setRepairsProvider(String repairsProvider) {
		this.repairsProvider = repairsProvider;
	}
	
	
	
	public String getThirdPartyFldServProvider() {
		return thirdPartyFldServProvider;
	}
	public void setThirdPartyFldServProvider(String thirdPartyFldServProvider) {
		this.thirdPartyFldServProvider = thirdPartyFldServProvider;
	}
	
	public String getCustomerKey() {
		return customerKey;
	}
	public void setCustomerKey(String customerKey) {
		this.customerKey = customerKey;
	}
	public String getProductKey() {
		return productKey;
	}
	public void setProductKey(String productKey) {
		this.productKey = productKey;
	}
	public String getManagerKey() {
		return managerKey;
	}
	public void setManagerKey(String managerKey) {
		this.managerKey = managerKey;
	}
	public String getRecordId() {
		return recordId;
	}
	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getLastOverHaulDT() {
		return lastOverHaulDT;
	}
	public void setLastOverHaulDT(String lastOverHaulDT) {
		this.lastOverHaulDT = lastOverHaulDT;
	}
	public String getHrsAtLastOverHaul() {
		return hrsAtLastOverHaul;
	}
	public void setHrsAtLastOverHaul(String hrsAtLastOverHaul) {
		this.hrsAtLastOverHaul = hrsAtLastOverHaul;
	}
	public String getNextOverHaulDT() {
		return nextOverHaulDT;
	}
	public void setNextOverHaulDT(String nextOverHaulDT) {
		this.nextOverHaulDT = nextOverHaulDT;
	}
	public String getPartsProvider() {
		return partsProvider;
	}
	public void setPartsProvider(String partsProvider) {
		this.partsProvider = partsProvider;
	}
	public String getFieldServiceProvider() {
		return fieldServiceProvider;
	}
	public void setFieldServiceProvider(String fieldServiceProvider) {
		this.fieldServiceProvider = fieldServiceProvider;
	}
	public String getMarketSegment() {
		return marketSegment;
	}
	public void setMarketSegment(String marketSegment) {
		this.marketSegment = marketSegment;
	}
	public String getNoOfCyclinders() {
		return noOfCyclinders;
	}
	public void setNoOfCyclinders(String noOfCyclinders) {
		this.noOfCyclinders = noOfCyclinders;
	}
	
	public String getRatedBhp() {
		return ratedBhp;
	}
	public void setRatedBhp(String ratedBhp) {
		this.ratedBhp = ratedBhp;
	}
	public String getTurboCharged() {
		return turboCharged;
	}
	public void setTurboCharged(String turboCharged) {
		this.turboCharged = turboCharged;
	}
	public String getServiceManager() {
		return serviceManager;
	}
	public void setServiceManager(String serviceManager) {
		this.serviceManager = serviceManager;
	}
	public String getThirdPartyPartsProvides() {
		return thirdPartyPartsProvides;
	}
	public void setThirdPartyPartsProvides(String thirdPartyPartsProvides) {
		this.thirdPartyPartsProvides = thirdPartyPartsProvides;
	}
	public String getThirdPartyRepairsProvides() {
		return thirdPartyRepairsProvides;
	}
	public void setThirdPartyRepairsProvides(String thirdPartyRepairsProvides) {
		this.thirdPartyRepairsProvides = thirdPartyRepairsProvides;
	}
	
	public String getNotesFuturePlans() {
		return notesFuturePlans;
	}
	public void setNotesFuturePlans(String notesFuturePlans) {
		this.notesFuturePlans = notesFuturePlans;
	}
	
	
	public String getNoOfActvComprsrThrows() {
		return noOfActvComprsrThrows;
	}
	public void setNoOfActvComprsrThrows(String noOfActvComprsrThrows) {
		this.noOfActvComprsrThrows = noOfActvComprsrThrows;
	}
	public String getTurbochargerServiceProvider() {
		return turbochargerServiceProvider;
	}
	public void setTurbochargerServiceProvider(String turbochargerServiceProvider) {
		this.turbochargerServiceProvider = turbochargerServiceProvider;
	}
	
	public String getPlansToRepairReplace() {
		return plansToRepairReplace;
	}
	public void setPlansToRepairReplace(String plansToRepairReplace) {
		this.plansToRepairReplace = plansToRepairReplace;
	}
	
	public String getRetireDt() {
		return retireDt;
	}
	public void setRetireDt(String retireDt) {
		this.retireDt = retireDt;
	}
	public String getUtilization2016HST() {
		return utilization2016HST;
	}
	public void setUtilization2016HST(String utilization2016hst) {
		utilization2016HST = utilization2016hst;
	}
	public String getUtilization2015HST() {
		return utilization2015HST;
	}
	public void setUtilization2015HST(String utilization2015hst) {
		utilization2015HST = utilization2015hst;
	}
	public String getMaintenancePratice() {
		return maintenancePratice;
	}
	public void setMaintenancePratice(String maintenancePratice) {
		this.maintenancePratice = maintenancePratice;
	}
	
	public String getDirectInderct() {
		return directInderct;
	}
	public void setDirectInderct(String directInderct) {
		this.directInderct = directInderct;
	}
	
	
	
	public String getAccountManagerName() {
		return accountManagerName;
	}
	public void setAccountManagerName(String accountManagerName) {
		this.accountManagerName = accountManagerName;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getUnitType() {
		return unitType;
	}
	public void setUnitType(String unitType) {
		this.unitType = unitType;
	}
	public String getProductModel() {
		return productModel;
	}
	public void setProductModel(String productModel) {
		this.productModel = productModel;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getEndUserName() {
		return endUserName;
	}
	public void setEndUserName(String endUserName) {
		this.endUserName = endUserName;
	}
	public String getGeRegion() {
		return geRegion;
	}
	public void setGeRegion(String geRegion) {
		this.geRegion = geRegion;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getStationLocation() {
		return stationLocation;
	}
	public void setStationLocation(String stationLocation) {
		this.stationLocation = stationLocation;
	}
	public String getUsaStateName() {
		return usaStateName;
	}
	public void setUsaStateName(String usaStateName) {
		this.usaStateName = usaStateName;
	}
	public RecipData(String shortEndUser, String shortCustomerName, String shortStationLocation,
			String shortNotesFuturePlans, String customerKey, String productKey, String managerKey, String recordId,
			String serialNumber, String customerDunsNo, String status, String utilization2017Current,
			String utilization2018Projected, String lastOverHaulDT, String hrsAtLastOverHaul, String nextOverHaulDT,
			String partsProvider, String fieldServiceProvider, String repairsProvider, 
			String marketSegment, String noOfCyclinders, String ratedBhp,
			String turboCharged, String serviceManager, String thirdPartyPartsProvides,
			String thirdPartyFldServProvider, String thirdPartyRepairsProvides, 
			String notesFuturePlans, String noOfActvComprsrThrows,
			String turbochargerServiceProvider, 
			String plansToRepairReplace, String retireDt, String utilization2016hst,
			String utilization2015hst, String maintenancePratice, String directInderct,
			String accountManagerName,
			String productName, String unitType, String productModel, String customerName, String endUserName,
			String geRegion, String country, String stationLocation, String usaStateName, String county,
			String selected, String lastUpdateDate, String turbochargerMake, String turbochargerModel,
			String designCode) {
		super();
		this.shortEndUser = shortEndUser;
		this.shortCustomerName = shortCustomerName;
		this.shortStationLocation = shortStationLocation;
		this.shortNotesFuturePlans = shortNotesFuturePlans;
		this.customerKey = customerKey;
		this.productKey = productKey;
		this.managerKey = managerKey;
		this.recordId = recordId;
		this.serialNumber = serialNumber;
		this.customerDunsNo = customerDunsNo;
		this.status = status;
		this.utilization2017Current = utilization2017Current;
		this.utilization2018Projected = utilization2018Projected;
		this.lastOverHaulDT = lastOverHaulDT;
		this.hrsAtLastOverHaul = hrsAtLastOverHaul;
		this.nextOverHaulDT = nextOverHaulDT;
		this.partsProvider = partsProvider;
		this.fieldServiceProvider = fieldServiceProvider;
		this.repairsProvider = repairsProvider;
		
		this.marketSegment = marketSegment;
		this.noOfCyclinders = noOfCyclinders;
		
		this.ratedBhp = ratedBhp;
		this.turboCharged = turboCharged;
		this.serviceManager = serviceManager;
		this.thirdPartyPartsProvides = thirdPartyPartsProvides;
		this.thirdPartyFldServProvider = thirdPartyFldServProvider;
		this.thirdPartyRepairsProvides = thirdPartyRepairsProvides;
		
		this.notesFuturePlans = notesFuturePlans;
		
		
		this.noOfActvComprsrThrows = noOfActvComprsrThrows;
		this.turbochargerServiceProvider = turbochargerServiceProvider;
		this.plansToRepairReplace = plansToRepairReplace;
		
		this.retireDt = retireDt;
		this.utilization2016HST = utilization2016hst;
		this.utilization2015HST = utilization2015hst;
		this.maintenancePratice = maintenancePratice;
		
		this.directInderct = directInderct;
		
		
		
		this.accountManagerName = accountManagerName;
		this.productName = productName;
		this.unitType = unitType;
		this.productModel = productModel;
		this.customerName = customerName;
		this.endUserName = endUserName;
		this.geRegion = geRegion;
		this.country = country;
		this.stationLocation = stationLocation;
		this.usaStateName = usaStateName;
		this.county = county;
		this.selected = selected;
		this.lastUpdateDate = lastUpdateDate;
		this.turbochargerMake = turbochargerMake;
		this.turbochargerModel = turbochargerModel;
		this.designCode = designCode;
	}
	
	
}
