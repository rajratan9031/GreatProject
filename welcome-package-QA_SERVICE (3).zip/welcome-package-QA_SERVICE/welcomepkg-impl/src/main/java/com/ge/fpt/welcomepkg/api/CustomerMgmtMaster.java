package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.Date;

public class CustomerMgmtMaster implements Serializable {
	private static final long serialVersionUID = 1L;
	private int custId;
	private String customerId;
	private String customerName;
	private String country;
	private String activeInactive;
	private String region;
	private String dunsNumber;
	private Date createdDate;
	private Date updatedDate;
	private String updatedBy;
	private String createdBy;

	
	
	public String getDunsNumber() {
		return dunsNumber;
	}
	public void setDunsNumber(String dunsNumber) {
		this.dunsNumber = dunsNumber;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getActiveInactive() {
		return activeInactive;
	}
	public void setActiveInactive(String activeInactive) {
		this.activeInactive = activeInactive;
	}
	
	public CustomerMgmtMaster() {
		super();
	}
	
	public CustomerMgmtMaster(int custId, String customerId, String customerName, String country,
			String activeInactive, String region, String dunsNumber, Date createdDate, Date updatedDate,
			String updatedBy, String createdBy) {
		super();
		this.custId = custId;
		this.customerId = customerId;
		this.customerName = customerName;
		this.country = country;
		this.activeInactive = activeInactive;
		this.region = region;
		this.dunsNumber = dunsNumber;
		this.createdDate = createdDate;
		this.updatedDate = updatedDate;
		this.updatedBy = updatedBy;
		this.createdBy = createdBy;
	}
	@Override
	public String toString() {
		return "Customer_mgmt_Master [custId=" + custId + ", customerId=" + customerId + ", customerName="
				+ customerName + ", country=" + country + ", activeInactive=" + activeInactive + ", region=" + region
				+ ", dunsNumber=" + dunsNumber + ", createdDate=" + createdDate + ", updatedDate=" + updatedDate
				+ ", updatedBy=" + updatedBy + ", createdBy=" + createdBy + "]";
	}
	
	
	
}
