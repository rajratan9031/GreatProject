package com.ge.fpt.welcomepkg.api;

import java.util.List;

public class CustomerDetailsForOrderNumber {
	
	
	private String rn;
	private String recSource;
	private String orderId;
	private String salesOrder;
	private String serialNumber;
	private String lastupdateDate;
	private String linkcustomerNmae;
	private String custId;
	private String updatedBy;
	private String dunsNumber;

	private List<CustomerInfo> custData;
	
	
	
	public String getDunsNumber() {
		return dunsNumber;
	}
	public void setDunsNumber(String dunsNumber) {
		this.dunsNumber = dunsNumber;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public List<CustomerInfo> getCustData() {
		return custData;
	}
	public void setCustData(List<CustomerInfo> custData) {
		this.custData = custData;
	}
	public String getRn() {
		return rn;
	}
	public void setRn(String rn) {
		this.rn = rn;
	}
	public String getRecSource() {
		return recSource;
	}
	public void setRecSource(String recSource) {
		this.recSource = recSource;
	}
	public String getSalesOrder() {
		return salesOrder;
	}
	public void setSalesOrder(String salesOrder) {
		this.salesOrder = salesOrder;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getLastupdateDate() {
		return lastupdateDate;
	}
	public void setLastupdateDate(String lastupdateDate) {
		this.lastupdateDate = lastupdateDate;
	}
	public String getLinkcustomerNmae() {
		return linkcustomerNmae;
	}
	public void setLinkcustomerNmae(String linkcustomerNmae) {
		this.linkcustomerNmae = linkcustomerNmae;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	public CustomerDetailsForOrderNumber(String rn, String recSource, String orderId, String salesOrder,
			String serialNumber, String lastupdateDate, String linkcustomerNmae, String custId, String updatedBy,
			String dunsNumber, List<CustomerInfo> custData) {
		super();
		this.rn = rn;
		this.recSource = recSource;
		this.orderId = orderId;
		this.salesOrder = salesOrder;
		this.serialNumber = serialNumber;
		this.lastupdateDate = lastupdateDate;
		this.linkcustomerNmae = linkcustomerNmae;
		this.custId = custId;
		this.updatedBy = updatedBy;
		this.dunsNumber = dunsNumber;
		this.custData = custData;
	}
	public CustomerDetailsForOrderNumber() {
		super();
	}
	
	
	

	
	

	
}
