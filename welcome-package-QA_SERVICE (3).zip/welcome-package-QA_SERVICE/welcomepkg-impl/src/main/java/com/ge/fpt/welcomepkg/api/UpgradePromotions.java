package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.sql.Date;

public class UpgradePromotions implements Serializable { 
	
	private static final long serialVersionUID = -5579178899880989818L;
	
	private String optionId; 
	private String upgradeId;
	private double discount;
	private String couponCode;
	private Date validity;
	private double originalAmount;
	private double discountedAmount;
	public String getOptionId() {
		return optionId;
	}
	public void setOptionId(String optionId) {
		this.optionId = optionId;
	}
	public String getUpgradeId() {
		return upgradeId;
	}
	public void setUpgradeId(String upgradeId) {
		this.upgradeId = upgradeId;
	}
	
	public String getCouponCode() {
		return couponCode;
	}
	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}
	public Date getValidity() {
		return validity;
	}
	public void setValidity(Date validity) {
		this.validity = validity;
	}
	
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	public double getOriginalAmount() {
		return originalAmount;
	}
	public void setOriginalAmount(double originalAmount) {
		this.originalAmount = originalAmount;
	}
	public double getDiscountedAmount() {
		return discountedAmount;
	}
	public void setDiscountedAmount(double discountedAmount) {
		this.discountedAmount = discountedAmount;
	}
	@Override
	public String toString() {
		return "UpgradePromotions [optionId=" + optionId + ", upgradeId=" + upgradeId + ", discount=" + discount
				+ ", couponCode=" + couponCode + ", validity=" + validity + ", originalAmount=" + originalAmount
				+ ", discountedAmount=" + discountedAmount + "]";
	}
	
	
	
	

}
