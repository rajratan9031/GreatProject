package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;

public class CustomerSqtLinkT implements Serializable{
	private static final long serialVersionUID = -5579175197980496818L;

private Long orderId;
private String orderNumber;
private Long orderlineId;
private String serialNumber;
private String recSource;


public Long getOrderId() {
	return orderId;
}
public void setOrderId(Long orderId) {
	this.orderId = orderId;
}
public Long getOrderlineId() {
	return orderlineId;
}
public void setOrderlineId(Long orderlineId) {
	this.orderlineId = orderlineId;
}
public String getOrderNumber() {
	return orderNumber;
}
public void setOrderNumber(String orderNumber) {
	this.orderNumber = orderNumber;
}

public String getSerialNumber() {
	return serialNumber;
}
public void setSerialNumber(String serialNumber) {
	this.serialNumber = serialNumber;
}

public String getRecSource() {
	return recSource;
}
public void setRecSource(String recSource) {
	this.recSource = recSource;
}



public CustomerSqtLinkT(Long orderId, String orderNumber, Long orderlineId, String serialNumber, String recSource) {
	super();
	this.orderId = orderId;
	this.orderNumber = orderNumber;
	this.orderlineId = orderlineId;
	this.serialNumber = serialNumber;
	this.recSource = recSource;
}
public CustomerSqtLinkT() {
	super();
}
@Override
public String toString() {
	return "CustomerSqtLinkT [orderId=" + orderId + ", orderNumber=" + orderNumber + ", orderlineId=" + orderlineId
			+ ", serialNumber=" + serialNumber + ", recSource=" + recSource + "]";
}



}
