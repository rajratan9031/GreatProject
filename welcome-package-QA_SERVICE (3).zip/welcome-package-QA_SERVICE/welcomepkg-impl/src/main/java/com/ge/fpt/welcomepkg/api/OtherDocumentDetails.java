package com.ge.fpt.welcomepkg.api;

public class OtherDocumentDetails {

	private String asitecode;
	private String atypeflowproject;
	private String aprojectnumber;
	private String asalesorder;
	private String asalesorderline;
	private String aprodorderno;
	private String serialNumber;
	private String adocType;
	private String adocdesc;
	private String afilename;
	private String afilelink;
	private String adoclang;
	private String docType;
	private String asourcesys;
	private String amd5;
	private String docName;
	private String ipath;
	private String iresource;
	private String iserialnumber;
	public String getAsitecode() {
		return asitecode;
	}
	public void setAsitecode(String asitecode) {
		this.asitecode = asitecode;
	}
	public String getAtypeflowproject() {
		return atypeflowproject;
	}
	public void setAtypeflowproject(String atypeflowproject) {
		this.atypeflowproject = atypeflowproject;
	}
	public String getAprojectnumber() {
		return aprojectnumber;
	}
	public void setAprojectnumber(String aprojectnumber) {
		this.aprojectnumber = aprojectnumber;
	}
	public String getAsalesorder() {
		return asalesorder;
	}
	public void setAsalesorder(String asalesorder) {
		this.asalesorder = asalesorder;
	}
	public String getAsalesorderline() {
		return asalesorderline;
	}
	public void setAsalesorderline(String asalesorderline) {
		this.asalesorderline = asalesorderline;
	}
	public String getAprodorderno() {
		return aprodorderno;
	}
	public void setAprodorderno(String aprodorderno) {
		this.aprodorderno = aprodorderno;
	}
	
	public String getAdocdesc() {
		return adocdesc;
	}
	public void setAdocdesc(String adocdesc) {
		this.adocdesc = adocdesc;
	}
	public String getAfilename() {
		return afilename;
	}
	public void setAfilename(String afilename) {
		this.afilename = afilename;
	}
	public String getAfilelink() {
		return afilelink;
	}
	public void setAfilelink(String afilelink) {
		this.afilelink = afilelink;
	}
	public String getAdoclang() {
		return adoclang;
	}
	public void setAdoclang(String adoclang) {
		this.adoclang = adoclang;
	}
	
	public String getDocType() {
		return docType;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	public String getAsourcesys() {
		return asourcesys;
	}
	public void setAsourcesys(String asourcesys) {
		this.asourcesys = asourcesys;
	}
	public String getAmd5() {
		return amd5;
	}
	public void setAmd5(String amd5) {
		this.amd5 = amd5;
	}
	
	public String getIpath() {
		return ipath;
	}
	public void setIpath(String ipath) {
		this.ipath = ipath;
	}
	public String getIresource() {
		return iresource;
	}
	public void setIresource(String iresource) {
		this.iresource = iresource;
	}
	public String getIserialnumber() {
		return iserialnumber;
	}
	public void setIserialnumber(String iserialnumber) {
		this.iserialnumber = iserialnumber;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	public String getAdocType() {
		return adocType;
	}
	public void setAdocType(String adocType) {
		this.adocType = adocType;
	}
	
	
	
	public OtherDocumentDetails(String asitecode, String atypeflowproject, String aprojectnumber, String asalesorder,
			String asalesorderline, String aprodorderno, String serialNumber, String adocType, String adocdesc,
			String afilename, String afilelink, String adoclang, String docType, String asourcesys, String amd5,
			String docName, String ipath, String iresource, String iserialnumber) {
		super();
		this.asitecode = asitecode;
		this.atypeflowproject = atypeflowproject;
		this.aprojectnumber = aprojectnumber;
		this.asalesorder = asalesorder;
		this.asalesorderline = asalesorderline;
		this.aprodorderno = aprodorderno;
		this.serialNumber = serialNumber;
		this.adocType = adocType;
		this.adocdesc = adocdesc;
		this.afilename = afilename;
		this.afilelink = afilelink;
		this.adoclang = adoclang;
		this.docType = docType;
		this.asourcesys = asourcesys;
		this.amd5 = amd5;
		this.docName = docName;
		this.ipath = ipath;
		this.iresource = iresource;
		this.iserialnumber = iserialnumber;
	}
	public OtherDocumentDetails() {
		super();
	}
	@Override
	public String toString() {
		return "OtherDocumentDetails [asitecode=" + asitecode + ", atypeflowproject=" + atypeflowproject
				+ ", aprojectnumber=" + aprojectnumber + ", asalesorder=" + asalesorder + ", asalesorderline="
				+ asalesorderline + ", aprodorderno=" + aprodorderno + ", serialNumber=" + serialNumber + ", adocType="
				+ adocType + ", adocdesc=" + adocdesc + ", afilename=" + afilename + ", afilelink=" + afilelink
				+ ", adoclang=" + adoclang + ", docType=" + docType + ", asourcesys=" + asourcesys + ", amd5=" + amd5
				+ ", docName=" + docName + ", ipath=" + ipath + ", iresource=" + iresource + ", iserialnumber="
				+ iserialnumber + "]";
	}
	
	
}
