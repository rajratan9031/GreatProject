package com.ge.fpt.welcomepkg.persistence;

import java.util.HashMap;
import java.util.List;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ge.fpt.welcomepkg.api.CPPromotionalCartData;
import com.ge.fpt.welcomepkg.api.CPUpgradeDetailSMIView;
import com.ge.fpt.welcomepkg.api.CPUpgradeDetailView;
import com.ge.fpt.welcomepkg.api.CPUpgradeDocument;
import com.ge.fpt.welcomepkg.api.CPUpgradeInfo;
import com.ge.fpt.welcomepkg.api.DropDownItem;
import com.ge.fpt.welcomepkg.api.EquipmentBoms;
import com.ge.fpt.welcomepkg.api.PromotionalCart;
import com.ge.fpt.welcomepkg.api.PromotionalCartViewData;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.api.UpgradeDocument;
import com.ge.fpt.welcomepkg.api.UpgradeInfo;
import com.ge.fpt.welcomepkg.api.UpgradeInfoNew;
import com.ge.fpt.welcomepkg.api.UpgradeInfoNewDTO;
import com.ge.fpt.welcomepkg.api.UpgradeOptionDetails;
import com.ge.fpt.welcomepkg.api.UpgradeOptionListDTO;
import com.ge.fpt.welcomepkg.api.UpgradeOptions;
import com.ge.fpt.welcomepkg.api.UpgradePartModel;

public interface IUpgradeInfoPersistence {


	@Transactional(propagation=Propagation.REQUIRED)
	Boolean getPartOrModelData(Object part);

	@Transactional(propagation=Propagation.REQUIRED)
	int getUpgradeOptionsCount(UpgradeOptions upgradeOptions);

	@Transactional(propagation=Propagation.REQUIRED)
	List<UpgradeOptions> getUpgradeOptionsData(int pageNo,int rowsPerPage,UpgradeOptions upgradeOptions);

	@Transactional(propagation=Propagation.REQUIRED)
	StatusInfo saveUpgradeOptions(UpgradeOptions upgradeOptions);

	@Transactional(propagation=Propagation.REQUIRED)
	StatusInfo saveUpgradeDetails(UpgradeInfo upgradeInfo);
	
	@Transactional(propagation=Propagation.REQUIRED)
	StatusInfo saveUpgradeNewDetails(String sso,UpgradeInfo upgradeInfo);

	@Transactional(propagation=Propagation.REQUIRED)
	int getUpgradeDetailsCount(UpgradeInfo upgradeInfo);

	@Transactional(propagation=Propagation.REQUIRED)
	List<UpgradeInfo> getUpgradeDetailsData(int pageNo,int rowsPerPage,UpgradeInfo upgradeInfo);

	@Transactional(propagation=Propagation.REQUIRED)
	StatusInfo deleteUpgradeLegacyPnModel(UpgradePartModel upgradePartModel);

	@Transactional(propagation=Propagation.REQUIRED)
	StatusInfo deleteUpgradeOptionsDetailsPartModel(UpgradeOptionDetails upgradeOptionDetails);

	@Transactional(propagation=Propagation.REQUIRED)
	List<EquipmentBoms> getUpgradesByUpgradename(int page, int rowsPerPage, String globalSearch, String sortCol, String sortOrder,int upgradeId,
			String dunsNumber, EquipmentBoms equipmentboms);

	@Transactional(propagation=Propagation.REQUIRED)
	int getUpgradesCount(String globalSearch,int upgradeId, String dunsNumber, EquipmentBoms equipmentboms);
	
	@Transactional(propagation=Propagation.REQUIRED)
	List<DropDownItem> getUpgradeOptionsDataUI( String sso,String region);	

	@Transactional(propagation = Propagation.REQUIRED)
	List<EquipmentBoms> getPartDataByByRecSourceAndSerialNumber(String serialNumber, String recSource, String region,
			String currency);
	
	@Transactional(propagation = Propagation.REQUIRED)
	List<UpgradeOptions> getOptionsByUpgradeId(String upgradeId);

	@Transactional(propagation = Propagation.REQUIRED)
	UpgradeInfo getUpgradeCoupon(String upgradeId);

	@Transactional(propagation = Propagation.REQUIRED)
	List<PromotionalCartViewData> getPromotionalCart(String sso);
	
	@Transactional(propagation = Propagation.REQUIRED)
	int getPromotionalCartCount(String sso);
	
	@Transactional(propagation = Propagation.REQUIRED)
	List<String> getSavedPromotionalCarts(String sso);

	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo savePromotionalCart(String sso, String cartName);
	
	@Transactional(propagation = Propagation.REQUIRED)
	int checkPromotionalCartExists(String sso, String cartName);
	
	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo deletePromotionFromCart(String sso,PromotionalCartViewData promotionalCartViewData);
	
	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo deleteAllPromotionFromCart(String sso);

	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo loadPromotionalCart(String sso, String cartName);
/*
	@Transactional(propagation = Propagation.REQUIRED)
	ArrayList<String> loadGetUpgradeName(String cartName);*/
	
	@Transactional(propagation = Propagation.REQUIRED)
	List<EquipmentBoms> getUpgradesByUpgradenameForGEUsers(int page, int rowsPerPage, String globalSearch,
			String sortCol, String sortOrder, int upgradeId, EquipmentBoms equipmentboms);

	@Transactional(propagation = Propagation.REQUIRED)
	int getUpgradesCountForGEUsers(String globalSearch,int upgradeId, EquipmentBoms equipmentboms);

	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo saveQuantity(String sso, PromotionalCartViewData promotionalcartViewData);

	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo sendEmailNotification();
	
	//Sindhura : Start :Delete functionality for upgrade module
	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo upgradeprogramdelete(String programupgradeId);

	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo upgradeoptionsdelete(String newupgradeId);
	
	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo upgradeoptiondeleteById(String newupgradeId, String programOptionId);
	
	//Sindhura : End :Delete functionality for upgrade module

	//Sujeet : Start : Delete functionality for new upgrade module
	
	@Transactional(propagation=Propagation.REQUIRED)
	List<UpgradeInfoNew> getUpgradeDetailsDataNew();
	
	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo deleteUpgradeInfoByID(UpgradeInfoNewDTO upgradeInfoNewDTO);
	
	@Transactional(propagation=Propagation.REQUIRED)
	StatusInfo getUpgradeNewInfoPartFileUpload(HashMap getCompleteData);
	
	//Sujeet : end : Delete functionality for new upgrade module


	//Raj changes
	@Transactional(propagation=Propagation.REQUIRED)
	List<UpgradeInfo> getUpgradeNewInfo(String upgradeId);

	@Transactional(propagation=Propagation.REQUIRED)
	List<CPUpgradeInfo> getCpUpgradesListData(String sso, String region, CPUpgradeInfo cpUpgradeInfo);

	
	//Raj changes
	@Transactional(propagation=Propagation.REQUIRED)
	StatusInfo deleteUpgradePackageDocument(String documentID);

	@Transactional(propagation=Propagation.REQUIRED)
	List<UpgradeInfoNew> getUpgradeNewInfoById(String upgradeId);
	
	@Transactional(propagation=Propagation.REQUIRED)
	List<UpgradeOptions> getUpgradeOptionNewInfoById(String upgradeId);
	
	@Transactional(propagation = Propagation.REQUIRED)
	StatusInfo deleteUpgradeOptionsNew(UpgradeOptionListDTO OptionList);

	@Transactional(propagation=Propagation.REQUIRED)
	StatusInfo saveUpgradeOptionInfo(String sso,UpgradeOptions upgradeOptions);
	
	@Transactional(propagation=Propagation.REQUIRED)
	List<UpgradeOptions> getUpgradeOptionNewInfo(String optionId);
	
	@Transactional(propagation=Propagation.REQUIRED)
	List<String> getEndUserList();
	
	
	@Transactional(propagation=Propagation.REQUIRED)
	CPUpgradeDetailView getCpUpgradeDetailViewData(int upgradeId);
	
	@Transactional(propagation=Propagation.REQUIRED)
	CPUpgradeDetailSMIView getCpUpgradeSMIViewData(int upgradeId);
	
	@Transactional(propagation=Propagation.REQUIRED)
	CPUpgradeDocument getUpgradeDocumentDetails(int documentId);
	
}
