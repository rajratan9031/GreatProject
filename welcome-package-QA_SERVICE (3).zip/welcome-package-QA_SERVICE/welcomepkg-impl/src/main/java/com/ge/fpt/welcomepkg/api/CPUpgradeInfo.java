package com.ge.fpt.welcomepkg.api;

import java.sql.Date;

public class CPUpgradeInfo {
	
	private int serialNo;
	private String upgradeId;
	private String upgradeName;
	private String state;
	private String upgradesType;
	private Long discountPercentage;
	private String description;
	private int daysRemaining;
	private Date startDate;
	private Date endDate;
	private String image;
	
	
	public int getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}
	
	public String getUpgradeId() {
		return upgradeId;
	}
	public void setUpgradeId(String upgradeId) {
		this.upgradeId = upgradeId;
	}
	public String getUpgradeName() {
		return upgradeName;
	}
	public void setUpgradeName(String upgradeName) {
		this.upgradeName = upgradeName;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Long getDiscountPercentage() {
		return discountPercentage;
	}
	public void setDiscountPercentage(Long discountPercentage) {
		this.discountPercentage = discountPercentage;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getDaysRemaining() {
		return daysRemaining;
	}
	public void setDaysRemaining(int daysRemaining) {
		this.daysRemaining = daysRemaining;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	
	
	public String getUpgradesType() {
		return upgradesType;
	}
	public void setUpgradesType(String upgradesType) {
		this.upgradesType = upgradesType;
	}
	@Override
	public String toString() {
		return "CPUpgradeInfo [serialNo=" + serialNo + ", upgradeId=" + upgradeId + ", upgradeName=" + upgradeName
				+ ", state=" + state + ", upgradesType=" + upgradesType + ", discountPercentage=" + discountPercentage
				+ ", description=" + description + ", daysRemaining=" + daysRemaining + ", startDate=" + startDate
				+ ", endDate=" + endDate + ", image=" + image + "]";
	}
	
	
	
	
	
	
	
	

}
