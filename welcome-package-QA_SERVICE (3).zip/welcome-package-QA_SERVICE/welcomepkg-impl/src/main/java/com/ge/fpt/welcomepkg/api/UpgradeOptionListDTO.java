package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.List;

public class UpgradeOptionListDTO implements Serializable {

	private static final long serialVersionUID =1L;
	
	private List<String> optionId;

	public List<String> getOptionId() {
		return optionId;
	}

	public void setOptionId(List<String> optionId) {
		this.optionId = optionId;
	}
	
	@Override
	public String toString() {
		return "UpgradeOptionListDTO [optionId=" + optionId + "]";
	}
	
}
