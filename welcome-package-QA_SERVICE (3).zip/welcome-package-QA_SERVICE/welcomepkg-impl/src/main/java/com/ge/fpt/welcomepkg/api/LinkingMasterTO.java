package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.List;

public class LinkingMasterTO implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private List<String> serialNumber;
	private int customerId ;
	private String customerName;
	private int plantId;
	private String orderId;
	private String orderNumber;
	private String recSource;
	private String dunsNumber;
	private int projectId;
	private String isActiveCust;
	private String isActivePlant;

	
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getIsActiveCust() {
		return isActiveCust;
	}
	public void setIsActiveCust(String isActiveCust) {
		this.isActiveCust = isActiveCust;
	}
	public String getIsActivePlant() {
		return isActivePlant;
	}
	public void setIsActivePlant(String isActivePlant) {
		this.isActivePlant = isActivePlant;
	}
	public String getDunsNumber() {
		return dunsNumber;
	}
	public void setDunsNumber(String dunsNumber) {
		this.dunsNumber = dunsNumber;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	
	public String getRecSource() {
		return recSource;
	}
	public void setRecSource(String recSource) {
		this.recSource = recSource;
	}
	public List<String> getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(List<String> serialNumber) {
		this.serialNumber = serialNumber;
	}
	
	
	
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getPlantId() {
		return plantId;
	}
	public void setPlantId(int plantId) {
		this.plantId = plantId;
	}
	public LinkingMasterTO() {
		super();
	}
	
	
	public int getProjectId() {
		return projectId;
	}
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	@Override
	public String toString() {
		return "LinkingMasterTO [serialNumber=" + serialNumber + ", customerId=" + customerId + ", customerName="
				+ customerName + ", plantId=" + plantId + ", orderId=" + orderId + ", orderNumber=" + orderNumber
				+ ", recSource=" + recSource + ", dunsNumber=" + dunsNumber + ", projectId=" + projectId
				+ ", isActiveCust=" + isActiveCust + ", isActivePlant=" + isActivePlant + "]";
	}
	public LinkingMasterTO(List<String> serialNumber, int customerId, String customerName, int plantId, String orderId,
			String orderNumber, String recSource, String dunsNumber, int projectId, String isActiveCust,
			String isActivePlant) {
		super();
		this.serialNumber = serialNumber;
		this.customerId = customerId;
		this.customerName = customerName;
		this.plantId = plantId;
		this.orderId = orderId;
		this.orderNumber = orderNumber;
		this.recSource = recSource;
		this.dunsNumber = dunsNumber;
		this.projectId = projectId;
		this.isActiveCust = isActiveCust;
		this.isActivePlant = isActivePlant;
	}
	
	
	


}
