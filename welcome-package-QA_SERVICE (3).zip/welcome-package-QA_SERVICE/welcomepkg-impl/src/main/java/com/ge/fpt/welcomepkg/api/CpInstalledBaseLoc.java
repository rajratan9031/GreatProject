package com.ge.fpt.welcomepkg.api;

import java.util.List;

public class CpInstalledBaseLoc {
private List<InstallBaseLoc> insallBaseLocList;
private String dunsNumber;
public List<InstallBaseLoc> getInsallBaseLocList() {
	return insallBaseLocList;
}
public void setInsallBaseLocList(List<InstallBaseLoc> insallBaseLocList) {
	this.insallBaseLocList = insallBaseLocList;
}
public String getDunsNumber() {
	return dunsNumber;
}
public void setDunsNumber(String dunsNumber) {
	this.dunsNumber = dunsNumber;
}

}
