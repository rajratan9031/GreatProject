package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.Date;

public class Inventory implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1090059810506819689L;
	
	private Long  id;
	private String partNumber;
	private String partDesc;
	private String legacyPart;
	private String repPart;
	private int quantity;
	private String productCode;
	private String uploadBy;
	private Date uploadDate;
	private String company;
	private String phone;
	private String site;
	private String email;
	private Long siteId;
	
	public Long getSiteId() {
		return siteId;
	}

	public void setSiteId(Long siteId) {
		this.siteId = siteId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public String getPartDesc() {
		return partDesc;
	}

	public void setPartDesc(String partDesc) {
		this.partDesc = partDesc;
	}

	public String getLegacyPart() {
		return legacyPart;
	}

	public void setLegacyPart(String legacyPart) {
		this.legacyPart = legacyPart;
	}

	public String getRepPart() {
		return repPart;
	}

	public void setRepPart(String repPart) {
		this.repPart = repPart;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getUploadBy() {
		return uploadBy;
	}

	public void setUploadBy(String uploadBy) {
		this.uploadBy = uploadBy;
	}

	public Date getUploadDate() {
		return uploadDate;
	}

	public void setUploadDate(Date uploadDate) {
		this.uploadDate = uploadDate;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getSite() {
		return site;
	}

	public void setSite(String site) {
		this.site = site;
	}

	public Inventory() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Inventory(Long id, String partNumber, String partDesc,
			String legacyPart, String repPart, int quantity,
			String productCode, String uploadBy, Date uploadDate,
			String company, String phone, String site,String email,Long siteId) {
		super();
		this.id = id;
		this.partNumber = partNumber;
		this.partDesc = partDesc;
		this.legacyPart = legacyPart;
		this.repPart = repPart;
		this.quantity = quantity;
		this.productCode = productCode;
		this.uploadBy = uploadBy;
		this.uploadDate = uploadDate;
		this.company = company;
		this.phone = phone;
		this.site = site;
		this.email=email;
		this.siteId=siteId;
	}
}
