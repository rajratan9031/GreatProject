package com.ge.fpt.welcomepkg.api;

public class CPUpgradeParts {
	
	private String partNumber;
	private double discountedPrice;
	private String indicator;
	private int quantity;
	
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public double getDiscountedPrice() {
		return discountedPrice;
	}
	public void setDiscountedPrice(double discountedPrice) {
		this.discountedPrice = discountedPrice;
	}
	public String getIndicator() {
		return indicator;
	}
	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	@Override
	public String toString() {
		return "CPUpgradeParts [partNumber=" + partNumber + ", discountedPrice=" + discountedPrice + ", indicator="
				+ indicator + ", quantity=" + quantity + "]";
	}
	
	
	
	
	
	

}
