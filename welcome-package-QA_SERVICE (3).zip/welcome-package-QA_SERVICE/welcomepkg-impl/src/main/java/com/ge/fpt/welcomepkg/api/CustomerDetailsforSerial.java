package com.ge.fpt.welcomepkg.api;

import java.util.List;

public class CustomerDetailsforSerial {
	private String rn;
	private String recSource;
	private String orderId;
	private String salesOrder;
	private String serialNumber;
	private String lastupdateDate;
	private String linkcustomerNmae;
	private String custId;
	private String updatedBy;
	private String dunsNumber;
	
	
	//NEW ADDED 
	private String custEuIndustry;
	private String custEuCountry;
	private String custEuState;
	private String custEuCity;
	private String custEuPostalCode;
	private String custEuCustomerName;
	private String custEuActiveInactive;
	
	// NEW ADDED 
	private int plantId;
	private String plantName;
	private String plantLocation;
	private String plantContact;
	private String plantMaintaenanceInternal;
	private String plantCountry;
	private String plantActiveInavctive;
	private String plantValveLocation;
	private String plantCustomerEmail;
	private String plantCity;
	private String plantState;
	private String plantPostalCode;
	
	
	private int projectId;
	private String projectName;
	private String projectCountry;
	private String projectCity;
	private String projectState;
	private String projectPostalCode;
	private String projectLocation;
	private boolean isprojectPlantLocation;
	private int projectPlantId;	

	private List<CustomerInfo> custData;
	private List<PlantDataManagmentMaster> plantData;
	private List<ProjectDataMaster> projectDataMaster;
	
	

	
	public String getCustEuActiveInactive() {
		return custEuActiveInactive;
	}
	public void setCustEuActiveInactive(String custEuActiveInactive) {
		this.custEuActiveInactive = custEuActiveInactive;
	}
	public String getCustEuIndustry() {
		return custEuIndustry;
	}
	public void setCustEuIndustry(String custEuIndustry) {
		this.custEuIndustry = custEuIndustry;
	}
	public String getCustEuCountry() {
		return custEuCountry;
	}
	public void setCustEuCountry(String custEuCountry) {
		this.custEuCountry = custEuCountry;
	}
	public String getCustEuState() {
		return custEuState;
	}
	public void setCustEuState(String custEuState) {
		this.custEuState = custEuState;
	}
	public String getCustEuCity() {
		return custEuCity;
	}
	public void setCustEuCity(String custEuCity) {
		this.custEuCity = custEuCity;
	}
	public String getCustEuPostalCode() {
		return custEuPostalCode;
	}
	public void setCustEuPostalCode(String custEuPostalCode) {
		this.custEuPostalCode = custEuPostalCode;
	}
	public String getCustEuCustomerName() {
		return custEuCustomerName;
	}
	public void setCustEuCustomerName(String custEuCustomerName) {
		this.custEuCustomerName = custEuCustomerName;
	}
	public int getProjectPlantId() {
		return projectPlantId;
	}
	public void setProjectPlantId(int projectPlantId) {
		this.projectPlantId = projectPlantId;
	}
	public String getPlantCity() {
		return plantCity;
	}
	public void setPlantCity(String plantCity) {
		this.plantCity = plantCity;
	}
	public String getPlantState() {
		return plantState;
	}
	public void setPlantState(String plantState) {
		this.plantState = plantState;
	}
	public String getPlantPostalCode() {
		return plantPostalCode;
	}
	public void setPlantPostalCode(String plantPostalCode) {
		this.plantPostalCode = plantPostalCode;
	}
	public List<PlantDataManagmentMaster> getPlantData() {
		return plantData;
	}
	public void setPlantData(List<PlantDataManagmentMaster> plantData) {
		this.plantData = plantData;
	}
	public String getPlantCustomerEmail() {
		return plantCustomerEmail;
	}
	public void setPlantCustomerEmail(String plantCustomerEmail) {
		this.plantCustomerEmail = plantCustomerEmail;
	}
	public String getDunsNumber() {
		return dunsNumber;
	}
	public void setDunsNumber(String dunsNumber) {
		this.dunsNumber = dunsNumber;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public List<CustomerInfo> getCustData() {
		return custData;
	}
	public void setCustData(List<CustomerInfo> custData) {
		this.custData = custData;
	}
	public String getRn() {
		return rn;
	}
	public void setRn(String rn) {
		this.rn = rn;
	}
	public String getRecSource() {
		return recSource;
	}
	public void setRecSource(String recSource) {
		this.recSource = recSource;
	}
	public String getSalesOrder() {
		return salesOrder;
	}
	public void setSalesOrder(String salesOrder) {
		this.salesOrder = salesOrder;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getLastupdateDate() {
		return lastupdateDate;
	}
	public void setLastupdateDate(String lastupdateDate) {
		this.lastupdateDate = lastupdateDate;
	}
	public String getLinkcustomerNmae() {
		return linkcustomerNmae;
	}
	public void setLinkcustomerNmae(String linkcustomerNmae) {
		this.linkcustomerNmae = linkcustomerNmae;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	public CustomerDetailsforSerial(String rn, String recSource, String orderId, String salesOrder, String serialNumber,
			String lastupdateDate, String linkcustomerNmae, String custId, String updatedBy, String dunsNumber,
			List<CustomerInfo> custData) {
		super();
		this.rn = rn;
		this.recSource = recSource;
		this.orderId = orderId;
		this.salesOrder = salesOrder;
		this.serialNumber = serialNumber;
		this.lastupdateDate = lastupdateDate;
		this.linkcustomerNmae = linkcustomerNmae;
		this.custId = custId;
		this.updatedBy = updatedBy;
		this.dunsNumber = dunsNumber;
		this.custData = custData;
	}
	public CustomerDetailsforSerial() {
		super();
	}
	

	public List<ProjectDataMaster> getProjectDataMaster() {
		return projectDataMaster;
	}
	public void setProjectDataMaster(List<ProjectDataMaster> projectDataMaster) {
		this.projectDataMaster = projectDataMaster;
	}
	
	
	public int getPlantId() {
		return plantId;
	}
	public void setPlantId(int plantId) {
		this.plantId = plantId;
	}
	public String getPlantName() {
		return plantName;
	}
	public void setPlantName(String plantName) {
		this.plantName = plantName;
	}
	public String getPlantLocation() {
		return plantLocation;
	}
	public void setPlantLocation(String plantLocation) {
		this.plantLocation = plantLocation;
	}
	public int getProjectId() {
		return projectId;
	}
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	
	public String getPlantContact() {
		return plantContact;
	}
	public void setPlantContact(String plantContact) {
		this.plantContact = plantContact;
	}
	public String getPlantMaintaenanceInternal() {
		return plantMaintaenanceInternal;
	}
	public void setPlantMaintaenanceInternal(String plantMaintaenanceInternal) {
		this.plantMaintaenanceInternal = plantMaintaenanceInternal;
	}
	public String getPlantCountry() {
		return plantCountry;
	}
	public void setPlantCountry(String plantCountry) {
		this.plantCountry = plantCountry;
	}
	public String getPlantActiveInavctive() {
		return plantActiveInavctive;
	}
	public void setPlantActiveInavctive(String plantActiveInavctive) {
		this.plantActiveInavctive = plantActiveInavctive;
	}
	public String getPlantValveLocation() {
		return plantValveLocation;
	}
	public void setPlantValveLocation(String plantValveLocation) {
		this.plantValveLocation = plantValveLocation;
	}
	public String getProjectCountry() {
		return projectCountry;
	}
	public void setProjectCountry(String projectCountry) {
		this.projectCountry = projectCountry;
	}
	public String getProjectCity() {
		return projectCity;
	}
	public void setProjectCity(String projectCity) {
		this.projectCity = projectCity;
	}
	public String getProjectState() {
		return projectState;
	}
	public void setProjectState(String projectState) {
		this.projectState = projectState;
	}
	public String getProjectPostalCode() {
		return projectPostalCode;
	}
	public void setProjectPostalCode(String projectPostalCode) {
		this.projectPostalCode = projectPostalCode;
	}
	public String getProjectLocation() {
		return projectLocation;
	}
	public void setProjectLocation(String projectLocation) {
		this.projectLocation = projectLocation;
	}
	public boolean isIsprojectPlantLocation() {
		return isprojectPlantLocation;
	}
	public void setIsprojectPlantLocation(boolean isprojectPlantLocation) {
		this.isprojectPlantLocation = isprojectPlantLocation;
	}
	@Override
	public String toString() {
		return "CustomerDetailsforSerial [rn=" + rn + ", recSource=" + recSource + ", orderId=" + orderId
				+ ", salesOrder=" + salesOrder + ", serialNumber=" + serialNumber + ", lastupdateDate=" + lastupdateDate
				+ ", linkcustomerNmae=" + linkcustomerNmae + ", custId=" + custId + ", updatedBy=" + updatedBy
				+ ", dunsNumber=" + dunsNumber + ", plantId=" + plantId + ", plantName=" + plantName
				+ ", plantLocation=" + plantLocation + ", plantContact=" + plantContact + ", plantMaintaenanceInternal="
				+ plantMaintaenanceInternal + ", plantCountry=" + plantCountry + ", plantActiveInavctive="
				+ plantActiveInavctive + ", plantValveLocation=" + plantValveLocation + ", plantCustomerEmail="
				+ plantCustomerEmail + ", plantCity=" + plantCity + ", plantState=" + plantState + ", plantPostalCode="
				+ plantPostalCode + ", projectId=" + projectId + ", projectName=" + projectName + ", projectCountry="
				+ projectCountry + ", projectCity=" + projectCity + ", projectState=" + projectState
				+ ", projectPostalCode=" + projectPostalCode + ", projectLocation=" + projectLocation
				+ ", isprojectPlantLocation=" + isprojectPlantLocation + ", projectPlantId=" + projectPlantId
				+ ", custData=" + custData + ", plantData=" + plantData + ", projectDataMaster=" + projectDataMaster
				+ "]";
	}
	
	
	
}
