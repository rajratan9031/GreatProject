package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.Date;

public class BomConfigurator implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2222963361664561672L;
	
	
	private String serialNumber;
	private String source;
	private String modifiedUser;
	private String modifiedOrg;
	private Date modifiedDate;
	private String reason;
	private String remark;
	private String finishModelNumber;
	private String tagNumber;
	private String temperature;
	private String capacity;
	private String asmeCodeStamp;
	private String cdtp;
	private String backPressure;
	private String service;
	private String springNumberRange;
	private String valveType;
	private String valveDesc;
	
	public BomConfigurator() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public BomConfigurator(String serialNumber, String source,
			String modifiedUser, String modifiedOrg, Date modifiedDate,
			String reason, String remark, String finishModelNumber,
			String tagNumber, String temperature, String capacity,
			String asmeCodeStamp, String cdtp, String backPressure,
			String service, String springNumberRange, String valveType) {
		super();
		this.serialNumber = serialNumber;
		this.source = source;
		this.modifiedUser = modifiedUser;
		this.modifiedOrg = modifiedOrg;
		this.modifiedDate = modifiedDate;
		this.reason = reason;
		this.remark = remark;
		this.finishModelNumber = finishModelNumber;
		this.tagNumber = tagNumber;
		this.temperature = temperature;
		this.capacity = capacity;
		this.asmeCodeStamp = asmeCodeStamp;
		this.cdtp = cdtp;
		this.backPressure = backPressure;
		this.service = service;
		this.springNumberRange = springNumberRange;
		this.valveType = valveType;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getModifiedUser() {
		return modifiedUser;
	}

	public void setModifiedUser(String modifiedUser) {
		this.modifiedUser = modifiedUser;
	}

	public String getModifiedOrg() {
		return modifiedOrg;
	}

	public void setModifiedOrg(String modifiedOrg) {
		this.modifiedOrg = modifiedOrg;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getFinishModelNumber() {
		return finishModelNumber;
	}

	public void setFinishModelNumber(String finishModelNumber) {
		this.finishModelNumber = finishModelNumber;
	}

	public String getTagNumber() {
		return tagNumber;
	}

	public void setTagNumber(String tagNumber) {
		this.tagNumber = tagNumber;
	}

	public String getTemperature() {
		return temperature;
	}

	public void setTemperature(String temperature) {
		this.temperature = temperature;
	}

	public String getCapacity() {
		return capacity;
	}

	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}

	public String getAsmeCodeStamp() {
		return asmeCodeStamp;
	}

	public void setAsmeCodeStamp(String asmeCodeStamp) {
		this.asmeCodeStamp = asmeCodeStamp;
	}

	public String getCdtp() {
		return cdtp;
	}

	public void setCdtp(String cdtp) {
		this.cdtp = cdtp;
	}

	public String getBackPressure() {
		return backPressure;
	}

	public void setBackPressure(String backPressure) {
		this.backPressure = backPressure;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public String getSpringNumberRange() {
		return springNumberRange;
	}

	public void setSpringNumberRange(String springNumberRange) {
		this.springNumberRange = springNumberRange;
	}

	public String getValveType() {
		return valveType;
	}

	public void setValveType(String valveType) {
		this.valveType = valveType;
	}

	public String getValveDesc() {
		return valveDesc;
	}

	public void setValveDesc(String valveDesc) {
		this.valveDesc = valveDesc;
	}

	@Override
	public String toString() {
		return "BomConfigurator [serialNumber=" + serialNumber + ", source=" + source + ", modifiedUser=" + modifiedUser
				+ ", modifiedOrg=" + modifiedOrg + ", modifiedDate=" + modifiedDate + ", reason=" + reason + ", remark="
				+ remark + ", finishModelNumber=" + finishModelNumber + ", tagNumber=" + tagNumber + ", temperature="
				+ temperature + ", capacity=" + capacity + ", asmeCodeStamp=" + asmeCodeStamp + ", cdtp=" + cdtp
				+ ", backPressure=" + backPressure + ", service=" + service + ", springNumberRange=" + springNumberRange
				+ ", valveType=" + valveType + "]";
	}
	

}
