
/*
 * Copyright (c) 2013 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */ 

package com.ge.fpt.welcomepkg.api;

import java.io.InputStream;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jws.WebService;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;


/**
 * Welcome Pkg service interface
 * 
 * @author 212414241
 */

@Path("/")
@WebService
public interface IWelcomePkgService {

	/**
	 * @param sso
	 *            of company
	 * @return list of OrderInfo Objects
	 */

	// @GET
	// @Path("orders/{sso}")
	// @Consumes(MediaType.APPLICATION_JSON)
	// @Produces(MediaType.APPLICATION_JSON)
	// List<OrderInfo> getOrdersBySSO(@PathParam("sso") String sso,
	// @DefaultValue(value="0") @QueryParam(value="page") int page,
	// @DefaultValue(value="100000") @QueryParam(value="rowsPerPage") int
	// rowsPerPage);
	// //List<OrderInfo> getOrdersBySSO(@PathParam("sso") String sso,
	// @DefaultValue(value="0") @QueryParam(value="page") int page);

	@POST
	@Path("orders/{sso}")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_JSON)
	List<OrderInfo> getOrdersBySSO(@PathParam("sso") String sso,
			@QueryParam(value = "page") int page,
			@QueryParam(value = "rowsPerPage") int rowsPerPage,
			@QueryParam(value = "sortCol") String sortCol,
			@QueryParam(value = "sortOrder") String sortOrder,
			@QueryParam(value = "globalSearch") String globalSearch,
			@QueryParam(value = "blanketSearch") boolean blanketSearch,
			@QueryParam(value = "serialNo") String serialNo,
			@QueryParam(value = "partNo") String partNo,
			@QueryParam(value = "tagNo") String tagNo,
			@QueryParam(value = "fileName") String fileName,
			@QueryParam(value = "engineeredValve") String engineeredValve,
			OrderInfo orderInfo);

	// List<OrderInfo> getOrdersBySSO(@PathParam("sso") String sso,
	// @DefaultValue(value="0") @QueryParam(value="page") int page);

	/**
	 * @param recSource
	 *            record source
	 * @param orderNumber
	 *            sales order number
	 * @return list of Equipment
	 */
	@GET
	@Path("equipment/{recSource}/{orderNumber}/{engineeredValve}/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<OrderEquipment> getEquipmentByRecSourceAndSalesOrder(
			@PathParam("recSource") String recSource,
			@PathParam("orderNumber") String orderNumber ,
			@PathParam("engineeredValve") String engineeredValve,
			@PathParam("sso") String sso);

	// List<OrderEquipment>
	// getEquipmentByRecSourceAndSalesOrder(@PathParam("recSource") String
	// recSource, @PathParam("orderNumber") String orderNumber,
	// @DefaultValue(value="0") @QueryParam(value="page") int page);

	/**
	 * @param recSource
	 *            record source
	 * @param serialNumber
	 *            equipment serial number
	 * @return list of Bom Objects
	 */
	@GET
	@Path("boms/{recSource}/{serialNumber}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<EquipmentBoms> getBomsByByRecSourceAndSerialNumber(
			@PathParam("recSource") String recSource,
			@PathParam("serialNumber") String serialNumber,
			@DefaultValue(value = "NA") @QueryParam(value = "region") String region,
			@DefaultValue(value = "USD") @QueryParam(value = "currency") String currency);

	/**
	 * @param cartName
	 *            RSP cart name to save
	 */
	@POST
	@Path("rsp/save")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	void saveRSPCartData(
			@QueryParam(value = "cartName") @DefaultValue(value = "") String cartName);

	/**
	 * @param lookupData
	 *            sales order, serial number, rec source for looking up
	 *            equipment
	 * @return full list of Equipment based on lookup data
	 */
	@POST
	@Path("rsp/getequipment")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<OrderEquipment> getEquipmentBySalesOrderSerialNumberRecSource(
			EquipLookupData[] lookupData);

	@GET
	@Path("test/get")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<TestData> getTestData(
			@QueryParam(value = "value1") @DefaultValue(value = "0") String val1,
			@QueryParam(value = "value2") @DefaultValue(value = "0") String val2);

	@POST
	@Path("test/post")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<TestData> postTestData(TestData[] testData);

	@POST
	@Path("rsp/addtocart/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	UpdateCartResponse addToRSPCart(
			@PathParam(value = "sso") @DefaultValue(value = "") String sso,
			OrderEquipment[] saveData);

	@GET
	@Path("rsp/getcartcount/{sso}")
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	int getCartCount(@PathParam(value = "sso") String sso);

	@POST
	@Path("rsp/deletefromcart/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	UpdateCartResponse deleteFromRSPCart(@PathParam(value = "sso") String sso,
			Long[] valveInfoIds);

	@GET
	@Path("rsp/getcart/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<RSPCartData> getCurrentRSPCart(@PathParam(value = "sso") String sso);

	@POST
	@Path("rsp/savecart/{sso}")
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo saveCart(@PathParam(value = "sso") String sso, String cartName);

	@POST
	@Path("rsp/loadcart/{sso}")
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo loadCart(@PathParam(value = "sso") String sso, String cartName);

	@POST
	@Path("rsp/checkcartexists/{sso}")
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.APPLICATION_JSON)
	int checkCartExists(@PathParam(value = "sso") String sso, String cartName);

	@POST
	@Path("rsp/deletesavedcart/{sso}")
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo deleteSavedCart(@PathParam(value = "sso") String sso,
			String cartName);

	@GET
	@Path("rsp/deleteallfromcart/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo deleteAllFromRSPCart(@PathParam(value = "sso") String sso);

	@GET
	@Path("rsp/getsavedcarts/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<String> getSavedCarts(@PathParam(value = "sso") String sso);

	@GET
	@Path("user/loadsettings/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	UserSettings loadUserSettings(@PathParam(value = "sso") String sso);

	@POST
	@Path("user/savesettings/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo saveUserSettings(@PathParam(value = "sso") String sso,
			UserSettings saveData);

	@POST
	@Path("pricetool")
	@Consumes({ "application/xml" })
	@Produces({ "application/json" })
	List<PriceToolData> getPriceToolList(
			PriceToolSearchCriteria paramPriceToolSearchCriteria);

	@GET
	@Path("currencycode")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	List<DropDownItem> getCurrencyCodeList();

	@GET
	@Path("region")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	List<DropDownItem> getRegionList();

	@GET
	@Path("region/{sso}")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	List<DropDownItem> getRegionListByUser(@PathParam(value = "sso") String sso);

	@GET
	@Path("getpricetooluser")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	List<PriceToolUser> getPriceToolUser();

	@POST
	@Path("savepricetooluser/{sso}")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	StatusInfo savePriceToolUser(@PathParam(value = "sso") String sso,
			PriceToolUser priceToolUser);

	@POST
	@Path("deletepricetooluser")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	StatusInfo deletePriceToolUser(PriceToolUser priceToolUser);

	@GET
	@Path("getvalidadminuser/{sso}")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	boolean getValidAdminUser(@PathParam(value = "sso") String sso);

	@GET
	@Path("getvalidpricetooluser/{sso}")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	boolean getValidPriceToolUser(@PathParam(value = "sso") String sso);

	@GET
	@Path("convertorder/{sso}/{orderNum}/{recSource}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo convertOrder(@PathParam(value = "sso") String sso,
			@PathParam(value = "orderNum") Long orderNum,
			@PathParam(value = "recSource") String recSource);

	@GET
	@Path("getuserdata/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	UserData getUserData(@PathParam(value = "sso") String sso);

	// @GET
	// @Path("ordercount/{sso}")
	// @Consumes(MediaType.APPLICATION_JSON)
	// @Produces(MediaType.APPLICATION_JSON)
	// int getOrdersCount(@PathParam(value="sso") String sso);

	@POST
	@Path("ordercount/{sso}")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_JSON)
	int getOrdersCount(@PathParam(value = "sso") String sso,
			@QueryParam(value = "globalSearch") String globalSearch,
			@QueryParam(value = "blanketSearch") boolean blanketSearch,
			@QueryParam(value = "serialNo") String serialNo,
			@QueryParam(value = "partNo") String partNo,
			@QueryParam(value = "tagNo") String tagNo,
			@QueryParam(value = "fileName") String fileName, 
			@QueryParam(value = "engineeredValve") String engineeredValve,
			OrderInfo orderInfo);

	@POST
	@Path("dashboardorders/{sso}")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_JSON)
	List<OrderInfo> getOrdersByDUNS(@PathParam(value = "sso") String sso,
			@QueryParam(value = "type") String type,
			@QueryParam(value = "duns") String duns,
			@QueryParam(value = "year") String year,
			@QueryParam(value = "month") String month,
			@QueryParam(value = "pc") String pc,
			@QueryParam(value = "page") int page,
			@QueryParam(value = "rowsPerPage") int rowsPerPage,
			@QueryParam(value = "sortCol") String sortCol,
			@QueryParam(value = "sortOrder") String sortOrder,
			@QueryParam(value = "globalSearch") String globalSearch,
			OrderInfo orderInfo) throws ParseException;

	@POST
	@Path("dashboardordercount/{sso}")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_JSON)
	int getOrderCountByDUNS(@PathParam(value = "sso") String sso,
			@QueryParam(value = "type") String type,
			@QueryParam(value = "duns") String duns,
			@QueryParam(value = "year") String year,
			@QueryParam(value = "month") String month,
			@QueryParam(value = "pc") String pc,
			@QueryParam(value = "globalSearch") String globalSearch,
			OrderInfo orderInfo) throws ParseException;

	@GET
	@Path("getsalesorderbyso/{sso}/{salesorder}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<OrderInfo> getOrdersBySalesOrder(@PathParam(value = "sso") String sso,
			@PathParam(value = "salesorder") String salesorder);

	@POST
	@Path("updatesalesorderinfo/{sso}")
	@Consumes({ "application/xml" })
	@Produces({ "application/json" })
	StatusInfo UpdateSalesOrderInfo(@PathParam(value = "sso") String sso,
			OrderInfo orderinfo);

	@GET
	@Path("countrycode")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	List<DropDownItem> getCountryCodeList();

	@GET
	@Path("enduserindustry")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	List<DropDownItem> getEndUserIndustryList();

	@GET
	@Path("autocomplete/{sso}")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	List<String> getAutocompleteDataList(@PathParam(value = "sso") String sso,
			@QueryParam(value = "col") String col,
			@QueryParam(value = "input") String input);

	@POST
	@Path("rsp/getEquipmentbysn")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	List<OrderEquipment> getEquipmentBySn(EquipLookupData lookupData);

	@POST
	@Path("rsp/updateequipment/{sso}")
	@Consumes({ "application/xml" })
	@Produces({ "application/json" })
	StatusInfo updateEquipment(@PathParam(value = "sso") String sso,
			OrderEquipment orderEquipment);

	@POST
	@Path("bom/getpartno/{recsource}/{serialno}")
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.APPLICATION_JSON)
	List<String> getPartNo(@PathParam(value = "recsource") String recsource,
			@PathParam(value = "serialno") String serialno, String partNo);

	@POST
	@Path("bom/partdesc/{recsource}")
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.APPLICATION_JSON)
	List<String> getPartDesc(@PathParam(value = "recsource") String recsource,
			String partNo);

	@POST
	@Path("bom/deletepartheader/{sso}")
	@Consumes({ "application/xml" })
	@Produces({ "application/json" })
	StatusInfo deletePartHeader(@PathParam(value = "sso") String sso,
			EquipmentBoms equipmentBoms);

	@POST
	@Path("bom/savepartheader/{serialNumber}/{recSource}/{sso}")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	StatusInfo savePartHeader(
			@PathParam(value = "serialNumber") String serialNumber,
			@PathParam(value = "recSource") String recSource,
			@PathParam(value = "sso") String sso, EquipmentBoms[] equipmentBoms);

	/*
	 * @POST
	 * 
	 * @Path("orderlist")
	 * 
	 * @Consumes({"application/xml"})
	 * 
	 * @Produces({"application/json"}) List orderList(OrderEquipment
	 * orderEquipment);
	 */

	@GET
	@Path("statelist/{country}")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	List<DropDownItem> getStateList(@PathParam(value = "country") String country);

	@POST
	@Path("ExcelUpload")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo getExcelFileToUpload(@RequestBody HashMap excelData);

	@GET
	@Path("channeldatabysso/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<ChannelData> channelDataBySso(@PathParam(value = "sso") String sso);

	@POST
	@Path("savechanneldata")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo saveChannelData(@RequestBody ChannelData channelData);

	@POST
	@Path("channeldata")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<ChannelData> getChannelData(@QueryParam(value = "pageNo") int pageNo,
			@QueryParam(value = "rowperpage") int rowperpage,
			@RequestBody ChannelData channelData);

	@POST
	@Path("channeldatacount")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	int getChannelDataCount(@RequestBody ChannelData channelData);

	@GET
	@Path("partDataByPartInfoId/{partInfoId}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<PartData> partDataByPartInfoId(
			@PathParam(value = "partInfoId") String partInfoId);

	@POST
	@Path("savepartdata/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo savePartData(@PathParam(value = "sso") String sso,
			@RequestBody PartData partData);

	@POST
	@Path("partdata")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<PartData> getPartData(@QueryParam(value = "pageNo") int pageNo,
			@QueryParam(value = "rowperpage") int rowperpage,
			@RequestBody PartData partData);

	@POST
	@Path("partdatacount")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	int getPartDataCount(@RequestBody PartData partData);

	@GET
	@Path("spareindicator")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<DropDownItem> getSpareIndicatorList();

	@GET
	@Path("stocktype")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<DropDownItem> getStockTypeList();

	@GET
	@Path("recsource")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<DropDownItem> getRecsourceList();

	@GET
	@Path("companyfromduns/{duns}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List getCompanyFromDuns(@PathParam(value = "duns") String duns);

	@GET
	@Path("vkreportdata/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<VKReportData> getVKReportData(@PathParam(value = "sso") String sso,
			@QueryParam("region") String region,
			@QueryParam("currency") String currency);

	@POST
	@Path("getPartDetails")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<PartDataComponents> getPartDetails(@RequestBody HashMap partData);

	@POST
	@Path("getComponentDetails")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<PartDetailsOfComponent> getComponentDetails(
			@RequestBody HashMap componentData);

	@GET
	@Path("getvalidenggadminuser/{sso}")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	boolean getValidEnggAdminUser(@PathParam(value = "sso") String sso);

	@POST
	@Path("componentDesc")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List getcomponentDesc(@RequestBody HashMap partAndComponentData);

	@POST
	@Path("saveParentPartDetails")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo saveParentPartDetails(
			@RequestBody List<PartDataComponents> partData);

	@POST
	@Path("partDataFileUpload")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo getPartDataToUpload(@RequestBody HashMap excelData);

	@POST
	@Path("assemblyDataFileUpload")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo getAssemblyDataToUpload(@RequestBody HashMap excelData);

	@GET
	@Path("configuratoroption")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<DropDownItem> getConfiguratorOption();

	@POST
	@Path("savebomconfigurator/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo saveBomConfigurator(@PathParam(value = "sso") String sso,
			@RequestBody BomConfigurator bomConfigurator);

	@GET
	@Path("getbomconfigurator")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<BomConfigurator> getBomConfigurator(
			@QueryParam(value = "serialNumber") String serialNumber,
			@QueryParam(value = "recSource") String recSource);

	@POST
	@Path("inventoryDataFileUpload")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo uploadInventory(@RequestBody HashMap excelData);

	@POST
	@Path("getinventory")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<Inventory> getInventory(@RequestBody Inventory inventory);

	@GET
	@Path("getsiteinfo/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<DropDownItem> getSiteInfo(@PathParam(value = "sso") String sso);

	@POST
	@Path("reportService/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<Report> getReportData(@RequestBody ReportData reportData,
			@PathParam(value = "sso") String sso);

	@POST
	@Path("cplocation")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<CpLocationInfo> getLocationData(
			@QueryParam(value = "pageNo") int pageNo,
			@QueryParam(value = "rowperpage") int rowperpage,
			@RequestBody CpLocationInfo cpLocationInfo);

	@POST
	@Path("savecplocation")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo saveCpLocationData(@RequestBody CpLocationInfo locationInfo);

	@POST
	@Path("cplocationdatacount")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	int getCpLocationDataCount(@RequestBody CpLocationInfo cpLocationInfo);

	@POST
	@Path("deletecplocation")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo deleteCpLocation(@RequestBody CpLocationInfo cpLocationInfo);

	@GET
	@Path("serialnumbers/{serial}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<String> getEquipments(@PathParam(value = "serial") String serial);

	@GET
	@Path("recsources/{serial}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<String> getRecSources(@PathParam(value = "serial") String serial);

	@GET
	@Path("shipDates")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	Map<String, String> getShippingDate(
			@QueryParam(value = "rec") String recSource,
			@QueryParam(value = "serial") String serial);

	@POST
	@Path("saveequipmentinplant")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo saveequipment(@RequestBody PlantEquipment equipment);

	@POST
	@Path("plantequipmentcount")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	int getEquipmentCountinPlant(@RequestBody PlantEquipment equipment)
			throws Exception;

	@POST
	@Path("equipmentsinPlant")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<PlantEquipment> getEquipmentinPlant(
			@QueryParam(value = "pageNo") int pageNo,
			@QueryParam(value = "rowperpage") int rowsPerpage,
			@RequestBody PlantEquipment equipment);

	@POST
	@Path("deleteequipment")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo deleteEquipment(@RequestBody PlantEquipment equipment);

	@POST
	@Path("plantdata")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<PlantData> getPlantData(@QueryParam(value = "pageNo") int pageNo,
			@QueryParam(value = "rowperpage") int rowperpage,
			@RequestBody PlantData plantData);

	@POST
	@Path("plantdatacount")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	int getPlantDataCount(@RequestBody PlantData plantData);

	@POST
	@Path("saveplantdata")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo savePlantData(@RequestBody PlantData plantData);

	@GET
	@Path("plantDataByPlantId/{plantId}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<PlantData> plantDataByPlantId(
			@PathParam(value = "plantId") String plantId);

	@POST
	@Path("deletePlantdata")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo deletePlantdata(@RequestBody PlantData plantData);

	@GET
	@Path("getinventoryuser")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	List<InventoryUser> getInventoryUser();

	@POST
	@Path("saveinventoryuser/{sso}")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	StatusInfo saveInventoryUser(@PathParam(value = "sso") String sso,
			InventoryUser inventoryUser);

	@POST
	@Path("deleteinventoryuser")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	StatusInfo deleteInventoryUser(InventoryUser inventoryUser);

	@GET
	@Path("getvalidinventoryuser/{sso}")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	boolean getValidInventoryUser(@PathParam(value = "sso") String sso);

	@POST
	@Path("exportExcel/{sso}")
	@Consumes({ "application/json" })
	@Produces({ "application/vnd.ms-excel" })
	byte[] exportExcel(@RequestBody ReportData reportData,
			@PathParam(value = "sso") String sso);

	@POST
	@Path("exportPDF/{sso}")
	@Consumes({ "application/json" })
	@Produces({ "application/pdf" })
	byte[] exportPDF(@RequestBody ReportData reportData,
			@PathParam(value = "sso") String sso);

	@POST
	@Path("getPartCrossRefData")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<PartLookupData> getPartCrossRefData(@RequestBody PartLookupData part);

	@GET
	@Path("blanketEquipment")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	List<OrderEquipment> getBlanketEquipment( 
			@QueryParam(value = "col") String sso,
			@QueryParam(value = "val") String val,
			@QueryParam(value = "sso1") String sso1);

	@POST
	@Path("emailService/{sso}")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	StatusInfo getEmailDetails(@RequestBody Map mailDetails,
			@PathParam(value = "sso") String sso);

	@POST
	@Path("upgradeInfo")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<UpgradeInfo> getUpgradeInfo(@QueryParam(value = "pageNo") int pageNo,
			@QueryParam(value = "rowperpage") int rowperpage,
			@RequestBody UpgradeInfo upgradeInfo);

	@POST
	@Path("upgradeInfoCount")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	int getUpgradeInfoCount(@RequestBody UpgradeInfo upgradeInfo);

	@POST
	@Path("upgradeOptions")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<UpgradeOptions> getUpgradeOptions(
			@QueryParam(value = "pageNo") int pageNo,
			@QueryParam(value = "rowperpage") int rowperpage,
			@RequestBody UpgradeOptions upgradeOptions);

	@POST
	@Path("upgradeOptionsCount")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	int getUpgradeOptionsCount(@RequestBody UpgradeOptions upgradeOptions);

	@POST
	@Path("saveUpgradeInfo")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo saveUpgradeInfo(@RequestBody UpgradeInfo upgradeInfo);

	@POST
	@Path("saveUpgradeOptions")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo saveUpgradeOptions(@RequestBody UpgradeOptions upgradeOptions);

	/*@GET
	@Path("getModelData")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	Boolean getModelData(@QueryParam(value = "model") String model);*/

	@POST
	@Path("getPartOrModelData")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	Boolean getPartOrModelData(@RequestBody UpgradePartModel partModel);

	@POST
	@Path("deleteUpgradeLegacyPnModel")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo deleteUpgradeLegacyPnModel(
			@RequestBody UpgradePartModel upgradePartModel);

	@POST
	@Path("deleteUpgradeOptionsDetailsPartModel")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo deleteUpgradeOptionsDetailsPartModel(
			@RequestBody UpgradeOptionDetails upgradeOptionDetails);

	

	@GET
	@Path("getvalidrcaccountmgmtuser/{sso}")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	boolean getValidRCAccountMgmtUser(@PathParam(value = "sso") String sso);
	
	
	@GET
	@Path("getvalidrccustomermgmtuser/{sso}")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	boolean getValidRCCustomerMgmtUser(@PathParam(value = "sso") String sso);
	
	@GET
	@Path("getvalidrcproductmgmtuser/{sso}")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	boolean getValidRCProductMgmtUser(@PathParam(value = "sso") String sso);
	
	
	@GET
	@Path("getvalidupgrademgmtuser/{sso}")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	boolean getValidUpgradeMgmtUser(@PathParam(value = "sso") String sso);

	@GET
	@Path("upgradeOptionsUI/{sso}/{region}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<DropDownItem> getUpgradeOptionsUI(@PathParam(value = "sso") String sso,
			@PathParam(value = "region") String region);

	@POST
	@Path("getUpgrades")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_JSON)
	List<EquipmentBoms> getUpgradesByUpgradename(
			@QueryParam(value = "page") int page,
			@QueryParam(value = "rowsPerPage") int rowsPerPage,
			@QueryParam(value = "globalSearch") String globalSearch,
			@QueryParam(value = "sortCol") String sortCol,
			@QueryParam(value = "sortOrder") String sortOrder,
			@QueryParam(value = "upgradeId") int upgradeId,
			@QueryParam(value = "dunsNumber") String dunsNumber,
			@RequestBody EquipmentBoms equipmentboms);

	@POST
	@Path("getUpgradesForGEUsers")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_JSON)
	List<EquipmentBoms> getUpgradesByUpgradenameForGEUsers(
			@QueryParam(value = "page") int page,
			@QueryParam(value = "rowsPerPage") int rowsPerPage,
			@QueryParam(value = "globalSearch") String globalSearch,
			@QueryParam(value = "sortCol") String sortCol,
			@QueryParam(value = "sortOrder") String sortOrder,
			@QueryParam(value = "upgradeId") int upgradeId,
			@RequestBody EquipmentBoms equipmentboms);

	@POST
	@Path("getUpgradesCount")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_JSON)
	int getUpgradesCount(@QueryParam(value = "globalSearch") String globalSearch,@QueryParam(value = "upgradeId") int upgradeId,
			@QueryParam(value = "dunsNumber") String dunsNumber,
			@RequestBody EquipmentBoms equipmentboms);

	
	@POST
	@Path("getUpgradesCountForGEUsers")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_JSON)
	int getUpgradesCountForGEUsers(@QueryParam(value = "globalSearch") String globalSearch,@QueryParam(value = "upgradeId") int upgradeId,
			@RequestBody EquipmentBoms equipmentboms);
	
	
	@GET
	@Path("partdata/{recSource}/{serialNumber}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<EquipmentBoms> getPartDataByByRecSourceAndSerialNumber(
			@PathParam("recSource") String recSource,
			@PathParam("serialNumber") String serialNumber,
			@DefaultValue(value = "NA") @QueryParam(value = "region") String region,
			@DefaultValue(value = "USD") @QueryParam(value = "currency") String currency);


	@POST
    @Path("angolaReportService/{sso}")
    @Consumes({"application/json"})
    @Produces({"application/vnd.ms-excel"})
    byte[] angolaReportService(@RequestBody Map reportParam,@PathParam(value="sso") String sso);
	
	@GET
	@Path("getOptionNames/{upgradeId}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<UpgradeOptions> getOptionsByUpgradeId(@PathParam("upgradeId") String upgradeId);


	@GET
	@Path("getUpgradeCoupon/{upgradeId}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	UpgradeInfo getUpgradeCoupon(@PathParam("upgradeId") String upgradeId);
	
	@POST
	@Path("savePromotionalCart/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	UpdateCartResponse addToPromotionalCart(
			@PathParam(value = "sso") @DefaultValue(value = "") String sso,
			PromotionalCart saveData);

	@POST
	@Path("checkUpgradeAlreadyExist/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	Boolean checkUpgradeExist(@PathParam(value = "sso") @DefaultValue(value = "") String sso,PromotionalCart saveData);

	@GET
	@Path("promo/getpromotionalcart/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<PromotionalCartViewData> getPromotionalCartData(@PathParam(value = "sso") String sso);
	
	@GET
	@Path("promo/getpromotionalcartcount/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	int getPromotionalCartCount(@PathParam(value = "sso") String sso);
	
	@GET
	@Path("promo/getsavedpromotionalcart/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<String> getSavedPromotionalCarts(@PathParam(value = "sso") String sso);
	
	@POST
	@Path("promo/savepromotionalcartname/{sso}")
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo savePromotionalCart(@PathParam(value = "sso") String sso, String cartName);
	
	@POST
	@Path("promo/checkpromotionalcartexists/{sso}")
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.APPLICATION_JSON)
	int checkPromotionalCartExists(@PathParam(value = "sso") String sso, String cartName);
	

	@POST
	@Path("promo/loadpromotionalcart/{sso}")
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo loadPromotionalCart(@PathParam(value = "sso") String sso, String cartName);
	
	
	@POST
	@Path("promo/deletepromotionfromcart/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo deletePromotionFromCart(@PathParam(value = "sso") String sso,
			@RequestBody PromotionalCartViewData promotionalCartViewData);
	
	@GET
	@Path("promo/deleteallpromotionfromcart/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo deleteAllPromotionFromCart(@PathParam(value = "sso") String sso);
	
	@POST
	@Path("rsp/saveistorestatus/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo saveCartStatus(@PathParam(value = "sso") String sso, Map<String,String> data);

	@POST
	@Path("rsp/getistorestatus/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<String> getCartStatus(@PathParam(value = "sso") String sso, Map<String,String> data);
	
	@POST
	@Path("promo/saveupgradeoptionquantity/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo saveQuantity(@PathParam(value = "sso") String sso,@RequestBody PromotionalCartViewData promotionalcartViewData);
	
	@GET
	@Path("emailNotification")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo sendNotification();
	

	@POST
	@Path("installbase/installbasegeovalues")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	HeatMapOverlayData getInstallBaseZipcodes(@RequestBody InstallBaseFilter installBaseFilter);
	
	@POST
	@Path("installbase/installbasegeovaluesWithDuns")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	InstalledBaseWithDuns getInstallBaseZipcodesWithDuns(@RequestBody InstallBaseFilter installBaseFilter);

	
	@POST
	@Path("installbase/installedvalveinfo")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<InstalledValveInfo> getInstalledValveInfo(@QueryParam(value = "pageNo") int pageNo,
			@QueryParam(value = "rowperpage") int rowperpage,
			@RequestBody InstalledValveInfo installedValveInfo);
	
	@POST
	@Path("installbase/installedvalveinfocount")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	int getInstalledValveInfoCount(@RequestBody InstalledValveInfo installedValveInfo);
	
	@GET
	@Path("channel/{productcode}")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	List<DropDownItem> getChannelList(@PathParam(value="productcode") String productCode);

	@GET
	@Path("deletekitcomponent/{sso}/{partNo}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo deleteKitComponent(@PathParam(value = "sso") String sso, @PathParam(value = "partNo") String partNo);

	@POST
	@Path("rsp/getcartpc/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	int getCartPC(@PathParam(value = "sso") String sso, Map<String,String> data);
	
	@POST
	@Path("vkstgreportdata")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<VKSTGReportData> getVKSTGReportData(@RequestBody Map param);
	
	@GET
	@Path("orderinfo")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	OrderInfo getSalesorderInfo(@QueryParam(value="sso") String sso, @QueryParam(value="order") String orderId,@QueryParam(value="recsource") String recSource); 
	
	@POST
	@Path("digitalDataFileUpload")
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo digitalDataFileUpload(@RequestBody InputStream digitalFile,@Context HttpHeaders httpHeaders) ;
	
	@GET
	@Path("getchannelsettingsproduct/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<String> getChannelSettingsProduct(@PathParam(value = "sso") String sso);
	
	@POST
	@Path("accountdata")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<AccountData> getAccountData(@QueryParam(value = "pageNo") int pageNo,
			@QueryParam(value = "rowperpage") int rowperpage,
			@QueryParam(value = "sortCol") String sortCol,
			@QueryParam(value = "sortOrder") String sortOrder,
			@RequestBody AccountData accountData);
	
	@POST
	@Path("accountdatacount")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	int getAccountdatacount(@RequestBody AccountData accountData);
	
	@POST
	@Path("saveaccountdata")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo saveAccountData(@RequestBody AccountData accountData);
	
	@POST
	@Path("deleteAccountdata")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo deleteAccountdata(@RequestBody AccountData accountData);
	
	
	@POST
	@Path("customerdata")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<CustomerData> getCustomerdata(@QueryParam(value = "pageNo") int pageNo,
			@QueryParam(value = "rowperpage") int rowperpage,
			@QueryParam(value = "sortCol") String sortCol,
			@QueryParam(value = "sortOrder") String sortOrder,
			@RequestBody CustomerData customerdata);
	
	@POST
	@Path("customerdatacount")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	int getCustomerdatacount(@RequestBody CustomerData customerdata);
	
	@POST
	@Path("savecustomerdata")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo saveCustomerdata(@RequestBody CustomerData customerdata);
	
	@POST
	@Path("deletecustomerdata")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo deleteCustomerdata(@RequestBody CustomerData customerdata);
	
	@POST
	@Path("productdata")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<ProductData> getProductdata(@QueryParam(value = "pageNo") int pageNo,
			@QueryParam(value = "rowperpage") int rowperpage,
			@QueryParam(value = "sortCol") String sortCol,
			@QueryParam(value = "sortOrder") String sortOrder,
			@RequestBody ProductData productdata);
	
	@POST
	@Path("productdatacount")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	int getProductdatacount(@RequestBody ProductData productdata);
	
	@POST
	@Path("saveproductdata")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo saveProductdata(@RequestBody ProductData productdata);
	
	@POST
	@Path("deleteproductdata")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo deleteProductdata(@RequestBody ProductData productdata);
	
	
	@POST
	@Path("recipdata")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<RecipData> getRecipData(@QueryParam(value = "pageNo") int pageNo,
			@QueryParam(value = "rowperpage") int rowperpage,
			@QueryParam(value = "globalSearch") String globalSearch,
			@QueryParam(value = "sortCol") String sortCol,
			@QueryParam(value = "sortOrder") String sortOrder,
			@RequestBody RecipData recipData);
	
/* Sindhura : ServiceNow Changes : Start */
	
	@GET
	@Path("selectChannelPartnerName")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<DropDownItem> selectChannelPartnerName();
	
	
	@GET
	@Path("getCPusername")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<ChannelData> getCPusernames(@QueryParam(value = "channelname")String channelname);
	
	@GET
	@Path("getLoggedUserInfo/{loggedUser}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	ChannelData getLoggedUserInfo(@PathParam(value = "loggedUser") String loggedUser);
	
	@GET
	@Path("getLoggedUserInfoForCP/{loggedUserSubmitter}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	ChannelData getLoggedUserInfoForCP(@PathParam(value = "loggedUserSubmitter") String loggedUserSubmitter);
	
	@GET
	@Path("getChannelPartnerName")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<String> getChannelPartnerName();
	
	@GET
	@Path("getSerialNumberForValve/{serialNumberValue}/{newvalve}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<SerialNoDetails> getSerialNumberForValve(@PathParam(value = "serialNumberValue") String serialNumberValue,@PathParam(value = "newvalve") String newvalve);

	@GET
	@Path("getUserDataFromCP/{channelpartnername}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	ChannelData getUserDataFromCP(@PathParam(value = "channelpartnername") String channelpartnername);

	/* Sindhura : ServiceNow Changes : End */
	
	@POST
	@Path("recipdatacount")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	int getRecipDataCount(@QueryParam(value = "globalSearch") String globalSearch,@RequestBody RecipData recipData);

	@POST
	@Path("recipparts")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<EquipmentBoms> getRecipPartData(@QueryParam(value = "pageNo") int pageNo,
			@QueryParam(value = "rowperpage") int rowperpage,
			@RequestBody RecipData recipData);
	
	@POST
	@Path("recippartsdatacount")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	int getRecipPartsDataCount(@RequestBody RecipData recipData);

	@POST
	@Path("updaterecipdata")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo updateRecipdata(RecipData recipData);
	
	@POST
	@Path("addrecipdata")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo addRecipdata(RecipData recipData);

	/*@GET
	@Path("getvalidrcuser")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	boolean getRcUser(String sso);*/
	
	@GET
	@Path("customerName/{customerName}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<String> getCustomerName(@PathParam(value = "customerName") String customerName);
	
	@GET
	@Path("accountManagerName/{accountManagerName}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<String> getAccountManagerName(@PathParam(value = "accountManagerName") String accountManagerName);
	
	@GET
	@Path("productName/{productName}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<String> getProductName(@PathParam(value = "productName") String productName);
		
	@POST
	@Path("saveFilePath")
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo saveFilePath(@QueryParam(value = "serialNumber") String serialNumber,
			@QueryParam(value = "recSource") String recSource,
			@QueryParam(value = "fileNameToSave") String fileName,
			@QueryParam(value = "pathToSave") String filePath) ;
	
	@POST
	@Path("serialDigitalUpload")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo getSerialDigitalUpload(@RequestBody HashMap excelData);
	
	@POST
	@Path("saveequipmentdigital")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	String saveEquipmentDigital(@RequestBody DigitalEquipmentData digitalEquipmentData);
	
	
	@POST
	@Path("savebomdigital/{valveInfoId}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo saveBomDigital(@PathParam(value = "valveInfoId") String valveInfoId,@RequestBody List<DigitalBOMData> digitalBomData);
	
	/*@GET
	@Path("cnDataInfo/{serialNumber}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	CnDataInfo getCnDataInfo(@PathParam(value = "serialNumber") String serialNumber);*/
	
	//Sindhura : Start :Delete functionality for upgrade module
	
	@GET
	@Path("deletedprogram/{programupgradeId}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo upgradeprogramdelete( @PathParam(value = "programupgradeId") String programupgradeId);
	
	@GET
	@Path("deletedoptions/{newupgradeId}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo upgradeoptionsdelete( @PathParam(value = "newupgradeId") String newupgradeId);
	
	@GET
	@Path("deletedoptionsById/{newupgradeId}/{programOptionId}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	StatusInfo deletedoptionById( @PathParam(value = "newupgradeId") String newupgradeId, @PathParam(value = "programOptionId") String programOptionId);
	
	//Sindhura : End : Delete functionality for upgrade module	
	//alfresco service 
	
	@GET
	@Path("getAllDocDetails")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<DocumentDetails> getAllDocDetails(@QueryParam("serialNumber") String serialNumber);

	

	@GET
	@Path("downloadDocuments/{serialNumber}/{docName}")
	@Produces(MediaType.APPLICATION_JSON)
	List<DocumentDetails> downloadDocument(@PathParam("serialNumber")String serialNumber,@PathParam("docName") List<String> docName);

	/*------------------------CICS Services-----------*/
	
	
	
	@GET
	@Path("getPartNumberData/{searchBy}/{partNo}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<PartMasterData> getPartNumberData(@PathParam("searchBy") String searchBy,
			@PathParam("partNo") String partNo,
			@DefaultValue(value = "1") @QueryParam(value = "startPartIndex") Integer startPartIndex,
			@DefaultValue(value = "11") @QueryParam(value = "endPartIndex") Integer endPartIndex);
	
	
	

	@GET
	@Path("getSubPartNumberData/{searchBy}/{partNo}/{subPartNo}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<PartMasterData> getSubPartNumberData(@PathParam("searchBy") String searchBy,
			@PathParam("partNo") String partNo, @PathParam("subPartNo") String subPartNo,
			@DefaultValue(value = "1") @QueryParam(value = "startPartIndex") Integer startPartIndex,
			@DefaultValue(value = "11") @QueryParam(value = "endPartIndex") Integer endPartIndex);
	
	
	
	@GET
	@Path("getPartDataOnClick/{partNo}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<PartMasterData1> getPartDataOnClick(@PathParam("partNo") String partNo);

	
	@GET
	@Path("getWhereusedData/{partNo}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<BomWhereusedData> getWhereusedData(@PathParam("partNo") String partNo,
			@QueryParam(value = "startIndex") Integer startIndex,
			@QueryParam(value = "endIndex") Integer endIndex);
	
	@GET
	@Path("getBOMData/{partNo}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<BomWhereusedData> getBOMData(@PathParam("partNo") String partNo, @QueryParam(value = "startIndex") Integer startIndex, @QueryParam(value = "endIndex") Integer endIndex);


	@GET
	@Path("getTurboCharger")
	@Produces(MediaType.APPLICATION_JSON)
	List<TurboDropDown> getTurboChargerDropDownValues();
	
	//added by sujeet
		
		
		@GET
		@Path("getplantdatamaster/{customerId}/{sso}")
		@Consumes(MediaType.APPLICATION_JSON)
		@Produces(MediaType.APPLICATION_JSON)
		List<PlantDataManagmentMaster> getPlantDataMaster(@PathParam(value = "customerId") String customerId,@PathParam(value = "sso") String sso);

		@GET
		@Path("getcustomerdatamaster/{sso}")
		@Consumes(MediaType.APPLICATION_JSON)
		@Produces(MediaType.APPLICATION_JSON)
		List<CustomerDataManagmentMaster> getCustomerDataMaster(@PathParam(value = "sso") String sso);
		
		@POST
		@Path("savecustomerdatamaster/{sso}")
		@Consumes({ "application/json" })
		@Produces({ "application/json" })
		StatusInfo saveCustomerDataMaster(@PathParam(value = "sso") String sso,CustomerDataManagmentMaster customerDataManagmentMaster);
		
		@POST
		@Path("saveplantdatamaster/{sso}")
		@Consumes({ "application/json" })
		@Produces({ "application/json" })
		StatusInfo savePlantDataMaster(@PathParam(value = "sso") String sso,PlantDataManagmentMaster plantDataManagmentMaster);
		
		@POST
		@Path("editplantdatamaster/{sso}")
		@Consumes({ "application/json" })
		@Produces({ "application/json" })
		StatusInfo editplantdatamaster(@PathParam(value = "sso") String sso,PlantDataManagmentMaster plantDataManagmentMaster);
		
		@POST
		@Path("saveusersdatamaster/{sso}")
		@Consumes({ "application/json" })
		@Produces({ "application/json" })
		StatusInfo saveUsersDataMaster(@PathParam(value = "sso") String sso,@RequestBody UsersDataManagmentMaster usersDataManagmentMaster);
		
		@POST
		@Path("editusersdatamaster/{sso}")
		@Consumes({ "application/json" })
		@Produces({ "application/json" })
		StatusInfo editUsersDataMaster(@PathParam(value = "sso") String sso,@RequestBody UsersDataManagmentMaster usersDataManagmentMaster);

		
		@GET
		@Path("getusersdatamaster/{customerId}")
		@Consumes(MediaType.APPLICATION_JSON)
		@Produces(MediaType.APPLICATION_JSON)
		List<UsersDataManagmentMaster> getUsersDataMaster(@PathParam(value = "customerId") String customerId);
		
		@GET
		@Path("getcustomerdatamanagement/{customerId}")
		@Consumes(MediaType.APPLICATION_JSON)
		@Produces(MediaType.APPLICATION_JSON)
		List<OrderEquipment> getCustomerDataManagement(@PathParam(value = "customerId") String customerId);
		
		@GET
		@Path("getcustomerforserial")
		@Consumes(MediaType.APPLICATION_JSON)
		@Produces(MediaType.APPLICATION_JSON)
		List<OrderEquipment> getCustomerForSerial();
		
		@GET
		@Path("upgradeNewInfo")
		@Consumes(MediaType.APPLICATION_JSON)
		@Produces(MediaType.APPLICATION_JSON)
		List<UpgradeInfoNew> getUpgradeNewInfo();
		
		@POST
		@Path("deleteUpgradeNew")
		@Consumes(MediaType.APPLICATION_JSON)
		@Produces(MediaType.APPLICATION_JSON)
		StatusInfo deleteUpgradeInfoByID(@RequestBody UpgradeInfoNewDTO upgradeInfoNewDTO);

		@POST
		@Path("upgradeNewInfoPartFileUpload")
		@Consumes(MediaType.APPLICATION_JSON)
		@Produces(MediaType.APPLICATION_JSON)
		StatusInfo getUpgradeNewInfoPartFileUpload(@RequestBody HashMap excelData);


		//end by sujeet
		
	       //@ashish
			@GET
			@Path("plantMasterDataBycustId/{customerId}")
			@Consumes(MediaType.APPLICATION_JSON)
			@Produces(MediaType.APPLICATION_JSON)
			List<PlantDataMaster> getplantMaster(@PathParam(value = "customerId") String customerId);
			
			//@ashish
			@GET
			@Path("getcustomermgmt")
			@Consumes(MediaType.APPLICATION_JSON)
			@Produces(MediaType.APPLICATION_JSON)
			public List<CustomerMgmtMaster> getcustomermgmt();

			@GET
			@Path("getcartData")
			@Consumes(MediaType.APPLICATION_JSON)
			@Produces(MediaType.APPLICATION_JSON)
			public List<CartData> getcartData();
			
			@POST
			@Path("addLinkingdata/{sso}")
			@Consumes(MediaType.APPLICATION_JSON)
			@Produces(MediaType.APPLICATION_JSON)
			public StatusInfo addLinkingdata(@PathParam(value = "sso") String sso,@RequestBody LinkingMasterTO linkingMasterTO);
			
			
			//@ashish
			@GET
			@Path("deleteplantMaster/{sso}/{customerId}")
			@Consumes(MediaType.APPLICATION_JSON)
			@Produces(MediaType.APPLICATION_JSON)
			StatusInfo deleteplantMaster(@PathParam(value = "sso") String sso, @PathParam(value = "customerId") String customerId);

			@GET
			@Path("deletecartData/{serialNumber}")
			@Consumes(MediaType.APPLICATION_JSON)
			@Produces(MediaType.APPLICATION_JSON)
			StatusInfo deleteCartData(@PathParam(value = "serialNumber") String serialNumber);

			@GET
			@Path("getRegionCoutryStatesDetails")
			@Consumes(MediaType.APPLICATION_JSON)
			@Produces(MediaType.APPLICATION_JSON)
			List<Region_Data> getRegionCoutryStatesDetails();

			
			@POST
			@Path("documentFileUpload")
			@Produces(MediaType.APPLICATION_JSON)
			StatusInfo documentFileUpload(@RequestBody InputStream digitalFile,@Context HttpHeaders httpHeaders) ;

		
			@POST
			@Path("saveFileForDataBook")
			@Produces(MediaType.APPLICATION_JSON)
			StatusInfo saveFileForDataBook(@QueryParam(value = "serialNumber") String serialNumber,
					@QueryParam(value = "docType") String docType,
					@QueryParam(value = "DocumentDescription") String DocumentDescription,
					@QueryParam(value = "FileName") String fileName,
					@QueryParam(value = "FileLINK") String fileLINK,
					@QueryParam(value = "language") String language) ;
			
			@POST
			@Path("saveFileForOthers")
			@Produces(MediaType.APPLICATION_JSON)
			StatusInfo saveFileForOthers(@QueryParam(value = "serialNumber") String serialNumber,
					@QueryParam(value = "docType") String docType,
					@QueryParam(value = "DocumentDescription") String DocumentDescription,
					@QueryParam(value = "FileName") String FileName,
					@QueryParam(value = "FileLINK") String FileLINK,
					@QueryParam(value = "language") String language) ;
			
			@GET
			@Path("getAllDocDownloadDetails")
			@Consumes(MediaType.APPLICATION_JSON)
			@Produces(MediaType.APPLICATION_JSON)
			List<OtherDocumentDetails> getAllDocDownloadDetails(@QueryParam("serialNumber") String serialNumber);

			
			@GET
			@Path("OtherMultipleDocumentsDownload/{serialNumber}/{docName}")
			@Produces(MediaType.APPLICATION_JSON)
			List<OtherDocumentDetails> OtherMultipleDocumentsDownload(@PathParam("serialNumber")String serialNumber,@PathParam("docName") List<String> docName,String docType);


			

			@POST
			@Path("getCustLinkData")
			@Consumes(MediaType.APPLICATION_JSON)
			@Produces(MediaType.APPLICATION_JSON)
			String getCustLinkData(@RequestBody SalesSerial salesSerial);

			//end by ashish
		
			@POST
			@Path("uploadUpgradeDocument")
			@Produces(MediaType.APPLICATION_JSON)
			StatusInfo uploadUpgradeDocument(@RequestBody InputStream digitalFile,@Context HttpHeaders httpHeaders) ;

			@POST
			@Path("saveUpgradeFile")
			@Produces(MediaType.APPLICATION_JSON)
			StatusInfo saveUpgradeFile(@QueryParam(value = "upgradeId") String upgradeId,
					@QueryParam(value = "optionId") String optionId,
					@QueryParam(value = "docContentType") String docContentType,
					@QueryParam(value = "docType") String docType,
					@QueryParam(value = "DocName") String DocName,
					@QueryParam(value = "FileLINK") String fileLINK,
					@QueryParam(value = "language") String language,
					@QueryParam(value = "sso") String sso) ;
			//Raj
			@GET
			@Path("getUpgradeNewInfo/{upgradeId}")
			@Consumes(MediaType.APPLICATION_JSON)
			@Produces(MediaType.APPLICATION_JSON)
			List<UpgradeInfo> getUpgradeNewInfo(@PathParam(value = "upgradeId") String upgradeId);
			
			//Siddhesh & RAJ
			@POST
			@Path("saveUpgradeNewInfo/{sso}")
			@Consumes(MediaType.APPLICATION_JSON)
			@Produces(MediaType.APPLICATION_JSON)
			StatusInfo saveUpgradeNewInfo(@PathParam(value = "sso") String sso,@RequestBody UpgradeInfo upgradeInfo);

			//Siddhes 
			@GET
			@Path("deleteUpgradePackageDocument/{documentID}")
			@Consumes(MediaType.APPLICATION_JSON)
			@Produces(MediaType.APPLICATION_JSON)
			StatusInfo deleteUpgradePackageDocument(@PathParam(value = "documentID") String documentID);



			@POST
			@Path("cpUpgradeInfo/{sso}/{region}")
			@Produces(MediaType.APPLICATION_JSON)
			List<CPUpgradeInfo> getCpUpgradesList(@PathParam(value = "sso") String sso,
					@PathParam(value = "region") String region, @RequestBody CPUpgradeInfo cpUpgradeInfo);
			
	@POST
	@Path("valvekeepXMLDataSync")
	@Consumes(MediaType.APPLICATION_JSON)
	public StatusInfo valvekeepXMLDataSync(@RequestBody List<String[]> xmlData);

	@POST
	@Path("saveFilePathValvekeep")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public StatusInfo saveFilePathValvekeep(@RequestBody ValvekeepUploadData vkUploadData);

	@POST
	@Path("getdocdata")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public List<ValveKeepPushData> getDocData(@RequestBody List<CartData> cartData);

	/*@POST
	@Path("valvekeeporderdocumentdata")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public List<VKOrderDocument> getVkOrderDocumentData(@RequestBody List<CartData> cartData);
*/
	@POST
	@Path("valvekeepcustorderinfospeqt")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public List<VKCustOrderInfoSpeqT> getVkCustOrderInfoSpeqT(@RequestBody List<CartData> vkCartData);

	@POST
	@Path("getcartinfo")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public List<CartData> getCartData(@RequestBody Map postdata);
	
	@POST
	@Path("getsofordoc/{documentName}")
	@Produces(MediaType.APPLICATION_JSON)
	public String getSOFromDocName(@PathParam(value = "documentName") String documentName);
	
/*	@POST
	@Path("getsnfordoc/{documentName}")
	@Produces(MediaType.APPLICATION_JSON)
	public String getSNFromDocName(@PathParam(value = "documentName") String documentName);*/
	
	@POST
	@Path("deleteexistingorderrecords/{orderNumber}")
	@Produces(MediaType.APPLICATION_JSON)
	public StatusInfo removeDuplicateSOValveKeep(@PathParam(value = "orderNumber") String orderNumber);
	
	@POST
	@Path("validateSO/{orderNumber}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<OrderInfo> validateSO(@PathParam(value = "orderNumber") String orderNumber);
	
	
	@GET
	@Path("getEndUserListByTxt/{searchTxt}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<EndUserDetail> getEndUserListByTxt(@PathParam(value = "searchTxt") String searchTxt); 
		
	
 
	@GET
	@Path("getProjectDataMaster/{customerId}/{plantId}/{sso}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<ProjectDataMaster> getProjectDataMaster(@PathParam(value = "customerId") String customerId,
			@PathParam(value = "plantId") String plantId,
			@PathParam(value = "sso") String sso); 

	@POST
	@Path("saveProjectDataMaster/{sso}")
	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	StatusInfo saveProjectDataMaster(@PathParam(value = "sso") String sso,
			ProjectDataMaster projectDataMaster);
	
	
	@GET
	@Path("getUpgradeOptionNewInfo/{optionId}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	List<UpgradeOptions> getUpgradeOptionNewInfo(@PathParam(value = "optionId") String optionId);
	
	// Package Services
		@GET
		@Path("getUpgradeNewInfoById/{upgradeId}")
		@Consumes(MediaType.APPLICATION_JSON)
	 	@Produces(MediaType.APPLICATION_JSON)
		List<UpgradeInfoNew> getUpgradeNewInfoById(@PathParam(value = "upgradeId") String upgradeId);

		@GET
		@Path("getUpgradeOptionNewInfoById/{upgradeId}")
		@Consumes(MediaType.APPLICATION_JSON)
		@Produces(MediaType.APPLICATION_JSON)
		List<UpgradeOptions> getUpgradeOptionNewInfoById(@PathParam(value = "upgradeId") String upgradeId);


		
		
	 	@POST
		@Path("deleteUpgradeOptionsNew")
		@Consumes(MediaType.APPLICATION_JSON)
	 	@Produces(MediaType.APPLICATION_JSON)
		StatusInfo deleteUpgradeOptionsNew(@RequestBody UpgradeOptionListDTO optionList);

		
	 	@POST
		@Path("saveUpgradeOptionInfo/{sso}")
		@Consumes(MediaType.APPLICATION_JSON)
	 	@Produces(MediaType.APPLICATION_JSON)
		StatusInfo saveUpgradeOptionInfo(@PathParam(value = "sso") String sso, @RequestBody UpgradeOptions upgradeOptions);
	
	 	
		@GET
		@Path("getCoutryList")
		@Consumes(MediaType.APPLICATION_JSON)
		@Produces(MediaType.APPLICATION_JSON)
		List<CountryDTO> getCoutryList();
		
		
		// Channel Partner - upgrades
		
		@GET
		@Path("cpUpgradeDetailView/{upgradeId}")
		@Consumes(MediaType.APPLICATION_JSON)
		@Produces(MediaType.APPLICATION_JSON)
		CPUpgradeDetailView getCpUpgradeDetailView(@PathParam(value = "upgradeId") int upgradeId);

		@POST
		@Path("addToPromotionalCartCP/{sso}/{promotionalCartLevel}")
		@Consumes(MediaType.APPLICATION_JSON)
		@Produces(MediaType.APPLICATION_JSON)
		StatusInfo addToPromotionalCartCP(@PathParam(value = "sso") String sso, @PathParam(value = "promotionalCartLevel") String promotionalCartLevel, 
				@RequestBody CPPromotionalCart data);
		
		@POST
		@Path("addToPromotionalCartSMI/{sso}")
		@Consumes(MediaType.APPLICATION_JSON)
		@Produces(MediaType.APPLICATION_JSON)
		StatusInfo addToPromotionalCartSMI(@PathParam(value = "sso") String sso, @RequestBody CPPromotionalCart data);
		
	
		@GET
		@Path("cpUpgradeDetailSMIView/{upgradeId}")
		@Consumes(MediaType.APPLICATION_JSON)
		@Produces(MediaType.APPLICATION_JSON)
		CPUpgradeDetailSMIView getCpUpgradeSMIViewData(@PathParam(value = "upgradeId") int upgradeId);
		
		@GET
		@Path("getUpgradeDocumentDetails/{documentId}")
		@Consumes(MediaType.APPLICATION_JSON)
		@Produces(MediaType.APPLICATION_JSON)
		CPUpgradeDocument getUpgradeDocumentDetails(@PathParam(value = "documentId") int documentId);
		
		@GET
 		@Path("getDocuments/{sourceSystem}/{docType}/{updatedDate}")
 		@Consumes(MediaType.APPLICATION_JSON)
 		@Produces(MediaType.APPLICATION_JSON)
 		List<DocumentDetails> getDocument(@PathParam("sourceSystem")String sourceSystem,@PathParam("docType") String docType, @PathParam("updatedDate") String updatedDate);

		@GET
		@Path("getEndUserList/{searchTxt}")
		@Consumes(MediaType.APPLICATION_JSON)
		@Produces(MediaType.APPLICATION_JSON)
		List<EndUserDetail> getEndUserList(@PathParam(value = "searchTxt") String searchTxt); 
		
		@GET
		@Path("getFileImageDataCount")
		@Produces(MediaType.APPLICATION_JSON)
		int getFileImageDataCount(@QueryParam(value = "serialNumber") String serialNumber);
		
}
