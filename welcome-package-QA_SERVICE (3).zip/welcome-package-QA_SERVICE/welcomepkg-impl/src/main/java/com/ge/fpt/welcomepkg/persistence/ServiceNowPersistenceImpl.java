package com.ge.fpt.welcomepkg.persistence;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.URL;
import java.net.URLConnection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.sql.DataSource;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.ws.security.util.Base64;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;

import com.ge.fpt.welcomepkg.api.ChannelData;
import com.ge.fpt.welcomepkg.api.DropDownItem;
import com.ge.fpt.welcomepkg.api.OrderEquipment;
import com.ge.fpt.welcomepkg.api.SerialNoDetails;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;
import com.ge.fpt.welcomepkg.impl.WelcomePkgServiceImpl;
import com.ge.fpt.welcomepkg.persistence.IServiceNowPersistence;
import com.ge.fpt.welcomepkg.persistence.DropDownPersistenceImpl.DropDownMapper;
import com.ge.fpt.welcomepkg.util.Constants;


public class ServiceNowPersistenceImpl implements IServiceNowPersistence {
	@SuppressWarnings("javadoc")
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory.getLogger(ServiceNowPersistenceImpl.class);
	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;
	/**
	 * Data source for the JDBC
	 */
	javax.sql.DataSource dataSource;
	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;
	NamedParameterJdbcTemplate namedParamTemplate;

	/**
	 * @return the dataSource
	 */
	public javax.sql.DataSource getDataSource() {
		return this.dataSource;
	}

	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate = new NamedParameterJdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	/* Sindhura : Service Now Changes : Start */

	@Override
	public List<ChannelData> getCPusernames(String channelname) {
		logger.info("inside getusername" + channelname);
		List<ChannelData> channelDataresult=null;
		String sql = "select distinct duns_number,USER_NAME,EMAIL,PHONE,company,sso_id from ddsafm.sqt_channel_sso where duns_number=:channelname";
		try{
		channelDataresult = this.jdbcTemplate.query(sql, new Object[] { channelname },
				new ChannelUserDataMapper());
		logger.info("sql"+sql+"logger="+channelname);}
		catch (Exception ex) {
			logger.info("error occured:");
			logger.error("Convert Order error:", ex);
		}
		return channelDataresult;
	}
	
	@Override
	public List<DropDownItem> selectChannelPartnerName() {
		List<DropDownItem> dropDownItem = null;
			logger.error("Is cp name testing");
			try{
				String sql="select distinct company as text,duns_number as value from ddsafm.sqt_channel_sso where duns_number IS NOT NULL";
				logger.error("Is cp name testing sql="+sql);
				dropDownItem =  this.jdbcTemplate.query(sql, new DropDownMapper());
				logger.info("sql"+sql+"logger=");}
				catch (Exception ex) {
					logger.info("error occured:");
					logger.error("Convert Order error:", ex);
				}
				return dropDownItem;
		}

		
	@Override
	public ChannelData getLoggedUserInfo(String loggedUser) {
		logger.info("inside getLoggedUserInfo" + loggedUser.toUpperCase());
		String sql = "select distinct duns_number,USER_NAME,EMAIL,PHONE,company,sso_id from ddsafm.sqt_channel_sso where UPPER(SSO_ID)=:loggedUser";
		ChannelData loggedUserData = this.jdbcTemplate.queryForObject(sql, new Object[] { loggedUser.toUpperCase() },
				new ChannelUserDataMapper());
		logger.info("sql"+sql+"logger="+loggedUserData);
		logger.info("sql"+sql+"logger="+loggedUserData.getDuns());
		logger.info("after query");
		return  loggedUserData;
	}
	
	@Override
	public ChannelData getLoggedUserInfoForCP(String loggedUserSubmitter) {
		logger.info("inside getLoggedUserInfo" + loggedUserSubmitter.toUpperCase());
		String sql = "select distinct duns_number,USER_NAME,EMAIL,PHONE,company,sso_id from ddsafm.sqt_channel_sso where UPPER(SSO_ID)=:loggedUser";
		ChannelData loggedUserDataCP = this.jdbcTemplate.queryForObject(sql, new Object[] { loggedUserSubmitter.toUpperCase() },
				new ChannelUserDataMapper());
		logger.info("sql"+sql+"logger="+loggedUserDataCP);
		logger.info("sql"+sql+"logger="+loggedUserDataCP.getDuns());
		logger.info("after query");
		return  loggedUserDataCP;
	}

	@Override
	public List<String> getCPNameByChannelData() {
		logger.info("inside getCPNameByChannelData");
		String sql = "select distinct company from ddsafm.sqt_channel_sso";
		logger.info("sql=" + sql);
		List<String> result = this.jdbcTemplate.queryForList(sql, String.class);
		logger.info("after query=" + result.size() + "num");
		return result;
	}

	

	@Override
	public List<SerialNoDetails> getSerialNumberForValve(String serialNumberValue, String newvalve) {
		logger.info("inside getSerialNumberForValve"+newvalve);
		String productLine=null;
		if("Masoneilan".equalsIgnoreCase(newvalve)){
			productLine="MN";
		}
		else if("Consolidated".equalsIgnoreCase(newvalve)){
			productLine="CN";
		}
		else if("MOONEY".equalsIgnoreCase(newvalve)){
			productLine="MO";
		}
		else if("BECKER".equalsIgnoreCase(newvalve)){
			productLine="BK";
		}
		else{
			logger.info("incorrect product code");
		}
		logger.info("product code"+productLine);
		String SNUpperCase=serialNumberValue.toUpperCase();
		logger.info("SN "+SNUpperCase);
		/*String sql ="SELECT V.SERIAL_NUMBER,V.ITEM_NUMBER AS PART_NUMBER,V.DESCRIPTION,OL.ACTUAL_SHIPMENT_DATE,"
				+ "OL.SHIPPED_QUANTITY,V.TAG_NUMBER,SRC.SOURCE_SYSTEM FROM SQT_VALVE_INFO_T V,SQT_ORDER_LINE_INFO_T OL,"
				+ "SQT_SOURCES_T SRC WHERE V.ORDER_LINE_ID = OL.ORDER_LINE_ID AND V.REC_SOURCE = OL.REC_SOURCE "
				+ "AND SRC.REC_SOURCE = V.REC_SOURCE and V.product_code =:newvalve and upper(V.SERIAL_NUMBER)  =:SNUpperCase";
		MapSqlParameterSource paramMap = new MapSqlParameterSource();
		paramMap.addValue("newvalve", productLine);
		paramMap.addValue("SNUpperCase", SNUpperCase);
		logger.info("sql=" + sql+SNUpperCase);
		
		logger.info("serialnumber=" + serialNumberValue);
		List<SerialNoDetails> result = this.namedParamTemplate.query(sql, paramMap, new SerialNoDataMapper());
		logger.info("after query=" + result.size() + "num");
		logger.info("after query=" + result.get(0).getSerialNumber() + "and" + result.get(0).getValvePartNumber()+
				"and"+result.get(0).getValveDescription()+"and"+result.get(0).getActualShipDate()+"and"+
				result.get(0).getQuantityShipped()+"and"+result.get(0).getTagNumber()+"and"+result.get(0).getSourceSystem());
		return result;*/
		
		String sql ="SELECT V.SERIAL_NUMBER,O.CUST_PO_NUMBER as PO,O.ORDER_NUMBER as SALES_ORDER,V.ITEM_NUMBER AS PART_NUMBER,V.DESCRIPTION,OL.ACTUAL_SHIPMENT_DATE,"
				+ "OL.SHIPPED_QUANTITY,V.TAG_NUMBER,SRC.SOURCE_SYSTEM FROM SQT_VALVE_INFO_T V,SQT_ORDER_INFO_T O,SQT_ORDER_LINE_INFO_T OL,"
				+ "SQT_SOURCES_T SRC WHERE 1=1 and V.ORDER_LINE_ID = OL.ORDER_LINE_ID AND V.REC_SOURCE = OL.REC_SOURCE "
				+ "AND O.ORDER_ID=OL.ORDER_ID AND SRC.REC_SOURCE = V.REC_SOURCE and V.product_code = ? AND UPPER(V.SERIAL_NUMBER) like UPPER('%'||?||'%') ";
		serialNumberValue = serialNumberValue.replaceAll("[^a-zA-Z0-9]", "-");
		logger.info("SN "+sql);
		try {
			List<SerialNoDetails> equipment = this.jdbcTemplate.query(sql,
					new Object[] { productLine,serialNumberValue }, new SerialNoDataMapper());
			logger.info("SN equpi "+equipment);
			return equipment;
		} catch (Exception ex) {
			logger.error("get blanket search equipemnt error.. " + ex);
			return null;
		}
		
		
	}

	@Override
	public ChannelData getUserDataFromChannelPartner(String channelpartnername) {
		logger.info("inside getusernamefromCP" + channelpartnername.toUpperCase());
		ChannelData userData =null;
		String sql = "select distinct email,phone,company,duns_number,user_name,sso_id from ddsafm.sqt_channel_sso where UPPER(sso_id)=:channelpartnername";
		logger.info("after getusername" + channelpartnername);
		logger.info("after ddd" + channelpartnername);
		try{
		userData = this.jdbcTemplate.queryForObject(sql, new Object[] { channelpartnername.toUpperCase() },
				new ChannelUserDataMapper());
		logger.info("sql"+sql+"after query="+userData);
		}
			catch (Exception ex) {
				logger.info("Convert Order error:");
				logger.error("Convert Order error:", ex);
			}
		
		return userData;
	}

	private static final class ChannelUserDataMapper implements RowMapper<ChannelData> {
		public ChannelUserDataMapper() {
		}

		@Override
		public ChannelData mapRow(ResultSet rs, int rowNum) throws SQLException {
			ChannelData result = new ChannelData();
			result.setCompany(rs.getString("company") != null ? rs.getString("company") : "");
			result.setEmail(rs.getString("email") != null ? rs.getString("email") : "");
			result.setPhone(rs.getString("phone") != null ? rs.getString("phone") : "");
			result.setUserName(rs.getString("user_name") !=null ? rs.getString("user_name") : "");
			result.setDuns(rs.getString("duns_number") !=null ? rs.getString("duns_number") : "");
			result.setSso(rs.getString("sso_id")!=null?rs.getString("sso_id"):"");
			return result;
		}

		
	}
	
	private static final class SerialNoDataMapper implements RowMapper<SerialNoDetails> {
		public SerialNoDataMapper() {
		}

		@Override
		public SerialNoDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
			logger.info("inside the try of service1");
			SerialNoDetails result = new SerialNoDetails();
			try{
				logger.info("inside the try of service");
			result.setSerialNumber(rs.getString("SERIAL_NUMBER") != null ? rs.getString("SERIAL_NUMBER") : "");
			logger.info("inside the try of"+result.getSerialNumber().toUpperCase());
			result.setSalesOrder(rs.getString("SALES_ORDER") != null ? rs.getString("SALES_ORDER") : "");
			logger.info("inside the try of"+result.getSalesOrder().toUpperCase());
			result.setPO(rs.getString("PO")!= null ? rs.getString("PO") : "");
			logger.info("inside the try of"+result.getPO().toUpperCase());
			result.setValvePartNumber(rs.getString("PART_NUMBER") != null ? rs.getString("PART_NUMBER") : "");
			logger.info("inside the try of item"+result.getValvePartNumber());
			result.setValveDescription(rs.getString("DESCRIPTION") != null ? rs.getString("DESCRIPTION") : "");
			logger.info("inside the try of"+result.getValveDescription());
			result.setQuantityShipped(rs.getLong("SHIPPED_QUANTITY"));
			logger.info("inside the try of"+result.getQuantityShipped());
			result.setTagNumber(rs.getString("TAG_NUMBER") != null ? rs.getString("TAG_NUMBER") : "");
			logger.info("inside the try of"+result.getTagNumber());
			result.setSourceSystem(rs.getString("SOURCE_SYSTEM") != null ? rs.getString("SOURCE_SYSTEM") : "");
			logger.info("inside the try of"+result.getSourceSystem());
			if(null!=rs.getString("ACTUAL_SHIPMENT_DATE")){
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //$NON-NLS-1$
				Date actualShipDate = formatter.parse(rs.getString("ACTUAL_SHIPMENT_DATE")); //$NON-NLS-1$
				result.setActualShipDate(actualShipDate);
			}
		} catch (Exception e) {
			logger.error("OrderEquipment Mapper: ", e); //$NON-NLS-1$
		}
			
			return result;
		}

		
	}
	
	public static final class DropDownMapper implements RowMapper<DropDownItem> {
		public DropDownItem mapRow(ResultSet rs, int rowNum) throws SQLException {
			DropDownItem result = new DropDownItem();
			result.setText(rs.getString("text"));
			result.setValue(rs.getString("value"));
			return result;
		}
	}

	

	
/*	@Override
	public boolean getPartDataForSN(String partValue) {
		logger.info("inside getpart data sn");
		String sql = "select count(*) from ddsafm.sqt_part_info_t where item_number=?";
		int count = this.jdbcTemplate.queryForInt(sql,partValue);
		logger.info("inside getpart data sn count"+count);
		if (count != 0) {
			return true;
		} else {
			return false;
		}	}
*/

	/*
	private Boolean ValidatePartOrModel(Object partModel, String indicator) {
		
			String sql = null;
			if ("Part".equalsIgnoreCase(indicator))
				sql = "select count(*) from ddsafm.sqt_part_info_t where item_number=?";
			int count = this.jdbcTemplate.queryForInt(sql, new Object[] { partModel });
			if (count != 0) {
				return true;
			} else {
				return false;
			}
		}*/

	/* Sindhura : Service Now Changes : End */

}
