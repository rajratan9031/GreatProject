package com.ge.fpt.welcomepkg.persistence;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.fpt.welcomepkg.api.CurrencyDetails;
import com.ge.fpt.welcomepkg.api.Report;
import com.ge.fpt.welcomepkg.api.ReportData;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;
import com.ge.fpt.welcomepkg.util.ExcelExport;
import com.ge.fpt.welcomepkg.util.PDFExport;

public class ReportServicePersistenceImpl implements IReportServicePersistence {

	@SuppressWarnings("javadoc")
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory
			.getLogger(ReportServicePersistenceImpl.class);

	// static final int SQL_RETURN_RECORD_LIMIT = 25;

	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;

	/**
	 * Data source for the JDBC
	 */
	DataSource dataSource;

	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;

	NamedParameterJdbcTemplate namedParamTemplate;

	/**
	 * @return the dataSource
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}

	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate = new NamedParameterJdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	public List<Report> getReportData(ReportData reportData,String sso) {
		List<Report> result = null;
		List<String> serialNoList = new ArrayList<String>();
		List<String> recSourceList = new ArrayList<String>();
		if (reportData.getData() != null) {
			for (int i = 0; i < reportData.getData().size(); i++) {
				serialNoList.add(reportData.getData().get(i)
						.get("serialNumber"));
				recSourceList.add(reportData.getData().get(i)
						.get("sourceSystem"));
			}
		}

		String sql = "";
		MapSqlParameterSource paramMap = new MapSqlParameterSource();

		if (reportData.isWipSpir()) {
			if (reportData.getReportType().equalsIgnoreCase("4")) {
				//sql = "SELECT /*+ partition*/ SALES_ORDER as SALES_ORDER, SALES_ORDER_LINE as SALES_ORDER_LINE, PURCHASE_ORDER_NUMBER as PURCHASE_ORDER_NUMBER, "
				//		+ "SOLD_TO_CUSTOMER_NAME as SOLD_TO_CUSTOMER_NAME, NVL(END_USER_COUNTRY,'') as SOLD_TO_COUNTRY, NVL(SOLD_TO_STATE,'') as SOLD_TO_STATE, "
				//		+ "SOLD_TO_PROVINCE as SOLD_TO_PROVINCE, NVL(SOLD_TO_CITY,''), REP_NAME as REP_NAME, ORDERED_ITEM_NUMBER as ORDERED_ITEM_NUMBER, "
				//		+ "QUANTITY_SHIPPED as QUANTITY_SHIPPED, UNIT_SELLING_PRICE as UNIT_SELLING_PRICE, ACTUAL_SHIP_DATE as ACTUAL_SHIP_DATE, "
				//		+ "VALVE_SRNO , VALVE_PART_NUMBER as VALVE_PART_NUMBER, VALVE_DESCRIPTION as VALVE_DESCRIPTION, TAG as TAG_NUMBER, "
				//		+ "PART_NO as COMPONENT_ITEM_NUMBER, DESCRIPTION  as COMPONENT_DESCRIPTION, LEGACY_PART_NUMBER as LEGACY_PART_NUMBER, "
				//		+ "SPARES_INDICATOR as SPARES_CATEGORY, STOCK_TYPE as STOCK_TYPE, TO_NUMBER(QUANTITY) as QUANTITY, "
				//		+ "TO_NUMBER(REGEXP_REPLACE(LIST_PRICE, '[^0-9^\\.]', '')) AS LIST_PRICE, "
				//		+ "TO_NUMBER(REGEXP_REPLACE(LIST_PRICE, '[^0-9^\\.]', '')) AS PART_PRICE, LEAD_TIME as LEAD_TIME, source_system as SOURCE_SYSTEM, "
				//		+ "Factory as Factory, spare_type as SPARE_TYPE, currency as TO_CURRENCY ,DEFAULT_PERCENT "
				//		+ "FROM DDSAFM.ODS_SQT_SPIR_REPORT_V "
				//		+ "Where user_name=:sso and spares_indicator in('C', 'W', 'I', '1', '2') "
				//		+ "  ORDER BY PART_NO ";*/
				sql="select SALES_ORDER,"
						+ "       (select Ceil(qty.multiplier * MAXQTY)"
					    + "	          from DDSAFM.sqt_spir_recomended_qty qty"
					    + "	         where qty.spare_indicator = SPARES_CATEGORY"
					    + "	           and count between qty.start_qty and qty.end_qty) RecomendedQty,"
					    + "	       SALES_ORDER_LINE,"
					    + "	       MAXQTY,"
					    + "	       COUNT,"
					    + "	       PURCHASE_ORDER_NUMBER,"
					    + "	       SOLD_TO_CUSTOMER_NAME,"
					    + "	       SOLD_TO_COUNTRY,"
					    + "	       SOLD_TO_STATE,"
					    + "	       SOLD_TO_PROVINCE,"
					    + "	       SOLD_TO_CITY,"
					    + "	       REP_NAME,"
					    + "	       ORDERED_ITEM_NUMBER,"
					    + "	       QUANTITY_SHIPPED,"
					    + "	       UNIT_SELLING_PRICE,"
					    + "	       ACTUAL_SHIP_DATE,"
					    + "	       VALVE_SRNO,"
					    + "	       VALVE_PART_NUMBER,"
					    + "	       VALVE_DESCRIPTION,"
					    + "	       TAG_NUMBER,"
					    + "	       COMPONENT_ITEM_NUMBER,"
					    + "	       COMPONENT_DESCRIPTION,"
					    + "	       LEGACY_PART_NUMBER,"
					    + "	       SPARES_CATEGORY,"
					    + "	       STOCK_TYPE,"
					    + "	       QUANTITY,"
					    + "	       LIST_PRICE,"
					    + "	       PART_PRICE,"
					    + "	       LEAD_TIME,"
					    + "	       SOURCE_SYSTEM,"
					    + "	       FACTORY,"
					    + "	       SPARE_TYPE,"
					    + "	       TO_CURRENCY,"
					    + "	       DEFAULT_PERCENT"
					    + "	  from (SELECT /*+ partition*/"
					    + "	         SALES_ORDER as SALES_ORDER,"
					    + "	         SALES_ORDER_LINE as SALES_ORDER_LINE,"
					    + "	         MAX(quantity) OVER(PARTITION BY PART_NO) MaxQty,"
					    + "	         COUNT(PART_NO) OVER(PARTITION BY PART_NO) count,"
					    + "	         PURCHASE_ORDER_NUMBER as PURCHASE_ORDER_NUMBER,"
					    + "	         SOLD_TO_CUSTOMER_NAME as SOLD_TO_CUSTOMER_NAME,"
					    + "	         NVL(END_USER_COUNTRY, '') as SOLD_TO_COUNTRY,"
					    + "	         NVL(SOLD_TO_STATE, '') as SOLD_TO_STATE,"
					    + "	         SOLD_TO_PROVINCE as SOLD_TO_PROVINCE,"
					    + "	         NVL(SOLD_TO_CITY, '') as SOLD_TO_CITY,"
					    + "	         REP_NAME as REP_NAME,"
					    + "	         ORDERED_ITEM_NUMBER as ORDERED_ITEM_NUMBER,"
					    + "	         QUANTITY_SHIPPED as QUANTITY_SHIPPED,"
					    + "	         UNIT_SELLING_PRICE as UNIT_SELLING_PRICE,"
					    + "	         ACTUAL_SHIP_DATE as ACTUAL_SHIP_DATE,"
					    + "	         VALVE_SRNO,"
					    + "	         VALVE_PART_NUMBER as VALVE_PART_NUMBER,"
					    + "	         VALVE_DESCRIPTION as VALVE_DESCRIPTION,"
					    + "	         TAG as TAG_NUMBER,"
					    + "	         PART_NO as COMPONENT_ITEM_NUMBER,"
					    + "	         DESCRIPTION as COMPONENT_DESCRIPTION,"
					    + "	         LEGACY_PART_NUMBER as LEGACY_PART_NUMBER,"
					    + "	         SPARES_INDICATOR as SPARES_CATEGORY,"
					    + "	         STOCK_TYPE as STOCK_TYPE,"
					    + "	         TO_NUMBER(QUANTITY) as QUANTITY,"
					    + "	         TO_NUMBER(REGEXP_REPLACE(LIST_PRICE, '[^0-9^\\.]', '')) AS LIST_PRICE,"
					    + "	         TO_NUMBER(REGEXP_REPLACE(LIST_PRICE, '[^0-9^\\.]', '')) AS PART_PRICE,"
					    + "	         LEAD_TIME as LEAD_TIME,"
					    + "	         source_system as SOURCE_SYSTEM,"
					    + "	         Factory as Factory,"
					    + "	         spare_type as SPARE_TYPE,"
					    + "	         currency as TO_CURRENCY,"
					    + "	         DEFAULT_PERCENT"
					    + "	          FROM DDSAFM.ODS_SQT_SPIR_REPORT_V"
					    + "	         Where user_name = :sso"
					    + "	           and spares_indicator in ('C', 'W', 'I', '1', '2')"
					    + "	         ORDER BY PART_NO)";
			} else if (reportData.getReportType().equalsIgnoreCase("5")) {
				sql = "SELECT /*+ partition*/ SALES_ORDER as SALES_ORDER, SALES_ORDER_LINE as SALES_ORDER_LINE, PURCHASE_ORDER_NUMBER as PURCHASE_ORDER_NUMBER, "
						+ "SOLD_TO_CUSTOMER_NAME as SOLD_TO_CUSTOMER_NAME, NVL(END_USER_COUNTRY,'') as SOLD_TO_COUNTRY, NVL(SOLD_TO_STATE,'') as SOLD_TO_STATE, "
						+ "SOLD_TO_PROVINCE as SOLD_TO_PROVINCE, NVL(SOLD_TO_CITY,'') as SOLD_TO_CITY, REP_NAME as REP_NAME, ORDERED_ITEM_NUMBER as ORDERED_ITEM_NUMBER, "
						+ "QUANTITY_SHIPPED as QUANTITY_SHIPPED, UNIT_SELLING_PRICE as UNIT_SELLING_PRICE, ACTUAL_SHIP_DATE as ACTUAL_SHIP_DATE, "
						+ "VALVE_SRNO, VALVE_PART_NUMBER as VALVE_PART_NUMBER, VALVE_DESCRIPTION as VALVE_DESCRIPTION, TAG as TAG_NUMBER, "
						+ "PART_NO as COMPONENT_ITEM_NUMBER, DESCRIPTION  as COMPONENT_DESCRIPTION, LEGACY_PART_NUMBER as LEGACY_PART_NUMBER, "
						+ "SPARES_INDICATOR as SPARES_INDICATOR, STOCK_TYPE as STOCK_TYPE, TO_NUMBER(QUANTITY) as QUANTITY, "
						+ "TO_NUMBER(REGEXP_REPLACE(LIST_PRICE, '[^0-9^\\.]', '')) AS LIST_PRICE, "
						+ "TO_NUMBER(REGEXP_REPLACE(LIST_PRICE, '[^0-9^\\.]', '')) AS PART_PRICE, LEAD_TIME as LEAD_TIME, source_system as SOURCE_SYSTEM, "
						+ "Factory as Factory, spare_type as SPARE_TYPE,currency as TO_CURRENCY "
						+ "FROM DDSAFM.ODS_SQT_SPIR_REPORT_V "
						+ "Where user_name=:sso  and  spares_indicator in('C', 'W', 'I', '1', '2')"
						+ " ORDER BY SALES_ORDER_LINE, VALVE_SRNO, TAG_NUMBER ";
			} else if (reportData.getReportType().equalsIgnoreCase("6")) {
				sql = "SELECT NVL(SALES_ORDER,'') SALES_ORDER,NVL(SALES_ORDER_LINE,'') SALES_ORDER_LINE,"
						+ "NVL(PURCHASE_ORDER_NUMBER,'') PURCHASE_ORDER_NUMBER,NVL(SOLD_TO_CUSTOMER_NAME,'') SOLD_TO_CUSTOMER_NAME,"
						+ "NVL(SOLD_TO_COUNTRY,'') SOLD_TO_COUNTRY,NVL(SOLD_TO_STATE,'') SOLD_TO_STATE,NVL(SOLD_TO_PROVINCE,'') SOLD_TO_PROVINCE,"
						+ "NVL(SOLD_TO_CITY,'') SOLD_TO_CITY,NVL(REP_NAME,'') REP_NAME,NVL(ORDERED_ITEM_NUMBER,'') ORDERED_ITEM_NUMBER,"
						+ "NVL(QUANTITY_SHIPPED,'') QUANTITY_SHIPPED,NVL(UNIT_SELLING_PRICE,'') UNIT_SELLING_PRICE,NVL(ACTUAL_SHIP_DATE,'') ACTUAL_SHIP_DATE,"
						+ "NVL(VALVE_SRNO,'') VALVE_SRNO,NVL(VALVE_PART_NUMBER,'') VALVE_PART_NUMBER,NVL(VALVE_DESCRIPTION,'') VALVE_DESCRIPTION,"
						+ "NVL(TAG_NUMBER,'') TAG_NUMBER,NVL(COMPONENT_ITEM_NUMBER,'') COMPONENT_ITEM_NUMBER,NVL((CASE WHEN SUBSTR(COMPONENT_DESCRIPTION,1,3)='(+)' THEN LTRIM(REPLACE(COMPONENT_DESCRIPTION,'(+)'))"
						+ "WHEN SUBSTR(COMPONENT_DESCRIPTION,1,3)='(2)' THEN LTRIM(REPLACE(COMPONENT_DESCRIPTION,'(2)'))"
						+ "WHEN SUBSTR(COMPONENT_DESCRIPTION,1,3)='(!)' THEN LTRIM(REPLACE(COMPONENT_DESCRIPTION,'(!)'))"
						+ "ELSE COMPONENT_DESCRIPTION END),'') COMPONENT_DESCRIPTION,NVL(LEGACY_PART_NUMBER,'') LEGACY_PART_NUMBER,"
						+ "NVL(SPARES_INDICATOR,'') SPARES_INDICATOR,NVL(STOCK_TYPE,'') STOCK_TYPE,SUM(QUANTITY) QUANTITY,NVL(LIST_PRICE,'') LIST_PRICE,NVL(LEAD_TIME,'') LEAD_TIME,NVL(SOURCE_SYSTEM,'') SOURCE_SYSTEM,"
						+ "NVL(Factory,'') Factory,NVL(SPARE_TYPE,'') SPARE_TYPE,NVL(TO_CURRENCY,'') TO_CURRENCY FROM (SELECT /*+ partition*/ DISTINCT SALES_ORDER as SALES_ORDER, NVL(SALES_ORDER_LINE,'') as SALES_ORDER_LINE, "
						+ "PURCHASE_ORDER_NUMBER as PURCHASE_ORDER_NUMBER,SOLD_TO_CUSTOMER_NAME as SOLD_TO_CUSTOMER_NAME,NVL(END_USER_COUNTRY,'') as SOLD_TO_COUNTRY, NVL(SOLD_TO_STATE,'') as SOLD_TO_STATE,"
						+ "SOLD_TO_PROVINCE as SOLD_TO_PROVINCE,NVL(SOLD_TO_CITY,'') as SOLD_TO_CITY,REP_NAME as REP_NAME,ORDERED_ITEM_NUMBER as ORDERED_ITEM_NUMBER,QUANTITY_SHIPPED as QUANTITY_SHIPPED, "
						+ "UNIT_SELLING_PRICE as UNIT_SELLING_PRICE,ACTUAL_SHIP_DATE as ACTUAL_SHIP_DATE,NVL(VALVE_SRNO,'') as VALVE_SRNO, VALVE_PART_NUMBER as VALVE_PART_NUMBER,VALVE_DESCRIPTION as VALVE_DESCRIPTION,"
						+ "NVL(TAG,'') as TAG_NUMBER,PART_NO  as COMPONENT_ITEM_NUMBER,DESCRIPTION  as COMPONENT_DESCRIPTION,LEGACY_PART_NUMBER as LEGACY_PART_NUMBER,SPARES_INDICATOR as SPARES_INDICATOR,STOCK_TYPE as STOCK_TYPE,"
						+ "TO_NUMBER(QUANTITY) as QUANTITY,TO_NUMBER(REGEXP_REPLACE(LIST_PRICE, '[^0-9^\\.]', '')) AS LIST_PRICE,LEAD_TIME as LEAD_TIME, SOURCE_SYSTEM as SOURCE_SYSTEM,Factory as Factory,spare_type as SPARE_TYPE,"
						+ "currency as TO_CURRENCY from DDSAFM.ODS_SQT_SPIR_REPORT_V Where user_name=:sso) GROUP BY NVL(SALES_ORDER,''),NVL(SALES_ORDER_LINE,''),NVL(PURCHASE_ORDER_NUMBER,''),NVL(SOLD_TO_CUSTOMER_NAME,''),NVL(SOLD_TO_COUNTRY,''),"
						+ "NVL(SOLD_TO_STATE,''),NVL(SOLD_TO_PROVINCE,''),NVL(SOLD_TO_CITY,''),NVL(REP_NAME,''),NVL(ORDERED_ITEM_NUMBER,''),NVL(QUANTITY_SHIPPED,''),NVL(UNIT_SELLING_PRICE,''),NVL(ACTUAL_SHIP_DATE,''),NVL(VALVE_SRNO,''),"
						+ "NVL(VALVE_PART_NUMBER,''),NVL(VALVE_DESCRIPTION,''),NVL(TAG_NUMBER,''),NVL(COMPONENT_ITEM_NUMBER,''),NVL((CASE WHEN SUBSTR(COMPONENT_DESCRIPTION,1,3)='(+)' THEN LTRIM(REPLACE(COMPONENT_DESCRIPTION,'(+)')) "
						+ "WHEN SUBSTR(COMPONENT_DESCRIPTION,1,3)='(2)' THEN LTRIM(REPLACE(COMPONENT_DESCRIPTION,'(2)')) WHEN SUBSTR(COMPONENT_DESCRIPTION,1,3)='(!)' THEN LTRIM(REPLACE(COMPONENT_DESCRIPTION,'(!)')) ELSE COMPONENT_DESCRIPTION END),''),"
						+ "NVL(LEGACY_PART_NUMBER,''),NVL(SPARES_INDICATOR,''),NVL(STOCK_TYPE,''),NVL(LIST_PRICE,''),NVL(LEAD_TIME,''),NVL(SOURCE_SYSTEM,''),NVL(Factory,''),NVL(SPARE_TYPE,''),NVL(TO_CURRENCY,'')";
						
						
						/*"SELECT /*+ partition*/ /*SALES_ORDER as SALES_ORDER, NVL(SALES_ORDER_LINE,'') as SALES_ORDER_LINE, PURCHASE_ORDER_NUMBER as PURCHASE_ORDER_NUMBER, "
						+ "SOLD_TO_CUSTOMER_NAME as SOLD_TO_CUSTOMER_NAME, NVL(END_USER_COUNTRY,'') as SOLD_TO_COUNTRY, NVL(SOLD_TO_STATE,'') as SOLD_TO_STATE, "
						+ "SOLD_TO_PROVINCE as SOLD_TO_PROVINCE, NVL(SOLD_TO_CITY,'') as SOLD_TO_CITY, REP_NAME as REP_NAME, ORDERED_ITEM_NUMBER as ORDERED_ITEM_NUMBER, "
						+ "QUANTITY_SHIPPED as QUANTITY_SHIPPED, UNIT_SELLING_PRICE as UNIT_SELLING_PRICE, ACTUAL_SHIP_DATE as ACTUAL_SHIP_DATE, "
						+ "NVL(VALVE_SRNO,'') as VALVE_SRNO, VALVE_PART_NUMBER as VALVE_PART_NUMBER, VALVE_DESCRIPTION as VALVE_DESCRIPTION, "
						+ "NVL(TAG,'') as TAG_NUMBER, PART_NO  as COMPONENT_ITEM_NUMBER, DESCRIPTION  as COMPONENT_DESCRIPTION, LEGACY_PART_NUMBER as LEGACY_PART_NUMBER, "
						+ "SPARES_INDICATOR as SPARES_INDICATOR, STOCK_TYPE as STOCK_TYPE, TO_NUMBER(QUANTITY) as QUANTITY, "
						+ "TO_NUMBER(REGEXP_REPLACE(LIST_PRICE, '[^0-9^\\.]', '')) AS LIST_PRICE, LEAD_TIME as LEAD_TIME, SOURCE_SYSTEM as SOURCE_SYSTEM, "
						+ "Factory as Factory, spare_type as SPARE_TYPE,currency as TO_CURRENCY "
						+ "from DDSAFM.ODS_SQT_SPIR_REPORT_V "
						+ "Where user_name=:sso "
						+ " ORDER by SOURCE_SYSTEM, VALVE_SRNO ";*/
			} else if (reportData.getReportType().equalsIgnoreCase("7")) {
				sql = "select /*+ partition*/ ACTUAL_SHIP_DATE as ACTUAL_SHIP_DATE, VALVE_SRNO , TAG as TAG_NUMBER, SALES_ORDER as SALES_ORDER, "
						+ "SOLD_TO_CUSTOMER_NAME as END_USER_NAME,NVL(END_USER_COUNTRY,'') as SOLD_TO_COUNTRY,NVL(END_USER_LOCATION,'') as END_USER_LOCATION,VALVE_DESCRIPTION AS VALVE_DESCRIPTION, PART_NO AS PART_NUMBER, PART_NO AS COMPONENT_ITEM_NUMBER,DESCRIPTION  as COMPONENT_DESCRIPTION, "
						+ "CHANNEL_PARTNER as CHANNEL_PARTNER,TO_NUMBER(QUANTITY) as QUANTITY, TO_NUMBER(REGEXP_REPLACE(LIST_PRICE, '[^0-9^\\.]', '')) AS LIST_PRICE, "
						+ "TO_NUMBER(REGEXP_REPLACE(LIST_PRICE, '[^0-9^\\.]', ''))*NVL(QUANTITY,0) AS TOTAL_PRICE, "
						+ "LEAD_TIME as LEAD_TIME, SPARES_INDICATOR as SPARES_INDICATOR, currency as TO_CURRENCY "
						+ "from DDSAFM.ODS_SQT_SPIR_REPORT_V "
						+ "Where user_name=:sso and  spares_indicator in('C', 'W', 'I', '1', '2')"
						+ " ORDER BY VALVE_SRNO, TAG_NUMBER, SALES_ORDER ";
			}
		} else {
			if (reportData.getReportType().equalsIgnoreCase("4")) {
				/*sql = "SELECT DISTINCT A.SALES_ORDER, "
						+ " A.CUSTOMER_PO PURCHASE_ORDER_NUMBER, "
						+ " A.SOLD_TO_CUSTOMER_NAME, "
						+ " A.SOLD_TO_COUNTRY END_USER_COUNTRY, "
						+ " A.SOLD_TO_PROVINCE, "
						+ " A.SOLD_TO_STATE, "
						+ " A.SOLD_TO_CITY, "
						+ " A.REP_NAME, "
						+ " A.SERIAL_NUMBER VALVE_SRNO, "
						+ " A.TAG_NUMBER, "
						+ " A.COMPONENT_ITEM_NUMBER, "
						+ " A.COMPONENT_DESCRIPTION, "
						+ " A.LEGACY_PART_NUMBER, "
						+ " TO_NUMBER(REGEXP_REPLACE(B.LIST_PRICE, '[^0-9^\\.]', '')) AS LIST_PRICE, "
						+ " TO_NUMBER(REGEXP_REPLACE(B.LIST_PRICE, '[^0-9^\\.]', '')) AS PART_PRICE, "
						+ " C.LEAD_TIME, "
						+ " A.SOURCE_SYSTEM, "
						+ " A.QUANTITY, "
						+ " A.SPARES_CATEGORY, "
						+ " A.DEFAULT_PERCENT, "
						+ " B.TO_CURRENCY "
						+ " FROM DDSAFM.ODS_SQT_SPIR_V           A, "
						+ " DDSAFM.ODS_SQT_PRICE_LOOK_UP_MV B, "
						+ " DDSAFM.LEAD_TIME_LOOKUP_MV      C "
						+ " WHERE A.COMPONENT_ITEM_NUMBER = B.PART_NUMBER(+) "
						+ " AND A.COMPONENT_ITEM_NUMBER = C.ITEM_NUMBER(+) "
						+ " AND (B.TO_CURRENCY = :currency OR B.TO_CURRENCY IS NULL) "
						+ " AND (B.REGION = :region) "
						+ " AND (C.REGION = :region) "
						+ "  AND A.SERIAL_NUMBER in (:serialNoList) "
						+ "  AND a.REC_SOURCE in (:recSourceList) "
						+ "  ORDER BY A.COMPONENT_ITEM_NUMBER ";*/
				sql= "select SALES_ORDER, "
						+ " (select Ceil(qty.multiplier * MAXQTY)"
						+ "	          from DDSAFM.sqt_spir_recomended_qty qty"
					    + "	         where qty.spare_indicator = SPARES_INDICATOR"
					    + "	           and count between qty.start_qty and qty.end_qty) RecomendedQty,"
					    + "	       PURCHASE_ORDER_NUMBER,"
					    + "	       COMPONENT_ITEM_NUMBER,"
					    + "	       MAXQTY,"
					    + "	       COUNT,"
					    + "	       SOLD_TO_CUSTOMER_NAME,"
					    + "	       END_USER_COUNTRY,"
					    + "	       SOLD_TO_PROVINCE,"
					    + "	       SOLD_TO_STATE,"
					    + "	       SOLD_TO_CITY,"
					    + "	       REP_NAME,"
					    + "	       VALVE_SRNO,"
					    + "	       TAG_NUMBER,"
					    + "	       COMPONENT_DESCRIPTION,"
					    + "	       LEGACY_PART_NUMBER,"
					    + "	       LIST_PRICE,"
					    + "	       PART_PRICE,"
					    + "	       LEAD_TIME,"
					    + "	       SOURCE_SYSTEM,"
					    + "	       QUANTITY,"
					    + "	       SPARES_CATEGORY,"
					    + "	       SPARES_INDICATOR,"
					    + "	       DEFAULT_PERCENT,"
					    + "	       TO_CURRENCY"
					    + "	  from (SELECT DISTINCT A.SALES_ORDER,"
					    + "	                        A.CUSTOMER_PO PURCHASE_ORDER_NUMBER,"
					    + "	                        A.COMPONENT_ITEM_NUMBER,"
					    + "	                        MAX(quantity) OVER(PARTITION BY COMPONENT_ITEM_NUMBER) MaxQty,"
					    + "	                        COUNT(distinct serial_number) OVER(PARTITION BY COMPONENT_ITEM_NUMBER) count,"
					    + "	                        A.SOLD_TO_CUSTOMER_NAME,"
					    + "	                        A.SOLD_TO_COUNTRY END_USER_COUNTRY,"
					    + "	                        A.SOLD_TO_PROVINCE,"
					    + "	                        A.SOLD_TO_STATE,"
					    + "	                        A.SOLD_TO_CITY,"
					    + "	                        A.REP_NAME,"
					    + "	                        A.SERIAL_NUMBER VALVE_SRNO,"
					    + "					    	A.TAG_NUMBER,"
					    + "	                        A.COMPONENT_DESCRIPTION,"
					    + "	                        A.LEGACY_PART_NUMBER,"
					    + "	                        TO_NUMBER(REGEXP_REPLACE(B.LIST_PRICE,"
					    + "	                                                 '[^0-9^\\.]',"
					    + "	                                                 '')) AS LIST_PRICE,"
					    + "	                        TO_NUMBER(REGEXP_REPLACE(B.LIST_PRICE,"
					    + "	                                                 '[^0-9^\\.]',"
					    + "	                                                 '')) AS PART_PRICE,"
					    + "	                        C.LEAD_TIME,"
					    + "	                        A.SOURCE_SYSTEM,"
					    + "	                        A.QUANTITY,"
					    + "	                        A.SPARES_CATEGORY,"
					    + "	                        A.SPARES_INDICATOR,"
					    + "	                        A.DEFAULT_PERCENT,"
					    + "	                        B.TO_CURRENCY"
					    + "			FROM DDSAFM.ODS_SQT_SPIR_V A"
					    + "				LEFT OUTER JOIN DDSAFM.ODS_SQT_PRICE_LOOK_UP_MV B ON A.COMPONENT_ITEM_NUMBER = B.PART_NUMBER"
					    + "				LEFT OUTER JOIN DDSAFM.LEAD_TIME_LOOKUP_MV C ON A.COMPONENT_ITEM_NUMBER = C.ITEM_NUMBER"
//					    + "	          FROM DDSAFM.ODS_SQT_SPIR_V           A,"
//					    + "	               DDSAFM.ODS_SQT_PRICE_LOOK_UP_MV B,"
//					    + "	               DDSAFM.LEAD_TIME_LOOKUP_MV      C"
//					    + "	         WHERE A.COMPONENT_ITEM_NUMBER = B.PART_NUMBER(+)"
//					    + "	           AND A.COMPONENT_ITEM_NUMBER = C.ITEM_NUMBER(+)"
					    + "	           WHERE (B.TO_CURRENCY = :currency OR B.TO_CURRENCY IS NULL)"
					    + "	           AND (B.REGION = :region OR B.REGION IS NULL)"
					    + "	           AND (C.REGION = :region OR C.REGION IS NULL)"
					    + "	           AND A.SERIAL_NUMBER in"
					    + "	               (:serialNoList)"
					    + "	           AND a.REC_SOURCE in (:recSourceList) "
					    + "	         ORDER BY A.COMPONENT_ITEM_NUMBER) in_query ";
			} else if (reportData.getReportType().equalsIgnoreCase("5")) {
				sql = " SELECT distinct A.SALES_ORDER, "
						+ "    A.SALES_ORDER_LINE, "
						+ "   A.CUSTOMER_PO PURCHASE_ORDER_NUMBER, "
						+ "   A.SOLD_TO_CUSTOMER_NAME, "
						+ "   A.SOLD_TO_COUNTRY END_USER_COUNTRY, "
						+ "   A.SOLD_TO_STATE, "
						+ "   A.SOLD_TO_PROVINCE, "
						+ "   A.SOLD_TO_CITY, "
						+ "   A.REP_NAME, "
						+ "   A.ORDERED_ITEM_NUMBER, "
						+ "   A.QUANTITY_SHIPPED, "
						+ "   A.UNIT_SELLING_PRICE, "
						+ "   A.ACTUAL_SHIP_DATE, "
						+ "   A.SERIAL_NUMBER VALVE_SRNO, "
						+ "   A.VALVE_PART_NUMBER, "
						+ "   A.VALVE_DESCRIPTION, "
						+ "   A.TAG_NUMBER, "
						+ "   A.COMPONENT_ITEM_NUMBER, "
						+ "   A.COMPONENT_DESCRIPTION, "
						+ "   A.LEGACY_PART_NUMBER, "
						+ "   A.SPARES_INDICATOR, "
						+ "   A.STOCK_TYPE, "
						+ "   A.QUANTITY, "
						+ "   TO_NUMBER(REGEXP_REPLACE(B.LIST_PRICE, '[^0-9^\\.]', '')) AS LIST_PRICE, "
						+ "   TO_NUMBER(REGEXP_REPLACE(B.LIST_PRICE, '[^0-9^\\.]', '')) AS PART_PRICE, "
						+ "   C.LEAD_TIME, "
						+ "   A.SOURCE_SYSTEM, "
						+ "   B.TO_CURRENCY "
					    + "			FROM ODS_SQT_BY_SALES_ORDER_V A"
					    + "				LEFT OUTER JOIN DDSAFM.ODS_SQT_PRICE_LOOK_UP_MV B ON A.COMPONENT_ITEM_NUMBER = B.PART_NUMBER"
					    + "				LEFT OUTER JOIN DDSAFM.LEAD_TIME_LOOKUP_MV C ON A.COMPONENT_ITEM_NUMBER = C.ITEM_NUMBER"					
//						+ " FROM ODS_SQT_BY_SALES_ORDER_V A, "
//						+ " DDSAFM.ODS_SQT_PRICE_LOOK_UP_MV B, "
//						+ " DDSAFM.LEAD_TIME_LOOKUP_MV      C "
//						+ " where A.COMPONENT_ITEM_NUMBER = B.PART_NUMBER(+) "
//						+ " AND A.COMPONENT_ITEM_NUMBER = C.ITEM_NUMBER(+) "
						+ " WHERE SPARES_INDICATOR IN ('C', 'W', 'I', '1', '2') "
						+ " AND (B.TO_CURRENCY = :currency OR B.TO_CURRENCY IS NULL) "
						+ " AND (B.REGION = :region OR B.REGION IS NULL) "
						+ " AND (C.REGION = :region OR C.REGION IS NULL) "
						+ " AND SERIAL_NUMBER in (:serialNoList) "
						+ " AND a.REC_SOURCE in (:recSourceList) "
						+ " ORDER BY SALES_ORDER_LINE, SERIAL_NUMBER, TAG_NUMBER ";
			} else if (reportData.getReportType().equalsIgnoreCase("6")) {
				sql = " SELECT distinct A.SALES_ORDER, "
						+ "  A.SALES_ORDER_LINE, "
						+ "   A.CUSTOMER_PO PURCHASE_ORDER_NUMBER, "
						+ "  A.SOLD_TO_CUSTOMER_NAME, "
						+ "  A.SOLD_TO_COUNTRY END_USER_COUNTRY, "
						+ "   A.SOLD_TO_STATE, "
						+ "   A.SOLD_TO_PROVINCE, "
						+ "   A.SOLD_TO_CITY, "
						+ "   A.REP_NAME, "
						+ "   A.ORDERED_ITEM_NUMBER, "
						+ "   A.QUANTITY_SHIPPED, "
						+ "   A.UNIT_SELLING_PRICE, "
						+ "   A.ACTUAL_SHIP_DATE, "
						+ "   A.SERIAL_NUMBER VALVE_SRNO, "
						+ "   A.VALVE_PART_NUMBER, "
						+ "   A.VALVE_DESCRIPTION, "
						+ "   A.TAG_NUMBER, "
						+ "   A.COMPONENT_ITEM_NUMBER, "
						+ "   A.COMPONENT_DESCRIPTION, "
						+ "   A.LEGACY_PART_NUMBER, "
						+ "   A.SPARES_INDICATOR, "
						+ "   A.STOCK_TYPE, "
						+ "   A.QUANTITY, "
						+ "   TO_NUMBER(REGEXP_REPLACE(B.LIST_PRICE, '[^0-9^\\.]', '')) AS LIST_PRICE, "
						+ "   C.LEAD_TIME, "
						+ "   A.SOURCE_SYSTEM "
					    + "			FROM ODS_SQT_BY_SALES_ORDER_V A"
					    + "				LEFT OUTER JOIN DDSAFM.ODS_SQT_PRICE_LOOK_UP_MV B ON A.COMPONENT_ITEM_NUMBER = B.PART_NUMBER"
					    + "				LEFT OUTER JOIN DDSAFM.LEAD_TIME_LOOKUP_MV C ON A.COMPONENT_ITEM_NUMBER = C.ITEM_NUMBER"
//						+ "  FROM ODS_SQT_BY_SALES_ORDER_V        A, "
//						+ "   DDSAFM.ODS_SQT_PRICE_LOOK_UP_MV B, "
//						+ "   DDSAFM.LEAD_TIME_LOOKUP_MV      C "
//						+ " WHERE A.COMPONENT_ITEM_NUMBER = B.PART_NUMBER(+) "
//						+ "  AND A.COMPONENT_ITEM_NUMBER = C.ITEM_NUMBER(+) "
						+ " WHERE (B.TO_CURRENCY = :currency OR B.TO_CURRENCY IS NULL) "
						+ " AND (B.REGION = :region OR B.REGION IS NULL) "
						+ " AND (C.REGION = :region OR C.REGION IS NULL) "
						+ " AND SERIAL_NUMBER in (:serialNoList) "
						+ " AND a.REC_SOURCE in (:recSourceList) "
						+ " ORDER by SOURCE_SYSTEM, SERIAL_NUMBER ";
			} else if (reportData.getReportType().equalsIgnoreCase("7")) {
				/*
				sql = "SELECT distinct A.ACTUAL_SHIP_DATE, "
						+ " A.SERIAL_NUMBER as VALVE_SRNO, "
						+ " A.TAG_NUMBER, "
						+ " A.SALES_ORDER, "
						+ " A.VALVE_DESCRIPTION, "
						+ " A.COMPONENT_ITEM_NUMBER, "
						+ " A.COMPONENT_DESCRIPTION, "
						+ " A.QUANTITY, "
						+ " A.SOLD_TO_CUSTOMER_NAME as END_USER_NAME, "
						+ " A.SOLD_TO_COUNTRY as SOLD_TO_COUNTRY, "
						+ " null as END_USER_LOCATION, "
						+ " TO_NUMBER(REGEXP_REPLACE(B.LIST_PRICE, '[^0-9^\\.]', '')) AS LIST_PRICE, "
						+ " TO_NUMBER(REGEXP_REPLACE(B.LIST_PRICE, '[^0-9^\\.]', '')) *  "
						+ " NVL(A.QUANTITY, 0) AS TOTAL_PRICE, "
						+ " C.LEAD_TIME, "
						+ " A.SPARES_INDICATOR, "
						+ " B.TO_CURRENCY, "
						+ " (SELECT COMPANY FROM FPTODS.SQT_CHANNEL_SSO WHERE SSO_ID = :sso) as CHANNEL_PARTNER"
					    + "			FROM ODS_SQT_BY_SALES_ORDER_V A"
					    + "				LEFT OUTER JOIN DDSAFM.ODS_SQT_PRICE_LOOK_UP_MV B ON A.COMPONENT_ITEM_NUMBER = B.PART_NUMBER"
					    + "				LEFT OUTER JOIN DDSAFM.LEAD_TIME_LOOKUP_MV C ON A.COMPONENT_ITEM_NUMBER = C.ITEM_NUMBER"						
//						+ " FROM ODS_SQT_BY_SALES_ORDER_V A, "
//						+ " DDSAFM.ODS_SQT_PRICE_LOOK_UP_MV B, "
//						+ " DDSAFM.LEAD_TIME_LOOKUP_MV C "
//						+ " WHERE A.COMPONENT_ITEM_NUMBER = B.PART_NUMBER(+) "
//						+ " AND A.COMPONENT_ITEM_NUMBER = C.ITEM_NUMBER(+) "
						+ " WHERE (B.TO_CURRENCY = :currency OR B.TO_CURRENCY IS NULL) "
						+ " AND (B.REGION = :region OR B.REGION IS NULL) "
						+ " AND (C.REGION = :region OR C.REGION IS NULL) "
						+ " AND SPARES_INDICATOR IN ('C', 'W', 'I', '1', '2') "
						+ " AND SERIAL_NUMBER in (:serialNoList) "
						+ " AND a.REC_SOURCE in (:recSourceList) "
						+ " ORDER BY A.SERIAL_NUMBER, A.TAG_NUMBER, A.SALES_ORDER ";
			*/
			sql="SELECT ACTUAL_SHIP_DATE,VALVE_SRNO,TAG_NUMBER,SALES_ORDER,VALVE_DESCRIPTION,COMPONENT_ITEM_NUMBER,COMPONENT_DESCRIPTION,SUM(QUANTITY) QUANTITY,"
					+ "END_USER_NAME,SOLD_TO_COUNTRY,END_USER_LOCATION,LIST_PRICE,TOTAL_PRICE,LEAD_TIME,SPARES_INDICATOR,TO_CURRENCY,"
					+ "CHANNEL_PARTNER FROM (SELECT A.ACTUAL_SHIP_DATE,A.SERIAL_NUMBER as VALVE_SRNO,A.TAG_NUMBER,  A.SALES_ORDER, A.VALVE_DESCRIPTION,"
					+ "A.COMPONENT_ITEM_NUMBER,CASE WHEN SUBSTR(A.COMPONENT_DESCRIPTION,1,3)='(+)' THEN LTRIM(REPLACE(A.COMPONENT_DESCRIPTION,'(+)'))"
					+ "ELSE A.COMPONENT_DESCRIPTION END  AS COMPONENT_DESCRIPTION,A.QUANTITY,A.SOLD_TO_CUSTOMER_NAME as END_USER_NAME, "
					+ "A.SOLD_TO_COUNTRY as SOLD_TO_COUNTRY, null as END_USER_LOCATION,"
					+ "TO_NUMBER(REGEXP_REPLACE(B.LIST_PRICE, '[^0-9^\\.]','')) AS LIST_PRICE,"
					+ "TO_NUMBER(REGEXP_REPLACE(B.LIST_PRICE, '[^0-9^\\.]', '')) *   NVL(A.QUANTITY, 0) AS TOTAL_PRICE,C.LEAD_TIME, "
					+ "A.SPARES_INDICATOR, B.TO_CURRENCY,(SELECT COMPANY FROM FPTODS.SQT_CHANNEL_SSO WHERE SSO_ID = :sso) as CHANNEL_PARTNER "
					+ "FROM ODS_SQT_BY_SALES_ORDER_V A LEFT OUTER JOIN DDSAFM.ODS_SQT_PRICE_LOOK_UP_MV B ON A.COMPONENT_ITEM_NUMBER = B.PART_NUMBER  "
					+ "LEFT OUTER JOIN DDSAFM.LEAD_TIME_LOOKUP_MV C ON A.COMPONENT_ITEM_NUMBER = C.ITEM_NUMBER "
					+ "WHERE (B.TO_CURRENCY = :currency OR B.TO_CURRENCY IS NULL)  AND (B.REGION = :region OR B.REGION IS NULL) AND (C.REGION = :region OR C.REGION IS NULL) "
					+ "AND SPARES_INDICATOR IN ('C', 'W', 'I', '1', '2')  AND SERIAL_NUMBER in (:serialNoList)  AND a.REC_SOURCE in (:recSourceList) ORDER BY "
					+ "A.COMPONENT_ITEM_NUMBER,A.SERIAL_NUMBER, A.TAG_NUMBER,A.SALES_ORDER) GROUP BY ACTUAL_SHIP_DATE,VALVE_SRNO,TAG_NUMBER,SALES_ORDER,"
					+ "VALVE_DESCRIPTION,COMPONENT_ITEM_NUMBER,COMPONENT_DESCRIPTION,END_USER_NAME,SOLD_TO_COUNTRY,END_USER_LOCATION,LIST_PRICE,"
					+ "TOTAL_PRICE,LEAD_TIME,SPARES_INDICATOR,TO_CURRENCY,CHANNEL_PARTNER ORDER BY SALES_ORDER,VALVE_SRNO,COMPONENT_ITEM_NUMBER,TAG_NUMBER";
			}
		}
		if (reportData.isWipSpir()) {
			paramMap.addValue("sso", sso);
		} else {
			paramMap.addValue("currency", reportData.getCurrency());
			paramMap.addValue("region", reportData.getRegion());
			paramMap.addValue("serialNoList", serialNoList);
			paramMap.addValue("recSourceList", recSourceList);
			if (reportData.getReportType().equalsIgnoreCase("7")) {
				paramMap.addValue("sso", sso);
			}
		}
		try {
			result = this.namedParamTemplate.query(sql, paramMap,
					new ReportMapper());
		} catch (Exception e) {
			logger.info("Exception when running query: " + e);
		}
		return result;
	}

	public byte[] generateExcel(ReportData reportData, String sso) {
		ExcelExport exportExcel = new ExcelExport();
		CurrencyDetails currencyDetail = getCurrencySymbol(reportData.getCurrency());
		return exportExcel.generateExcel(getReportData(reportData, sso),
				reportData,currencyDetail.getCurrencySymbol(), sso);

	}

	public byte[] generatePdf(ReportData reportData, String sso) {
		PDFExport exportPdf = new PDFExport();
		logger.info("inside pdf method");
		CurrencyDetails currencyDetail = getCurrencySymbol(reportData.getCurrency());
		logger.info("currency symbol :"+ currencyDetail.getCurrencySymbol());
	
		return exportPdf.generatePDF(getReportData(reportData, sso),
				reportData, currencyDetail.getCurrencySymbol() ,sso);


	}
	
	public CurrencyDetails getCurrencySymbol(String currency){
		logger.info("inside getcurrencysymbol method :"+ currency);
		String currencyQuery = "select CURRENCY_SYMBOL,TO_CURRENCY,FROM_CURRENCY from ddsafm.sqt_currency_list where TO_CURRENCY= :currency";
		SqlParameterSource  param = new MapSqlParameterSource("currency",currency);
		CurrencyDetails currencyDetail = (CurrencyDetails) namedParamTemplate.queryForObject(currencyQuery, param ,
				new CurrencyMapper());
		
		return currencyDetail;
	}
	
	public static final class CurrencyMapper implements RowMapper<CurrencyDetails>{
		public CurrencyDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
			CurrencyDetails result = new CurrencyDetails();
			List<String> colList = new ArrayList<String>();
			ResultSetMetaData meta = rs.getMetaData();
			for(int i =1; i<=meta.getColumnCount();i++){
				colList.add(meta.getColumnName(i));
			}
			result.setCurrencySymbol(colList.contains("CURRENCY_SYMBOL")== true ? rs.getString("CURRENCY_SYMBOL") : null);
			result.setToCurrency(colList.contains("TO_CURRENCY")== true ? rs.getString("TO_CURRENCY") : null);
			result.setFromCurrency(colList.contains("FROM_CURRENCY")== true ? rs.getString("FROM_CURRENCY") : null);
			return result;
		}
			
	}

	public static final class ReportMapper implements RowMapper<Report> {
		public Report mapRow(ResultSet rs, int rowNum) throws SQLException {
			Report result = new Report();
			List<String> colList = new ArrayList<String>();
			ResultSetMetaData meta = rs.getMetaData();
			for (int i = 1; i <= meta.getColumnCount(); i++) {
				colList.add(meta.getColumnName(i));
			}
			result.setActualShippedDate(colList.contains("ACTUAL_SHIP_DATE") == true ? rs
					.getDate("ACTUAL_SHIP_DATE") : null);
			result.setComponentDescription(colList
					.contains("COMPONENT_DESCRIPTION") ? rs
					.getString("COMPONENT_DESCRIPTION") : "");
			result.setComponentItemNumber(colList
					.contains("COMPONENT_ITEM_NUMBER") ? rs
					.getString("COMPONENT_ITEM_NUMBER") : "");
			result.setDefaultPercent(colList.contains("DEFAULT_PERCENT") ? rs
					.getDouble("DEFAULT_PERCENT") : 0);
			result.setDescription(colList.contains("DESCRIPTION") ? rs
					.getString("DESCRIPTION") : "");
			result.setEndUserCountry(colList.contains("END_USER_COUNTRY") ? rs
					.getString("END_USER_COUNTRY") : "");
			result.setEndUserLocation(colList.contains("END_USER_LOCATION") ? rs
					.getString("END_USER_LOCATION") : "");
			result.setEndUserName(colList.contains("END_USER_NAME") ? rs
					.getString("END_USER_NAME") : "");
			result.setExtendedListPrice(colList.contains("EXTND_LIST_PRICE") ? rs
					.getDouble("EXTND_LIST_PRICE") : 0);
			result.setFactory(colList.contains("FACTORY") ? rs
					.getString("FACTORY") : "");
			result.setLeadTime(colList.contains("LEAD_TIME") ? rs
					.getString("LEAD_TIME") : "");
			result.setLegacyPartNumber(colList.contains("LEGACY_PART_NUMBER") ? rs
					.getString("LEGACY_PART_NUMBER") : "");
			result.setListPrice(colList.contains("LIST_PRICE") ? rs
					.getDouble("LIST_PRICE") : 0);
			result.setOrderedItemNumber(colList.contains("ORDERED_ITEM_NUMBER") ? rs
					.getString("ORDERED_ITEM_NUMBER") : "");
			result.setPartNumber(colList.contains("PART_NO") ? rs
					.getString("PART_NO") : "");
			result.setPurchaseOrderNumber(colList
					.contains("PURCHASE_ORDER_NUMBER") ? rs
					.getString("PURCHASE_ORDER_NUMBER") : "");
			result.setQuantity(colList.contains("QUANTITY") ? rs
					.getInt("QUANTITY") : 0);
			result.setQuantityShipped(colList.contains("QUANTITY_SHIPPED") ? rs
					.getInt("QUANTITY_SHIPPED") : 0);
			result.setRecommendedQuantity(colList
					.contains("RECOMMENDED_QUANTITY") ? rs
					.getInt("RECOMMENDED_QUANTITY") : 0);
			result.setRecSource(colList.contains("REC_SOURCE") ? rs
					.getString("REC_SOURCE") : "");
			result.setRegion(colList.contains("REGION") ? rs
					.getString("REGION") : "");
			result.setRepName(colList.contains("REP_NAME") ? rs
					.getString("REP_NAME") : "");
			result.setSalesOrder(colList.contains("SALES_ORDER") ? rs
					.getString("SALES_ORDER") : "");
			result.setSalesOrderLine(colList.contains("SALES_ORDER_LINE") ? rs
					.getString("SALES_ORDER_LINE") : "");
			result.setSoldToCity(colList.contains("SOLD_TO_CITY") ? rs
					.getString("SOLD_TO_CITY") : "");
			result.setSoldToCustomerName(colList
					.contains("SOLD_TO_CUSTOMER_NAME") ? rs
					.getString("SOLD_TO_CUSTOMER_NAME") : "");
			result.setSoldToProvince(colList.contains("SOLD_TO_PROVINCE") ? rs
					.getString("SOLD_TO_PROVINCE") : "");
			result.setSoldToState(colList.contains("SOLD_TO_STATE") ? rs
					.getString("SOLD_TO_STATE") : "");
			result.setSourceSystem(colList.contains("SOURCE_SYSTEM") ? rs
					.getString("SOURCE_SYSTEM") : "");
			result.setSpareCategory(colList.contains("SPARES_CATEGORY") ? rs
					.getString("SPARES_CATEGORY") : "");
			result.setSpareIndicator(colList.contains("SPARES_INDICATOR") ? rs
					.getString("SPARES_INDICATOR") : "");
			result.setSpareQuotes(colList.contains("SPARE_QUOTE") ? rs
					.getString("SPARE_QUOTE") : "");
			result.setSpareType(colList.contains("SPARE_TYPE") ? rs
					.getString("SPARE_TYPE") : "");
			result.setStockType(colList.contains("STOCK_TYPE") ? rs
					.getString("STOCK_TYPE") : "");
			result.setTagNumber(colList.contains("TAG_NUMBER") ? rs
					.getString("TAG_NUMBER") : "");
			result.setUnitSellingPrice(colList.contains("UNIT_SELLING_PRICE") ? rs
					.getString("UNIT_SELLING_PRICE") : "");
			result.setUserName(colList.contains("USER_NAME") ? rs
					.getString("USER_NAME") : "");
			result.setValveDescription(colList.contains("VALVE_DESCRIPTION") ? rs
					.getString("VALVE_DESCRIPTION") : "");
			result.setValvePartNumber(colList.contains("VALVE_PART_NUMBER") ? rs
					.getString("VALVE_PART_NUMBER") : "");
			result.setValveSerialNumber(colList.contains("VALVE_SRNO") ? rs
					.getString("VALVE_SRNO")!=null?rs.getString("VALVE_SRNO"):"" : "");
			result.setChannelPartner(colList.contains("CHANNEL_PARTNER") ? rs
					.getString("CHANNEL_PARTNER") : "");
			result.setCurrencyUnit(colList.contains("TO_CURRENCY") ? rs
					.getString("TO_CURRENCY") : "");
			result.setRecomendedQty(colList.contains("RECOMENDEDQTY") ? rs
					.getInt("RECOMENDEDQTY"):0);

			return result;
		}
	}

}