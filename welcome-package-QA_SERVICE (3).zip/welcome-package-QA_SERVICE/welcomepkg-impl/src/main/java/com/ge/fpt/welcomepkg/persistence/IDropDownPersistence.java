package com.ge.fpt.welcomepkg.persistence;

import com.ge.fpt.welcomepkg.api.DropDownItem;
import com.ge.fpt.welcomepkg.api.EndUserDetail;

import java.util.List;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

public abstract interface IDropDownPersistence
{
  @Transactional(propagation=Propagation.REQUIRED)
  public abstract List<DropDownItem> getCurrencyCodeList();
  
  @Transactional(propagation=Propagation.REQUIRED)
  public abstract List<DropDownItem> getRegionList();
  
  @Transactional(propagation=Propagation.REQUIRED)
  public abstract List<DropDownItem> getRegionListByUser(String sso);
  
  @Transactional(propagation=Propagation.REQUIRED)
  public abstract List<DropDownItem> getCountryCodeList();
  
  @Transactional(propagation=Propagation.REQUIRED)
  public abstract List<DropDownItem> getEndUserIndustryList();
  
  @Transactional(propagation = Propagation.REQUIRED)
  public abstract List<DropDownItem> getStateList(String country);
  
  @Transactional(propagation = Propagation.REQUIRED)
  public abstract List<DropDownItem> getSpareIndicatorList();
  
  @Transactional(propagation = Propagation.REQUIRED)
  public abstract List<DropDownItem> getStockTypeList();
  
  @Transactional(propagation = Propagation.REQUIRED)
  public abstract List<DropDownItem> getRecsourceList();
  
  @Transactional(propagation = Propagation.REQUIRED)
  public abstract List<DropDownItem> getConfiguratorOption();
  
  @Transactional(propagation = Propagation.REQUIRED)
  public abstract List<DropDownItem> getSiteInfo(String sso);
  
  @Transactional(propagation=Propagation.REQUIRED)
  public abstract List<DropDownItem> getChannelList(String productCode);

  @Transactional(propagation = Propagation.REQUIRED)
  public abstract List<EndUserDetail> getEndUserList(String searchTxt);
  
  @Transactional(propagation = Propagation.REQUIRED)
  public abstract List<EndUserDetail> getEndUserListByTxt(String searchTxt);

}
