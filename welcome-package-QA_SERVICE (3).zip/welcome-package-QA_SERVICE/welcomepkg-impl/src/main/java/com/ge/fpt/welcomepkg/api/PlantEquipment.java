package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;

public class PlantEquipment implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -2486511903617059052L;
	private String lastServiced;
	private String isServiceNeed ;
	private String manufacturerName;
	private String recSource;
	private Long cpLocId;
	private String isPriority;
	private String isGe; 
	private Long plantId;
	private String serialNumber;
	private String valveId;
	private String cpLocation;
	private String description;
	private String itemNumber;
	private String tagNumber;
	private String shipmentDate;
	private String requiredService;
	
	private Long orderLineId; 
	private String orderNumber;

	public String getLastServiced() {
		return lastServiced;
	}
	public void setLastServiced(String lastServiced) {
		this.lastServiced = lastServiced;
	}
	public String getIsServiceNeed() {
		return isServiceNeed;
	}
	public void setIsServiceNeed(String isServiceNeed) {
		this.isServiceNeed = isServiceNeed;
	}
	public String getManufacturerName() {
		return manufacturerName;
	}
	public void setManufacturerName(String manufacturerName) {
		this.manufacturerName = manufacturerName;
	}
	public String getRecSource() {
		return recSource;
	}
	public void setRecSource(String recSource) {
		this.recSource = recSource;
	}
	public Long getCpLocId() {
		return cpLocId;
	}
	public void setCpLocId(Long cpLocId) {
		this.cpLocId = cpLocId;
	}
	public String getIsPriority() {
		return isPriority;
	}
	public void setIsPriority(String isPriority) {
		this.isPriority = isPriority;
	}
	public String getIsGe() {
		return isGe;
	}
	public void setIsGe(String isGe) {
		this.isGe = isGe;
	}
	public Long getPlantId() {
		return plantId;
	}
	public void setPlantId(Long plantId) {
		this.plantId = plantId;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getValveId() {
		return valveId;
	}
	public void setValveId(String valveId) {
		this.valveId = valveId;
	}
	public String getCpLocation() {
		return cpLocation;
	}
	public void setCpLocation(String cpLocation) {
		this.cpLocation = cpLocation;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getItemNumber() {
		return itemNumber;
	}
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}
	public String getTagNumber() {
		return tagNumber;
	}
	public void setTagNumber(String tagNumber) {
		this.tagNumber = tagNumber;
	}
	public String getShipmentDate() {
		return shipmentDate;
	}
	public void setShipmentDate(String shipmentDate) {
		this.shipmentDate = shipmentDate;
	}
	public Long getOrderLineId() {
		return orderLineId;
	}
	public void setOrderLineId(Long orderLineId) {
		this.orderLineId = orderLineId;
	}
	public String getRequiredService() {
		return requiredService;
	}
	public void setRequiredService(String requiredService) {
		this.requiredService = requiredService;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	@Override
	public String toString() {
		return "PlantEquipment [lastServiced=" + lastServiced + ", isServiceNeed=" + isServiceNeed
				+ ", manufacturerName=" + manufacturerName + ", recSource=" + recSource + ", cpLocId=" + cpLocId
				+ ", isPriority=" + isPriority + ", isGe=" + isGe + ", plantId=" + plantId + ", serialNumber="
				+ serialNumber + ", valveId=" + valveId + ", cpLocation=" + cpLocation + ", description=" + description
				+ ", itemNumber=" + itemNumber + ", tagNumber=" + tagNumber + ", shipmentDate=" + shipmentDate
				+ ", requiredService=" + requiredService + ", orderLineId=" + orderLineId + ", orderNumber="
				+ orderNumber + "]";
	}
	

	
}
