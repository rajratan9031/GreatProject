package com.ge.fpt.welcomepkg.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.activation.CommandMap;
import javax.activation.MailcapCommandMap;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.sql.DataSource;
import org.apache.commons.lang.StringUtils;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.fpt.welcomepkg.api.ChannelData;
import com.ge.fpt.welcomepkg.api.Inventory;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;


public class InventoryPersistenceImpl implements IInventoryPersistence {

	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory
			.getLogger(InventoryPersistenceImpl.class);

	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;

	/**
	 * Data source for the JDBC
	 */
	DataSource dataSource;

	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;

	NamedParameterJdbcTemplate namedParamTemplate;

	/**
	 * @return the dataSource
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}

	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate = new NamedParameterJdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	/* (non-Javadoc)
	 * @see com.ge.fpt.welcomepkg.persistence.IInventoryPersistence#getInventory(com.ge.fpt.welcomepkg.api.Inventory)
	 */
	@Override
	public List<Inventory> getInventory(Inventory inventory) {
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		String sql = "select * from ddsafm.sqt_inventory_part_upload_v where 1=1";
		if (inventory.getPartNumber() != null
				&& !inventory.getPartNumber().isEmpty()) {
			sql += " and upper(Part_number) like upper('%'||:pn||'%') ";
			parameters.addValue("pn", inventory.getPartNumber());
		}
		if (inventory.getPartDesc() != null
				&& !inventory.getPartDesc().isEmpty()) {
			sql += " and upper(Part_desc) like upper('%'||:pd||'%') ";
			parameters.addValue("pd", inventory.getPartDesc());
		}

		if (inventory.getLegacyPart() != null
				&& !inventory.getLegacyPart().isEmpty()) {
			sql += " and upper(legacy_part) like upper('%'||:lp||'%') ";
			parameters.addValue("lp", inventory.getLegacyPart());
		}
		List<Inventory> inv = this.namedParamTemplate.query(sql, parameters,
				new InvMapper());
		return inv;
	}

	private static final class InvMapper implements RowMapper<Inventory> {
		public InvMapper() {
		}

		@Override
		public Inventory mapRow(ResultSet rs, int rowNum) throws SQLException {
			Inventory result = new Inventory();
			result.setId(rs.getLong("UPLOAD_ID"));
			result.setPartNumber(rs.getString("PART_NUMBER"));
			result.setPartDesc(rs.getString("PART_DESC"));
			result.setLegacyPart(rs.getString("LEGACY_PART"));
			result.setRepPart(rs.getString("REP_PART"));
			result.setQuantity(rs.getInt("QUANTITY"));
			result.setCompany(rs.getString("COMPANY"));
			result.setPhone(rs.getString("PHONE"));
			result.setEmail(rs.getString("EMAIL"));
			result.setSite(rs.getString("SITE"));
			result.setUploadBy(rs.getString("UPLOAD_BY"));
			result.setUploadDate(rs.getDate("UPLOAD_DATE"));
			result.setProductCode(rs.getString("PRODUCT_CODE"));
			return result;

		}
	}
	
	/* (non-Javadoc)
	 * @see com.ge.fpt.welcomepkg.persistence.IInventoryPersistence#uploadInventory(java.util.HashMap)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public StatusInfo uploadInventory(HashMap getCompleteData) {
		StatusInfo info = new StatusInfo();

		List<List<String>> getCompleteExcelData = (List<List<String>>) getCompleteData.get("getExcelData");
		String ssoID = (String) getCompleteData.get("sso_id");
		String site = (String) getCompleteData.get("site");
		String pc = (String) getCompleteData.get("pc");

		String deleteSql =  "Delete from fptods.sqt_inventory_part_upload_t where  site=? and product_code=?";
		String insertsql = "insert into fptods.sqt_inventory_part_upload_t (upload_id,part_number,part_desc,"
				+ " legacy_part,rep_part,quantity,site,product_code,upload_by,upload_date) values "
				+ " (fptods.inventory_s.nextval,?,?,?,?,?,?,?,?,sysdate)";
		//String countsql = "select Count(*) from fptods.sqt_inventory_part_upload_t where part_number=? and site=?";
		try{
		if(getCompleteExcelData.size() > 1){
			this.jdbcTemplate.update(deleteSql,new Object[] { site, pc});
			List<Object[]> parameters = new ArrayList<Object[]>();

			List<Object[]> invalidRecords = new ArrayList<Object[]>();
			for (int i = 1; i < getCompleteExcelData.size(); i++) {	
					if(!(getCompleteExcelData.get(i).get(2).equals("0")) && !(StringUtils.isEmpty(getCompleteExcelData.get(i).get(2))) &&
							isValidNumber(getCompleteExcelData.get(i).get(2))){
						Object[] params = {getCompleteExcelData.get(i).get(0),getCompleteExcelData.get(i).get(1),getCompleteExcelData.get(i).get(3),getCompleteExcelData.get(i).get(4),
									getCompleteExcelData.get(i).get(2),site,pc,ssoID};
						parameters.add(params);
					}
					else{ 
						if( !(getCompleteExcelData.get(i).get(0).equals(""))){
							logger.info("invalid record :"+ getCompleteExcelData.get(i).get(2));
							String reason ="Quantity cannot be zero or negative and cannot have alphabets/special characters";
							Object[] invalidData = {getCompleteExcelData.get(i).get(0),getCompleteExcelData.get(i).get(1),getCompleteExcelData.get(i).get(3),getCompleteExcelData.get(i).get(4),
							getCompleteExcelData.get(i).get(2),site,pc,ssoID,reason};
							invalidRecords.add(invalidData);
						}
					}
				}
			 this.jdbcTemplate.batchUpdate(insertsql, parameters);
		logger.info("loading completed");
		logger.info("invalid data count :"+ invalidRecords.size());

		info.setStatusCode(0);
		info.setStatusMessage("Data Save successfully ");
		info.setData(invalidRecords);
		}else{
			info.setStatusCode(1);
			info.setStatusMessage("No Data available to upload ");	
		}
		return info;

	}catch(Exception ex){
		logger.info("inventory upload issue : "+ex);
		info.setStatusCode(-1);
		info.setStatusMessage(ex.getMessage());	
		return info;
	}
}
	
	public static boolean isValidNumber(String num){
		boolean isValidNumber=false;
		try{
			if(Double.parseDouble(num)>0){
				isValidNumber = true;
			}
		}
		catch(NumberFormatException ex){
			return isValidNumber;
		}
		return isValidNumber;
	}

	public StatusInfo sendEmail(Map mailDetails, String sso) {
		MailcapCommandMap mc = (MailcapCommandMap) CommandMap.getDefaultCommandMap();
		mc.addMailcap("text/html;; x-java-content-handler=com.sun.mail.handlers.text_html");
		mc.addMailcap("text/xml;; x-java-content-handler=com.sun.mail.handlers.text_xml");
		mc.addMailcap("text/plain;; x-java-content-handler=com.sun.mail.handlers.text_plain");
		mc.addMailcap("multipart/*;; x-java-content-handler=com.sun.mail.handlers.multipart_mixed");
		mc.addMailcap("message/rfc822;; x-java-content- handler=com.sun.mail.handlers.message_rfc822");
		logger.info("email notifications");
		String recipient = mailDetails.get("recipient")!=null?mailDetails.get("recipient").toString():"";
		String subject = mailDetails.get("subject")!=null?mailDetails.get("subject").toString():"";
	    String body = mailDetails.get("message")!=null?mailDetails.get("message").toString():"";
	    String from;
		String smtpHostServer = "smtpmail.np.ge.com";
		String smptfordev = "10.38.9.235";
		//Get the session object
		 Properties properties = System.getProperties();  
	     properties.setProperty("mail.smtp.host", smtpHostServer);  
	     Session session = Session.getDefaultInstance(properties); 
	     //compose the message  
	     int count=0;
	      try{  
	         MimeMessage message = new MimeMessage(session);  
	         logger.info("User SSO"+sso);
	         String replyTo="";
	         logger.info("count result");
	         String sql1 ="select count(*) from FPTODS.SQT_CHANNEL_SSO WHERE SSO_ID= ?";
	         logger.info("count result"+sql1);
	         count =  jdbcTemplate.queryForInt(sql1, new Object[] { sso });
	         logger.info("count result"+count);
	         if(count==0){
	        	 from = "noreplywelcomepackage@ge.com";
	        	 logger.info("count result"+from);
	        	 replyTo="noreplywelcomepackage@ge.com";
	         }
	         else{       	 
	            String sql="select email from FPTODS.SQT_CHANNEL_SSO WHERE SSO_ID = ?";
		        String getEmail =  jdbcTemplate.queryForObject(sql, new Object[] { sso }, String.class);
		        logger.info("Email result"+getEmail);
		        if(null==getEmail || getEmail.equals("") ){
		        	logger.info("Email result"+getEmail);
		        	from= mailDetails.get("from").toString();
		        	replyTo="noreplywelcomepackage@ge.com";
		        }
		        else
		        {
		        logger.info("Email result"+getEmail);
		        replyTo=getEmail;
		        from= mailDetails.get("from").toString();
		        }
		        
	      }
		        message.setFrom(new InternetAddress(from));  
		        message.addRecipient(Message.RecipientType.TO,new InternetAddress(recipient));  
		        message.setSubject(subject);  
		        message.setText(body);
		        message.setReplyTo(new javax.mail.Address[]
		        		{
		        		    new javax.mail.internet.InternetAddress(replyTo)
		        		});
	         logger.info("reply to"+message.getReplyTo());
	      // Send message  
	         Transport.send(message);  
	         logger.info("message sent successfully....");  
	         StatusInfo info = new StatusInfo();
	 		info.setStatusMessage("successfull");
	 		info.setStatusCode(1);
	 		logger.info("email notifications1"+info.getStatusMessage()+"info = "+info.getStatusCode());
	 		return info;
	      }catch (MessagingException mex) {
	    	  mex.printStackTrace();
	    	  return null;
	      }  
	}


}