package com.ge.fpt.welcomepkg.api;

public class PartLookupData {

	
	private static final long serialVersionUID = -5579175197980496818L;
	
	private String partNumber;
	private String partDescription;
	
	
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getPartDescription() {
		return partDescription;
	}
	public void setPartDescription(String partDescription) {
		this.partDescription = partDescription;
	}
	
	public PartLookupData() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public PartLookupData(String partNumber, String partDescription) {
		super();
		this.partNumber = partNumber;
		this.partDescription = partDescription;
	}
	
}
