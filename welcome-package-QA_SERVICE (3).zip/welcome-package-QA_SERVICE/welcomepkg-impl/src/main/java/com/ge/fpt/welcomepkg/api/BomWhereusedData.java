package com.ge.fpt.welcomepkg.api;




public class BomWhereusedData {
	
	private static final long serialVersionUID = 1L;
	private String componentPart;
	private Double quantityPerAssembly;
	private String destinationCode;
	private String engrChangeNumber;
	private String pmtStatusCode;
	private String pmtDrawingNumber;
	private String pmtDescription;
	private long rowNumber;
	public String getComponentPart() {
		return componentPart;
	}
	public void setComponentPart(String componentPart) {
		this.componentPart = componentPart;
	}
	public Double getQuantityPerAssembly() {
		return quantityPerAssembly;
	}
	public void setQuantityPerAssembly(Double quantityPerAssembly) {
		this.quantityPerAssembly = quantityPerAssembly;
	}
	public String getDestinationCode() {
		return destinationCode;
	}
	public void setDestinationCode(String destinationCode) {
		this.destinationCode = destinationCode;
	}
	public String getEngrChangeNumber() {
		return engrChangeNumber;
	}
	public void setEngrChangeNumber(String engrChangeNumber) {
		this.engrChangeNumber = engrChangeNumber;
	}
	public String getPmtStatusCode() {
		return pmtStatusCode;
	}
	public void setPmtStatusCode(String pmtStatusCode) {
		this.pmtStatusCode = pmtStatusCode;
	}
	public String getPmtDrawingNumber() {
		return pmtDrawingNumber;
	}
	public void setPmtDrawingNumber(String pmtDrawingNumber) {
		this.pmtDrawingNumber = pmtDrawingNumber;
	}
	public String getPmtDescription() {
		return pmtDescription;
	}
	public void setPmtDescription(String pmtDescription) {
		this.pmtDescription = pmtDescription;
	}
	public long getRowNumber() {
		return rowNumber;
	}
	public void setRowNumber(long rowNumber) {
		this.rowNumber = rowNumber;
	}
	@Override
	public String toString() {
		return "BomWhereusedData [componentPart=" + componentPart + ", quantityPerAssembly=" + quantityPerAssembly
				+ ", destinationCode=" + destinationCode + ", engrChangeNumber=" + engrChangeNumber + ", pmtStatusCode="
				+ pmtStatusCode + ", pmtDrawingNumber=" + pmtDrawingNumber + ", pmtDescription=" + pmtDescription
				+ ", rowNumber=" + rowNumber + "]";
	}
	
	
	

}
