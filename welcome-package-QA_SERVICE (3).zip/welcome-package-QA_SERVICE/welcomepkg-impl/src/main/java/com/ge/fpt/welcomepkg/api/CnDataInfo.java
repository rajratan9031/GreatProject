package com.ge.fpt.welcomepkg.api;

public class CnDataInfo {

private static final long serialVersionUID = 1L;
	
	public CnDataInfo(){
		super();
	}	
	
	
	private String dvsKeyRecordCode;
	private String dvsKeySerialNo;
	private String dvsKeySerlNoDupShipDate;
	private String valvesSku;
	private String  notes;
	private String  invoiceNo;
	private String setPressure;
	private String cds;
	private String backPressure;
	private String temperature;
	private String capacity;
	private String service;
	private String capCode;
	private String springType;
	private String spring;
	private String asme;
	private String size;
	private String bellows;
	private String specialFeatures;
	private String orifice;
	private String productCommodity;
	private String billOfMaterialNo;
	
	

	public String getDvsKeyRecordCode() {
		return dvsKeyRecordCode;
	}
	public void setDvsKeyRecordCode(String dvsKeyRecordCode) {
		this.dvsKeyRecordCode = dvsKeyRecordCode;
	}
	public String getDvsKeySerialNo() {
		return dvsKeySerialNo;
	}
	public void setDvsKeySerialNo(String dvsKeySerialNo) {
		this.dvsKeySerialNo = dvsKeySerialNo;
	}
	public String getDvsKeySerlNoDupShipDate() {
		return dvsKeySerlNoDupShipDate;
	}
	public void setDvsKeySerlNoDupShipDate(String dvsKeySerlNoDupShipDate) {
		this.dvsKeySerlNoDupShipDate = dvsKeySerlNoDupShipDate;
	}
	public String getValvesSku() {
		return valvesSku;
	}
	public void setValvesSku(String valvesSku) {
		this.valvesSku = valvesSku;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getInvoiceNo() {
		return invoiceNo;
	}
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	public String getSetPressure() {
		return setPressure;
	}
	public void setSetPressure(String setPressure) {
		this.setPressure = setPressure;
	}
	public String getCds() {
		return cds;
	}
	public void setCds(String cds) {
		this.cds = cds;
	}
	public String getBackPressure() {
		return backPressure;
	}
	public void setBackPressure(String backPressure) {
		this.backPressure = backPressure;
	}
	public String getTemperature() {
		return temperature;
	}
	public void setTemperature(String temperature) {
		this.temperature = temperature;
	}
	public String getCapacity() {
		return capacity;
	}
	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	public String getCapCode() {
		return capCode;
	}
	public void setCapCode(String capCode) {
		this.capCode = capCode;
	}
	public String getSpringType() {
		return springType;
	}
	public void setSpringType(String springType) {
		this.springType = springType;
	}
	public String getSpring() {
		return spring;
	}
	public void setSpring(String spring) {
		this.spring = spring;
	}
	public String getAsme() {
		return asme;
	}
	public void setAsme(String asme) {
		this.asme = asme;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	public String getBellows() {
		return bellows;
	}
	public void setBellows(String bellows) {
		this.bellows = bellows;
	}
	public String getSpecialFeatures() {
		return specialFeatures;
	}
	public void setSpecialFeatures(String specialFeatures) {
		this.specialFeatures = specialFeatures;
	}
	public String getOrifice() {
		return orifice;
	}
	public void setOrifice(String orifice) {
		this.orifice = orifice;
	}
	public String getProductCommodity() {
		return productCommodity;
	}
	public void setProductCommodity(String productCommodity) {
		this.productCommodity = productCommodity;
	}
	public String getBillOfMaterialNo() {
		return billOfMaterialNo;
	}
	public void setBillOfMaterialNo(String billOfMaterialNo) {
		this.billOfMaterialNo = billOfMaterialNo;
	}
	public CnDataInfo(String dvsKeyRecordCode, String dvsKeySerialNo, String dvsKeySerlNoDupShipDate, String valvesSku,
			String notes, String invoiceNo, String setPressure, String cds, String backPressure, String temperature,
			String capacity, String service, String capCode, String springType, String spring, String asme, String size,
			String bellows, String specialFeatures, String orifice, String productCommodity, String billOfMaterialNo) {
		super();
		this.dvsKeyRecordCode = dvsKeyRecordCode;
		this.dvsKeySerialNo = dvsKeySerialNo;
		this.dvsKeySerlNoDupShipDate = dvsKeySerlNoDupShipDate;
		this.valvesSku = valvesSku;
		this.notes = notes;
		this.invoiceNo = invoiceNo;
		this.setPressure = setPressure;
		this.cds = cds;
		this.backPressure = backPressure;
		this.temperature = temperature;
		this.capacity = capacity;
		this.service = service;
		this.capCode = capCode;
		this.springType = springType;
		this.spring = spring;
		this.asme = asme;
		this.size = size;
		this.bellows = bellows;
		this.specialFeatures = specialFeatures;
		this.orifice = orifice;
		this.productCommodity = productCommodity;
		this.billOfMaterialNo = billOfMaterialNo;
	}
	
	
	
	
}
