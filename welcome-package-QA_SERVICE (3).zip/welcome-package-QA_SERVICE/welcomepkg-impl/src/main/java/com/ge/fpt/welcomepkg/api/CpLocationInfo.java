package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;

public class CpLocationInfo implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long cpId;
private String location;
private String email;
private String phoneNumber;
private String duns;
private String fax;
private boolean isAdmin;


public Long getCpId() {
	return cpId;
}
public void setCpId(Long cpId) {
	this.cpId = cpId;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPhoneNumber() {
	return phoneNumber;
}
public void setPhoneNumber(String phoneNumber) {
	this.phoneNumber = phoneNumber;
}
public String getDuns() {
	return duns;
}
public void setDuns(String duns) {
	this.duns = duns;
}
public String getFax() {
	return fax;
}
public void setFax(String fax) {
	this.fax = fax;
}
public boolean getIsAdmin() {
	return isAdmin;
}
public void setIsAdmin(boolean isAdmin) {
	this.isAdmin = isAdmin;
}
@Override
public String toString() {
	return "CpLocationInfo [cpId=" + cpId + ", location=" + location + ", email=" + email + ", phoneNumber="
			+ phoneNumber + ", duns=" + duns + ", fax=" + fax + ", isAdmin=" + isAdmin + "]";
}
}
