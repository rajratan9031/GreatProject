
package com.ge.fpt.welcomepkg.persistence;

import java.io.File;
import java.io.InputStream;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.regex.Pattern;

import javax.sql.DataSource;
import javax.ws.rs.core.HttpHeaders;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.fpt.welcomepkg.api.DocDownloadDetails;
import com.ge.fpt.welcomepkg.api.DocumentDetails;
import com.ge.fpt.welcomepkg.api.OtherDocumentDetails;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;
import com.ge.fpt.welcomepkg.util.Constants;
import com.ge.fpt.welcomepkg.util.QueryConstants;

public class DocumentPersistenceImpl implements IDocumentPersistence {

	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory.getLogger(DocumentPersistenceImpl.class);

	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;

	/**
	 * Data source for the JDBC
	 */
	DataSource dataSource;

	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;

	NamedParameterJdbcTemplate namedParamTemplate;

	/**
	 * @return the dataSource
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}

	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate = new NamedParameterJdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	@Override
	public List<DocumentDetails> getDocumentsBySerialNumber(String serialNumber, List<String> docName) {
		logger.info("inside getDocuments");
		List<DocumentDetails> docs = new ArrayList<>();
		try {
			logger.info("size :" + docName.size());
			String documentNames = docName.get(0).replaceAll("\\[|\\]", "");
			documentNames = documentNames.replaceAll("\\s*,\\s*", ",");
			String[] docNames = documentNames.split(",");

			List<String> names = Arrays.asList(docNames);
			logger.info("names :" + names.size());
			String docQuery = "SELECT al.site_code  AS asitecode,al.type_flow_project AS atypeflowproject,al.project_number AS aprojectnumber,al.sales_order_number AS asalesorder,al.sales_order_line_number AS asalesorderline,al.production_order_number AS aprodorderno,al.serial_number_sap  AS aserialnumbersap,al.document_type AS adoctype,al.document_description  AS adocdesc,al.file_name  AS afilename,al.file_link  AS afilelink,al.document_language AS adoclang,al.document_content_type  AS adocconttype,al.source_system AS asourcesys ,al.md5  AS amd5,'' AS ifilename,'' AS ipath,'' AS iresource,'' AS iserialnumber FROM fptods.SQT_ALFRESCO_SERIAL_NUMBER_T al WHERE al.SERIAL_NUMBER_SAP IS NOT NULL AND al.SERIAL_NUMBER_SAP=:serialNumber And al.file_name =:docName UNION SELECT '' AS asitecode,'' AS atypeflowproject,'' AS aprojectnumber,'' AS asalesorder,'' AS asalesorderline,''  AS aprodorderno,''  AS aserialnumbersap,''              AS adoctype,'' AS adocdesc,''  AS afilename,'' AS afilelink,'' AS adoclang,'IMAGE'  AS adocconttype,'NAS' AS asourcesys ,''  AS amd5,img.file_name  AS ifilename,img.file_path  AS ipath,img.rec_source AS iresource,img.serial_number AS iserialnumber FROM fptods.image_data img WHERE img.file_name=:serialNumber";
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("serialNumber", serialNumber);
			parameters.addValue("docName", names);
			logger.info("query :" + docQuery);
			logger.info("param values :" + parameters.getValue("docName"));
			docs = this.namedParamTemplate.query(docQuery, parameters, new DocumentMapper());
			logger.info("result size  :" + docs.size());
			return docs;
		} catch (Exception ex) {
			logger.info("Error## :" + ex.toString());
		}
		return docs;
	}

	private static final class DocumentMapper implements RowMapper<DocumentDetails> {
		public DocumentMapper() {
		}

		@Override
		public DocumentDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
			DocumentDetails result = new DocumentDetails();
			result.setSiteCode(rs.getString("ASITECODE"));
			result.setTypeFlowProject(rs.getString("ATYPEFLOWPROJECT"));
			result.setProjectNumber(rs.getString("APROJECTNUMBER"));
			result.setSalesOrderNumber(rs.getString("ASALESORDER"));
			result.setSalesOrderLineNumber(rs.getString("ASALESORDERLINE"));
			result.setProductionOrderNumber(rs.getString("APRODORDERNO"));
			result.setSerialNumber(rs.getString("ASERIALNUMBERSAP"));
			result.setDocumentType(rs.getString("ADOCTYPE"));
			result.setDocDesc(rs.getString("ADOCDESC"));
			String accountType = rs.getString("ADOCCONTTYPE");
			if (accountType.equalsIgnoreCase("DATABOOK") || accountType.equalsIgnoreCase("OTHERS")) {
				result.setFileName(rs.getString("AFILENAME"));
			} else {
				String fname = rs.getString("IPATH");
				logger.info("fname:-" + fname);
				if (null != fname && !fname.equalsIgnoreCase("")) {
					String extn = fname.substring(fname.lastIndexOf("."));

					result.setFileName(rs.getString("IFILENAME") + extn);
				}
			}
			if (accountType.equalsIgnoreCase("IMAGE")) {
				result.setDocument_content_type("OTHERS");
				result.setDocument_content_type("OTHERS");
				result.setFileLink(rs.getString("IPATH"));
			} else {
				result.setDocument_content_type(rs.getString("ADOCCONTTYPE"));
				result.setFileLink(rs.getString("AFILELINK"));
			}

			result.setDocumentLanguage(rs.getString("ADOCLANG"));

			result.setSourceSystem(rs.getString("ASOURCESYS"));
			result.setAmd5(rs.getString("AMD5"));

			result.setIresource(rs.getString("IRESOURCE"));
			if (accountType.equalsIgnoreCase("IMAGE")) {
				result.setSerialNumber(rs.getString("ISERIALNUMBER"));

			}

			return result;

		}
	}

	private static final class DocumentMapper1 implements RowMapper<DocumentDetails> {
		public DocumentMapper1() {
		}

		@Override
		public DocumentDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
			DocumentDetails result = new DocumentDetails();
			result.setSiteCode(rs.getString("SITE_CODE"));
			result.setTypeFlowProject(rs.getString("TYPE_FLOW_PROJECT"));
			result.setCategoryNuclearCommercial(rs.getString("CATEGORY_NUCLEAR_COMMERCIAL"));
			result.setSalesOrderNumber(rs.getString("SALES_ORDER_NUMBER"));
			result.setSalesOrderLineNumber(rs.getString("SALES_ORDER_LINE_NUMBER"));
			result.setProductionOrderNumber(rs.getString("PRODUCTION_ORDER_NUMBER"));
			result.setSerialNumber(rs.getString("SERIAL_NUMBER_SAP"));
			result.setDocumentType(rs.getString("DOCUMENT_TYPE"));
			result.setDocDesc(rs.getString("DOCUMENT_DESCRIPTION"));
			result.setFileName(rs.getString("FILE_NAME"));
			result.setFileLink(rs.getString("FILE_LINK"));
			result.setUniqId(rs.getInt("UNIQ_ID"));
			result.setProjectNumber(rs.getString("PROJECT_NUMBER"));
			result.setDocumentLanguage(rs.getString("DOCUMENT_LANGUAGE"));
			result.setDocument_content_type(rs.getString("DOCUMENT_CONTENT_TYPE"));
			result.setSourceSystem(rs.getString("SOURCE_SYSTEM"));
			result.setCreationDate(rs.getDate("CREATION_DATE"));
			result.setLastUpdateDate(rs.getDate("LAST_UPDATE_DATE"));

			return result;

		}
	}

	@Override
	public List<DocumentDetails> getAllDocDetails(String serialNumber) {
		logger.info("inside getDocuments");
		List<DocumentDetails> docs = new ArrayList<>();
		try {
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("serialNumber", serialNumber);
			String docQuery = "select * from fptods.SQT_ALFRESCO_SERIAL_NUMBER_T where SERIAL_NUMBER_SAP is not null and SERIAL_NUMBER_SAP=:serialNumber";
			docs = this.namedParamTemplate.query(docQuery, parameters, new DocumentMapper1());
			return docs;
		} catch (Exception ex) {
			logger.info("Error## :" + ex.toString());
		}
		return docs;
	}

	@Override
	public StatusInfo documentFileUpload(InputStream file, HttpHeaders httpHeaders) {
		StatusInfo info = new StatusInfo();
		return info;
	}

	
	@Override
	public StatusInfo saveFileForDataBook(String serialNumber, String docType, String documentDescription, String fileName,
			String fileLINK, String language) {
		StatusInfo statusinfo = new StatusInfo();
		try {

			String sql = "select max(UNIQ_ID) from fptods.SQT_ALFRESCO_SERIAL_NUMBER_T";
			Long unId = this.jdbcTemplate.queryForLong(sql);
			unId = unId + 1;
			Calendar currenttime = Calendar.getInstance();
			Date sqldate = new Date((currenttime.getTime()).getTime());
			String saveSql = "insert into fptods.SQT_ALFRESCO_SERIAL_NUMBER_T(UNIQ_ID,SERIAL_NUMBER_SAP,DOCUMENT_TYPE,DOCUMENT_DESCRIPTION,FILE_NAME,FILE_LINK,DOCUMENT_LANGUAGE,DOCUMENT_CONTENT_TYPE,SOURCE_SYSTEM,CREATION_DATE,LAST_UPDATE_DATE) values(?,?,?,?,?,?,?,?,?,?,?)";
			Object[] param = { unId, serialNumber, docType, documentDescription, fileName, fileLINK, language,
					"DATABOOK", "NAS", sqldate, sqldate };
			this.jdbcTemplate.update(saveSql, param);

			statusinfo.setStatusCode(1);
			statusinfo.setStatusMessage("Data uploaded Successfully");
		} catch (Exception e) {
			logger.error("Error occurred while updating filePath..." + e.getMessage());
			statusinfo.setStatusCode(-1);
			statusinfo.setStatusMessage("Error occurred while updating filePath...");
		}
		return statusinfo;

	}

	@Override
	public StatusInfo saveFileForOthers(String serialNumber, String docType, String documentDescription, String fileName,
			String fileLINK, String language) {
		StatusInfo statusinfo = new StatusInfo();
		try {

			String sql = "select max(UNIQ_ID) from fptods.SQT_ALFRESCO_SERIAL_NUMBER_T";
			Long unId = this.jdbcTemplate.queryForLong(sql);
			unId = unId + 1;
			Calendar currenttime = Calendar.getInstance();
			Date sqldate = new Date((currenttime.getTime()).getTime());
			String saveSql = "insert into fptods.SQT_ALFRESCO_SERIAL_NUMBER_T(UNIQ_ID,SERIAL_NUMBER_SAP,DOCUMENT_TYPE,DOCUMENT_DESCRIPTION,FILE_NAME,FILE_LINK,DOCUMENT_LANGUAGE,DOCUMENT_CONTENT_TYPE,SOURCE_SYSTEM,CREATION_DATE,LAST_UPDATE_DATE) values(?,?,?,?,?,?,?,?,?,?,?)";
			Object[] param = { unId, serialNumber, docType, documentDescription, fileName, fileLINK, language, "OTHERS",
					"NAS", sqldate, sqldate };
			this.jdbcTemplate.update(saveSql, param);

			statusinfo.setStatusCode(1);
			statusinfo.setStatusMessage("Data uploaded Successfully");
		} catch (Exception e) {
			logger.error("Error occurred while updating filePath..." + e.getMessage());
			statusinfo.setStatusCode(-1);
			statusinfo.setStatusMessage("Error occurred while updating filePath...");
		}
		return statusinfo;

	}

	@Override
	public List<OtherDocumentDetails> getAllDocDownloadDetails(String serialNumber) {

		logger.info("inside getAllDocDownloadDetails" + serialNumber);
		List<OtherDocumentDetails> docs = new ArrayList<>();
		try {
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			parameters.addValue("serialNumber", serialNumber);
			parameters.addValue("serialNumber1", serialNumber);
			String docQuery = "select al.site_code as asitecode,al.type_flow_project as "
					+ "atypeflowproject, al.project_number as aprojectnumber,al.sales_order_number "
					+ "as asalesorder,al.sales_order_line_number as asalesorderline,al.production_order_number"
					+ " as aprodorderno,al.serial_number_sap as aserialnumbersap,al.document_type as adoctype,"
					+ "al.document_description as adocdesc,al.file_name as afilename,al.file_link as afilelink,"
					+ "al.document_language as adoclang,al.document_content_type as adocconttype,al.source_system "
					+ "as asourcesys ,al.md5 as amd5,'' as ifilename,'' as ipath,''as iresource,'' as iserialnumber "
					+ "FROM fptods.SQT_ALFRESCO_SERIAL_NUMBER_T al where al.SERIAL_NUMBER_SAP is not null  and"
					+ " al.SERIAL_NUMBER_SAP=:serialNumber union select '' as asitecode,'' as atypeflowproject,'' as aprojectnumber,"
					+ "'' as asalesorder,'' as asalesorderline,'' as aprodorderno,'' as aserialnumbersap,'' as adoctype,'' as adocdesc,'' as afilename,'' as afilelink,"
					+ "'' as adoclang,'IMAGE' as adocconttype,'NAS' as asourcesys ,'' as amd5,img.file_name as ifilename,img.file_path as ipath,img.rec_source as iresource,"
					+ "img.serial_number as iserialnumber FROM fptods.image_data img where img.file_name =:serialNumber1";
			docs = this.namedParamTemplate.query(docQuery, parameters, new OtherDocumentMapper());
			logger.info("query for others" + docQuery);
			return docs;
		} catch (Exception ex) {
			ex.printStackTrace();
			logger.info("Error## :" + ex);
		}
		return docs;
	}

	// Ashish other doc start

	@Override
	public List<OtherDocumentDetails> getAllOtherDocDetails(String serialNumber, List<String> docName, String docType) {
		logger.info("inside getAllOtherDocDetails");
		List<OtherDocumentDetails> docs = new ArrayList<>();
		try {
			logger.info("size :" + docName.size());
			String documentNames = docName.get(0).replaceAll("\\[|\\]", "");
			documentNames = documentNames.replaceAll("\\s*,\\s*", ",");
			String[] docNames = documentNames.split(",");

			List<String> names = Arrays.asList(docNames);
			logger.info("names :" + names.size());
			String docQuery = "";
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			if (docType.equals(Constants.DOCTYPE)) {
				docQuery = QueryConstants.ALFRESCODOCTYPE_QUERY;
				parameters.addValue("serialNumber", serialNumber);
				parameters.addValue("docName", names);
			} else if (docType.equals(Constants.IMAGEDOCTYPE)) {
				docQuery = QueryConstants.IMAGEDOCTYPE_QUERY;
				parameters.addValue("serialNumber", serialNumber);

			}
			logger.info("getAllOtherDocDetails :" + docQuery);

			docs = this.namedParamTemplate.query(docQuery, parameters, new OtherDocumentMapper());
			logger.info("result size  :" + docs.size());
			return docs;
		} catch (Exception ex) {
			logger.info("Error## :" + ex.toString());
		}
		return docs;
	}

	private static final class OtherDocumentMapper implements RowMapper<OtherDocumentDetails> {
		public OtherDocumentMapper() {
		}

		@Override
		public OtherDocumentDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
			OtherDocumentDetails result = new OtherDocumentDetails();
			result.setAsitecode(rs.getString("ASITECODE"));
			result.setAtypeflowproject(rs.getString("ATYPEFLOWPROJECT"));
			result.setAprojectnumber(rs.getString("APROJECTNUMBER"));
			result.setAsalesorder(rs.getString("ASALESORDER"));
			result.setAsalesorderline(rs.getString("ASALESORDERLINE"));
			result.setAprodorderno(rs.getString("APRODORDERNO"));
			result.setSerialNumber(rs.getString("ASERIALNUMBERSAP"));
			result.setAdocType(rs.getString("ADOCTYPE"));
			result.setAdocdesc(rs.getString("ADOCDESC"));
			String accountType = rs.getString("ADOCCONTTYPE");
			if (accountType.equalsIgnoreCase("DATABOOK") || accountType.equalsIgnoreCase("OTHERS")) {
				result.setAfilename(rs.getString("AFILENAME"));
			} else {
				String fname = rs.getString("IPATH");
				logger.info("fname:-" + fname);
				if (null != fname && !fname.equalsIgnoreCase("")) {
					String extn = fname.substring(fname.lastIndexOf("."));

					result.setAfilename(rs.getString("IFILENAME") + extn);
				}

			}
			if (accountType.equalsIgnoreCase("IMAGE")) {
				result.setDocType("OTHERS");
				result.setAdocType("OTHERS");
				result.setAfilelink(rs.getString("IPATH"));
			} else {
				result.setDocType(rs.getString("ADOCCONTTYPE"));
				result.setAfilelink(rs.getString("AFILELINK"));
			}

			result.setAdoclang(rs.getString("ADOCLANG"));

			result.setAsourcesys(rs.getString("ASOURCESYS"));
			result.setAmd5(rs.getString("AMD5"));

			result.setIresource(rs.getString("IRESOURCE"));
			result.setSerialNumber(rs.getString("ISERIALNUMBER"));

			return result;

		}
	}
	// Ashish other doc start

	@Override
	public StatusInfo uploadUpgradeDocument(InputStream file, HttpHeaders httpHeaders) {
		StatusInfo info = new StatusInfo();
		return info;
	}

	@Override
	public StatusInfo saveUpgradeFile(String upgradeId, String optionId, String docContentType, String docType,
			String DocName, String fileLINK, String language, String sso) {
		logger.info("inside saveUpgradeFile");
		StatusInfo statusinfo = new StatusInfo();
		try {

			int upgradeIdInt = Integer.parseInt(upgradeId);
			if (upgradeIdInt == 0) {
				String sql = "select max(upgrade_id) from FPTODS.SQT_UPGRADE_INFO ";
				upgradeIdInt = this.jdbcTemplate.queryForInt(sql);

			}
			logger.info("inside-before optionID" + optionId);

			int optionIdInt = Integer.parseInt(optionId);

			logger.info("inside optionID" + optionIdInt);

			if (docContentType.equalsIgnoreCase("Package") && optionIdInt == 0) {
				logger.info("inside optionID query" + optionIdInt);
				String sql = "select max(OPTION_ID) from FPTODS.SQT_UPGRADE_OPTIONS";
				optionIdInt = this.jdbcTemplate.queryForInt(sql);
			}

			// unId=unId+1;
			Calendar currenttime = Calendar.getInstance();
			Date sqldate = new Date((currenttime.getTime()).getTime());
			logger.info("inside saveUpgradeFile>>>>>>>>>>>upgradeId " + upgradeId);
			logger.info("inside saveUpgradeFile>>>>>>>>>>>optionId " + optionId);
			logger.info("inside saveUpgradeFile>>>>>>>>>>>docContentType " + docContentType);
			logger.info("inside saveUpgradeFile>>>>>>>>>>>docType " + docType);
			logger.info("inside saveUpgradeFile>>>>>>>>>>>DocName " + DocName);
			logger.info("inside saveUpgradeFile>>>>>>>>>>>fileLINK " + fileLINK);
			logger.info("inside saveUpgradeFile>>>>>>>>>>>language " + language);
			logger.info("inside saveUpgradeFile>>>>>>>>>>>SSO " + sso);
			String saveSql = "insert into FPTODS.SQT_UPGRADE_PACKAGE_DOCUMENT_T	"
					+ "(UPGRADE_ID,OPTION_ID,DOCUMENT_NAME,DOCUMENT_TYPE,"
					+ "LANGUAGE,DOCUMENT_UPLOAD_PATH,DCOUMENT_CONTENT,CREATED_BY,CREATED_DATE)"
					+ "values(?,?,?,?,?,?,?,?,?)";

			// int optionIdInt=Integer.parseInt(optionId);

			Object[] param = { upgradeIdInt, optionIdInt, DocName, docType, language, fileLINK, docContentType, sso,
					sqldate };
			this.jdbcTemplate.update(saveSql, param);
			logger.info("Error occurred while updating filePath1..." + param);

			statusinfo.setStatusCode(1);
			statusinfo.setStatusMessage("Data uploaded Successfully");
		} catch (Exception e) {
			logger.error("Error occurred while updating filePath..." + e.getMessage());
			statusinfo.setStatusCode(-1);
			statusinfo.setStatusMessage("Error occurred while updating filePath...");
		}
		return statusinfo;

	}

	@Override
	public List<DocumentDetails> getDocuments(String sourceSystem, String documentType, String updatedDate) {
		List<DocumentDetails> docs = new ArrayList<>();
		try {
			MapSqlParameterSource params = new MapSqlParameterSource();
			params.addValue("sourceSystem", sourceSystem);
			params.addValue("documentType", documentType);
			params.addValue("updatedDate", updatedDate);
			docs = this.namedParamTemplate.query(QueryConstants.GET_DOCS, params, new GetDocumentMapper());
			return docs;
		} catch (Exception ex) {
			logger.info("Error while getting the documents to download from Alfresco in Valvekeep Scheduler :"
					+ ex.getMessage());
		}
		return docs;
	}

	private static final class GetDocumentMapper implements RowMapper<DocumentDetails> {
		public GetDocumentMapper() {
		}

		public DocumentDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
			DocumentDetails result = new DocumentDetails();
			result.setFileLink(rs.getString("FILE_LINK"));
			result.setFileName(rs.getString("FILE_NAME"));
			result.setSerialNumber(rs.getString("SERIAL_NUMBER_SAP"));
			result.setSalesOrderNumber(rs.getString("SALES_ORDER_NUMBER"));
			return result;

		}

	}

}
