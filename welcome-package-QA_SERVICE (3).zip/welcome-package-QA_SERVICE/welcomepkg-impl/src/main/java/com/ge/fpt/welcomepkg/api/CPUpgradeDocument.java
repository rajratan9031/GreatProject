package com.ge.fpt.welcomepkg.api;

public class CPUpgradeDocument {

	private int documentId;
	private String documentName;
	private String documentContent;
	private String documentUploadPath;
	public int getDocumentId() {
		return documentId;
	}
	public void setDocumentId(int documentId) {
		this.documentId = documentId;
	}
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public String getDocumentContent() {
		return documentContent;
	}
	public void setDocumentContent(String documentContent) {
		this.documentContent = documentContent;
	}
	
	public String getDocumentUploadPath() {
		return documentUploadPath;
	}
	public void setDocumentUploadPath(String documentUploadPath) {
		this.documentUploadPath = documentUploadPath;
	}
	@Override
	public String toString() {
		return "CPUpgradeDocument [documentId=" + documentId + ", documentName=" + documentName + ", documentContent="
				+ documentContent + ", documentUploadPath=" + documentUploadPath + "]";
	}
	
	
	
	
	
}
