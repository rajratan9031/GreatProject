package com.ge.fpt.welcomepkg.persistence;

import java.util.List;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ge.fpt.welcomepkg.api.ChannelData;
import com.ge.fpt.welcomepkg.api.DropDownItem;
import com.ge.fpt.welcomepkg.api.SerialNoDetails;

public interface IServiceNowPersistence {

/*Sindhura : Service Now Changes : Start */
	
	@Transactional(propagation=Propagation.REQUIRED)
	List<DropDownItem> selectChannelPartnerName();	

	@Transactional(propagation = Propagation.REQUIRED)
	List<ChannelData> getCPusernames(String channelname);
	
	@Transactional(propagation = Propagation.REQUIRED)
	List<String> getCPNameByChannelData();

	@Transactional(propagation = Propagation.REQUIRED)
	List<SerialNoDetails> getSerialNumberForValve(String serialNumberValue,String newvalve);

	@Transactional(propagation = Propagation.REQUIRED)
	ChannelData getUserDataFromChannelPartner(String channelpartnername);

	@Transactional(propagation = Propagation.REQUIRED)
	ChannelData getLoggedUserInfo(String loggedUser);
	
	@Transactional(propagation = Propagation.REQUIRED)
	ChannelData getLoggedUserInfoForCP(String loggedUserSubmitter);
	
	/*Sindhura : Service Now Changes : End */

}
