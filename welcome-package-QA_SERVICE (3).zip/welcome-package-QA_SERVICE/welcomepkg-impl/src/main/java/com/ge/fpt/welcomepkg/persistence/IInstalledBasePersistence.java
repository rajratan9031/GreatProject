package com.ge.fpt.welcomepkg.persistence;

import java.util.List;

import com.ge.fpt.welcomepkg.api.HeatMapOverlayData;
import com.ge.fpt.welcomepkg.api.InstallBaseFilter;
import com.ge.fpt.welcomepkg.api.InstalledBaseWithDuns;
import com.ge.fpt.welcomepkg.api.InstalledValveInfo;

public interface IInstalledBasePersistence {
HeatMapOverlayData getInstallBaseGeoLoc(InstallBaseFilter baseFilter);
List<InstalledValveInfo> getValveInfo(int pageNo,int rowperpage,InstalledValveInfo installedValveInfo);
InstalledBaseWithDuns getInstallBaseGeoLocWithDuns(InstallBaseFilter baseFilter);
int getValveInfoCount(InstalledValveInfo installedValveInfo);
}
