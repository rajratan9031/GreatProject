/**
 * 
 */
package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author 204060632
 *
 */

@XmlRootElement
public class RSPCartData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4778807749833835573L;
	/**
	 * 
	 */

	public RSPCartData() {
		// TODO Auto-generated constructor stub
	}
	
	private String sso;
	private String cartName;
	private Long valveInfoId;
	private Long orderLineId;
	private String recSource;
	private String serialNumber;
	private String tagNumber;
	private String itemNumber;
	private String description;
	private String productModel;
	private String productCode;
	private String salesOrder;
	private Date dateSaved;
	private String customerName;
	/**
	 * @return the sso
	 */
	public String getSso() {
		return sso;
	}
	/**
	 * @param sso the sso to set
	 */
	public void setSso(String sso) {
		this.sso = sso;
	}
	/**
	 * @return the cartName
	 */
	public String getCartName() {
		return cartName;
	}
	/**
	 * @param cartName the cartName to set
	 */
	public void setCartName(String cartName) {
		this.cartName = cartName;
	}
	/**
	 * @return the valveInfoId
	 */
	public Long getValveInfoId() {
		return valveInfoId;
	}
	/**
	 * @param valveInfoId the valveInfoId to set
	 */
	public void setValveInfoId(Long valveInfoId) {
		this.valveInfoId = valveInfoId;
	}
	/**
	 * @return the orderLineId
	 */
	public Long getOrderLineId() {
		return orderLineId;
	}
	/**
	 * @param orderLineId the orderLineId to set
	 */
	public void setOrderLineId(Long orderLineId) {
		this.orderLineId = orderLineId;
	}
	/**
	 * @return the recSource
	 */
	public String getRecSource() {
		return recSource;
	}
	/**
	 * @param recSource the recSource to set
	 */
	public void setRecSource(String recSource) {
		this.recSource = recSource;
	}
	/**
	 * @return the serialNumber
	 */
	public String getSerialNumber() {
		return serialNumber;
	}
	/**
	 * @param serialNumber the serialNumber to set
	 */
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	/**
	 * @return the tagNumber
	 */
	public String getTagNumber() {
		return tagNumber;
	}
	/**
	 * @param tagNumber the tagNumber to set
	 */
	public void setTagNumber(String tagNumber) {
		this.tagNumber = tagNumber;
	}
	/**
	 * @return the itemNumber
	 */
	public String getItemNumber() {
		return itemNumber;
	}
	/**
	 * @param itemNumber the itemNumber to set
	 */
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the productModel
	 */
	public String getProductModel() {
		return productModel;
	}
	/**
	 * @param productModel the productModel to set
	 */
	public void setProductModel(String productModel) {
		this.productModel = productModel;
	}
	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}
	/**
	 * @param productCode the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	/**
	 * @return the salesOrder
	 */
	public String getSalesOrder() {
		return salesOrder;
	}
	/**
	 * @param salesOrder the salesOrder to set
	 */
	public void setSalesOrder(String salesOrder) {
		this.salesOrder = salesOrder;
	}
	/**
	 * @return the dateSaved
	 */
	public Date getDateSaved() {
		return dateSaved;
	}
	/**
	 * @param dateSaved the dateSaved to set
	 */
	public void setDateSaved(Date dateSaved) {
		this.dateSaved = dateSaved;
	}
	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}
	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	

}
