package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;

public class ProductData implements Serializable{ 

	private static final long serialVersionUID = 1L;
	private String productKey;
	private String productName;
	private String unitType;
	private String model;
 
	public String getProductKey() {
		return productKey;
	}

	public void setProductKey(String productKey) {
		this.productKey = productKey;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getUnitType() {
		return unitType;
	}

	public void setUnitType(String unitType) {
		this.unitType = unitType;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public ProductData(){
		super();
	}

	public ProductData(String productKey, String productName, String unitType, String model) {
		super();
		this.productKey=productKey;
		this.productName = productName;
		this.unitType = unitType;
		this.model = model;
	}



}

