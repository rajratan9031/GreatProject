package com.ge.fpt.welcomepkg.api;

import java.sql.Timestamp;

public class VKCustOrderInfoSpeqT {
	private String rec_source;
	private String orderNumber;
	private String documentName;
	private String attribute;
	private String field;
	private String value;
	private String createdBy;
	private Timestamp createdTime;
	private String quoteNumber;
	private String customer;
	private String rfqNumber;
	private String custPoNumber;
	private String project;
	private String guli;
	private String itemNumber;
	private String tagNumber;
	private String dunsNumber;
	private String transferredBy;
	private Timestamp transferredDateTime;
	private String valveTransferredUniqueKey;
	private String xferd;
	private String serialNumber;

	public String getRec_source() {
		return rec_source;
	}

	public void setRec_source(String rec_source) {
		this.rec_source = rec_source;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getAttribute() {
		return attribute;
	}

	public void setAttribute(String attribute) {
		this.attribute = attribute;
	}

	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Timestamp createdTime) {
		this.createdTime = createdTime;
	}

	public String getQuoteNumber() {
		return quoteNumber;
	}

	public void setQuoteNumber(String quoteNumber) {
		this.quoteNumber = quoteNumber;
	}

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public String getRfqNumber() {
		return rfqNumber;
	}

	public void setRfqNumber(String rfqNumber) {
		this.rfqNumber = rfqNumber;
	}

	public String getCustPoNumber() {
		return custPoNumber;
	}

	public void setCustPoNumber(String custPoNumber) {
		this.custPoNumber = custPoNumber;
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public String getGuli() {
		return guli;
	}

	public void setGuli(String guli) {
		this.guli = guli;
	}

	public String getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}

	public String getTagNumber() {
		return tagNumber;
	}

	public void setTagNumber(String tagNumber) {
		this.tagNumber = tagNumber;
	}

	public String getDunsNumber() {
		return dunsNumber;
	}

	public void setDunsNumber(String dunsNumber) {
		this.dunsNumber = dunsNumber;
	}

	public String getTransferredBy() {
		return transferredBy;
	}

	public void setTransferredBy(String transferredBy) {
		this.transferredBy = transferredBy;
	}

	public Timestamp getTransferredDateTime() {
		return transferredDateTime;
	}

	public void setTransferredDateTime(Timestamp transferredDateTime) {
		this.transferredDateTime = transferredDateTime;
	}

	public String getValveTransferredUniqueKey() {
		return valveTransferredUniqueKey;
	}

	public void setValveTransferredUniqueKey(String valveTransferredUniqueKey) {
		this.valveTransferredUniqueKey = valveTransferredUniqueKey;
	}

	public String getXferd() {
		return xferd;
	}

	public void setXferd(String xferd) {
		this.xferd = xferd;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	
	

}
