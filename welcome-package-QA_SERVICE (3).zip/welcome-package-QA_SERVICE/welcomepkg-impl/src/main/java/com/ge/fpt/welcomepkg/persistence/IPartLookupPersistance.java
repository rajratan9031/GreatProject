package com.ge.fpt.welcomepkg.persistence;

import java.util.List;

import com.ge.fpt.welcomepkg.api.PartLookupData;

public interface IPartLookupPersistance {
	public  List<PartLookupData> getPartCrossRefData(PartLookupData part);
}
