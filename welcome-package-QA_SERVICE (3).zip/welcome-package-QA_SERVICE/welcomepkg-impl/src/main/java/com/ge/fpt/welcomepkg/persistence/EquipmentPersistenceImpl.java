/*
 * Copyright (c) 2013 GE Global Research. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * GE Global Research. The software may be used and/or copied only
 * with the written permission of GE Global Research or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.fpt.welcomepkg.persistence;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;
import javax.ws.rs.core.UriBuilder;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.opensaml.xml.util.Base64;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;

import com.ge.fpt.welcomepkg.api.DigitalBOMData;
import com.ge.fpt.welcomepkg.api.DigitalEquipmentData;
import com.ge.fpt.welcomepkg.api.CPPromotionalCart;
import com.ge.fpt.welcomepkg.api.CPUpgradeParts;
import com.ge.fpt.welcomepkg.api.CnDataInfo;
import com.ge.fpt.welcomepkg.api.CustomerDataManagmentMaster;
import com.ge.fpt.welcomepkg.api.EquipLookupData;
import com.ge.fpt.welcomepkg.api.OrderEquipment;
import com.ge.fpt.welcomepkg.api.PromotionalCart;
import com.ge.fpt.welcomepkg.api.RSPCartData;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.api.UpdateCartResponse;
import com.ge.fpt.welcomepkg.api.UpgradeInfo;
import com.ge.fpt.welcomepkg.api.UpgradeOptionDetails;
import com.ge.fpt.welcomepkg.api.UpgradePartModel;
import com.ge.fpt.welcomepkg.api.VKReportData;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;
import com.ge.fpt.welcomepkg.util.Constants;

/**
 * @author 212414241
 * 
 */
public class EquipmentPersistenceImpl implements IEquipmentPersistence {
	@SuppressWarnings("javadoc")
	private static final org.slf4j.Logger logger = WelcomePackageLoggerFactory
	.getLogger(EquipmentPersistenceImpl.class);

	static final int SQL_RETURN_RECORD_LIMIT = 25;

	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;

	/**
	 * Data source for the JDBC
	 */
	DataSource dataSource;

	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;

	NamedParameterJdbcTemplate namedParamTemplate;

	/**
	 * @return the dataSource
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}

	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate = new NamedParameterJdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	/*
	 * Propagation.REQUIRED is used. (non-Javadoc)
	 * 
	 * @see com.ge.ast.platform.dsp.jpa.AstPersistence#
	 * getEquipmentBySalesOrderAndRecSource(java.lang. String)
	 */
	@SuppressWarnings("nls")
	@Override
	public List<OrderEquipment> getEquipmentBySalesOrderAndRecSource(String salesOrder, String recSource,
			String engineeredValve, String dunsNumber) {

		logger.info("Duns Number:" + dunsNumber);
		List<OrderEquipment> equipments = new ArrayList<OrderEquipment>();
		try {
			String sql = "";
			List<OrderEquipment> equipment = new ArrayList<OrderEquipment>();
			if (engineeredValve.equals("Y")) {
				sql = "SELECT * FROM (SELECT C.*,T.link_customer_name,t.duns_number FROM ODS_SQT_BY_SALES_ORDER_E C "
						+ "LEFT OUTER JOIN(SELECT * FROM (SELECT m.ORDER_NUMBER,m.link_customer_name,m.serial_number,"
						+ "m.cust_id,duns_number,row_number() over(PARTITION BY ORDER_NUMBER,serial_number,rec_source"
						+ " ORDER BY serial_number DESC) AS rn FROM fptods.CUSTOMER_LINK_MASTER_T m)mm WHERE mm.rn=1)t"
						+ " ON T.ORDER_NUMBER =C.SALES_ORDER AND t.serial_number=c.serial_number WHERE c.serial_number"
						+ " IS NOT NULL) WHERE SALES_ORDER = ? AND REC_SOURCE = ? AND ENGINEERED_VALVE= ?";//$NON-NLS-1$
				equipment = this.jdbcTemplate.query(sql, new Object[] { salesOrder, recSource, engineeredValve },
						new EquipmentMapper());
			} else {
				
				logger.info("inside else condition");
				sql = "SELECT * FROM (SELECT C.*,T.link_customer_name,t.duns_number FROM ODS_SQT_BY_SALES_ORDER_E C LEFT OUTER JOIN(SELECT * FROM (SELECT m.ORDER_NUMBER,m.link_customer_name,m.serial_number,m.cust_id,duns_number,row_number() over(PARTITION BY ORDER_NUMBER,serial_number,rec_source ORDER BY serial_number DESC) AS rn FROM fptods.CUSTOMER_LINK_MASTER_T m)mm WHERE mm.rn=1)t ON T.ORDER_NUMBER =C.SALES_ORDER AND t.serial_number=c.serial_number WHERE c.serial_number IS NOT NULL) WHERE SALES_ORDER = ? AND REC_SOURCE = ?";//$NON-NLS-1$
				equipment = this.jdbcTemplate.query(sql, new Object[] { salesOrder, recSource }, new EquipmentMapper());
			}
			int i = 0;
			logger.info("sales order query" + sql);
			for (OrderEquipment orderEquipment : equipment) {
				logger.info("i" + i);
				// Logger.info();
				OrderEquipment o1 = new OrderEquipment();

				o1.setRecSource(orderEquipment.getRecSource());
				o1.setValveInfoId(orderEquipment.getValveInfoId());
				o1.setSalesOrder(orderEquipment.getSalesOrder());
				o1.setOrderIdentifier(orderEquipment.getOrderIdentifier());
				o1.setSalesOrderLine(orderEquipment.getSalesOrderLine());
				o1.setCustomerPo(orderEquipment.getCustomerPo());
				o1.setSoldToCustomerName(orderEquipment.getSoldToCustomerName());
				o1.setSoldToCountry(orderEquipment.getSoldToCountry());
				o1.setSoldToState(orderEquipment.getSoldToState());
				o1.setSoldToProvince(orderEquipment.getSoldToProvince());
				o1.setSoldToCity(orderEquipment.getSoldToCity());
				o1.setRepName(orderEquipment.getRepName());
				o1.setOrderedItemNumber(orderEquipment.getOrderedItemNumber());
				o1.setQuantityShipped(orderEquipment.getQuantityShipped());
				o1.setUnitSellingPrice(orderEquipment.getUnitSellingPrice());
				o1.setActualShipDate(orderEquipment.getActualShipDate());

				o1.setSerialNumber(orderEquipment.getSerialNumber());
				o1.setValvePartNumber(orderEquipment.getValvePartNumber());
				o1.setValveDescription(orderEquipment.getValveDescription());
				o1.setTagNumber(orderEquipment.getTagNumber());
				o1.setSourceSystem(orderEquipment.getSourceSystem());

				o1.setProductCode(orderEquipment.getProductCode());
				o1.setProductModel(orderEquipment.getProductModel());
				o1.setFilePath(orderEquipment.getFilePath());
				o1.setFileName(orderEquipment.getFileName());
				// columns added for i info button 
				o1.setSerialNumberValveSeg(orderEquipment.getSerialNumberValveSeg());
				o1.setValvesSku(orderEquipment.getValvesSku());
				o1.setNotes(orderEquipment.getNotes());
				o1.setInvoiceNo(orderEquipment.getInvoiceNo());
				o1.setSetPressure(orderEquipment.getSetPressure());
				o1.setCds(orderEquipment.getCds());
				o1.setBackPressure(orderEquipment.getBackPressure());
				o1.setTemperature(orderEquipment.getTemperature());
				o1.setCapacity(orderEquipment.getCapacity());
				o1.setService(orderEquipment.getService());
				o1.setCapCode(orderEquipment.getCapCode());
				o1.setSpringType(orderEquipment.getSpringType());
				o1.setSpring(orderEquipment.getSpring());
				o1.setAsme(orderEquipment.getAsme());
				o1.setSize(orderEquipment.getSize());
				o1.setBellows(orderEquipment.getBellows());
				o1.setSpecialFeatures(orderEquipment.getSpecialFeatures());
				o1.setOrifice(orderEquipment.getOrifice());
				o1.setProductCommodity(orderEquipment.getProductCommodity());
				o1.setBillOfMaterialNo(orderEquipment.getBillOfMaterialNo());
				
				
				o1.setSerializable(orderEquipment.getSerializable());
				o1.setEngineeredValve(orderEquipment.getEngineeredValve());
				// only for channel case
				if (null != orderEquipment.getDuns_Number() && null != dunsNumber) {
					logger.info("orderequipment:-" + (orderEquipment.getDuns_Number().equalsIgnoreCase(dunsNumber)));
					if (orderEquipment.getDuns_Number().equalsIgnoreCase(dunsNumber)) {
						o1.setLink_Customer_Name(orderEquipment.getLink_Customer_Name());

						logger.info("equipments1" + equipments);

						// set customer link
					} else {
						o1.setLink_Customer_Name(null);
					}
				} else if ((null == orderEquipment.getDuns_Number() || orderEquipment.getDuns_Number().equalsIgnoreCase("")) && null != dunsNumber) {
					o1.setLink_Customer_Name(null);

				} else {
					o1.setLink_Customer_Name(orderEquipment.getLink_Customer_Name());

					logger.info("equipments2" + equipments);
				}
				i = i + 1;

				o1.setDuns_Number(orderEquipment.getDuns_Number());
				equipments.add(o1);

				// else set customer link as it is

			}
			logger.info("size of equipments" + equipments.size());
			return equipments;
		} catch (Exception ex) {
			logger.error("Get Equipment By Sales Order and Rec Source error:", ex);
		}
		return null;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ge.fpt.welcomepkg.persistence.IEquipmentPersistence#
	 * getEquipmentBySalesOrderSerialNumberAndRecSource
	 * (com.ge.fpt.welcomepkg.api.EquipLookupData)
	 */
	@SuppressWarnings("nls")
	@Override
	public List<OrderEquipment> getEquipmentBySalesOrderSerialNumberAndRecSource(
			EquipLookupData[] lookupData) {
		try {
			String sql = "SELECT * FROM DDSAFM.ODS_SQT_BY_SALES_ORDER_E WHERE ";

			List<Object> paramList = new ArrayList<Object>();

			for (int i = 0; i < lookupData.length; i++) {
				if (i > 0)
					sql += " OR ";

				if (lookupData[i].getSerialNumber() == "") {
					sql += "(SALES_ORDER = ? AND REC_SOURCE = ?)";
					paramList.add(lookupData[i].getSalesOrder());
					paramList.add(lookupData[i].getRecSource());
				} else {
					sql += "(SALES_ORDER = ? AND SERIAL_NUMBER = ? AND REC_SOURCE = ?)";
					paramList.add(lookupData[i].getSalesOrder());
					paramList.add(lookupData[i].getSerialNumber());
					paramList.add(lookupData[i].getRecSource());
				}
			}

			Object[] params = paramList.toArray();

			List<OrderEquipment> equipment = this.jdbcTemplate.query(sql,
					params, new EquipmentMapper());
			/*for(int i=0;i<equipment.size();i++){
				int count=0;
				String sqlForSerial = "select count(*) from fptods.dresser_valve_segment where DVS_KEY_RECORD_CODE || DVS_KEY_SERIAL_NO || DVS_KEY_SERL_NO_DUP_SHIP_DATE  =:serialNumber";
				MapSqlParameterSource parameters = new MapSqlParameterSource();
				parameters.addValue("serialNumber", equipment.get(i).getSerialNumber());
				count = this.namedParamTemplate.queryForInt(sqlForSerial, parameters);
				if(count>0){
					equipment.get(i).setCnDataLinkCheck(true);
				}
			}*/
			return equipment;

		} catch (Exception ex) {
			logger.error(
					"Get Equipment By Sales Order Serial Number and Rec Source error:",
					ex);
		}

		return null;
	}

	public List<OrderEquipment> getBlanketEquipment(String col, String val,String dunsNumber) {
		logger.info("Inside getBlanketEquipment method");
		String sql ="  SELECT * FROM ( SELECT ROW_NUMBER() OVER (ORDER BY SALES_ORDER desc) rn,a.* from "
				+ "(SELECT REC_SOURCE,  a.SALES_ORDER, SALES_ORDER_LINE,  SOLD_TO_CUSTOMER_NAME, CUSTOMER_PO,  "
				+ "ACTUAL_SHIP_DATE, SOLD_TO_COUNTRY,  SOLD_TO_STATE, SOLD_TO_PROVINCE,  SOLD_TO_CITY,  REP_NAME, "
				+ "ORDERED_ITEM_NUMBER,  QUANTITY_SHIPPED, UNIT_SELLING_PRICE,  a.SERIAL_NUMBER,VALVE_PART_NUMBER,  "
				+ "VALVE_DESCRIPTION, SOURCE_SYSTEM,  TAG_NUMBER,  VALVE_INFO_ID, NULL AS PRODUCT_CODE,  NULL AS "
				+ "PRODUCT_MODEL, FILE_PATH,  FILE_NAME , SERIAL_NUMBER_VALVE_SEG,  DVS_VALVE_SKU,  NOTES,  "
				+ "DVS_INVOICE_NO,  DVS_SET_PRESSURE,    DVS_CDS,  DVS_BACK_PRESSURE,  DVS_TEMPERATURE,  "
				+ "DVS_CAPACITY,  DVS_SERVICE,  DVS_CAP_CODE,  DVS_SPRING_TYPE, DVS_SPRING,  DVS_ASME,  DVS_SIZE,  "
				+ "DVS_BELLOWS,  DVS_SPECIAL_FEATURES,  DVS_ORIFICE,  DVS_PRODUCT_COMMODITY, DVS_BILL_OF_MATERIAL_NO ,"
				+ "  SERIALIZABLE ,  ENGINEERED_VALVE,LINK_CUSTOMER_NAME,duns_number FROM (SELECT  x.*, row_number() OVER"
				+ "( ORDER BY SALES_ORDER DESC) AS RANKVAL  fROM DDSAFM.ODS_SQT_BY_SALES_ORDER_E_MV x) a LEFT OUTER "
				+ "JOIN (select m.ORDER_NUMBER,serial_number,LINK_CUSTOMER_NAME,duns_number, row_number() "
				+ "over(PARTITION BY ORDER_NUMBER,LINK_CUSTOMER_NAME,duns_number,rec_source ORDER BY serial_number DESC) AS rn   "
				+ "from fptods.CUSTOMER_LINK_MASTER_T m) t   on  T.ORDER_NUMBER= A.SALES_ORDER and "
				+ "t.serial_number=a.serial_number where  1=1 ";
		
		if (col.equalsIgnoreCase("serialNumber")) {
			sql = sql + "AND UPPER(S_number) LIKE  UPPER('%'||?||'%')";
		} else if (col.equalsIgnoreCase("tagNumber")) {
			sql = sql + "AND UPPER(T_number) LIKE  UPPER('%'||?||'%')";
		} else if (col.equalsIgnoreCase("fileName")) {
			sql = sql + "AND UPPER(F_name) LIKE  UPPER('%'||?||'%')";
		}
		sql=sql+")a )";
		val = val.replaceAll("[^a-zA-Z0-9]", "");
		logger.info(" serial landing page final query"+sql);
		//List<OrderEquipment> equipments = new ArrayList<OrderEquipment>();

		try {
			List<OrderEquipment> equipment = this.jdbcTemplate.query(sql,
					new Object[] { val }, new EquipmentMapperBlanket());

			/*for(int i=0;i<equipment.size();i++){
				int count=0;
				String sqlForSerial = "select count(*) from fptods.dresser_valve_segment where DVS_KEY_RECORD_CODE || DVS_KEY_SERIAL_NO || DVS_KEY_SERL_NO_DUP_SHIP_DATE  =:serialNumber";
				MapSqlParameterSource parameters = new MapSqlParameterSource();
				parameters.addValue("serialNumber", equipment.get(i).getSerialNumber());
				count = this.namedParamTemplate.queryForInt(sqlForSerial, parameters);
				if(count>0){
					equipment.get(i).setCnDataLinkCheck(true);
				}
			}*/
			/*int i = 0;
			logger.info("sales order query" + sql);
			for (OrderEquipment orderEquipment : equipment) {
				logger.info("i" + i);
				// Logger.info();
				OrderEquipment o1 = new OrderEquipment();

				o1.setRecSource(orderEquipment.getRecSource());
				o1.setSalesOrder(orderEquipment.getSalesOrder());
				o1.setSalesOrderLine(orderEquipment.getSalesOrderLine());
				o1.setCustomerPo(orderEquipment.getCustomerPo());
				o1.setSoldToCustomerName(orderEquipment.getSoldToCustomerName());
				o1.setSoldToCountry(orderEquipment.getSoldToCountry());
				o1.setSoldToState(orderEquipment.getSoldToState());
				o1.setSoldToProvince(orderEquipment.getSoldToProvince());
				o1.setSoldToCity(orderEquipment.getSoldToCity());
				o1.setRepName(orderEquipment.getRepName());
				o1.setOrderedItemNumber(orderEquipment.getOrderedItemNumber());
				o1.setQuantityShipped(orderEquipment.getQuantityShipped());
				o1.setUnitSellingPrice(orderEquipment.getUnitSellingPrice());
				o1.setSerialNumber(orderEquipment.getSerialNumber());
				o1.setValvePartNumber(orderEquipment.getValvePartNumber());
				o1.setValveDescription(orderEquipment.getValveDescription());
				o1.setTagNumber(orderEquipment.getTagNumber());
				o1.setSourceSystem(orderEquipment.getSourceSystem());
				o1.setValveInfoId(orderEquipment.getValveInfoId());
				o1.setProductCode(orderEquipment.getProductCode());
				o1.setProductModel(orderEquipment.getProductModel());
				o1.setFilePath(orderEquipment.getFilePath());
				o1.setFileName(orderEquipment.getFileName());
				o1.setSerialNumberValveSeg(orderEquipment.getSerialNumberValveSeg());
				o1.setValvesSku(orderEquipment.getValvesSku());
				o1.setNotes(orderEquipment.getNotes());
				o1.setInvoiceNo(orderEquipment.getInvoiceNo());
				o1.setSetPressure(orderEquipment.getSetPressure());
				o1.setCds(orderEquipment.getCds());
				o1.setBackPressure(orderEquipment.getBackPressure());
				o1.setTemperature(orderEquipment.getTemperature());
				o1.setCapacity(orderEquipment.getCapacity());
				o1.setService(orderEquipment.getService());
				o1.setCapCode(orderEquipment.getCapCode());
				o1.setSpringType(orderEquipment.getSpringType());
				o1.setSpring(orderEquipment.getSpring());
				o1.setAsme(orderEquipment.getAsme());
				o1.setSize(orderEquipment.getSize());
				o1.setBellows(orderEquipment.getBellows());
				o1.setSpecialFeatures(orderEquipment.getSpecialFeatures());
				o1.setOrifice(orderEquipment.getOrifice());
				o1.setProductCommodity(orderEquipment.getProductCommodity());
				o1.setBillOfMaterialNo(orderEquipment.getBillOfMaterialNo());
				
				o1.setActualShipDate(orderEquipment.getActualShipDate());

				
				
				o1.setSerializable(orderEquipment.getSerializable());
				o1.setEngineeredValve(orderEquipment.getEngineeredValve());
				// only for channel case
				if (null != orderEquipment.getDuns_Number() && null != dunsNumber) {
					logger.info("orderequipment:-" + (orderEquipment.getDuns_Number().equalsIgnoreCase(dunsNumber)));
					if (orderEquipment.getDuns_Number().equalsIgnoreCase(dunsNumber)) {
						o1.setLink_Customer_Name(orderEquipment.getLink_Customer_Name());

						logger.info("equipments1" + equipments);

						// set customer link
					} else {
						o1.setLink_Customer_Name(null);
					}
				} else if ((null == orderEquipment.getDuns_Number() || orderEquipment.getDuns_Number().equalsIgnoreCase("")) && null != dunsNumber) {
					o1.setLink_Customer_Name(null);

				} else {
					o1.setLink_Customer_Name(orderEquipment.getLink_Customer_Name());

					logger.info("equipments2" + equipments);
				}
				i = i + 1;

				o1.setDuns_Number(orderEquipment.getDuns_Number());
				equipments.add(o1);

				// else set customer link as it is

			}
			logger.info("size of equipments" + equipments.size());
*/			return equipment;
		} catch (Exception ex) {
			logger.error("get blanket search equipemnt error.. " + ex);
			return null;
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ge.fpt.welcomepkg.persistence.ISparesPersistence#saveToRSPCart(com
	 * .ge.fpt.welcomepkg.api.OrderEquipment[])
	 */
	@SuppressWarnings("nls")
	@Override
	public UpdateCartResponse saveToRSPCart(String sso,
			OrderEquipment[] saveData) {

		// AddToCartResponse result2 = new AddToCartResponse();

		// //AddToCartResponse result2 = new AddToCartResponse();
		// result2.setMessage("Entry point 2 works");
		//
		// return result2;

		// result2.setTotalCartCount(saveData.length);
		// result2.setAddedCount(0);
		// result2.setMessage("Entry point works");
		//
		// List<RSPCartData> addedItems = new ArrayList<RSPCartData>();
		// for (int i = 0; i < saveData.length; i++){
		// RSPCartData cartData = new RSPCartData();
		// cartData.setSso(sso);
		// cartData.setSerialNumber(saveData[i].getSerialNumber());
		// cartData.setRecSource(saveData[i].getRecSource());
		//
		// addedItems.add(cartData);
		// }
		//
		// result2.setAddedItems(addedItems);
		//
		// return result2;

		int totalCartCount = 0;
		int addedCount = 0;
		List<RSPCartData> addedData = new ArrayList<RSPCartData>();

		UpdateCartResponse result = new UpdateCartResponse();
		try {

			String sql;

			for (int i = 0; i < saveData.length; i++) {
				RSPCartData cartData = new RSPCartData();

				cartData.setSso(sso);
				cartData.setValveInfoId(saveData[i].getValveInfoId());
				cartData.setOrderLineId((long) i);
				cartData.setRecSource(saveData[i].getRecSource());
				cartData.setSerialNumber(saveData[i].getSerialNumber());
				cartData.setTagNumber(saveData[i].getTagNumber());
				cartData.setItemNumber(saveData[i].getOrderedItemNumber());
				cartData.setDescription(saveData[i].getValveDescription());
				cartData.setProductModel(null);
				cartData.setProductCode(saveData[i].getProductCode());
				cartData.setSalesOrder(saveData[i].getSalesOrder());

				sql = "DELETE FROM FPTODS.SQT_SSO_CART WHERE SSO = ? AND SERIAL_NUMBER = ? AND REC_SOURCE = ?";
				this.jdbcTemplate.update(sql,
						new Object[] { sso, cartData.getSerialNumber(),
								cartData.getRecSource() });
				logger.info("inside add cart1--->> " + sql);
				sql = "INSERT INTO FPTODS.SQT_SSO_CART "
						+ "(SSO, VALVE_INFO_ID, ORDER_LINE_ID, REC_SOURCE, SERIAL_NUMBER, TAG_NUMBER, ITEM_NUMBER, DESCRIPTION, PRODUCT_MODEL, PRODUCT_CODE, ORDER_NUMBER, DATE_SAVED) "
						+ "VALUES "
						+ "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, sysdate)";

				Object[] params = { cartData.getSso(),
						cartData.getValveInfoId(), cartData.getOrderLineId(),
						cartData.getRecSource(), cartData.getSerialNumber(),
						cartData.getTagNumber(), cartData.getItemNumber(),
						cartData.getDescription(), cartData.getProductModel(),
						cartData.getProductCode(), cartData.getSalesOrder() };

				this.jdbcTemplate.update(sql, params);
				logger.info("inside add cart2--->> " + sql);
				addedCount++;
				addedData.add(cartData);
			}

			totalCartCount = getCartCount(sso);

			result.setTotalCartCount(totalCartCount);
			result.setUpdateCount(addedCount);
			result.setAddedItems(addedData);
			result.setMessage("Items added successfully.");

			return result;
		} catch (Exception ex) {
			logger.error("Save To RSP Cart error:", ex);

			result.setTotalCartCount(-1);
			result.setUpdateCount(addedCount);
			result.setAddedItems(addedData);
			result.setMessage(ex.getMessage());

			return result;
		}

	}

	@SuppressWarnings("nls")
	@Override
	public int getCartCount(String sso) {

		String sql = "SELECT COUNT(*) FROM FPTODS.SQT_SSO_CART WHERE SSO = ?";
		int result = this.jdbcTemplate.queryForInt(sql, new Object[] { sso });

		return result;
	}

	public UpdateCartResponse deleteFromRSPCart(String sso, Long[] valveInfoIds) {
		String sql = "DELETE FROM FPTODS.SQT_SSO_CART WHERE SSO = ?";

		List<Object> params = new ArrayList<Object>();

		params.add(sso);

		if (valveInfoIds.length > 0) {
			sql += " AND (";

			for (int i = 0; i < valveInfoIds.length; i++) {
				if (i > 0) {
					sql += " OR ";
				}

				sql += ("VALVE_INFO_ID = ?");

				params.add(valveInfoIds[i]);
			}

			sql += ")";
		}

		UpdateCartResponse result = new UpdateCartResponse();

		try {
			int updateCount = this.jdbcTemplate.update(sql, params.toArray());

			result.setTotalCartCount(getCartCount(sso));
			result.setUpdateCount(updateCount);
			result.setMessage(updateCount + " items deleted.");
		} catch (Exception ex) {
			logger.error("Delete from RSP cart error: ", ex);
			result.setTotalCartCount(-1);
			result.setUpdateCount(-1);
			result.setMessage(ex.getMessage());
		}

		return result;

	}

	public List<RSPCartData> getCurrentRSPCart(String sso) {
		try {
			String sql = "SELECT * FROM FPTODS.SQT_SSO_CART a LEFT OUTER JOIN DDSAFM.ODS_SQT_BY_SALES_ORDER_SSO_GE b ON (a.ORDER_NUMBER = b.SALES_ORDER AND a.REC_SOURCE = b.REC_SOURCE) WHERE SSO = ?";
			List<RSPCartData> cartItems = this.jdbcTemplate.query(sql,
					new Object[] { sso }, new RSPCartMapper());

			return cartItems;
		} catch (Exception ex) {
			logger.error("Get current RSP Cart error: ", ex);
		}
		return null;
	}

	public int checkCartExists(String sso, String cartName) {
		try {
			String sql = "SELECT COUNT(*) FROM FPTODS.SQT_SSO_SAVED_CARTS WHERE SSO = ? AND UPPER(CART_NAME) = ?";

			Object[] params = { sso, cartName.toUpperCase() };

			int count = this.jdbcTemplate.queryForInt(sql, params);

			if (count > 0)
				return 1;
			else
				return 0;
		} catch (Exception ex) {
			logger.error("Check cart exists error: ", ex);
		}
		return -1;
	}

	public StatusInfo saveCart(String sso, String cartName) {
		StatusInfo result = new StatusInfo();

		try {

			String sql = "SELECT * FROM FPTODS.SQT_SSO_CART WHERE SSO = ?";

			List<RSPCartData> cartDataList = this.jdbcTemplate.query(sql,
					new Object[] { sso }, new RSPCartMapper());

			if (cartDataList.size() > 0) {
				sql = "DELETE FROM FPTODS.SQT_SSO_SAVED_CARTS WHERE SSO = ? AND UPPER(CART_NAME) = ?";

				this.jdbcTemplate.update(sql,
						new Object[] { sso, cartName.toUpperCase() });

				for (int i = 0; i < cartDataList.size(); i++) {
					RSPCartData cartData = cartDataList.get(i);

					sql = "INSERT INTO FPTODS.SQT_SSO_SAVED_CARTS "
							+ "(CART_NAME, SSO, VALVE_INFO_ID, ORDER_LINE_ID, REC_SOURCE, SERIAL_NUMBER, TAG_NUMBER, ITEM_NUMBER, DESCRIPTION, PRODUCT_MODEL, PRODUCT_CODE, ORDER_NUMBER, DATE_SAVED, DATE_ATT1) "
							+ "VALUES "
							+ "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, sysdate, ?)";

					Object[] params = new Object[13];

					params[0] = cartName;
					params[1] = sso;
					params[2] = cartData.getValveInfoId();
					params[3] = cartData.getOrderLineId();
					params[4] = cartData.getRecSource();
					params[5] = cartData.getSerialNumber();
					params[6] = cartData.getTagNumber();
					params[7] = cartData.getItemNumber();
					params[8] = cartData.getDescription();
					params[9] = cartData.getProductModel();
					params[10] = cartData.getProductCode();
					params[11] = cartData.getSalesOrder();
					params[12] = cartData.getDateSaved();

					this.jdbcTemplate.update(sql, params);
				}

				result.setStatusCode(0);
				result.setStatusMessage("Cart saved successfully.");
			} else {
				logger.error("Save cart error: Cart is empty.");

				result.setStatusCode(-3);
				result.setStatusMessage("Cart is empty.");
			}

			return result;
		} catch (Exception ex) {
			logger.error("Save cart error: ", ex);

			result.setStatusCode(-1);
			result.setStatusMessage(ex.getMessage());
			return result;
		}
	}

	public StatusInfo loadCart(String sso, String cartName) {
		StatusInfo result = new StatusInfo();

		try {

			String sql = "SELECT * FROM FPTODS.SQT_SSO_SAVED_CARTS WHERE SSO = ? AND UPPER(CART_NAME) = ?";

			List<RSPCartData> cartDataList = this.jdbcTemplate.query(sql,
					new Object[] { sso, cartName.toUpperCase() },
					new RSPCartMapper());
			if (cartDataList.size() > 0) {
				sql = "DELETE FROM FPTODS.SQT_SSO_CART WHERE SSO = ?";
				this.jdbcTemplate.update(sql, new Object[] { sso });

				for (int i = 0; i < cartDataList.size(); i++) {
					RSPCartData cartData = cartDataList.get(i);

					sql = "INSERT INTO FPTODS.SQT_SSO_CART "
							+ "(SSO, VALVE_INFO_ID, ORDER_LINE_ID, REC_SOURCE, SERIAL_NUMBER, TAG_NUMBER, ITEM_NUMBER, DESCRIPTION, PRODUCT_MODEL, PRODUCT_CODE, ORDER_NUMBER, DATE_SAVED) "
							+ "VALUES "
							+ "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

					Object[] params = new Object[12];

					params[0] = sso;
					params[1] = cartData.getValveInfoId();
					params[2] = cartData.getOrderLineId();
					params[3] = cartData.getRecSource();
					params[4] = cartData.getSerialNumber();
					params[5] = cartData.getTagNumber();
					params[6] = cartData.getItemNumber();
					params[7] = cartData.getDescription();
					params[8] = cartData.getProductModel();
					params[9] = cartData.getProductCode();
					params[10] = cartData.getSalesOrder();
					params[11] = cartData.getDateSaved();

					this.jdbcTemplate.update(sql, params);
				}

				result.setStatusCode(0);
				result.setStatusMessage("Cart loaded successfully.");
			} else {
				logger.error("Load cart error: Cart does not exist.");

				result.setStatusCode(-2);
				result.setStatusMessage("Cart does not exist.");
			}

			return result;
		} catch (Exception ex) {
			logger.error("Load cart error: ", ex);

			result.setStatusCode(-1);
			result.setStatusMessage(ex.getMessage());
			return result;
		}
	}

	public StatusInfo deleteSavedCart(String sso, String cartName) {
		StatusInfo result = new StatusInfo();

		try {
			String sql = "DELETE FROM FPTODS.SQT_SSO_SAVED_CARTS WHERE SSO = ? AND UPPER(CART_NAME) = ?";

			int rowsAffected = this.jdbcTemplate.update(sql, new Object[] {
					sso, cartName.toUpperCase() });

			if (rowsAffected == 0) {
				result.setStatusCode(-2);
				result.setStatusMessage("No rows deleted.");
			} else {
				result.setStatusCode(0);
				result.setStatusMessage("Cart deleted successfully.");
			}

			return result;
		} catch (Exception ex) {
			logger.error("Delete saved cart error: ", ex);

			result.setStatusCode(-1);
			result.setStatusMessage(ex.getMessage());
			return result;
		}
	}

	public StatusInfo deleteAllFromRSPCart(String sso) {
		StatusInfo result = new StatusInfo();
		try {
			String sql = "DELETE FROM FPTODS.SQT_SSO_CART WHERE SSO = ?";

			int rowsAffected = this.jdbcTemplate.update(sql,
					new Object[] { sso });

			if (rowsAffected == 0) {
				result.setStatusCode(-2);
				result.setStatusMessage("No rows deleted.");
			} else {
				result.setStatusCode(0);
				result.setStatusMessage("Cart deleted successfully.");
			}

			return result;
		} catch (Exception ex) {
			logger.error("Delete all from RSP cart error: ", ex);

			result.setStatusCode(-1);
			result.setStatusMessage(ex.getMessage());
			return result;
		}
	}

	public List<String> getSavedCarts(String sso) {

		try {
			String sql = "SELECT DISTINCT CART_NAME FROM FPTODS.SQT_SSO_SAVED_CARTS WHERE SSO = ? ORDER BY CART_NAME";

			List<String> result = this.jdbcTemplate.queryForList(sql,
					new Object[] { sso }, String.class);

			if (result == null)
				result = new ArrayList<String>();

			return result;
		} catch (Exception ex) {
			logger.error("Get saved carts error: ", ex);

			return null;
		}
	}

	private static final class EquipmentMapper implements RowMapper<OrderEquipment> {
		public EquipmentMapper() {
		}

		@Override
		public OrderEquipment mapRow(ResultSet rs, int rowNum) throws SQLException {
			OrderEquipment result = new OrderEquipment();
			try {
				result.setRecSource(rs.getString("REC_SOURCE")); //$NON-NLS-1$
				result.setValveInfoId(rs.getLong("VALVE_INFO_ID"));
				result.setSalesOrder(rs.getString("SALES_ORDER"));
				result.setOrderIdentifier(rs.getString("ORDER_IDENTIFIER"));
				result.setSalesOrderLine(rs.getString("SALES_ORDER_LINE"));
				result.setCustomerPo(rs.getString("CUSTOMER_PO"));
				result.setSoldToCustomerName(rs.getString("SOLD_TO_CUSTOMER_NAME"));
				result.setSoldToCountry(rs.getString("SOLD_TO_COUNTRY"));
				result.setSoldToState(rs.getString("SOLD_TO_STATE"));
				result.setSoldToProvince(rs.getString("SOLD_TO_PROVINCE"));
				result.setSoldToCity(rs.getString("SOLD_TO_CITY"));
				result.setRepName(rs.getString("REP_NAME"));
				result.setOrderedItemNumber(rs.getString("ORDERED_ITEM_NUMBER"));
				result.setQuantityShipped(rs.getLong("QUANTITY_SHIPPED"));
				result.setUnitSellingPrice(rs.getDouble("UNIT_SELLING_PRICE"));
				if (null != rs.getString("ACTUAL_SHIP_DATE")) {
					SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //$NON-NLS-1$
					Date actualShipDate = formatter.parse(rs.getString("ACTUAL_SHIP_DATE")); //$NON-NLS-1$
					result.setActualShipDate(actualShipDate);
				}
				result.setSerialNumber(rs.getString("SERIAL_NUMBER"));
				result.setValvePartNumber(rs.getString("VALVE_PART_NUMBER"));
				result.setValveDescription(rs.getString("VALVE_DESCRIPTION"));
				result.setTagNumber(rs.getString("TAG_NUMBER"));
				result.setSourceSystem(rs.getString("SOURCE_SYSTEM"));

				result.setProductCode(rs.getString("PRODUCT_CODE"));
				result.setProductModel(rs.getString("PRODUCT_MODEL"));
				result.setFilePath(rs.getString("FILE_PATH"));
				result.setFileName(rs.getString("FILE_NAME"));

				result.setSerializable(rs.getString("SERIALIZABLE"));
				result.setEngineeredValve(rs.getString("ENGINEERED_VALVE"));
				result.setLink_Customer_Name(rs.getString("LINK_CUSTOMER_NAME"));
				result.setDuns_Number(rs.getString("DUNS_NUMBER"));
				
				//newly added for i button info
				
				result.setSerialNumberValveSeg(rs.getString("SERIAL_NUMBER_VALVE_SEG"));
				result.setValvesSku(rs.getString("DVS_VALVE_SKU")); 
				result.setNotes(rs.getString("NOTES"));
				result.setInvoiceNo(rs.getString("DVS_INVOICE_NO"));
				result.setSetPressure(rs.getString("DVS_SET_PRESSURE"));
				result.setCds(rs.getString("DVS_CDS"));
				result.setBackPressure(rs.getString("DVS_BACK_PRESSURE"));
				result.setTemperature(rs.getString("DVS_TEMPERATURE"));
				result.setCapacity(rs.getString("DVS_CAPACITY"));
				result.setService(rs.getString("DVS_SERVICE"));
				result.setCapCode(rs.getString("DVS_CAP_CODE"));
				result.setSpringType(rs.getString("DVS_SPRING_TYPE"));
				result.setSpring(rs.getString("DVS_SPRING"));
				result.setAsme(rs.getString("DVS_ASME"));
				result.setSize(rs.getString("DVS_SIZE"));
				result.setBellows(rs.getString("DVS_BELLOWS"));
				result.setSpecialFeatures(rs.getString("DVS_SPECIAL_FEATURES"));
				result.setOrifice(rs.getString("DVS_ORIFICE"));
				result.setProductCommodity(rs.getString("DVS_PRODUCT_COMMODITY"));
				result.setBillOfMaterialNo(rs.getString("DVS_BILL_OF_MATERIAL_NO"));
				


			} catch (Exception e) {
				logger.error("OrderEquipment Mapper: ", e); //$NON-NLS-1$
			}
			return result;
		}
	}



	private static final class EquipmentMapper1 implements
	RowMapper<OrderEquipment> {
		public EquipmentMapper1() {
		}

		@Override
		public OrderEquipment mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			OrderEquipment result = new OrderEquipment();
			try {	
				result.setRecSource(rs.getString("REC_SOURCE")); //$NON-NLS-1$
				result.setSalesOrder(rs.getString("SALES_ORDER"));
				result.setSalesOrderLine(rs.getString("SALES_ORDER_LINE"));
				result.setCustomerPo(rs.getString("CUSTOMER_PO"));
				result.setSoldToCustomerName(rs.getString("SOLD_TO_CUSTOMER_NAME"));
				result.setSoldToCountry(rs.getString("SOLD_TO_COUNTRY"));
				result.setSoldToState(rs.getString("SOLD_TO_STATE"));
				result.setSoldToProvince(rs.getString("SOLD_TO_PROVINCE"));
				result.setSoldToCity(rs.getString("SOLD_TO_CITY"));
				result.setRepName(rs.getString("REP_NAME"));
				result.setOrderedItemNumber(rs.getString("ORDERED_ITEM_NUMBER"));
				result.setQuantityShipped(rs.getLong("QUANTITY_SHIPPED"));
				result.setUnitSellingPrice(rs.getDouble("UNIT_SELLING_PRICE"));
				result.setSerialNumber(rs.getString("SERIAL_NUMBER"));
				result.setValvePartNumber(rs.getString("VALVE_PART_NUMBER"));
				result.setValveDescription(rs.getString("VALVE_DESCRIPTION"));
				result.setTagNumber(rs.getString("TAG_NUMBER"));
				result.setSourceSystem(rs.getString("SOURCE_SYSTEM"));

				result.setValveInfoId(rs.getLong("VALVE_INFO_ID"));
				result.setProductCode(rs.getString("PRODUCT_CODE"));
				result.setProductModel(rs.getString("PRODUCT_MODEL"));
				result.setFilePath(rs.getString("FILE_PATH"));
				result.setFileName(rs.getString("FILE_NAME"));	
				if(null!=rs.getString("ACTUAL_SHIP_DATE")){
					SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //$NON-NLS-1$
					Date actualShipDate = formatter.parse(rs.getString("ACTUAL_SHIP_DATE")); //$NON-NLS-1$
					result.setActualShipDate(actualShipDate);
				}
				result.setSerializable(rs.getString("SERIALIZABLE"));
				result.setEngineeredValve(rs.getString("ENGINEERED_VALVE"));
				result.setCustId(rs.getString("CUST_ID"));
				result.setLink_Customer_Name(rs.getString("LINK_CUSTOMER_NAME"));
				
			
			} catch (Exception e) {
				logger.error("OrderEquipment Mapper: ", e); //$NON-NLS-1$
			}
			return result;
		}
	}
	private static final class EquipmentMapperBlanket implements
	RowMapper<OrderEquipment> {
		public EquipmentMapperBlanket() {
		}

		@Override
		public OrderEquipment mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			OrderEquipment result = new OrderEquipment();
			try {
				result.setRecSource(rs.getString("REC_SOURCE")); //$NON-NLS-1$
				result.setSalesOrder(rs.getString("SALES_ORDER"));
				result.setSalesOrderLine(rs.getString("SALES_ORDER_LINE"));
				result.setCustomerPo(rs.getString("CUSTOMER_PO"));
				result.setSoldToCustomerName(rs.getString("SOLD_TO_CUSTOMER_NAME"));
				result.setSoldToCountry(rs.getString("SOLD_TO_COUNTRY"));
				result.setSoldToState(rs.getString("SOLD_TO_STATE"));
				result.setSoldToProvince(rs.getString("SOLD_TO_PROVINCE"));
				result.setSoldToCity(rs.getString("SOLD_TO_CITY"));
				result.setRepName(rs.getString("REP_NAME"));
				result.setOrderedItemNumber(rs.getString("ORDERED_ITEM_NUMBER"));
				result.setQuantityShipped(rs.getLong("QUANTITY_SHIPPED"));
				result.setUnitSellingPrice(rs.getDouble("UNIT_SELLING_PRICE"));
				result.setSerialNumber(rs.getString("SERIAL_NUMBER"));
				result.setValvePartNumber(rs.getString("VALVE_PART_NUMBER"));
				result.setValveDescription(rs.getString("VALVE_DESCRIPTION"));
				result.setTagNumber(rs.getString("TAG_NUMBER"));
				result.setSourceSystem(rs.getString("SOURCE_SYSTEM"));
				result.setValveInfoId(rs.getLong("VALVE_INFO_ID"));
				result.setProductCode(rs.getString("PRODUCT_CODE"));
				result.setProductModel(rs.getString("PRODUCT_MODEL"));
				result.setFilePath(rs.getString("FILE_PATH"));
				result.setFileName(rs.getString("FILE_NAME"));
				// CN DATA LINK
				result.setSerialNumberValveSeg(rs.getString("SERIAL_NUMBER_VALVE_SEG"));
				result.setValvesSku(rs.getString("DVS_VALVE_SKU")); 
				result.setNotes(rs.getString("NOTES"));
				result.setInvoiceNo(rs.getString("DVS_INVOICE_NO"));
				result.setSetPressure(rs.getString("DVS_SET_PRESSURE"));
				result.setCds(rs.getString("DVS_CDS"));
				result.setBackPressure(rs.getString("DVS_BACK_PRESSURE"));
				result.setTemperature(rs.getString("DVS_TEMPERATURE"));
				result.setCapacity(rs.getString("DVS_CAPACITY"));
				result.setService(rs.getString("DVS_SERVICE"));
				result.setCapCode(rs.getString("DVS_CAP_CODE"));
				result.setSpringType(rs.getString("DVS_SPRING_TYPE"));
				result.setSpring(rs.getString("DVS_SPRING"));
				result.setAsme(rs.getString("DVS_ASME"));
				result.setSize(rs.getString("DVS_SIZE"));
				result.setBellows(rs.getString("DVS_BELLOWS"));
				result.setSpecialFeatures(rs.getString("DVS_SPECIAL_FEATURES"));
				result.setOrifice(rs.getString("DVS_ORIFICE"));
				result.setProductCommodity(rs.getString("DVS_PRODUCT_COMMODITY"));
				result.setBillOfMaterialNo(rs.getString("DVS_BILL_OF_MATERIAL_NO"));		
				if(null!=rs.getString("ACTUAL_SHIP_DATE")){
					SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //$NON-NLS-1$
					Date actualShipDate = formatter.parse(rs.getString("ACTUAL_SHIP_DATE")); //$NON-NLS-1$
					result.setActualShipDate(actualShipDate);
				}
				result.setSerializable(rs.getString("SERIALIZABLE"));
				result.setEngineeredValve(rs.getString("ENGINEERED_VALVE"));
				result.setLink_Customer_Name(rs.getString("LINK_CUSTOMER_NAME"));
				result.setDuns_Number(rs.getString("DUNS_NUMBER"));

			} catch (Exception e) {
				logger.error("OrderEquipment Mapper: ", e); //$NON-NLS-1$
			}
			return result;
		}
	}

	public List<OrderEquipment> getEquipmentBySn(EquipLookupData lookupData) {
		try {
			String sql = "SELECT * FROM DDSAFM.ODS_SQT_BY_SO_E_UPDATE WHERE ";

			List<Object> paramList = new ArrayList<Object>();
			sql += "(SALES_ORDER = ? AND SERIAL_NUMBER = ? AND REC_SOURCE = ?)";
			paramList.add(lookupData.getSalesOrder());
			paramList.add(lookupData.getSerialNumber());
			paramList.add(lookupData.getRecSource());
			Object[] params = paramList.toArray();
			List<OrderEquipment> equipment = this.jdbcTemplate.query(sql,
					params, new EquipmentMapper());
			return equipment;

		} catch (Exception ex) {
			logger.error(
					"Get Equipment By Sales Order Serial Number and Rec Source error:",
					ex);
		}

		return null;

	}

	public StatusInfo updateEquipment(String sso, OrderEquipment orderEquipment) {
		StatusInfo result = new StatusInfo();
		String sql = "";
		try {

			sql = "select count(1) from DDSAFM.ODS_SQT_BY_SO_E_UPDATE where SERIAL_NUMBER=?";
			int count = this.jdbcTemplate.queryForInt(sql,
					new Object[] { orderEquipment.getSerialNumber() });

			if (count > 0) {
				sql = " update DDSAFM.ODS_SQT_BY_SO_E_UPDATE set VALVE_PART_NUMBER=? , VALVE_DESCRIPTION=?,QUANTITY_SHIPPED=?,TAG_NUMBER=?, "
						+ " updated_by =? , updated_date=sysdate where  SERIAL_NUMBER=?";

				Object[] params = new Object[6];
				params[0] = orderEquipment.getValvePartNumber();
				params[1] = orderEquipment.getValveDescription();
				params[2] = orderEquipment.getQuantityShipped();
				params[3] = orderEquipment.getTagNumber();
				params[4] = sso;
				params[5] = orderEquipment.getSerialNumber();
				this.jdbcTemplate.update(sql, params);



				String sqlNew=" update FPTODS.ODS_SQT_BY_SALES_ORDER_E_MV  set VALVE_PART_NUMBER=? , VALVE_DESCRIPTION=?,QUANTITY_SHIPPED=?,TAG_NUMBER=?"
						+ "where  SERIAL_NUMBER=?";

				Object[] paramsNew = new Object[5];
				paramsNew[0] = orderEquipment.getValvePartNumber();
				paramsNew[1] = orderEquipment.getValveDescription();
				paramsNew[2] = orderEquipment.getQuantityShipped();
				paramsNew[3] = orderEquipment.getTagNumber();
				paramsNew[4] = orderEquipment.getSerialNumber();
				this.jdbcTemplate.update(sqlNew, paramsNew);


				logger.error("Inside the update - Vinay");

				result.setStatusCode(0);
				result.setStatusMessage("Data updated successfully!!");
				// return result;
			} else {
				sql = "insert into DDSAFM.ODS_SQT_BY_SO_E_UPDATE (rec_source,valve_info_id,sales_order, "
						+ "sales_order_line,customer_po,"
						+ "ordered_item_number,quantity_shipped,unit_selling_price,actual_ship_date,serial_number,valve_part_number,valve_description,tag_number,"
						+ "source_system,updated_by,updated_date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,sysdate)";
				Object[] params = { orderEquipment.getRecSource(),
						orderEquipment.getValveInfoId(),
						orderEquipment.getSalesOrder(),
						orderEquipment.getSalesOrderLine(),
						orderEquipment.getCustomerPo(),
						orderEquipment.getOrderedItemNumber(),
						orderEquipment.getQuantityShipped(),
						orderEquipment.getUnitSellingPrice(),
						orderEquipment.getActualShipDate(),
						orderEquipment.getSerialNumber(),
						orderEquipment.getValvePartNumber(),
						orderEquipment.getValveDescription(),
						orderEquipment.getTagNumber(),
						orderEquipment.getSourceSystem(), sso

				};
				this.jdbcTemplate.update(sql, params);


				String sqlNewCount = "select count(1) from FPTODS.ODS_SQT_BY_SALES_ORDER_E_MV where SERIAL_NUMBER=? and REC_SOURCE=?";
				int countNew = this.jdbcTemplate.queryForInt(sqlNewCount,
						new Object[] { orderEquipment.getSerialNumber() , orderEquipment.getRecSource() });

				if(countNew > 0) {
					
					String sqlNew = "update FPTODS.ODS_SQT_BY_SALES_ORDER_E_MV set valve_info_id=?,sales_order=?,"
							+ "sales_order_line=?,customer_po=?,"
							+ "ordered_item_number=?,quantity_shipped=?,unit_selling_price=?,actual_ship_date=?,valve_part_number=?,valve_description=?,tag_number=?,"
							+ "source_system=? where serial_number=? and rec_source=?";

					Object[] paramsNew = { 
							orderEquipment.getValveInfoId(),
							orderEquipment.getSalesOrder(),
							orderEquipment.getSalesOrderLine(),
							orderEquipment.getCustomerPo(),
							orderEquipment.getOrderedItemNumber(),
							orderEquipment.getQuantityShipped(),
							orderEquipment.getUnitSellingPrice(),
							orderEquipment.getActualShipDate(),
							orderEquipment.getValvePartNumber(),
							orderEquipment.getValveDescription(),
							orderEquipment.getTagNumber(),
							orderEquipment.getSourceSystem(),
							orderEquipment.getSerialNumber(),
							orderEquipment.getRecSource()
					};
					logger.error("Inside the Update - Vinay");
					this.jdbcTemplate.update(sqlNew, paramsNew);

				} else {
					String sqlNew = "insert into FPTODS.ODS_SQT_BY_SALES_ORDER_E_MV  (rec_source,valve_info_id,sales_order, "
							+ "sales_order_line,customer_po,"
							+ "ordered_item_number,quantity_shipped,unit_selling_price,actual_ship_date,serial_number,valve_part_number,valve_description,tag_number,"
							+ "source_system) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

					Object[] paramsNew = { orderEquipment.getRecSource(),
							orderEquipment.getValveInfoId(),
							orderEquipment.getSalesOrder(),
							orderEquipment.getSalesOrderLine(),
							orderEquipment.getCustomerPo(),
							orderEquipment.getOrderedItemNumber(),
							orderEquipment.getQuantityShipped(),
							orderEquipment.getUnitSellingPrice(),
							orderEquipment.getActualShipDate(),
							orderEquipment.getSerialNumber(),
							orderEquipment.getValvePartNumber(),
							orderEquipment.getValveDescription(),
							orderEquipment.getTagNumber(),
							orderEquipment.getSourceSystem()
					};
					logger.error("Inside the Insert - Vinay");
					this.jdbcTemplate.update(sqlNew, paramsNew);
				}
			}
		} catch (Exception ex) {
			result.setStatusCode(0);
			result.setStatusMessage("Error in updating data");
			logger.error("Update Equipment  error:", ex);
		}
		return result;
	}

	public UpdateCartResponse addToPromotionalCart(String sso,
			PromotionalCart saveData) {
		UpdateCartResponse result = new UpdateCartResponse();
		try {
			// check whether the option already present in the cart
			String sqlCheckOption = "select count(*) from FPTODS.SQT_SSO_PROMOTIONAL_CART where UPGRADE_ID=? AND OPTION_ID=? AND SSO=? ";
			int countOption = this.jdbcTemplate.queryForInt(sqlCheckOption,
					new Object[] { Integer.valueOf(saveData.getUpgradeId()),
							Integer.valueOf(saveData.getOptionId()), sso });
			if (countOption > 0) {
				// already option is present in the cart....update it
				String sqlGetOptionQuantity = "select UNIQUE(QUANTITY) from FPTODS.SQT_SSO_PROMOTIONAL_CART where UPGRADE_ID=? AND OPTION_ID=? AND SSO=? ";
				String quantity = this.jdbcTemplate.queryForObject(
						sqlGetOptionQuantity, String.class, new Object[] {
								Integer.valueOf(saveData.getUpgradeId()),
								Integer.valueOf(saveData.getOptionId()), sso });
				int updatedQuantity = Integer.valueOf(quantity)
						+ Integer.valueOf(saveData.getQuantity());
				String updatedQuantityValue = String.valueOf(updatedQuantity);
				String updateOption = "update FPTODS.SQT_SSO_PROMOTIONAL_CART set QUANTITY=? where UPGRADE_ID=? AND OPTION_ID=? AND SSO=? ";
				Object[] params = new Object[4];
				params[0] = updatedQuantityValue;
				params[1] = saveData.getUpgradeId();
				params[2] = saveData.getOptionId();
				params[3] = sso;
				this.jdbcTemplate.update(updateOption, params);
				result.setMessage("Items added successfully.");
				return result;
			} else {
				// delete all the contents of the cart
				String sqlDelete = "delete from FPTODS.SQT_SSO_PROMOTIONAL_CART where SSO=? AND NOT UPGRADE_ID=?";
				this.jdbcTemplate.update(sqlDelete, new Object[] { sso,
						saveData.getUpgradeId() });
				String sql = "select * from FPTODS.SQT_UPGRADE_INFO where UPGRADE_ID=?";
				List<UpgradeInfo> upgradeInfo = this.jdbcTemplate.query(sql,
						new Object[] { saveData.getUpgradeId() },
						new UpgradeInfoMapper());
				String part = upgradeInfo.get(0).getUpgradePart();
				String model = upgradeInfo.get(0).getUpgradeModel();
				UpgradeOptionDetails details = new UpgradeOptionDetails();
				if (null != part && !part.equals("")) {
					details.setPartModel(part);
					details.setIndicator("Part");
				} else if (null != model && !model.equals("")) {
					details.setPartModel(model);
					details.setIndicator("Model");
				}
				List<UpgradeOptionDetails> upgradeOptionDetails = new ArrayList<UpgradeOptionDetails>();
				upgradeOptionDetails.addAll(saveData.getPartModel());
				upgradeOptionDetails.add(details);
				for (UpgradeOptionDetails info : upgradeOptionDetails) {
					String sqlUpgrade = "INSERT INTO FPTODS.SQT_SSO_PROMOTIONAL_CART "
							+ "(SSO,UPGRADE_ID,UPGRADE_NAME,OPTION_ID,OPTION_NAME,OPTION_DESCRIPTION,COUPON_CODE,PART_MODEL,INDICATOR,QUANTITY) "
							+ "VALUES " + "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
					Object[] params = new Object[10];
					params[0] = sso;
					params[1] = saveData.getUpgradeId();
					params[2] = saveData.getUpgradeName();
					params[3] = saveData.getOptionId();
					params[4] = saveData.getOptionName();
					params[5] = saveData.getOptionDescription();
					params[6] = saveData.getCouponCode();
					params[7] = info.getPartModel();
					params[8] = info.getIndicator();
					params[9] = saveData.getQuantity();
					this.jdbcTemplate.update(sqlUpgrade, params);
				}
				result.setMessage("Items added successfully.");
				return result;
			}
		} catch (Exception ex) {
			logger.error("Save To Promotional Cart error:", ex);
			result.setMessage(ex.getMessage());
			return result;
		}

	}

	@Override
	public boolean checkUpgradeExist(String sso, PromotionalCart saveData) {
		logger.error("Step 1 :- checkUpgradeAlreadyExist");
		try {
			// check whether there are already any elements inside the cart with
			// same upgrade
			String sqlCheckOption = "select count(*) from FPTODS.SQT_SSO_PROMOTIONAL_CART where NOT UPGRADE_ID=? AND SSO=? ";
			int countOption = this.jdbcTemplate.queryForInt(sqlCheckOption,
					new Object[] { Integer.valueOf(saveData.getUpgradeId()),
							sso });
			logger.error("Step 2 :- checkUpgradeAlreadyExist" + "countOption"
					+ countOption);
			if (countOption > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception ex) {
			logger.error("Save To Promotional Cart error:", ex);
			return false;
		}
	}

	private static final class RSPCartMapper implements RowMapper<RSPCartData> {
		public RSPCartMapper() {

		}

		@Override
		public RSPCartData mapRow(ResultSet rs, int rowNum) throws SQLException {
			RSPCartData result = new RSPCartData();

			try {
				Boolean hasCartName = false;
				Boolean hasCustName = false;

				ResultSetMetaData metaData = rs.getMetaData();
				int colCount = metaData.getColumnCount();
				for (int i = 0; i < colCount; i++)
					if (metaData.getColumnName(i + 1).equals("CART_NAME")) {
						hasCartName = true;
					} else if (metaData.getColumnName(i + 1).equals(
							"SOLD_TO_CUSTOMER_NAME")) {
						hasCustName = true;
					}

				result.setSso(rs.getString("SSO"));
				if (hasCartName)
					result.setCartName(rs.getString("CART_NAME"));
				else
					result.setCartName("");
				result.setValveInfoId(rs.getLong("VALVE_INFO_ID"));
				result.setOrderLineId(rs.getLong("ORDER_LINE_ID"));
				result.setRecSource(rs.getString("REC_SOURCE"));
				result.setSerialNumber(rs.getString("SERIAL_NUMBER"));
				result.setTagNumber(rs.getString("TAG_NUMBER"));
				result.setItemNumber(rs.getString("ITEM_NUMBER"));
				result.setDescription(rs.getString("DESCRIPTION"));
				result.setProductModel(rs.getString("PRODUCT_MODEL"));
				result.setProductCode(rs.getString("PRODUCT_CODE"));
				result.setSalesOrder(rs.getString("ORDER_NUMBER"));
				result.setDateSaved(rs.getDate("DATE_SAVED"));

				if (hasCustName)
					result.setCustomerName(rs
							.getString("SOLD_TO_CUSTOMER_NAME"));
				else
					result.setCustomerName("");
			} catch (Exception ex) {
				logger.error("RSPCartData Mapper error: ", ex);
			}

			return result;

		}
	}

	public List<VKReportData> getVKReportData(String sso, String region,
			String currency) {
		try {
			List<VKReportData> result = null;

			String sql = "SELECT DISTINCT A.SALES_ORDER AS SALES_ORDER, "
					+
					// "CASE WHEN TRIM(COALESCE(E.END_USER, '')) = '' THEN E.SOLD_TO_CUSTOMER_NAME ELSE E.END_USER END AS END_USER_CUST_NAME, "
					// +
					// "'' AS END_USER_CUST_ADDRESS,  " +
					// "CASE WHEN TRIM(COALESCE(E.END_USER, '')) = '' THEN E.SOLD_TO_CITY ELSE E.EU_CUST_CITY END AS CITY, "
					// +
					// "CASE WHEN TRIM(COALESCE(E.END_USER, '')) = '' THEN E.SOLD_TO_STATE ELSE E.EU_CUST_STATE END AS STATE, "
					// +
					// "CASE WHEN TRIM(COALESCE(E.END_USER, '')) = '' THEN '' ELSE E.EU_CUST_ZIP END AS POSTAL_CODE,  "
					// +
					// "CASE WHEN TRIM(COALESCE(E.END_USER, '')) = '' THEN E.SOLD_TO_COUNTRY ELSE E.EU_CUST_COUNTRY END AS COUNTRY, "
					// +
					"E.SOLD_TO_CUSTOMER_NAME AS END_USER_CUST_NAME, "
					+ "'' AS END_USER_CUST_ADDRESS, "
					+ "E.SOLD_TO_CITY AS CITY, "
					+ "E.SOLD_TO_STATE AS STATE, "
					+ "E.SOLD_TO_PROVINCE AS PROVINCE, "
					+ "E.EU_CUST_ZIP AS POSTAL_CODE, "
					+ "E.SOLD_TO_COUNTRY AS COUNTRY, "
					+ "A.ACTUAL_SHIP_DATE AS SHIP_DATE, "
					+ "E.SOURCESYSTEM AS SHIP_SOURCE, "
					+ "A.SERIAL_NUMBER AS SERIAL_NUMBER, "
					+ "A.VALVE_DESCRIPTION AS VALVE_DESCRIPTION, "
					+ "A.TAG_NUMBER AS TAG_NUMBER,  "
					+ "A.COMPONENT_ITEM_NUMBER AS PART_NUMBER, "
					+ "A.COMPONENT_DESCRIPTION AS PART_DESCRIPTION, "
					+ "A.SPARES_INDICATOR AS SPARES_CODE, "
					+ "A.QUANTITY AS QTY, "
					+ "A.LIST_PRICE AS LIST_PRICE, "
					+ "D.LEAD_TIME AS LEAD_TIME  "
					+ "FROM ODS_SQT_BY_SALES_ORDER_V A "
					+ "LEFT OUTER JOIN DDSAFM.ODS_SQT_PRICE_LOOK_UP_MV B ON A.COMPONENT_ITEM_NUMBER = B.PART_NUMBER "
					+ "LEFT OUTER JOIN FPTODS.SQT_SSO_CART C ON (A.SERIAL_NUMBER = C.SERIAL_NUMBER AND A.REC_SOURCE = C.REC_SOURCE) "
					+ "LEFT OUTER JOIN DDSAFM.LEAD_TIME_LOOKUP_MV D ON (A.COMPONENT_ITEM_NUMBER = D.ITEM_NUMBER AND D.REGION = B.REGION) "
					+ "LEFT OUTER JOIN DDSAFM.ODS_SQT_BY_SALES_ORDER_SSO_GE E on (A.SALES_ORDER = E.SALES_ORDER AND A.REC_SOURCE = E.REC_SOURCE) "
					+ "WHERE (B.TO_CURRENCY = ? OR B.TO_CURRENCY IS NULL) "
					+ "AND (B.REGION = ? OR B.REGION IS NULL) "
					+
					// "AND SPARES_INDICATOR IN ('C','W','I','1','2')  " +
					"AND C.SSO = ? "
					+ "ORDER BY A.SALES_ORDER,A.SERIAL_NUMBER, A.COMPONENT_ITEM_NUMBER";

			result = this.jdbcTemplate.query(sql, new Object[] { currency,
					region, sso }, new VKReportDataMapper());

			return result;
		} catch (Exception ex) {
			logger.error("getVKReportData Error: SSO = '" + sso + "';\n" + ex);
			return null;
		}
	}

	public StatusInfo saveCartStatus(String sso, Map<String, String> data) {
		logger.info("inside saveCartStatus");
		StatusInfo result = new StatusInfo();
		String cartName = data.get("cartName");
		String cartType = data.get("cartType");
		String currency = data.get("currency");
		String region = data.get("region");
		String pcsql = "";
		if (cartType.equalsIgnoreCase("RSP")) {
			pcsql = "SELECT DISTINCT PRODUCT_CODE FROM FPTODS.SQT_SSO_SAVED_CARTS WHERE CART_NAME=? and SSO=?";
		}
		if (cartType.equalsIgnoreCase("PROMO")) {
			pcsql = "SELECT DISTINCT BRAND FROM FPTODS.SQT_SSO_SAVED_PROMOTIONAL_CART WHERE CART_NAME=? and SSO=?";
		}

		String pc = this.jdbcTemplate.queryForObject(pcsql, new Object[] {
				cartName, sso }, String.class);
		String cartPc="";
		if(pc.equalsIgnoreCase("MN")){
			cartPc="Masoneilan";
		}if(pc.equalsIgnoreCase("CN")){
			cartPc="Consolidated";
		}

		URI uri = UriBuilder.fromPath(Constants.ISTORE_SERVICE_URL)
				.queryParam("SSO", sso)
				.queryParam("Cart_Name", cartName)
				.queryParam("Cart_Type", cartType)
				.queryParam("Currency_Code", currency)
				.queryParam("Region", region).queryParam("Item_Category", cartPc)
				.queryParam("operationName", "Request-Response").build();
		String responseBodyString = "";
		logger.info("uri-->>" +uri.toString());
		String authString =Constants.USER+":"+Constants.PASSWORD;
		try {	
			URL url=new URL(uri.toString());
			URLConnection urlConnection = url.openConnection();
			urlConnection.setConnectTimeout(120000);
			logger.info("urlConnection---->>>>>>>>"+urlConnection.toString());
			String encoding = Base64.encodeBytes(authString.getBytes());
			urlConnection.setRequestProperty("Authorization", "Basic " + encoding);
			InputStream is = urlConnection.getInputStream();
			logger.info("is-->>" +is);
			InputStreamReader isr = new InputStreamReader(is);
			StringBuilder sbuilder=new StringBuilder();
			BufferedReader in   =  new BufferedReader (isr);
			String line;
			while ((line = in.readLine()) != null) {
				sbuilder.append(line);
			}
			responseBodyString=sbuilder.toString();
			logger.info("responseBodyString-->>" +responseBodyString);
			DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory
					.newInstance();
			DocumentBuilder builder = docBuilderFactory.newDocumentBuilder();
			InputSource ins = new InputSource(new StringReader(responseBodyString));
			Document doc = builder.parse((ins));
			Element root = doc.getDocumentElement();
			if (root.getChildNodes().item(5).getTextContent().equals("0")) {
				return saveIstoreStatusofCart(sso, cartName, cartType);
			} else {
				result.setStatusCode(-1);
				result.setStatusMessage("Error in Istore SOA Service!!");
				return result;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("SOA Service Error: " + e);

			result.setStatusCode(-1);
			result.setStatusMessage("Error in Istore SOA Service!!");
			return result;
		}
	}

	private StatusInfo saveIstoreStatusofCart(String sso, String cartName,
			String cartType) {
		StatusInfo result = new StatusInfo();
		String sql = "";
		if (cartType.equalsIgnoreCase("RSP")) {
			sql = "UPDATE FPTODS.SQT_SSO_SAVED_CARTS SET ISTORE_STATUS='Y' WHERE CART_NAME=? and SSO=?";
		}
		if (cartType.equalsIgnoreCase("PROMO")) {
			sql = "UPDATE FPTODS.SQT_SSO_SAVED_PROMOTIONAL_CART SET ISTORE_STATUS='Y' WHERE CART_NAME=? and SSO=?";
		}
		try {
			this.jdbcTemplate.update(sql, new Object[] { cartName, sso });
			result.setStatusCode(1);
			result.setStatusMessage("Status Updated Successfully!!");
		} catch (Exception e) {
			result.setStatusCode(-1);
			result.setStatusMessage("Status Not Updated Successfully!!");
		}
		return result;
	}

	public List<String> getCartStatus(String sso, Map<String, String> data) {
		String cartName = data.get("cartName");
		String cartType = data.get("cartType");
		String sql = "";

		if (cartType.equalsIgnoreCase("RSP")) {
			sql = "Select DISTINCT ISTORE_STATUS FROM FPTODS.SQT_SSO_SAVED_CARTS WHERE CART_NAME=:cartName and SSO=:sso ";
		}
		if (cartType.equalsIgnoreCase("PROMO")) {
			sql = "Select DISTINCT ISTORE_STATUS FROM FPTODS.SQT_SSO_SAVED_PROMOTIONAL_CART WHERE CART_NAME=:cartName and SSO=:sso ";
		}
		MapSqlParameterSource paramMap = new MapSqlParameterSource();
		paramMap.addValue("cartName", cartName);
		paramMap.addValue("sso", sso);

		return this.namedParamTemplate
				.queryForList(sql, paramMap, String.class);
	}

	public int getCartPC(String sso, Map<String, String> data) {
		String cartName = data.get("cartName");
		String cartType = data.get("cartType");
		String sql = "";

		if (cartType.equalsIgnoreCase("RSP")) {
			sql = "Select count(DISTINCT PRODUCT_CODE) FROM FPTODS.SQT_SSO_SAVED_CARTS WHERE CART_NAME=:cartName and SSO=:sso ";
		}
		if (cartType.equalsIgnoreCase("PROMO")) {
			sql = "Select count(DISTINCT BRAND) FROM FPTODS.SQT_SSO_SAVED_PROMOTIONAL_CART WHERE CART_NAME=:cartName and SSO=:sso ";
		}
		MapSqlParameterSource paramMap = new MapSqlParameterSource();
		paramMap.addValue("cartName", cartName);
		paramMap.addValue("sso", sso);

		return this.namedParamTemplate
				.queryForInt(sql, paramMap );
	}

	@Override
	public String saveEquipmentDigital(DigitalEquipmentData digitalEquipmentData) {String result=null;
	Long orderId=9999999999999l;
	try{			
		logger.info("actual shipment date added in persistence");
		String selectValveInfoId="select max(VALVE_INFO_ID) from DDSAFM.SQT_VALVE_INFO_T";	
		Long valveId=this.jdbcTemplate.queryForLong(selectValveInfoId);		
		valveId=valveId+1;
		String selectOrderLineId="select max(ORDER_LINE_ID) from FPTODS.SQT_ORDER_LINE_INFO_T";	
		Long newOrderLineId=this.jdbcTemplate.queryForLong(selectOrderLineId);	
		logger.info("orderLineId is="+newOrderLineId);
		newOrderLineId=newOrderLineId+1;
		logger.info("orderLineId is="+newOrderLineId);
		String saveOrderSql="";
		saveOrderSql= "insert into DDSAFM.SQT_ORDER_LINE_INFO_T(ORDER_LINE_ID,ORDER_ID,REC_SOURCE,LINE_NUMBER,SHIPPED_QUANTITY,ORDERED_ITEM,"
				+ "UNIT_SELLING_PRICE,UNIT_LIST_PRICE,REQUEST_DATE,PROMISE_DATE,ACTUAL_SHIPMENT_DATE,CREATION_DATE,LAST_UPDATE_DATE,SERIALIZABLE,ENGINEERED_VALVE)"
				+ "values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";	
		Calendar current = Calendar.getInstance();
		Date sqldatenew = new Date((current.getTime()).getTime()); 
		logger.info("newOrderLineId is="+newOrderLineId+"sqldatenew is="+sqldatenew+"digitalEquipmentData.getActualShipDate(),"+	digitalEquipmentData.getActualShipDate());
		Object[] parameters={					 
				newOrderLineId,
				//orderLineId,
				"9999999999999",
				"DU",
				"DU_OL_NO_DUMMY",
				1,
				null,
				null,
				null,
				null,
				null,
				digitalEquipmentData.getActualShipDate(),
				sqldatenew,
				sqldatenew,
				null,
				null,
		};
		this.jdbcTemplate.update(saveOrderSql, parameters);
		Calendar currenttime = Calendar.getInstance();
		Date sqldate = new Date((currenttime.getTime()).getTime());   
		String saveSql="";
		saveSql= "insert into DDSAFM.SQT_VALVE_INFO_T(VALVE_INFO_ID,ORDER_LINE_ID,REC_SOURCE,SERIAL_NUMBER,TAG_NUMBER,ITEM_NUMBER,DESCRIPTION,CREATION_DATE,LAST_UPDATE_DATE,PRODUCT_MODEL,PRODUCT_CODE)"+
				"values (?,?,?,?,?,?,?,?,?,?,?)";	
		//Long orderLine=9999999999999l;
		Object[] param={					 
				valveId,
				//orderLineId,
				newOrderLineId,
				"DU",
				digitalEquipmentData.getSerialNumber(),
				digitalEquipmentData.getTagNumber(),
				digitalEquipmentData.getPartNumber(),
				digitalEquipmentData.getPartDescription(),
				sqldate,
				sqldate,
				"",
				digitalEquipmentData.getProductCode(),
		};
		this.jdbcTemplate.update(saveSql, param);

		String orderNumber="DU_ORDER_NO_DUMMY";
		//Long orderId=9999999999999l;
		String lineNumber="DU_OL_NO_DUMMY";
		
		
		logger.info("actual shipment date added after new come");
		String sqlNewCount = "select count(1) from FPTODS.ODS_SQT_BY_SALES_ORDER_E_MV where SERIAL_NUMBER=? and REC_SOURCE=?";
		int countNew = this.jdbcTemplate.queryForInt(sqlNewCount,
				new Object[] { digitalEquipmentData.getSerialNumber(), "DU" });

		if(countNew > 0) {
			
			String sqlNew = "update FPTODS.ODS_SQT_BY_SALES_ORDER_E_MV set VALVE_INFO_ID=?,SALES_ORDER=?,ORDER_IDENTIFIER=?,SALES_ORDER_LINE=?,"
					+ "TAG_NUMBER=?,T_NUMBER=?,VALVE_PART_NUMBER=?,VALVE_DESCRIPTION=?,ACTUAL_SHIP_DATE=? where SERIAL_NUMBER=? and REC_SOURCE=? and QUANTITY_SHIPPED=?";

			Object[] paramsNew={					 
					valveId,
					//orderLineId,
					orderNumber,
					orderId,
					lineNumber,
					digitalEquipmentData.getTagNumber(),
					digitalEquipmentData.getTagNumber(),
					digitalEquipmentData.getPartNumber(),
					digitalEquipmentData.getPartDescription(),
					digitalEquipmentData.getActualShipDate(),
					digitalEquipmentData.getSerialNumber(),
					"DU",
					"1"
			};
			logger.error("Inside the Update - Vinay");
			logger.info("actual shipment date added"+digitalEquipmentData.getActualShipDate());
			this.jdbcTemplate.update(sqlNew, paramsNew);

		}  else {
			
			String saveSqlSOEInf="insert into FPTODS.ODS_SQT_BY_SALES_ORDER_E_MV(VALVE_INFO_ID,SALES_ORDER,ORDER_IDENTIFIER,SALES_ORDER_LINE,REC_SOURCE,SERIAL_NUMBER,S_NUMBER,TAG_NUMBER,T_NUMBER,VALVE_PART_NUMBER,VALVE_DESCRIPTION,ACTUAL_SHIP_DATE,QUANTITY_SHIPPED)"+
					"values (?,?,?,?,?,?,?,?,?,?,?,?,?)";
			Object[] paramSOEInf={					 
					valveId,
					//orderLineId,
					orderNumber,
					orderId,
					lineNumber,
					"DU",
					digitalEquipmentData.getSerialNumber(),
					digitalEquipmentData.getSerialNumber(),
					digitalEquipmentData.getTagNumber(),
					digitalEquipmentData.getTagNumber(),
					digitalEquipmentData.getPartNumber(),
					digitalEquipmentData.getPartDescription(),
					digitalEquipmentData.getActualShipDate(),
					"1"
			};
			logger.info("actual shipment date added"+digitalEquipmentData.getActualShipDate());
			this.jdbcTemplate.update(saveSqlSOEInf, paramSOEInf);			
		}

		

		String saveSqlSOEUpdate="insert into DDSAFM.ODS_SQT_BY_SO_E_UPDATE(VALVE_INFO_ID,SALES_ORDER,ORDER_IDENTIFIER,SALES_ORDER_LINE,REC_SOURCE,SERIAL_NUMBER,TAG_NUMBER,VALVE_PART_NUMBER,VALVE_DESCRIPTION,ACTUAL_SHIP_DATE)"+
				"values (?,?,?,?,?,?,?,?,?,?)";
		Object[] paramSOEUpdate={					 
				valveId,
				//orderLineId,
				orderNumber,
				orderId,
				lineNumber,
				"DU",
				digitalEquipmentData.getSerialNumber(),
				digitalEquipmentData.getTagNumber(),
				digitalEquipmentData.getPartNumber(),
				digitalEquipmentData.getPartDescription(),
				digitalEquipmentData.getActualShipDate()
		};
		logger.info("actual shipment date added"+digitalEquipmentData.getActualShipDate());
		this.jdbcTemplate.update(saveSqlSOEUpdate, paramSOEUpdate);
		result=valveId.toString();
	} catch (Exception e) {
		logger.error("Exception in saving EquipmentDigital"+e.getLocalizedMessage());
	}
	return result;
	}

	@Override
	public StatusInfo saveBomDigital(String valveInfoId, List<DigitalBOMData> digitalBomData) {
		StatusInfo info= new StatusInfo();
		try{		
			for(DigitalBOMData data:digitalBomData){
				Calendar currenttime = Calendar.getInstance();
				Date sqldate = new Date((currenttime.getTime()).getTime());
				Long bomId=0l;
				List<Long> part_info_id=new ArrayList<Long>();
				String partInfo_Id="select PART_INFO_ID from DDSAFM.SQT_PART_INFO_T where ITEM_NUMBER=? AND REC_SOURCE=?";
				Object[] params={					 
						data.getComponentItemNumber(),	
						"DU"
				};
				//part_info_id=this.jdbcTemplate.queryForLong(partInfo_Id,params);		
				part_info_id=this.jdbcTemplate.queryForList(partInfo_Id, params, Long.class);

				if(null!=part_info_id && part_info_id.size()!=0){
					bomId=part_info_id.get(0).longValue();
				} else {
					String selectBomId="select max(PART_INFO_ID) from DDSAFM.SQT_PART_INFO_T";	
					bomId=this.jdbcTemplate.queryForLong(selectBomId);		
					bomId=bomId+1;
					String saveSql="";
					saveSql= "insert into DDSAFM.SQT_PART_INFO_T(PART_INFO_ID, REC_SOURCE, ITEM_NUMBER, DESCRIPTION, CREATION_DATE, LAST_UPDATE_DATE)"+
							"values (?,?,?,?,?,?)";				
					Object[] param={					 
							bomId,
							"DU",
							data.getComponentItemNumber(),
							data.getComponentDescription(),
							sqldate,
							sqldate		
					};
					this.jdbcTemplate.update(saveSql, param);
				}

				// save vale comp id
				String selectBomCompValve="select max(VALVE_COMP_ID) from DDSAFM.SQT_VALVE_COMP_T";	
				Long selectBomCompValveID=this.jdbcTemplate.queryForLong(selectBomCompValve);
				selectBomCompValveID=selectBomCompValveID+1;
				Long valveIdLong=Long.parseLong(valveInfoId);
				logger.error("Checking ValveIdLong"+valveIdLong);
				String saveSqlComp="insert into DDSAFM.SQT_VALVE_COMP_T(VALVE_COMP_ID, VALVE_ID, PART_ID, REC_SOURCE, QUANTITY, CREATION_DATE, LAST_UPDATE_DATE)"+
						"values (?,?,?,?,?,?,?)";
				Object[] paramComp={					 
						selectBomCompValveID,
						valveIdLong,
						bomId,
						"DU",
						data.getQuantity(),
						sqldate,
						sqldate		
				};
				this.jdbcTemplate.update(saveSqlComp, paramComp);
			}
			info.setStatusCode(0);
			info.setStatusMessage("Data saved succesfully");
		}catch (Exception e) {
			info.setStatusCode(-1);
			info.setStatusMessage("Saving EquipmentDigital failed");
			logger.error("Exception in saving EquipmentDigital"+e.getLocalizedMessage());
		}
		return info;
	}

	private static final class UpgradeInfoMapper implements
	RowMapper<UpgradeInfo> {
		public UpgradeInfoMapper() {
		}

		@Override
		public UpgradeInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
			UpgradeInfo result = new UpgradeInfo();
			int upgradeId = rs.getInt("upgrade_id");
			result.setUpgradeId(null != String.valueOf(upgradeId) ? String
					.valueOf(upgradeId) : "");
			result.setUpgradeName(rs.getString("upgrade_name") != null ? rs
					.getString("upgrade_name") : "");
			result.setUpgradeBrand(rs.getString("brand") != null ? rs
					.getString("brand") : "");
			result.setUpgradeDescription(rs.getString("description") != null ? rs
					.getString("description") : "");
			result.setUpgradeModel(rs.getString("model") != null ? rs
					.getString("model") : "");
			result.setUpgradePart(rs.getString("part_id") != null ? rs
					.getString("part_id") : "");
			result.setCouponCode(rs.getString("coupon_code") != null ? rs
					.getString("coupon_code") : "");
			result.setRegion(rs.getString("region") != null ? rs
					.getString("region") : "");
			result.setValidityFrom(rs.getDate("validity_from") != null ? rs
					.getDate("validity_from") : null);
			result.setValidityTo(rs.getDate("validity_to") != null ? rs
					.getDate("validity_to") : null);
			result.setPromo_file(rs.getString("promo_file") != null ? rs
					.getString("promo_file") : "");
			result.setPromo_name(rs.getString("promo_name") != null ? rs
					.getString("promo_name") : "");
			result.setCategory(rs.getString("promotion_category") != null ? rs
					.getString("promotion_category") : "");
			return result;
		}
	}

	private static final class VKReportDataMapper implements
	RowMapper<VKReportData> {
		public VKReportDataMapper() {
		}

		@Override
		public VKReportData mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			VKReportData result = new VKReportData();

			try {
				result.setSalesOrder(rs.getString("SALES_ORDER"));
				result.setEndUserCustName(rs.getString("END_USER_CUST_NAME"));
				result.setEndUserCustAddress(rs
						.getString("END_USER_CUST_ADDRESS"));
				result.setCity(rs.getString("CITY"));
				result.setState(rs.getString("STATE"));
				result.setProvince(rs.getString("PROVINCE"));
				result.setPostalCode(rs.getString("POSTAL_CODE"));
				result.setCountry(rs.getString("COUNTRY"));
				result.setShipSource(rs.getString("SHIP_SOURCE"));
				result.setSerialNumber(rs.getString("SERIAL_NUMBER"));
				result.setValveDescription(rs.getString("VALVE_DESCRIPTION"));
				result.setTagNumber(rs.getString("TAG_NUMBER"));
				result.setPartNumber(rs.getString("PART_NUMBER"));
				result.setPartDescription(rs.getString("PART_DESCRIPTION"));
				result.setSparesCode(rs.getString("SPARES_CODE"));
				result.setQty(rs.getString("QTY"));
				// result.setListPrice(rs.getString("LIST_PRICE"));
				result.setLeadTime(rs.getString("LEAD_TIME"));

				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); //$NON-NLS-1$
				result.setShipDate(formatter.format(rs.getDate("SHIP_DATE")));

			} catch (Exception ex) {
				logger.error("RSPCartData Mapper error: ", ex);
			}
			return result;
		}
	}
	
	//Added by sujeet
		public List<OrderEquipment> getCustomerDataManagement(String customerId){
			try{
				List<OrderEquipment> equipment=new ArrayList<OrderEquipment>();
				String sql="";
				logger.info("customerId is:-"+customerId);
				if(customerId!=null){
					logger.info("inside getCustomerDataManagement");
					sql = "	SELECT E.REC_SOURCE,E.SALES_ORDER,E.SALES_ORDER_LINE,E.CUSTOMER_PO,E.SOLD_TO_CUSTOMER_NAME,E.SOLD_TO_COUNTRY,"
							+ "E.SOLD_TO_STATE,E.SOLD_TO_PROVINCE,E.SOLD_TO_CITY,E.REP_NAME,E.ORDERED_ITEM_NUMBER,E.QUANTITY_SHIPPED,E.UNIT_SELLING_PRICE,"
							+ "E.SERIAL_NUMBER,E.VALVE_PART_NUMBER,E.VALVE_DESCRIPTION,E.TAG_NUMBER,E.SOURCE_SYSTEM,E.VALVE_INFO_ID,E.PRODUCT_CODE,"
							+ "E.PRODUCT_MODEL,E.FILE_PATH,E.FILE_NAME,E.ACTUAL_SHIP_DATE,E.SERIALIZABLE,E.ENGINEERED_VALVE,M.CUST_ID,M.LINK_CUSTOMER_NAME"
							+ " FROM DDSAFM.ODS_SQT_BY_SALES_ORDER_E E LEFT OUTER JOIN FPTODS.CUSTOMER_LINK_MASTER_T M ON M.ORDER_NUMBER=E.SALES_ORDER "
							+ "AND M.SERIAL_NUMBER=E.SERIAL_NUMBER	WHERE M.CUST_ID=?";
					equipment = this.jdbcTemplate.query(sql,new Object[] {customerId},new EquipmentMapper1());
					logger.info("inside getCustomerDataManagement()");
					return equipment;
				}
			}catch(Exception e){
				e.printStackTrace();
				logger.error("Get getCustomerDataManagement By CUSTOMER_ID:",e);
			}
			return null;
		}
	public List<OrderEquipment> getCustomerForSerial(){
		try{
			List<OrderEquipment> equipment=new ArrayList<OrderEquipment>();
			String sql="";
			logger.info("inside getCustomerForSerial ");
			sql = "	SELECT E.REC_SOURCE,E.SALES_ORDER,E.SALES_ORDER_LINE,E.CUSTOMER_PO,E.SOLD_TO_CUSTOMER_NAME,E.SOLD_TO_COUNTRY,"
					+ "E.SOLD_TO_STATE,E.SOLD_TO_PROVINCE,E.SOLD_TO_CITY,E.REP_NAME,E.ORDERED_ITEM_NUMBER,E.QUANTITY_SHIPPED,E.UNIT_SELLING_PRICE,"
					+ "E.SERIAL_NUMBER,E.VALVE_PART_NUMBER,E.VALVE_DESCRIPTION,E.TAG_NUMBER,E.SOURCE_SYSTEM,E.VALVE_INFO_ID,E.PRODUCT_CODE,"
					+ "E.PRODUCT_MODEL,E.FILE_PATH,E.FILE_NAME,E.ACTUAL_SHIP_DATE,E.SERIALIZABLE,E.ENGINEERED_VALVE,M.CUST_ID,M.LINK_CUSTOMER_NAME"
					+ " FROM DDSAFM.ODS_SQT_BY_SALES_ORDER_E E LEFT OUTER JOIN FPTODS.CUSTOMER_LINK_MASTER_T M ON M.ORDER_NUMBER=E.SALES_ORDER "
					+ "AND M.SERIAL_NUMBER=E.SERIAL_NUMBER	WHERE ROWNUM<=10";
			equipment = this.jdbcTemplate.query(sql,new EquipmentMapper());	
			logger.info("inside getCustomerForSerial");
			return equipment;
		}catch(Exception e){
			e.printStackTrace();
			logger.error("Get getCustomerForSerial:",e);
		}
		return null;
	}
	//end by sujeet

	
   // Channel Partner - Add to promotional Cart - Neha
	
	@Override
	public StatusInfo addToPromotionalCartCP(String sso, String promotionalCartLevel, CPPromotionalCart data) {
		StatusInfo statusInfo = new StatusInfo();
		int resultStatus = 0;
		
		try {
			// check whether the upgrade is already present in the cart
			String sqlCheckOption = "select count(*) from FPTODS.SQT_SSO_PROMOTIONAL_CART where UPGRADE_ID=? AND OPTION_ID=? AND SSO=? ";
			int countUpgrade = this.jdbcTemplate.queryForInt(sqlCheckOption,
					new Object[] { data.getUpgradeId(),
							data.getOptionId(), sso });
			logger.info("count for upgrade, if already present"+countUpgrade);
			if (countUpgrade > 0) {
				// already Upgrade is present in the cart....update it
				String sqlGetUpgradeQuantity = "select UNIQUE(QUANTITY) from FPTODS.SQT_SSO_PROMOTIONAL_CART where UPGRADE_ID=? AND OPTION_ID=? AND SSO=? ";
				int quantity = this.jdbcTemplate.queryForObject(
						sqlGetUpgradeQuantity, Integer.class, new Object[] {
								data.getUpgradeId(),
								data.getOptionId(), sso });
				int updatedQuantity = quantity + data.getQuantity();
				
				String updateUpgrade = "update FPTODS.SQT_SSO_PROMOTIONAL_CART set QUANTITY=? where UPGRADE_ID=? AND OPTION_ID=? AND SSO=? ";
				Object[] params = new Object[4];
				params[0] = updatedQuantity;
				params[1] = data.getUpgradeId();
				params[2] = data.getOptionId();
				params[3] = sso;
				resultStatus = this.jdbcTemplate.update(updateUpgrade, params);
				logger.info("Count updated for existing upgrade");
				
				
			} else {
				logger.info("Inside else condition, upgrade not already present");
				String sql = "select * from FPTODS.SQT_UPGRADE_INFO where UPGRADE_ID=?";
				List<UpgradeInfo> upgradeInfo = this.jdbcTemplate.query(sql,
						new Object[] { data.getUpgradeId() },
						new UpgradeInfoMapper());
				logger.info("Check for upgrade and package");
				resultStatus = CheckforUpgradeOrPackage(sso,data,upgradeInfo,promotionalCartLevel);
				 }	
			 if( resultStatus == 1 || resultStatus > 1) {
			     statusInfo.setStatusCode(1);
				 statusInfo.setStatusMessage("Items added successfully");
				}
		} catch (Exception ex) {
			 logger.error("Save To Promotional Cart error:", ex);
			 statusInfo.setStatusCode(-1);
			 statusInfo.setStatusMessage("Addding promotional cart data failed");
			 return statusInfo;
		}
		return statusInfo;
		}
	
	 
	private int CheckforUpgradeOrPackage(String sso, CPPromotionalCart data, List<UpgradeInfo> upgradeInfo, String promotionalCartLevel) {
		String sqlPromotionalCart = "INSERT INTO FPTODS.SQT_SSO_PROMOTIONAL_CART "
				+ "(SSO,UPGRADE_ID,UPGRADE_NAME,OPTION_ID,OPTION_NAME,OPTION_DESCRIPTION,COUPON_CODE,PART_MODEL,INDICATOR,QUANTITY) "
				+ "VALUES " + "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		int status = 0;
	    Object[] params = new Object[10];
			params[0] = sso;
			params[1] = data.getUpgradeId();
			params[2] = data.getUpgradeName();
			params[3] = data.getOptionId();
			params[4] = data.getOptionName();
			params[5] = data.getOptionDescription();
			if(promotionalCartLevel.equalsIgnoreCase("Upgrade")){
				params[6] = upgradeInfo.get(0).getCouponCode();
				params[7] = upgradeInfo.get(0).getUpgradePart();
			}else if(promotionalCartLevel.equalsIgnoreCase("Package")){
				params[6] = data.getCouponCode();
				params[7] = data.getKitNumber();
			}
			params[8] = upgradeInfo.get(0).getCategory();
			params[9] = data.getQuantity();
		    status = this.jdbcTemplate.update(sqlPromotionalCart, params);
		    logger.info("status of upgrade insert "+status);
		    return status;
	}
		
	

	

	@Override
	public StatusInfo addToPromotionalCartSMI(String sso, CPPromotionalCart data) {
		//Check for StatusInfoUpgradeId, optionId, PartNumber Combination already present in the cart
		int status = 0;
		StatusInfo statusInfo = new StatusInfo();
		List<CPUpgradeParts> partData = data.getUpgradePartsData();
	  try {  
	  for(CPUpgradeParts upgradePartData : partData){
			  
		String sqlCheckOption = "select count(*) from FPTODS.SQT_SSO_PROMOTIONAL_CART where UPGRADE_ID=? AND OPTION_ID=? AND PART_MODEL=? AND SSO=? ";
		int countUpgrade = this.jdbcTemplate.queryForInt(sqlCheckOption,
				new Object[] { data.getUpgradeId(),
						data.getOptionId(), upgradePartData.getPartNumber(), sso });
		logger.info("count for upgrade, if already present"+countUpgrade);
		if (countUpgrade > 0) {
			// already Upgrade is present in the cart....update it
			String sqlGetUpgradeQuantity = "select UNIQUE(QUANTITY) from FPTODS.SQT_SSO_PROMOTIONAL_CART where UPGRADE_ID=? AND OPTION_ID=? AND PART_MODEL=? AND SSO=? ";
		int quantity = this.jdbcTemplate.queryForObject(
					sqlGetUpgradeQuantity, Integer.class, new Object[] {
							data.getUpgradeId(),
							data.getOptionId(), upgradePartData.getPartNumber(), sso });
			int updatedQuantity = quantity + upgradePartData.getQuantity();
					
			
			String updateUpgradeParts = "update FPTODS.SQT_SSO_PROMOTIONAL_CART set QUANTITY=? where UPGRADE_ID=? AND OPTION_ID=? AND PART_MODEL=? AND SSO=? ";
			Object[] params = new Object[5];
			params[0] = updatedQuantity;
			params[1] = data.getUpgradeId();
			params[2] = data.getOptionId();
			params[3] = upgradePartData.getPartNumber();
			params[4] = sso;
			status = this.jdbcTemplate.update(updateUpgradeParts, params);
			logger.info("Count updated for existing upgrade");
			
		} else {
			
			logger.info("Inside else condition, upgrade, part not already present");
			
			String sql = "select * from FPTODS.SQT_UPGRADE_INFO where UPGRADE_ID=?";
			List<UpgradeInfo> upgradeInfo = this.jdbcTemplate.query(sql,
					new Object[] { data.getUpgradeId() },
					new UpgradeInfoMapper());
			String sqlPromotionalCart = "INSERT INTO FPTODS.SQT_SSO_PROMOTIONAL_CART "
					+ "(SSO,UPGRADE_ID,UPGRADE_NAME,OPTION_ID,OPTION_NAME,OPTION_DESCRIPTION,COUPON_CODE,PART_MODEL,INDICATOR,QUANTITY) "
					+ "VALUES " + "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			
		        Object[] params = new Object[10];
				params[0] = sso;
				params[1] = data.getUpgradeId();
				params[2] = data.getUpgradeName();
				params[3] = data.getOptionId();
				params[4] = data.getOptionName();
				params[5] = data.getOptionDescription();
				params[6] = upgradeInfo.get(0).getCouponCode();
				params[7] = upgradePartData.getPartNumber();
				params[8] = upgradePartData.getIndicator();
				params[9] = upgradePartData.getQuantity();
			    status = this.jdbcTemplate.update(sqlPromotionalCart, params);
			   }
		}        
	         if( status == 1) {
		     statusInfo.setStatusCode(1);
			 statusInfo.setStatusMessage("Items added successfully");
			 }
	  } catch (Exception ex) {
		 statusInfo.setStatusCode(-1);
		 statusInfo.setStatusMessage("Addding promotional cart  SMI data failed");
		 logger.error("Save To  SMI Promotional Cart error:", ex);
		 return statusInfo;
	}
	return statusInfo;
	  }

}
