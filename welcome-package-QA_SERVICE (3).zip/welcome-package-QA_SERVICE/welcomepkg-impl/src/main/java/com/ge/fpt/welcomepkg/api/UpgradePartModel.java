package com.ge.fpt.welcomepkg.api;

public class UpgradePartModel {
	
	private static final long serialVersionUID = -5579179999880989818L;
	private String upgradeId;
	private String indicator;
	private String partModel;
	private double discountPrice;
	
	
	public double getDiscountPrice() {
		return discountPrice;
	}
	public void setDiscountPrice(double discountPrice) {
		this.discountPrice = discountPrice;
	}
	public String getPartModel() {
		return partModel;
	}
	public void setPartModel(String partModel) {
		this.partModel = partModel;
	}
	public String getIndicator() {
		return indicator;
	}
	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}
	public String getUpgradeId() {
		return upgradeId;
	}
	public void setUpgradeId(String upgradeId) {
		this.upgradeId = upgradeId;
	}
	@Override
	public String toString() {
		return "UpgradePartModel [upgradeId=" + upgradeId + ", indicator=" + indicator + ", partModel=" + partModel
				+ ", discountPrice=" + discountPrice + "]";
	}

}
