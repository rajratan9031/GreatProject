package com.ge.fpt.welcomepkg.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.fpt.welcomepkg.api.CartData;
import com.ge.fpt.welcomepkg.api.CustomerSqtLinkT;
import com.ge.fpt.welcomepkg.api.CustomerMgmtMaster;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;
import com.ge.fpt.welcomepkg.persistence.CustomermgmtMasterPersistenceImpl.CustomerMgmtMasterMapper;

public class CardDataPersistenceImpl implements ICardDataPersistence {

	
	@SuppressWarnings("javadoc")
	static final org.slf4j.Logger logger = WelcomePackageLoggerFactory.getLogger(CustomerLinkMasterPersistenceImpl.class);

	/**
	 * Reference to the JdbcTemplate
	 */
	JdbcTemplate jdbcTemplate;

	/**
	 * Data source for the JDBC
	 */
	DataSource dataSource;

	/**
	 * Transaction Manager for the JDBC
	 */
	PlatformTransactionManager txManager;

	NamedParameterJdbcTemplate namedParamTemplate;

	/**
	 * @return the dataSource
	 */
	public DataSource getDataSource() {
		return this.dataSource;
	}

	/**
	 * @param ds
	 *            -- DataSource object for persistent
	 * 
	 */
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate = new NamedParameterJdbcTemplate(ds);
	}

	/**
	 * @return the txManager
	 */
	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	/**
	 * @param txManager
	 *            the txManager to set
	 */
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}


	
	@Override
	public StatusInfo deleteCartData(String serialNumber) {
		StatusInfo result= new StatusInfo();
		try{
			logger.info("inside delete card data###################");
			String sql="Delete from FPTODS.SQT_SSO_SAVED_CARTS where SERIAL_NUMBER=?";
			this.jdbcTemplate.update(sql, new Object[]{serialNumber});
			logger.info("after the deletecard data@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
			result.setStatusCode(0);
			result.setStatusMessage("Deleted Successfully!!");
			return result;
		
			}
	catch (Exception e){
		result.setStatusCode(-1);
		result.setStatusMessage("Error occurred while deleted..");
		return result;
	}

	}

public List<CartData> getcartData(){
		
		logger.info("inside the custmgmtmaster@@@@@@@@@@@@@@@@@@@");
		String sql= "select * from FPTODS.SQT_SSO_SAVED_CARTS";
		List<CartData> cartData=this.jdbcTemplate.query(sql,new cartDataMapper());
		logger.info("after the custmgmt saved@@@@@@@@@@@@@@");
		return cartData;
	}

public static final class cartDataMapper implements
RowMapper<CartData> {

	public CartData mapRow(ResultSet rs, int rowNum)
	throws SQLException {
		CartData result = new CartData();
		
	
		result.setCartName(rs.getString("CART_NAME"));
		result.setSso(rs.getString("SSO"));


		result.setValveInfoId(rs.getLong("VALVE_INFO_ID"));
		result.setOrderLineId(rs.getLong("ORDER_LINE_ID"));
		result.setRecSource(rs.getString("REC_SOURCE"));
		result.setSerialNumber(rs.getString("SERIAL_NUMBER"));
		result.setTagNumber(rs.getString("TAG_NUMBER"));
		result.setItemNumber(rs.getString("ITEM_NUMBER"));
		result.setDescription(rs.getString("DESCRIPTION"));
		result.setProductModel(rs.getString("PRODUCT_MODEL"));
		result.setProductCode(rs.getString("PRODUCT_CODE"));
		result.setSalesOrder(rs.getString("ORDER_NUMBER"));
		result.setDateSaved(rs.getDate("DATE_SAVED"));
		result.setDateATT1(rs.getDate("DATE_ATT1"));
		result.setDateATT2(rs.getDate("DATE_ATT2"));
		result.setIstore_Status(rs.getString("ISTORE_STATUS"));
		return result;
}
}

}
