package com.ge.fpt.welcomepkg.api;

import java.sql.Date;
import java.util.List;

public class UpgradeInfo {
	
	private static final long serialVersionUID = -5579178977880989818L;
	private String upgradeId;
	private String upgradeName;
	private String upgradeBrand;
	private String upgradeDescription;
	private String upgradeModel;
	private String upgradePart;
	private String region;
	private String couponCode;
	private Date validityFrom;
	private Date validityTo;
	private List<UpgradePartModel> upgradePartModel;
	private List<UpgradeDocument> upgradeDocument;
	private String promo_file;
	private String promo_name;
	private String category;
	private String featuredUpgrade;
	private double amount;
	private double discount;
	private String displayOnDashBoard;
	
	public List<UpgradeDocument> getUpgradeDocument() {
		return upgradeDocument;
	}
	public void setUpgradeDocument(List<UpgradeDocument> upgradeDocument) {
		this.upgradeDocument = upgradeDocument;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getFeaturedUpgrade() {
		return featuredUpgrade;
	}
	public void setFeaturedUpgrade(String featuredUpgrade) {
		this.featuredUpgrade = featuredUpgrade;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	public String getDisplayOnDashBoard() {
		return displayOnDashBoard;
	}
	public void setDisplayOnDashBoard(String displayOnDashBoard) {
		this.displayOnDashBoard = displayOnDashBoard;
	}
	public String getPromo_file() {
		return promo_file;
	}
	public void setPromo_file(String promo_file) {
		this.promo_file = promo_file;
	}
	public String getPromo_name() {
		return promo_name;
	}
	public void setPromo_name(String promo_name) {
		this.promo_name = promo_name;
	}
	public Date getValidityFrom() {
		return validityFrom;
	}
	public void setValidityFrom(Date validityFrom) {
		this.validityFrom = validityFrom;
	}
	public Date getValidityTo() {
		return validityTo;
	}
	public void setValidityTo(Date validityTo) {
		this.validityTo = validityTo;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getCouponCode() {
		return couponCode;
	}
	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}
	public String getUpgradeId() {
		return upgradeId;
	}
	public void setUpgradeId(String upgradeId) {
		this.upgradeId = upgradeId;
	}	
	public String getUpgradeName() {
		return upgradeName;
	}
	public void setUpgradeName(String upgradeName) {
		this.upgradeName = upgradeName;
	}
	public String getUpgradeBrand() {
		return upgradeBrand;
	}
	public void setUpgradeBrand(String upgradeBrand) {
		this.upgradeBrand = upgradeBrand;
	}
	public String getUpgradeDescription() {
		return upgradeDescription;
	}
	public void setUpgradeDescription(String upgradeDescription) {
		this.upgradeDescription = upgradeDescription;
	}
	public String getUpgradeModel() {
		return upgradeModel;
	}
	public void setUpgradeModel(String upgradeModel) {
		this.upgradeModel = upgradeModel;
	}
	public String getUpgradePart() {
		return upgradePart;
	}
	public void setUpgradePart(String upgradePart) {
		this.upgradePart = upgradePart;
	}
	public List<UpgradePartModel> getUpgradePartModel() {
		return upgradePartModel;
	}
	public void setUpgradePartModel(List<UpgradePartModel> upgradePartModel) {
		this.upgradePartModel = upgradePartModel;
	}
	
	@Override
	public String toString() {
		return "UpgradeInfo [upgradeId=" + upgradeId + ", upgradeName=" + upgradeName + ", upgradeBrand=" + upgradeBrand
				+ ", upgradeDescription=" + upgradeDescription + ", upgradeModel=" + upgradeModel + ", upgradePart="
				+ upgradePart + ", region=" + region + ", couponCode=" + couponCode + ", validityFrom=" + validityFrom
				+ ", validityTo=" + validityTo + ", upgradePartModel=" + upgradePartModel + ", upgradeDocument="
				+ upgradeDocument + ", promo_file=" + promo_file + ", promo_name=" + promo_name + ", category="
				+ category + ", featuredUpgrade=" + featuredUpgrade + ", amount=" + amount + ", discount=" + discount
				+ ", displayOnDashBoard=" + displayOnDashBoard + "]";
	}
	
}
