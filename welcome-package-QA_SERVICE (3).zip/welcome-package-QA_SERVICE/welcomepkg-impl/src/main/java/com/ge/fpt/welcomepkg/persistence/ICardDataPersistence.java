package com.ge.fpt.welcomepkg.persistence;

import java.util.List;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ge.fpt.welcomepkg.api.CartData;
import com.ge.fpt.welcomepkg.api.CustomerMgmtMaster;
import com.ge.fpt.welcomepkg.api.StatusInfo;

public interface ICardDataPersistence {
	@Transactional(propagation=Propagation.REQUIRED)
	StatusInfo deleteCartData(String serialNumber);
	
	@Transactional(propagation=Propagation.REQUIRED)
	public List<CartData> getcartData();
}
