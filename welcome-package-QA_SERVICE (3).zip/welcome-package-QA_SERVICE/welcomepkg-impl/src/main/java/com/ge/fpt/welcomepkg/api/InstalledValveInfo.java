package com.ge.fpt.welcomepkg.api;

public class InstalledValveInfo {
	private String recSource;
	private String salesOrder;
	private String customerPo;
	private String soldToProvince;
	private String rep_name;
	private String sourceSys;
	private String endUser;
	private String productCode;
	private String interCompany;
	private String soldToZip;
	private String serialNumber;
	private String tagNumber;
	private String itemNumber;
	private String description;
	private String productModel;
	private String duns;
	private String channel;
	private String country;
	private String state;
	public String getRecSource() {
		return recSource;
	}
	public void setRecSource(String recSource) {
		this.recSource = recSource;
	}
	public String getSalesOrder() {
		return salesOrder;
	}
	public void setSalesOrder(String salesOrder) {
		this.salesOrder = salesOrder;
	}
	public String getCustomerPo() {
		return customerPo;
	}
	public void setCustomerPo(String customerPo) {
		this.customerPo = customerPo;
	}
	public String getSoldToProvince() {
		return soldToProvince;
	}
	public void setSoldToProvince(String soldToProvince) {
		this.soldToProvince = soldToProvince;
	}
	public String getRep_name() {
		return rep_name;
	}
	public void setRep_name(String rep_name) {
		this.rep_name = rep_name;
	}
	public String getSourceSys() {
		return sourceSys;
	}
	public void setSourceSys(String sourceSys) {
		this.sourceSys = sourceSys;
	}
	public String getEndUser() {
		return endUser;
	}
	public void setEndUser(String endUser) {
		this.endUser = endUser;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getInterCompany() {
		return interCompany;
	}
	public void setInterCompany(String interCompany) {
		this.interCompany = interCompany;
	}
	public String getSoldToZip() {
		return soldToZip;
	}
	public void setSoldToZip(String soldToZip) {
		this.soldToZip = soldToZip;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getTagNumber() {
		return tagNumber;
	}
	public void setTagNumber(String tagNumber) {
		this.tagNumber = tagNumber;
	}
	public String getItemNumber() {
		return itemNumber;
	}
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getProductModel() {
		return productModel;
	}
	public void setProductModel(String productModel) {
		this.productModel = productModel;
	}
	public String getDuns() {
		return duns;
	}
	public void setDuns(String duns) {
		this.duns = duns;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	} 

}

