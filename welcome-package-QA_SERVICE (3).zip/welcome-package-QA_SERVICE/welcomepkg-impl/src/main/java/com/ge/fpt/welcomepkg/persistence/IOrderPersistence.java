/*
* Copyright (c) 2013 GE Global Research. All rights reserved.
*
* The copyright to the computer software herein is the property of
* GE Global Research. The software may be used and/or copied only
* with the written permission of GE Global Research or in accordance
* with the terms and conditions stipulated in the agreement/contract
* under which the software has been supplied.
*/

package com.ge.fpt.welcomepkg.persistence;

import java.text.ParseException;
import java.util.List;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ge.fpt.welcomepkg.api.CnDataInfo;
import com.ge.fpt.welcomepkg.api.CustomerDetailsForOrderNumber;
import com.ge.fpt.welcomepkg.api.CustomerDetailsforSerial;
import com.ge.fpt.welcomepkg.api.DropDownItem;
import com.ge.fpt.welcomepkg.api.OrderEquipment;
import com.ge.fpt.welcomepkg.api.OrderInfo;
import com.ge.fpt.welcomepkg.api.SalesSerial;
import com.ge.fpt.welcomepkg.api.StatusInfo;
import com.ge.fpt.welcomepkg.api.UserSettings;

/**
* @author 212414241
* 
 */
public interface IOrderPersistence {

               /**
               * Get Orders by SSO
               * 
                * @param sso
               *            company sso
               * @return list of orders, filtered by company sso
               */
               
//            @Transactional(propagation = Propagation.REQUIRED)
//            List<OrderInfo> getOrdersBySSO(String sso, UserSettings settings, int page, int rowsPerPage);

               @Transactional(propagation = Propagation.REQUIRED)
               List<OrderInfo> getOrdersBySSO(String sso, UserSettings settings, int page, int rowsPerPage,String sortCol,String sortOrder,OrderInfo orderInfo, String globalSearch,boolean blanketSearch,String serialNo, String partNo,String tagNo,String fileName,String engineeredValve);
               
               /**
               * @param sso
               * @param salesOrder
               * @param recSource
               * @return
               */
               @Transactional(propagation = Propagation.REQUIRED)
               StatusInfo convertOrder(String sso, Long orderNum, String recSource);
               
//            @Transactional(propagation = Propagation.REQUIRED)
//            int getOrdersCount(String sso, UserSettings settings);
               
               @Transactional(propagation = Propagation.REQUIRED)
               int getOrdersCount(String sso, UserSettings settings,OrderInfo orderInfo, String globalSearch,boolean blanketSearch,String serialNo, String partNo,String tagNo,String fileName,String engineeredValve);

               @Transactional(propagation = Propagation.REQUIRED)
               List<OrderInfo> getOrdersByDUNS(String sso, String type,String duns,String year, String month,String pc,int page, int rowsPerPage,String sortCol,String sortOrder,String globalSearch,OrderInfo orderInfo) throws ParseException;
               
               @Transactional(propagation = Propagation.REQUIRED)
               int getOrderCountByDUNS(String sso, String type,String duns,String year, String month,String pc, String globalSearch,OrderInfo orderinfo) throws ParseException;
               
               
               @Transactional(propagation = Propagation.REQUIRED)
               List<OrderInfo> getOrdersBySalesOrder(String sso, String salesOrder ) ;
               
               @Transactional(propagation = Propagation.REQUIRED)
               StatusInfo UpdateSalesOrderInfo(String sso,OrderInfo orderinfo);
               
               @Transactional(propagation = Propagation.REQUIRED)
               List getAutocompleteDataList(String sso, String col, String input);
               
               @Transactional(propagation = Propagation.REQUIRED)
               List<String> getChannelSettingsProduct(String sso);

               @Transactional(propagation = Propagation.REQUIRED)
               OrderInfo getSalesOrderInfo(String sso, String order,String recSource);
        
        	
           	@Transactional(propagation = Propagation.REQUIRED)
        	List<CustomerDetailsforSerial> getCustLinkData(SalesSerial salesSerial);
      
           	
/*         
 * 
 *   
 *   @Transactional(propagation = Propagation.REQUIRED)
               CnDataInfo getCnDataInfo(String serialNumber);*/
               
               /*@Transactional(propagation = Propagation.REQUIRED)
               List orderList(OrderEquipment orderEquipment);*/
}
