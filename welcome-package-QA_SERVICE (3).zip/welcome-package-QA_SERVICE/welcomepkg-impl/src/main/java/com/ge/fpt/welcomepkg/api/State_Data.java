package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;

public class State_Data implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String state_name;

	
	/**
	 * @return the state_name
	 */
	public String getState_name() {
		return state_name;
	}

	/**
	 * @param state_name the state_name to set
	 */
	public void setState_name(String state_name) {
		this.state_name = state_name;
	}

	

	@Override
	public String toString() {
		return "State_Data [state_name=" + state_name + "]";
	}
	
	


}
