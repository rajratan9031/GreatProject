/**
 * 
 */
package com.ge.fpt.welcomepkg.api;

/**
 * @author 212670449
 *
 */
public class TurboChargerDetail {

	private String turbochargerMake;
	private String turbochargerModel;
	/**
	 * @return the turbochargerMake
	 */
	public String getTurbochargerMake() {
		return turbochargerMake;
	}
	/**
	 * @param turbochargerMake the turbochargerMake to set
	 */
	public void setTurbochargerMake(String turbochargerMake) {
		this.turbochargerMake = turbochargerMake;
	}
	/**
	 * @return the turbochargerModel
	 */
	public String getTurbochargerModel() {
		return turbochargerModel;
	}
	/**
	 * @param turbochargerModel the turbochargerModel to set
	 */
	public void setTurbochargerModel(String turbochargerModel) {
		this.turbochargerModel = turbochargerModel;
	}
	
}
