package com.ge.fpt.welcomepkg.persistence;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

import com.ge.fpt.welcomepkg.api.Country;
import com.ge.fpt.welcomepkg.api.CountryDTO;
import com.ge.fpt.welcomepkg.api.Country_Data;
import com.ge.fpt.welcomepkg.api.CustomerSqtLinkT;
import com.ge.fpt.welcomepkg.api.CustomerMgmtMaster;
import com.ge.fpt.welcomepkg.api.LinkingMasterTO;
import com.ge.fpt.welcomepkg.api.PlantDataMaster;
import com.ge.fpt.welcomepkg.api.Region_Data;
import com.ge.fpt.welcomepkg.api.State_Data;
import com.ge.fpt.welcomepkg.impl.WelcomePackageLoggerFactory;

public class CustomermgmtMasterPersistenceImpl<E> implements ICustomermgmtMasterPersistence {
	private static final Logger logger = WelcomePackageLoggerFactory.getLogger(CustomermgmtMasterPersistenceImpl.class);
	JdbcTemplate jdbcTemplate;
	DataSource dataSource;
	PlatformTransactionManager txManager;
	NamedParameterJdbcTemplate namedParamTemplate;



	public DataSource getDataSource() {
		return this.dataSource;
	}

	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplate = new JdbcTemplate(ds);
		this.namedParamTemplate = new NamedParameterJdbcTemplate(ds);
	}

	public PlatformTransactionManager getTxManager() {
		return this.txManager;
	}

	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ge.fpt.welcomepkg.persistence.IpriceToolUserPersistence#getPriceToolUser
	 * ()
	 */
	public List<CustomerMgmtMaster> getcustomermgmt(){

		String sql= "select * from FPTODS.CUSTOMER_DATA_MANAGMENT_MASTER";
		List<CustomerMgmtMaster> custmgmtData=this.jdbcTemplate.query(sql,new CustomerMgmtMasterMapper());
		return custmgmtData;
	}



	public static final class CustomerMgmtMasterMapper implements
	RowMapper<CustomerMgmtMaster> {

		public CustomerMgmtMaster mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			CustomerMgmtMaster result = new CustomerMgmtMaster();

			int custid=rs.getInt("CUST_ID");
			result.setCustId(custid);
			//result.setCustomerId(rs.getString("CUSTOMER_ID"));
			result.setCustomerName(rs.getString("CUSTOMER_NAME"));
			//result.setCountry(rs.getString("COUNTRY"));
			result.setActiveInactive(rs.getString("ACTIVE_INACTIVE"));
			//result.setRegion(rs.getString("REGION"));
			result.setDunsNumber(rs.getString("DUNS_NUMBER"));
			result.setCreatedDate(rs.getDate("CREATED_DATE"));
			result.setUpdatedDate(rs.getDate("UPDATED_DATE"));
			result.setUpdatedBy(rs.getString("UPDATED_BY"));
			result.setCreatedBy(rs.getString("CREATED_BY"));

			return result;
		}
	}




	public static final class CustomerSqtLinkTMapper implements
	RowMapper<CustomerSqtLinkT> {

		public CustomerSqtLinkT mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			CustomerSqtLinkT result = new CustomerSqtLinkT();

			Long orderid= rs.getLong("order_ID");
			result.setOrderId(orderid);
			result.setOrderNumber(rs.getString("ORDER_NUMBER"));
			Long orderLINE=rs.getLong("ORDER_LINE_ID");
			result.setOrderlineId(orderLINE);
			result.setSerialNumber(rs.getString("SERIAL_NUMBER"));
			result.setRecSource(rs.getString("REC_SOURCE"));

			return result;
		}
	}



	@Override
	public CustomerMgmtMaster getCustomerById(int custId) {
		logger.info("before the custmgmt saved");
		String sql= "select * from FPTODS.CUSTOMER_DATA_MANAGMENT_MASTER where CUST_ID='"+custId+"'";
		List<CustomerMgmtMaster> custmgmtData=this.jdbcTemplate.query(sql,new CustomerMgmtMasterMapper());
		logger.info("after the custmgmt saved");
		return custmgmtData.get(0);
	}



	@Override
	public CustomerSqtLinkT getcustomersqtbySerialNo(String serialNo) {
		try{
			String sql="select * from  fptods.SQT_CUSTOMER_LINK_v where SERIAL_NUMBER=?"; 
			CustomerSqtLinkT result=jdbcTemplate.queryForObject(sql, new Object[]{serialNo},new CustomerSqtLinkTMapper());
			return result;
		}catch(Exception e){
			logger.error("customersqtlinkT:",e);
		}
		return null;

	}


	
	
	@Override
	public List<Region_Data> getRegionCoutryStatesDetails() {

		List<Region_Data> finalData=new ArrayList<Region_Data>();
		Map<String,Region_Data> regions = new LinkedHashMap<String,Region_Data>();
		try {

			String sql="select distinct * from DDSAFM.SQT_GE_COUNTRY_V Order by REGION, COUNTRY_CODE, STATES";
			List<Country> result = this.jdbcTemplate.query(sql, new CountryMapper());
			logger.info("inside getRegionCoutryStatesDetails() result:-"+result.size());

			for (Country country : result) {

				logger.info("[Region="+country.getRegion()+", Country="+country.getCountry()+", State="+country.getStates()+"]");
				
				if(!regions.containsKey(country.getRegion())){
					

					Region_Data rgObj= new Region_Data();
					rgObj.setRegion(country.getRegion());

					List<Country_Data> countries=rgObj.getCountry_Data();
					
					Country_Data cd = new Country_Data();
					cd.setCountry_Name(country.getCountry());
					
					if(country.getStates()!=null){	
						List<String> state= cd.getState();
						state.add(country.getStates());
						cd.setState(state);
					}
					
					
					countries.add(cd);
					rgObj.setCountry_Data(countries);

					regions.put(country.getRegion(),rgObj);
					

				}else{

					
					Region_Data rgObj=regions.get(country.getRegion());
					List<Country_Data> countries=rgObj.getCountry_Data();
					Country_Data cd = null;
					for(Country_Data cntry: countries){
						if(cntry.getCountry_Name().equalsIgnoreCase(country.getCountry())){
							cd = cntry;
						}
					}
					if(cd!=null){
						
						if(country.getStates()!=null){
							List<String> state= cd.getState();
							state.add(country.getStates());
							cd.setState(state);
						}


						
						rgObj.setCountry_Data(countries);

						regions.put(country.getRegion(),rgObj);

					}else{
						List<Country_Data> newcountries=new ArrayList<Country_Data>();
						cd = new Country_Data();
						cd.setCountry_Name(country.getCountry());
						
						if(country.getStates()!=null){
							List<String> state= cd.getState();
							state.add(country.getStates());
							cd.setState(state);
						}

					
						newcountries.add(cd);
						countries.addAll(newcountries);
						rgObj.setCountry_Data(countries);

						regions.put(country.getRegion(),rgObj);

					}
				}
			}

			for(Map.Entry<String, Region_Data> entry : regions.entrySet()){
				finalData.add(entry.getValue());
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return finalData;
	}


	public static final class CountryMapper implements RowMapper<Country> {
		@Override
		public Country mapRow(ResultSet rs, int rowNum)throws SQLException {
			Country country = new Country();
			country.setRegion(rs.getString("REGION"));
			country.setCountry_code(rs.getString("COUNTRY_CODE"));
			country.setCountry(rs.getString("COUNTRY"));
			country.setStates(rs.getString("STATES"));
			return country;
		}
	}

	public static final class GeCountryMapper implements RowMapper<Region_Data> {
		@Override
		public Region_Data mapRow(ResultSet rs, int rowNum)throws SQLException {
			Region_Data result = new Region_Data();
			result.setRegion(rs.getString("REGION"));

			return result;
		}
	}


	@Override
	public List<CountryDTO> getCoutryList() {
		try{
			String sql="Select distinct COUNTRY_CODE,COUNTRY from DDSAFM.SQT_GE_COUNTRY_V ORDER BY COUNTRY"; 
			List<CountryDTO> result=jdbcTemplate.query(sql,new getCoutryListMapper());
			return result;
		}catch(Exception e){
			logger.error("customersqtlinkT:",e);
		}
		return null;

	}

	public static final class getCoutryListMapper implements RowMapper<CountryDTO> {
		@Override
		public CountryDTO mapRow(ResultSet rs, int rowNum)throws SQLException {
			CountryDTO result = new CountryDTO();

			result.setCountry_code(rs.getString("COUNTRY_CODE") != null ? rs.getString("COUNTRY_CODE") : "");
			result.setCountry(rs.getString("COUNTRY") != null ? rs.getString("COUNTRY") : "");
			return result;
		}
	}

	
}
