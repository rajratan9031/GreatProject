package com.ge.fpt.welcomepkg.api;

import java.io.Serializable;
import java.util.Date;

public class PlantDataMaster implements Serializable {
private static final long serialVersionUID = -5579178977980989818L;
	

	private int custId;
	/*private String customerName;*/
	private int plantId;
	private String plantName;
	
	private String plantLocation;
	//private String plantArea;	
	//private String plantAccount;
	//private String planUniversal;
	private String contact;
	private String maintaenanceInternal;
	private String country;
	//private String region;
	private String activeInavctive;
	private String dunsNumber;
	private Date createdDate;
	private Date updatedDate;
	private String updatedBy;
	private String createdBy;
	private String customerEmail;
	private String valveLocation;
	private String city;
	private String state;
	private String postalCode;	

	
	

	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getPostalCode() {
		return postalCode;
	}


	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}


	public String getCustomerEmail() {
		return customerEmail;
	}


	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}


	public String getDunsNumber() {
		return dunsNumber;
	}


	public void setDunsNumber(String dunsNumber) {
		this.dunsNumber = dunsNumber;
	}


	public Date getCreatedDate() {
		return createdDate;
	}


	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}


	public Date getUpdatedDate() {
		return updatedDate;
	}


	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}


	public String getUpdatedBy() {
		return updatedBy;
	}


	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}


	public String getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}




	public int getCustId() {
		return custId;
	}


	public void setCustId(int custId) {
		this.custId = custId;
	}


/*	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
*/

	public int getPlantId() {
		return plantId;
	}


	public void setPlantId(int plantId) {
		this.plantId = plantId;
	}


	public String getPlantName() {
		return plantName;
	}


	public void setPlantName(String plantName) {
		this.plantName = plantName;
	}


	public String getPlantLocation() {
		return plantLocation;
	}




	public void setPlantLocation(String plantLocation) {
		this.plantLocation = plantLocation;
	}








	public String getContact() {
		return contact;
	}




	public void setContact(String contact) {
		this.contact = contact;
	}




	



	public String getMaintaenanceInternal() {
		return maintaenanceInternal;
	}




	public void setMaintaenanceInternal(String maintaenanceInternal) {
		this.maintaenanceInternal = maintaenanceInternal;
	}




	public String getCountry() {
		return country;
	}




	public void setCountry(String country) {
		this.country = country;
	}







	



	public String getActiveInavctive() {
		return activeInavctive;
	}




	public void setActiveInavctive(String activeInavctive) {
		this.activeInavctive = activeInavctive;
	}




	public String getValveLocation() {
		return valveLocation;
	}


	public void setValveLocation(String valveLocation) {
		this.valveLocation = valveLocation;
	}


	public PlantDataMaster() {
		super();
	}


	


	
	public PlantDataMaster(int custId, int plantId, String plantName, String plantLocation,
			String plantArea, String plantAccount, String planUniversal, String contact, String maintaenanceInternal,
			String country, String region, String activeInavctive, String dunsNumber, Date createdDate,
			Date updatedDate, String updatedBy, String createdBy) {
		super();
		this.custId = custId;
		/*this.customerName = customerName;*/
		this.plantId = plantId;
		this.plantName = plantName;
		this.plantLocation = plantLocation;
		this.contact = contact;
		this.maintaenanceInternal = maintaenanceInternal;
		this.country = country;
		this.activeInavctive = activeInavctive;
		this.dunsNumber = dunsNumber;
		this.createdDate = createdDate;
		this.updatedDate = updatedDate;
		this.updatedBy = updatedBy;
		this.createdBy = createdBy;
	}


	@Override
	public String toString() {
		return "PlantDataMaster [custId=" + custId + ", plantId=" + plantId + ", plantName=" + plantName
				+ ", plantLocation=" + plantLocation + ", contact=" + contact + ", maintaenanceInternal="
				+ maintaenanceInternal + ", country=" + country + ", activeInavctive=" + activeInavctive
				+ ", dunsNumber=" + dunsNumber + ", createdDate=" + createdDate + ", updatedDate=" + updatedDate
				+ ", updatedBy=" + updatedBy + ", createdBy=" + createdBy + ", valveLocation=" + valveLocation + "]";
	}









	

	


	
}
