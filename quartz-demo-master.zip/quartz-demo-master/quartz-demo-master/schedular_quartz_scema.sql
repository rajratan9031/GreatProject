/*
SQLyog Ultimate v8.8 
MySQL - 5.7.9-log : Database - quartz_db
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`quartz_db` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `quartz_db`;

/*Table structure for table `schedule_group_instance_detail` */

DROP TABLE IF EXISTS `schedule_group_instance_detail`;

CREATE TABLE `schedule_group_instance_detail` (
  `instance_id` int(11) NOT NULL AUTO_INCREMENT,
  `instance_name` varchar(128) NOT NULL,
  `job_id` int(11) DEFAULT NULL,
  `status` smallint(6) DEFAULT '1',
  `recurrence_type` varchar(1) DEFAULT 'N',
  `time_zone_id` varchar(64) DEFAULT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `previous_fire_datetime` datetime DEFAULT NULL,
  `next_fire_datetime` datetime DEFAULT NULL,
  `frequency` smallint(6) DEFAULT '1',
  `recurrence_interval` int(11) DEFAULT NULL,
  `repeat_count` smallint(6) DEFAULT NULL,
  `week_days` smallint(6) DEFAULT NULL,
  `months` smallint(6) DEFAULT NULL,
  `month_days` bigint(20) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  PRIMARY KEY (`instance_id`),
  UNIQUE KEY `un_schedule_grp_instance_name` (`instance_name`),
  KEY `fk_sgid_group_id` (`job_id`),
  CONSTRAINT `fk_sgid_job_id` FOREIGN KEY (`job_id`) REFERENCES `schedule_job` (`job_id`)
) ENGINE=InnoDB AUTO_INCREMENT=733 DEFAULT CHARSET=utf8;

/*Data for the table `schedule_group_instance_detail` */

insert  into `schedule_group_instance_detail`(`instance_id`,`instance_name`,`job_id`,`status`,`recurrence_type`,`time_zone_id`,`start_time`,`end_time`,`start_date`,`end_date`,`previous_fire_datetime`,`next_fire_datetime`,`frequency`,`recurrence_interval`,`repeat_count`,`week_days`,`months`,`month_days`,`created_by`,`created_date`,`modified_by`,`modified_date`) values (732,'First_job_instance',108,2,'N',NULL,'2019-03-22 13:17:25','2019-03-23 13:17:25','2019-03-22',NULL,NULL,NULL,1,60,NULL,NULL,NULL,NULL,1,'2019-03-22 13:17:25',NULL,NULL);

/*Table structure for table `schedule_job` */

DROP TABLE IF EXISTS `schedule_job`;

CREATE TABLE `schedule_job` (
  `job_id` int(11) NOT NULL AUTO_INCREMENT,
  `job_code` varchar(64) NOT NULL,
  `job_desc` varchar(64) NOT NULL,
  `job_execution_class` varchar(64) NOT NULL,
  `status` smallint(6) DEFAULT '1',
  `allow_concurrent_execution` smallint(6) DEFAULT '1',
  `created_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  PRIMARY KEY (`job_id`),
  UNIQUE KEY `un_schedule_job_code` (`job_code`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8;

/*Data for the table `schedule_job` */

insert  into `schedule_job`(`job_id`,`job_code`,`job_desc`,`job_execution_class`,`status`,`allow_concurrent_execution`,`created_by`,`created_date`,`modified_by`,`modified_date`) values (108,'FIRST_JOB','First_job','com.ashish.quartz.demo.jobs.SimpleJob',1,1,1,'2019-03-22 13:17:25',NULL,NULL);

/*Table structure for table `schedule_job_group` */

DROP TABLE IF EXISTS `schedule_job_group`;

CREATE TABLE `schedule_job_group` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_code` varchar(64) NOT NULL,
  `group_desc` varchar(64) NOT NULL,
  `job_type_id` int(11) DEFAULT NULL,
  `status` smallint(6) DEFAULT '1',
  `is_group_job` smallint(6) NOT NULL DEFAULT '0',
  `user_schedulable` smallint(6) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `un_schedule_job_group_code` (`group_code`),
  KEY `fk_sjg_job_type_id` (`job_type_id`),
  CONSTRAINT `fk_sjg_job_type_id` FOREIGN KEY (`job_type_id`) REFERENCES `schedule_job_type` (`job_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8;

/*Data for the table `schedule_job_group` */

insert  into `schedule_job_group`(`group_id`,`group_code`,`group_desc`,`job_type_id`,`status`,`is_group_job`,`user_schedulable`,`created_by`,`created_date`,`modified_by`,`modified_date`) values (110,'FIRST_JOB','First_job',3,1,0,1,1,'2019-03-22 13:17:25',NULL,NULL);

/*Table structure for table `schedule_job_group_mapping` */

DROP TABLE IF EXISTS `schedule_job_group_mapping`;

CREATE TABLE `schedule_job_group_mapping` (
  `group_job_mapping_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `job_order` smallint(6) DEFAULT '0',
  `created_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  PRIMARY KEY (`group_job_mapping_id`),
  UNIQUE KEY `un_sjgd_group_job_joborder` (`group_id`,`job_id`,`job_order`),
  KEY `fk_sjgd_job_id` (`job_id`),
  CONSTRAINT `fk_sjgd_group_id` FOREIGN KEY (`group_id`) REFERENCES `schedule_job_group` (`group_id`),
  CONSTRAINT `fk_sjgd_job_id` FOREIGN KEY (`job_id`) REFERENCES `schedule_job` (`job_id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8;

/*Data for the table `schedule_job_group_mapping` */

insert  into `schedule_job_group_mapping`(`group_job_mapping_id`,`group_id`,`job_id`,`job_order`,`created_by`,`created_date`,`modified_by`,`modified_date`) values (107,110,108,0,1,'2019-03-22 13:17:25',NULL,NULL);

/*Table structure for table `schedule_job_trigger` */

DROP TABLE IF EXISTS `schedule_job_trigger`;

CREATE TABLE `schedule_job_trigger` (
  `trigger_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `instance_id` int(11) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `trigger_fire_datetime` datetime NOT NULL,
  `start_fire_datetime` datetime DEFAULT NULL,
  `end_fire_datetime` datetime DEFAULT NULL,
  `run_duration` int(11) DEFAULT NULL,
  `status` smallint(6) DEFAULT '1',
  `current_trigger_count` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  PRIMARY KEY (`trigger_id`),
  KEY `fk_sgt_instance_id` (`instance_id`),
  KEY `fk_sgt_job_id` (`job_id`),
  KEY `Index_scheduler_group_trigger_status` (`status`),
  CONSTRAINT `fk_sgt_instance_id` FOREIGN KEY (`instance_id`) REFERENCES `schedule_group_instance_detail` (`instance_id`),
  CONSTRAINT `fk_sgt_job_id` FOREIGN KEY (`job_id`) REFERENCES `schedule_job` (`job_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2065287 DEFAULT CHARSET=utf8;

/*Data for the table `schedule_job_trigger` */

insert  into `schedule_job_trigger`(`trigger_id`,`instance_id`,`job_id`,`trigger_fire_datetime`,`start_fire_datetime`,`end_fire_datetime`,`run_duration`,`status`,`current_trigger_count`,`created_by`,`created_date`,`modified_by`,`modified_date`) values (2065251,732,108,'0000-00-00 00:00:00','2019-03-22 13:17:25','2019-03-22 13:17:25',10,6,NULL,1,'2019-03-22 13:17:25',NULL,NULL),(2065252,732,108,'2019-03-22 17:23:16',NULL,NULL,NULL,6,NULL,1,'2019-03-22 17:23:16',NULL,NULL),(2065253,732,108,'2019-03-22 17:23:17',NULL,NULL,NULL,6,NULL,1,'2019-03-22 17:23:17',NULL,NULL),(2065254,732,108,'2019-03-22 17:23:18',NULL,NULL,NULL,6,NULL,1,'2019-03-22 17:23:18',NULL,NULL),(2065255,732,108,'2019-03-22 17:23:19',NULL,NULL,NULL,6,NULL,1,'2019-03-22 17:23:19',NULL,NULL),(2065256,732,108,'2019-03-22 17:23:20',NULL,NULL,NULL,6,NULL,1,'2019-03-22 17:23:20',NULL,NULL),(2065257,732,108,'2019-03-22 17:23:21',NULL,NULL,NULL,6,NULL,1,'2019-03-22 17:23:21',NULL,NULL),(2065258,732,108,'2019-03-22 17:23:22',NULL,NULL,NULL,6,NULL,1,'2019-03-22 17:23:22',NULL,NULL),(2065259,732,108,'2019-03-22 17:23:23',NULL,NULL,NULL,6,NULL,1,'2019-03-22 17:23:23',NULL,NULL),(2065260,732,108,'2019-03-22 17:23:24',NULL,NULL,NULL,6,NULL,1,'2019-03-22 17:23:24',NULL,NULL),(2065261,732,108,'2019-03-22 17:23:25',NULL,NULL,NULL,6,NULL,1,'2019-03-22 17:23:25',NULL,NULL),(2065262,732,108,'2019-03-22 17:24:26',NULL,NULL,NULL,6,NULL,1,'2019-03-22 17:24:26',NULL,NULL),(2065263,732,108,'2019-03-22 17:24:27',NULL,NULL,NULL,6,NULL,1,'2019-03-22 17:24:27',NULL,NULL),(2065264,732,108,'2019-03-22 17:24:28',NULL,NULL,NULL,6,NULL,1,'2019-03-22 17:24:28',NULL,NULL),(2065265,732,108,'2019-03-22 17:24:29',NULL,NULL,NULL,6,NULL,1,'2019-03-22 17:24:29',NULL,NULL),(2065266,732,108,'2019-03-22 17:24:30',NULL,NULL,NULL,6,NULL,1,'2019-03-22 17:24:30',NULL,NULL),(2065267,732,108,'2019-03-22 17:29:30',NULL,'2019-03-22 17:29:35',5140,3,NULL,1,'2019-03-22 17:29:30',1,'2019-03-22 17:29:35'),(2065268,732,108,'2019-03-22 17:30:30',NULL,NULL,NULL,6,NULL,1,'2019-03-22 17:30:30',NULL,NULL),(2065269,732,108,'2019-03-22 17:30:33',NULL,'2019-03-22 17:30:38',5,3,NULL,1,'2019-03-22 17:30:33',1,'2019-03-22 17:30:38'),(2065270,732,108,'2019-03-22 17:31:33',NULL,'2019-03-22 17:31:38',5,3,NULL,1,'2019-03-22 17:31:33',1,'2019-03-22 17:31:38'),(2065271,732,108,'2019-03-22 17:32:33',NULL,'2019-03-22 17:32:38',5,3,NULL,1,'2019-03-22 17:32:33',1,'2019-03-22 17:32:38'),(2065272,732,108,'2019-03-22 17:33:33',NULL,'2019-03-22 17:33:38',5,3,NULL,1,'2019-03-22 17:33:33',1,'2019-03-22 17:33:38'),(2065273,732,108,'2019-03-22 17:34:33',NULL,'2019-03-22 17:34:38',5,3,NULL,1,'2019-03-22 17:34:33',1,'2019-03-22 17:34:38'),(2065274,732,108,'2019-03-22 17:35:33',NULL,'2019-03-22 17:35:38',5,3,NULL,1,'2019-03-22 17:35:33',1,'2019-03-22 17:35:38'),(2065275,732,108,'2019-03-22 17:36:33',NULL,'2019-03-22 17:36:38',5,3,NULL,1,'2019-03-22 17:36:33',1,'2019-03-22 17:36:38'),(2065276,732,108,'2019-03-22 18:27:53',NULL,'2019-03-22 18:28:03',10,3,NULL,1,'2019-03-22 18:27:53',1,'2019-03-22 18:28:03'),(2065277,732,108,'2019-03-22 18:28:53',NULL,'2019-03-22 18:29:03',10,3,NULL,1,'2019-03-22 18:28:53',1,'2019-03-22 18:29:03'),(2065278,732,108,'2019-03-22 18:31:49',NULL,'2019-03-22 18:31:59',10,3,NULL,1,'2019-03-22 18:31:49',1,'2019-03-22 18:31:59'),(2065279,732,108,'2019-03-22 18:32:49',NULL,'2019-03-22 18:32:59',10,3,NULL,1,'2019-03-22 18:32:49',1,'2019-03-22 18:32:59'),(2065280,732,108,'2019-03-22 18:33:23',NULL,'2019-03-22 18:33:33',10,3,NULL,1,'2019-03-22 18:33:23',1,'2019-03-22 18:33:33'),(2065281,732,108,'2019-03-22 18:33:38',NULL,NULL,NULL,6,NULL,1,'2019-03-22 18:33:38',NULL,NULL),(2065282,732,108,'2019-03-22 18:34:03',NULL,'2019-03-22 18:34:13',10,3,NULL,1,'2019-03-22 18:34:03',1,'2019-03-22 18:34:13'),(2065283,732,108,'2019-03-22 18:36:01',NULL,'2019-03-22 18:36:11',10,3,NULL,1,'2019-03-22 18:36:01',1,'2019-03-22 18:36:11'),(2065284,732,108,'2019-03-22 18:48:45',NULL,'2019-03-22 18:48:55',10,3,NULL,1,'2019-03-22 18:48:45',1,'2019-03-22 18:48:55'),(2065285,732,108,'2019-03-22 18:50:53',NULL,'2019-03-22 18:51:04',10,3,NULL,1,'2019-03-22 18:50:53',1,'2019-03-22 18:51:04'),(2065286,732,108,'2019-03-22 18:54:34',NULL,'2019-03-22 18:54:44',10,3,NULL,1,'2019-03-22 18:54:34',1,'2019-03-22 18:54:44');

/*Table structure for table `schedule_job_type` */

DROP TABLE IF EXISTS `schedule_job_type`;

CREATE TABLE `schedule_job_type` (
  `job_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `job_type_code` varchar(64) NOT NULL,
  `job_type_desc` varchar(64) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  PRIMARY KEY (`job_type_id`),
  UNIQUE KEY `un_schedule_job_type_code` (`job_type_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Data for the table `schedule_job_type` */

insert  into `schedule_job_type`(`job_type_id`,`job_type_code`,`job_type_desc`,`created_by`,`created_date`,`modified_by`,`modified_date`) values (3,'TYPE-1','type-1',1,'2019-03-22 13:17:25',NULL,NULL);

/*Table structure for table `scheduler_trigger_status` */

DROP TABLE IF EXISTS `scheduler_trigger_status`;

CREATE TABLE `scheduler_trigger_status` (
  `id` int(11) NOT NULL,
  `code` varchar(16) NOT NULL,
  `description` varchar(64) NOT NULL,
  `status` int(4) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `scheduler_trigger_status_code_unique` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `scheduler_trigger_status` */

insert  into `scheduler_trigger_status`(`id`,`code`,`description`,`status`,`created_by`,`created_date`,`modified_by`,`modified_date`) values (1,'NEW','New',1,1,'2015-10-07 16:55:27',NULL,NULL),(2,'RUNNING','Running',2,1,'2015-10-07 16:55:27',NULL,NULL),(3,'SUCCESS','Success',3,1,'2015-10-07 16:55:27',NULL,NULL),(4,'FAILURE','Failure',4,1,'2015-10-07 16:55:27',NULL,NULL),(5,'STOPPED','Stopped',5,1,'2015-10-07 16:55:27',NULL,NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
