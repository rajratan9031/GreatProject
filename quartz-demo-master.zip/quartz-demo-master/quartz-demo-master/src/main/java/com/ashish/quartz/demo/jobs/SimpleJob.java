package com.ashish.quartz.demo.jobs;

import java.util.Date;
import java.util.stream.IntStream;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.ashish.quartz.demo.BeanProvider;
import com.ashish.quartz.demo.QuartzDemoApplication;
import com.ashish.quartz.demo.service.impl.SchedulerServiceImpl;

import lombok.extern.slf4j.Slf4j;


@Slf4j
public class SimpleJob extends QuartzJobBean {
    @Override
    protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
    	Long triggerId = 0l;
    	short status = 2;
        SchedulerServiceImpl service=null;
        Long startTime = new Date().getTime();
        try {
        	//System.out.println(context.getJobDetail().getKey().toString());
	        QuartzDemoApplication.logger.info("SimpleJob Start................"+context.getJobDetail().getKey().toString());
	        service = BeanProvider.getBean(SchedulerServiceImpl.class);
	        boolean isActive = service.getInstanceStatusByInstanceId(context.getMergedJobDataMap().getInt("instanceId"));
	        if(isActive) {
	        	try {
			        triggerId = service.createTriggerEntryForInstance(context.getMergedJobDataMap());
			        IntStream.range(0, 10).forEach(i -> {
			            QuartzDemoApplication.logger.info("Counting - {}", i);
			            try {
			                Thread.sleep(1000);
			            } catch (InterruptedException e) {
			                QuartzDemoApplication.logger.error(e.getMessage(), e);
			            }
			        });
			        QuartzDemoApplication.logger.info("SimpleJob End................");
			        status = 3;
	        	}catch(Exception e) {
	        		 QuartzDemoApplication.logger.error("error while running trigger",e);
	            	status = 4;
	            }
	            service.updateTriggerEntryForInstance(triggerId,status,new Date().getTime()-startTime);
	        }else {
	        		service.deleteJob(context.getMergedJobDataMap().getString("jobCode"),context.getMergedJobDataMap().getInt("groupId"),context.getMergedJobDataMap().getInt("instanceId"));
	        		//service.deleteJob(context.getJobDetail().getKey());
	        }
        }catch(Exception e) {
        	QuartzDemoApplication.logger.error("error while running trigger",e);
        }
    }
}
