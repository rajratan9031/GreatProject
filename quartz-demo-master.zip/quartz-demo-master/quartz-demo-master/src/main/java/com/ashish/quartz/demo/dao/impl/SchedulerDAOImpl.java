package com.ashish.quartz.demo.dao.impl;

import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.BooleanType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.LongType;
import org.hibernate.type.StandardBasicTypes;
import org.hibernate.type.StringType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import com.ashish.quartz.demo.dao.SchedulerDAO;
import com.ashish.quartz.demo.to.PendingScheduleTriggerExt;
import com.ashish.quartz.demo.to.SchedulerInfoTO;
import com.ashish.quartz.enitiy.ScheduleGroupInstanceDetail;
import com.ashish.quartz.enitiy.ScheduleJob;
import com.ashish.quartz.enitiy.ScheduleJobTrigger;

@Repository
@PropertySource("classpath:queries.properties")
public class SchedulerDAOImpl implements SchedulerDAO{
	
	@Autowired
	Environment env;
	
	
	@Override
	public void getAllSchedulers() {
		
	}

	@Override
	public void getAllActiveSchedulers() {
		
	}

	@Override
	public void getSchedulerByName() {
		
	}

	

	@Override
	public void saveOrUpdateScheduleJobInstance(ScheduleGroupInstanceDetail detail) {
		
	}

	@Override
	public void saveOrUpdateScheduleGroupTriggerDetails(ScheduleJobTrigger trigger) {
		
	}


	@Override
	public List<PendingScheduleTriggerExt> getAllPendingJobs(Session session) {
		List<PendingScheduleTriggerExt> list = null;
		String queryStr = env.getProperty("SELECT_ALL_PENDING_JOBS");
		Query query = session.createNativeQuery(queryStr)
						.addScalar("instanceId",IntegerType.INSTANCE)
						.addScalar("repateAfter",LongType.INSTANCE)
						.addScalar("jobId",IntegerType.INSTANCE)
						.addScalar("jobCode",StringType.INSTANCE)
						.addScalar("executionClassName",StringType.INSTANCE)
						.addScalar("groupId",IntegerType.INSTANCE)
						.addScalar("allowConcurrentExec",BooleanType.INSTANCE)
						.addScalar("createdBy",IntegerType.INSTANCE)
						.addScalar("endDate",StandardBasicTypes.DATE)
						.setResultTransformer(Transformers.aliasToBean(PendingScheduleTriggerExt.class))
						;
		
		
		/*
		 * List<PendingScheduleTriggerExt> personAndAddressDTOs = session
		 * .createQuery(queryStr) .unwrap( org.hibernate.query.Query.class )
		 * .setResultTransformer( new ResultTransformer() {
		 * 
		 * @Override public Object transformTuple( Object[] tuple, String[] aliases) {
		 * return new PersonAndCountryDTO( (Person) tuple[0], (String) tuple[1] ); }
		 * 
		 * @Override public List transformList(List collection) { return collection; } }
		 * ) .getResultList();
		 */
		
		list = query.list();
		return list;
	}

	@Override
	public void markAllUnfinshedInstatncesTrigger(Session session) {
		Query query = session.createQuery("Update ScheduleJobTrigger set status=6 where status = 2");
		query.executeUpdate();
	}

	@Override
	public void createTriggerEntryForInstance(Integer instanceId, Integer jobId, Date triggerFireDateTime,
			Integer createdBy, Date createdDate,int status, Session session) {
		Query query = session.createQuery(env.getProperty("INSERT_JOB_TRIGGER"));
		//:instanceId,:jobId,:triggerFireDateTime,:status,:createdBy,:createdDate) ;
		query.setParameter("instanceId", instanceId)
				.setParameter("jobId", jobId)
				.setParameter("triggerFireDateTime", triggerFireDateTime)
				.setParameter("status", status)
				.setParameter("createdBy", createdBy)
				.setParameter("createdDate", createdDate);
		query.executeUpdate();
	}

	@Override
	public ScheduleGroupInstanceDetail getSchedulegroupInstanceDetailsByInstanceID(int instanceId,Session session) {
		ScheduleGroupInstanceDetail sgt = null;	
		sgt = session.find(ScheduleGroupInstanceDetail.class, instanceId);
		return sgt;
		
	}
	
	@Override
	public ScheduleJob getScheduleJobByJobID(Integer jobId,Session session) {
		ScheduleJob sj = null;
		sj = session.find(ScheduleJob.class, jobId);
		return sj;
		
	}

	@Override
	public Long saveOrUpdateScheduleGroupInstanceDetails(ScheduleJobTrigger sjt, Session session) {
		session.saveOrUpdate(sjt);
		return sjt.getTriggerId();
	}

	@Override
	public ScheduleJobTrigger getScheduleJobTriggerByTriggerId(Long triggerId, Session session) {
		ScheduleJobTrigger sjt = null;
		sjt = session.find(ScheduleJobTrigger.class, triggerId);
		return sjt;
	}

	@Override
	public boolean getInstanceStatusByInstanceId(int instanceId, Session session) {
		boolean isActive = false;
		/*
		 * String queryStr = env.getProperty("GET_ACTIVE_STATUS_BY_INSTANCE_ID"); Query
		 * query = session.createNativeQuery(queryStr)
		 * .addScalar("instanceId",IntegerType.INSTANCE)
		 * .addScalar("repateAfter",LongType.INSTANCE)
		 * .addScalar("jobId",IntegerType.INSTANCE)
		 * .addScalar("jobCode",StringType.INSTANCE)
		 * .addScalar("executionClassName",StringType.INSTANCE)
		 * .addScalar("groupId",IntegerType.INSTANCE)
		 * .addScalar("allowConcurrentExec",BooleanType.INSTANCE)
		 * .addScalar("createdBy",IntegerType.INSTANCE)
		 * .addScalar("endDate",StandardBasicTypes.DATE)
		 * .setResultTransformer(Transformers.aliasToBean(PendingScheduleTriggerExt.
		 * class)) ;
		 */
		ScheduleGroupInstanceDetail obj = session.get(ScheduleGroupInstanceDetail.class, instanceId);
		if(obj != null) {
			if(obj.getStatus() == (short)1 && obj.getEndTime().getTime()>=new Date().getTime()) {
				isActive = true;
			}else {
				if(obj.getStatus() == 1) {
					obj.setStatus((short)2);
					session.saveOrUpdate(obj);
				}
				isActive = false;
			}
		}
		return isActive;
	}

	@Override
	public List<SchedulerInfoTO> getAllScheduerInfo(Session session) {
		List<SchedulerInfoTO> list = null;
		String queryStr = env.getProperty("GET_ALL_SCHEDULER_INFO");
		Query query = session.createNativeQuery(queryStr)
						.addScalar("instanceID",IntegerType.INSTANCE)
						.addScalar("status",StringType.INSTANCE)
						/*.addScalar("isRunning",BooleanType.INSTANCE)*/
						.addScalar("repateAfterEverySec",IntegerType.INSTANCE)
						.addScalar("jobCode",StringType.INSTANCE)
						.addScalar("jobDesc",StringType.INSTANCE)
						.addScalar("groupCode",StringType.INSTANCE)
						.addScalar("createdBy",StringType.INSTANCE)
						.addScalar("createdDate",StandardBasicTypes.DATE)
						.setResultTransformer(Transformers.aliasToBean(SchedulerInfoTO.class))
						;
		
		list = query.list();
		return list;
	}


}
