package com.ashish.quartz.demo.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleTrigger;
import org.quartz.Trigger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ashish.quartz.demo.QuartzDemoApplication;
import com.ashish.quartz.demo.common.ResponseCodes;
import com.ashish.quartz.demo.component.JobScheduleCreator;
import com.ashish.quartz.demo.dao.SchedulerDAO;
import com.ashish.quartz.demo.service.SchedulerService;
import com.ashish.quartz.demo.to.PendingScheduleTriggerExt;
import com.ashish.quartz.demo.to.RestRequestStatusTO;
import com.ashish.quartz.demo.to.RestResponseTO;
import com.ashish.quartz.demo.to.SchedulerInfoTO;
import com.ashish.quartz.enitiy.ScheduleJobTrigger;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Transactional
@Service
@PropertySource("classpath:restMessages.properties")
public class SchedulerServiceImpl implements SchedulerService {

    @Autowired
    private SchedulerFactoryBean schedulerFactoryBean;

    @Autowired
    Environment env;
    
    
    @Autowired
    private SessionFactory sessionFactory;
    
    @Autowired
    private SchedulerDAO schedulerDAO;

    @Autowired
    private ApplicationContext context;

    @Autowired
    private JobScheduleCreator scheduleCreator;

    @Override
	public void startAllSchedulers() {
		/*
		 * List<SchedulerJobInfo> jobInfoList = schedulerRepository.findAll(); if
		 * (jobInfoList != null) { Scheduler scheduler =
		 * schedulerFactoryBean.getScheduler(); jobInfoList.forEach(jobInfo -> { try {
		 * JobDetail jobDetail = JobBuilder.newJob((Class<? extends QuartzJobBean>)
		 * Class.forName(jobInfo.getJobClass())) .withIdentity(jobInfo.getJobName(),
		 * jobInfo.getJobGroup()).build(); if
		 * (!scheduler.checkExists(jobDetail.getKey())) { Trigger trigger; jobDetail =
		 * scheduleCreator.createJob((Class<? extends QuartzJobBean>)
		 * Class.forName(jobInfo.getJobClass()), false, context, jobInfo.getJobName(),
		 * jobInfo.getJobGroup());
		 * 
		 * if (jobInfo.getCronJob() &&
		 * CronExpression.isValidExpression(jobInfo.getCronExpression())) { trigger =
		 * scheduleCreator.createCronTrigger(jobInfo.getJobName(), new Date(),
		 * jobInfo.getCronExpression(), SimpleTrigger.MISFIRE_INSTRUCTION_FIRE_NOW); }
		 * else { trigger = scheduleCreator.createSimpleTrigger(jobInfo.getJobName(),
		 * new Date(), jobInfo.getRepeatTime(),
		 * SimpleTrigger.MISFIRE_INSTRUCTION_FIRE_NOW); }
		 * 
		 * scheduler.scheduleJob(jobDetail, trigger);
		 * 
		 * } } catch (ClassNotFoundException e) {
		 * QuartzDemoApplication.logger.error("Class Not Found - {}",
		 * jobInfo.getJobClass(), e); } catch (SchedulerException e) {
		 * QuartzDemoApplication.logger.error(e.getMessage(), e); } }); }
		 */}

    @Override
	public void scheduleNewJob(PendingScheduleTriggerExt jobInfo) {
		/*
		 * try { Scheduler scheduler = schedulerFactoryBean.getScheduler();
		 * 
		 * JobDetail jobDetail = JobBuilder.newJob((Class<? extends QuartzJobBean>)
		 * Class.forName(jobInfo.getJobClass())) .withIdentity(jobInfo.getJobName(),
		 * jobInfo.getJobGroup()).build(); if
		 * (!scheduler.checkExists(jobDetail.getKey())) {
		 * 
		 * jobDetail = scheduleCreator.createJob((Class<? extends QuartzJobBean>)
		 * Class.forName(jobInfo.getJobClass()), false, context, jobInfo.getJobName(),
		 * jobInfo.getJobGroup());
		 * 
		 * Trigger trigger; if (jobInfo.getCronJob()) { trigger =
		 * scheduleCreator.createCronTrigger(jobInfo.getJobName(), new Date(),
		 * jobInfo.getCronExpression(), SimpleTrigger.MISFIRE_INSTRUCTION_FIRE_NOW); }
		 * else { trigger = scheduleCreator.createSimpleTrigger(jobInfo.getJobName(),
		 * new Date(), jobInfo.getRepeatTime(),
		 * SimpleTrigger.MISFIRE_INSTRUCTION_FIRE_NOW); }
		 * 
		 * scheduler.scheduleJob(jobDetail, trigger); schedulerRepository.save(jobInfo);
		 * } else {
		 * QuartzDemoApplication.logger.error("scheduleNewJobRequest.jobAlreadyExist");
		 * } } catch (ClassNotFoundException e) {
		 * QuartzDemoApplication.logger.error("Class Not Found - {}",
		 * jobInfo.getJobClass(), e); } catch (SchedulerException e) {
		 * QuartzDemoApplication.logger.error(e.getMessage(), e); }
		 */}

    @Override
	public void updateScheduleJob(Object jobInfo) {
		/*
		 * Trigger newTrigger; if (jobInfo.getCronJob()) { newTrigger =
		 * scheduleCreator.createCronTrigger(jobInfo.getJobName(), new Date(),
		 * jobInfo.getCronExpression(), SimpleTrigger.MISFIRE_INSTRUCTION_FIRE_NOW); }
		 * else { newTrigger = scheduleCreator.createSimpleTrigger(jobInfo.getJobName(),
		 * new Date(), jobInfo.getRepeatTime(),
		 * SimpleTrigger.MISFIRE_INSTRUCTION_FIRE_NOW); } try {
		 * schedulerFactoryBean.getScheduler().rescheduleJob(TriggerKey.triggerKey(
		 * jobInfo.getJobName()), newTrigger); schedulerRepository.save(jobInfo); }
		 * catch (SchedulerException e) {
		 * QuartzDemoApplication.logger.error(e.getMessage(), e); }
		 */}


    @Override
	public boolean unScheduleJob(String jobName) {
		/*
		 * try {
		 * System.out.println("scheduler trigers : "+schedulerFactoryBean.getScheduler()
		 * .getTriggersOfJob(new JobKey(jobName))); return
		 * schedulerFactoryBean.getScheduler().unscheduleJob(new TriggerKey(jobName)); }
		 * catch (SchedulerException e) {
		 * QuartzDemoApplication.logger.error("Failed to un-schedule job - {}", jobName,
		 * e); */return false; 
		 }

    @Override
	public boolean pauseJob(Object jobInfo) {
		/*
		 * try { schedulerFactoryBean.getScheduler().pauseJob(new
		 * JobKey(jobInfo.getJobName(), jobInfo.getJobGroup())); return true; } catch
		 * (SchedulerException e) {
		 * QuartzDemoApplication.logger.error("Failed to pause job - {}",
		 * jobInfo.getJobName(), e); return false; }
		 */
    	return false;
    }

    @Override
	public boolean resumeJob(Object jobInfo) {
		/*
		 * try { schedulerFactoryBean.getScheduler().resumeJob(new
		 * JobKey(jobInfo.getJobName(), jobInfo.getJobGroup())); return true; } catch
		 * (SchedulerException e) {
		 * QuartzDemoApplication.logger.error("Failed to resume job - {}",
		 * jobInfo.getJobName(), e); return false; }
		 */
    	return false;
    }

    @Override
	public boolean startJobNow(Object jobInfo) {
		/*
		 * try { schedulerFactoryBean.getScheduler().triggerJob(new
		 * JobKey(jobInfo.getJobName(), jobInfo.getJobGroup())); return true; } catch
		 * (SchedulerException e) {
		 * QuartzDemoApplication.logger.error("Failed to start new job - {}",
		 * jobInfo.getJobName(), e); return false; }
		 */
    	return false;
    }

	@Override
	public void startAllPendingJobs() {
		try {
			Session session = sessionFactory.getCurrentSession();
			List<PendingScheduleTriggerExt> pendingJobs = schedulerDAO.getAllPendingJobs(session);
			//change status of unfinished jobs whose status is 2(running) to 6 unfinished
			schedulerDAO.markAllUnfinshedInstatncesTrigger(session);
			if(pendingJobs != null && pendingJobs.size() > 0) {
				Scheduler scheduler = schedulerFactoryBean.getScheduler();
				pendingJobs.forEach(jobToSchedule -> {
	                try {
	                	scheduler.deleteJob(new JobKey(getJobKey(jobToSchedule)));
	                    JobDetail jobDetail = JobBuilder.newJob((Class<? extends QuartzJobBean>) Class.forName(jobToSchedule.getExecutionClassName()))
	                            .withIdentity(getJobKey(jobToSchedule), String.valueOf(jobToSchedule.getGroupId()) )
	                            .build();
	                    if (!scheduler.checkExists(jobDetail.getKey())) {
	                        Trigger trigger;
	                        jobDetail = scheduleCreator.createJob((Class<? extends QuartzJobBean>) Class.forName(jobToSchedule.getExecutionClassName()),
	                                false, context, getJobName(jobToSchedule), String.valueOf(jobToSchedule.getGroupId()));
	                        jobDetail.getJobDataMap().putAll(generateJobDataMap(jobToSchedule));
	                        /*if (jobToSchedule.getCronJob() && CronExpression.isValidExpression(jobInfo.getCronExpression())) {
	                            trigger = scheduleCreator.createCronTrigger(jobInfo.getJobName(), new Date(),
	                                    jobInfo.getCronExpression(), SimpleTrigger.MISFIRE_INSTRUCTION_FIRE_NOW);
	                        } else {*/
	                            trigger = scheduleCreator.createSimpleTrigger(getJobName(jobToSchedule), new Date(),
	                                    jobToSchedule.getRepateAfter()*1000, SimpleTrigger.MISFIRE_INSTRUCTION_FIRE_NOW);
	                       // }
	                            System.out.println("##$$$ entry set = ");jobDetail.getJobDataMap().forEach( (key, value) ->{
	    							System.out.println(key +" = "+value);
	    					});
	                           // trigger.getJobDataMap().putAll(jobDetail.getJobDataMap());
	                        scheduler.scheduleJob(jobDetail, trigger);

	                    }
	                } catch (ClassNotFoundException e) {
	                    QuartzDemoApplication.logger.error("Class Not Found - {}", jobToSchedule.getExecutionClassName(), e);
	                } catch (SchedulerException e) {
	                    QuartzDemoApplication.logger.error(e.getMessage(), e);
	                }
	            });
			}else {
				QuartzDemoApplication.logger.info("no pending schedulers found");
			}
		}catch (Exception e) {
			e.printStackTrace();
			QuartzDemoApplication.logger.error("no pending schedulers found",e);
		}
		
	}

	private Map<String,Object> generateJobDataMap(PendingScheduleTriggerExt jobToSchedule) {
		Map<String,Object> map = new HashMap<>();
		map.put("instanceId", jobToSchedule.getInstanceId());
		map.put("jobId", jobToSchedule.getJobId());
		map.put("groupId", jobToSchedule.getGroupId());
		map.put("jobCode", jobToSchedule.getJobCode());
		map.put("isTrigerRunning", "false");
		map.put("user", jobToSchedule.getCreatedBy().intValue());
		return map;
}
	private String getJobName(PendingScheduleTriggerExt jobToSchedule) {
		return jobToSchedule.getJobCode()+"_"+jobToSchedule.getInstanceId();
	}

	private String getJobKey(PendingScheduleTriggerExt jobToSchedule) {
		return jobToSchedule.getJobCode()+"_"+jobToSchedule.getJobId()+"_"+jobToSchedule.getInstanceId();
	}
	
	public String getJobKey(String jobCode,int jobId,int instanceId) {
		return jobCode+"_"+jobId+"_"+instanceId;
	}
	public String getJobName(String jobCode,int instanceId) {
		return jobCode+"_"+instanceId;
	}
	
	@Override
	public Long createTriggerEntryForInstance(JobDataMap jobDataMap) {
		System.out.println("**** creating trigger "+jobDataMap.size());
		Long triggerId = 0L;
		try{
			Session session = sessionFactory.getCurrentSession();
			jobDataMap.forEach((key,value) -> {
				System.out.println(key+" = "+value);
			});
			int instanceId = jobDataMap.getInt("instanceId");
			Integer jobId = jobDataMap.getInt("jobId");
			Date triggerFireDateTime = new Date();
			Date createdDate = new Date();
			Integer createdBy = jobDataMap.getInt("user");
			ScheduleJobTrigger sjt = new ScheduleJobTrigger();
			sjt.setCreatedBy(createdBy);
			sjt.setCreatedDate(createdDate);
			sjt.setScheduleGroupInstanceDetail(schedulerDAO.getSchedulegroupInstanceDetailsByInstanceID(instanceId,session));
			sjt.setScheduleJob(schedulerDAO.getScheduleJobByJobID(jobId, session));
			sjt.setTriggerFireDatetime(triggerFireDateTime);
			sjt.setStatus((short) 2);
			
			triggerId  = schedulerDAO.saveOrUpdateScheduleGroupInstanceDetails(sjt,session);
			System.out.println("trigger created with trigger id = "+triggerId);
			//schedulerDAO.createTriggerEntryForInstance(instanceId,jobId,triggerFireDateTime,createdBy,createdDate,2,session);
		}catch(Exception e) {
			QuartzDemoApplication.logger.error("error while creating trigger",e);
		}
		return triggerId;
	}

	public void updateTriggerEntryForInstance(Long triggerId, short status, long runDuration) {
		System.out.println("updating trigger "+triggerId);
		ScheduleJobTrigger sjt = null;
		Session session = null;
		try {
			session = sessionFactory.getCurrentSession();
			sjt = schedulerDAO.getScheduleJobTriggerByTriggerId(triggerId,session);
			sjt.setStatus(status);
			sjt.setModifiedBy(sjt.getCreatedBy());
			sjt.setModifiedDate(new Date());
			sjt.setRunDuration(((Long)runDuration).intValue()/1000);
			sjt.setEndFireDatetime(new Date());
			schedulerDAO.saveOrUpdateScheduleGroupInstanceDetails(sjt,session);
		}catch(Exception e) {
			QuartzDemoApplication.logger.error("error while updating trigger ",e);
			sjt.setStatus((short)4);
			schedulerDAO.saveOrUpdateScheduleGroupInstanceDetails(sjt,session);
		}
	}

	public boolean getInstanceStatusByInstanceId(int instanceId) {
		boolean isActive  = false;
		try {
			Session session = sessionFactory.getCurrentSession();
			isActive = schedulerDAO.getInstanceStatusByInstanceId(instanceId,session);
		}catch(Exception e) {
			QuartzDemoApplication.logger.error("error while getting status of instance",e);
			e.printStackTrace();
		}
		return isActive;
	}

	public boolean deleteJob(String jobCode, int groupId, int instanceId) {
		boolean deleted = false;
        try {
        	System.out.println("before Deleting job "+schedulerFactoryBean.getScheduler().getJobDetail(new JobKey(getJobName(jobCode,instanceId), String.valueOf(groupId) )));
            deleted =  schedulerFactoryBean.getScheduler().deleteJob(new JobKey(getJobName(jobCode,instanceId), String.valueOf(groupId) ));
            System.out.println("deleted = "+deleted);
            System.out.println("After Deleting job "+schedulerFactoryBean.getScheduler().getJobDetail(new JobKey(getJobName(jobCode,instanceId), String.valueOf(groupId) )));
            return deleted;
        } catch (SchedulerException e) {
            QuartzDemoApplication.logger.error("Failed to delete job - {}", getJobKey(jobCode,groupId,instanceId), e);
            return deleted;
        }
    }
	

    @Override
    public boolean deleteJob(JobKey jobKey) {
    	boolean deleted = false;
        try {
        	System.out.println("before Deleting job "+schedulerFactoryBean.getScheduler().getJobDetail(jobKey));
            deleted =schedulerFactoryBean.getScheduler().deleteJob(jobKey);
            System.out.println("deleted = "+deleted);
            System.out.println("After Deleting job "+schedulerFactoryBean.getScheduler().getJobDetail(jobKey));
            return deleted;
        } catch (SchedulerException e) {
            QuartzDemoApplication.logger.error("Failed to delete job - {}", jobKey.getName(), e);
            return deleted;
        }
    }

	@Override
	public RestResponseTO getAllSchedulerInfo() {
		RestResponseTO responseTO = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			List<SchedulerInfoTO> schedulerInfo = schedulerDAO.getAllScheduerInfo(session);
			RestRequestStatusTO status = new RestRequestStatusTO(ResponseCodes.SUCCESS_CODE,env.getProperty(String.valueOf(ResponseCodes.SUCCESS_CODE)));
			responseTO = new RestResponseTO(status,null);
			responseTO.setData(schedulerInfo);
		}catch(Exception e) {
			RestRequestStatusTO status = new RestRequestStatusTO(ResponseCodes.EXCEPTION_CODE,env.getProperty(String.valueOf(ResponseCodes.EXCEPTION_CODE)));
			responseTO = new RestResponseTO(status,null);
			e.printStackTrace();
		}
		return responseTO;
	}
}
