package com.ashish.quartz.demo.service;

import org.quartz.JobDataMap;
import org.quartz.JobKey;

import com.ashish.quartz.demo.to.PendingScheduleTriggerExt;
import com.ashish.quartz.demo.to.RestResponseTO;

public interface SchedulerService {
	
    void startAllSchedulers();

    void scheduleNewJob(PendingScheduleTriggerExt jobInfo);

   void updateScheduleJob(Object jobInfo);

    boolean unScheduleJob(String jobName);

    boolean deleteJob(JobKey jobInfo);

    boolean pauseJob(Object jobInfo);

    boolean resumeJob(Object jobInfo);

    boolean startJobNow(Object jobInfo);

	void startAllPendingJobs();

	Long createTriggerEntryForInstance(JobDataMap mergedJobDataMap);

	RestResponseTO getAllSchedulerInfo();


}
