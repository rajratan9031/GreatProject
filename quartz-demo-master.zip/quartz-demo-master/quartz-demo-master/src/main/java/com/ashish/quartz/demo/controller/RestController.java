package com.ashish.quartz.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ashish.quartz.demo.service.SchedulerService;
import com.ashish.quartz.demo.to.RestResponseTO;

@org.springframework.web.bind.annotation.RestController
@RequestMapping("/rest")
public class RestController {
	@Autowired
	SchedulerService service;
	
	@GetMapping(value="/allSchedulerInfo",produces="application/json")
	public @ResponseBody RestResponseTO getAllSchedulerInfo() {
		System.out.println("in rest controller : ");
		return service.getAllSchedulerInfo();
	}
}
