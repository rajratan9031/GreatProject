package com.ashish.quartz.demo.to;

public class RestResponseTO {
	private RestRequestStatusTO restRequestStatus;
	private Object data;
	
	public RestResponseTO() {
		
	}

	public RestResponseTO(RestRequestStatusTO restRequestStatus, Object data) {
		super();
		this.restRequestStatus = restRequestStatus;
		this.data = data;
	}

	public RestRequestStatusTO getRestRequestStatus() {
		return restRequestStatus;
	}

	public void setRestRequestStatus(RestRequestStatusTO restRequestStatus) {
		this.restRequestStatus = restRequestStatus;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}
	
	
}
