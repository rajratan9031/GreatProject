package com.ashish.quartz.demo.component;

import com.ashish.quartz.demo.QuartzDemoApplication;
import com.ashish.quartz.demo.service.SchedulerService;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;


@Slf4j
@Component
public class SchedulerStartUpHandler implements ApplicationRunner {

    @Autowired
    private SchedulerService schedulerService;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        QuartzDemoApplication.logger.info("Schedule all new scheduler jobs at app startup - starting");
        try {
           // schedulerService.startAllSchedulers();
            schedulerService.startAllPendingJobs();
            QuartzDemoApplication.logger.info("Schedule all new scheduler jobs at app startup - complete");
        } catch (Exception ex) {
            QuartzDemoApplication.logger.error("Schedule all new scheduler jobs at app startup - error", ex);
        }
    }
}
