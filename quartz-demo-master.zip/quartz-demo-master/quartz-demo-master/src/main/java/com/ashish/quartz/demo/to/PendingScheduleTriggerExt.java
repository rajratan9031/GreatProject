package com.ashish.quartz.demo.to;

import java.util.Date;

public class PendingScheduleTriggerExt implements java.io.Serializable {

	private static final long serialVersionUID = -3506381981472535007L;

	private Long triggerId;
	private Long repateAfter;
	private Integer instanceId;
	private boolean allowConcurrentExec;
	private Integer groupId;
	private Integer jobId;
	private String jobCode;
	private String executionClassName;
	private Integer createdBy;
	private Date endDate;
	
	public PendingScheduleTriggerExt() {
	}
	
	public Long getTriggerId() {
		return triggerId;
	}
	public void setTriggerId(Long triggerId) {
		this.triggerId = triggerId;
	}
	public Integer getInstanceId() {
		return instanceId;
	}
	public void setInstanceId(Integer instanceId) {
		this.instanceId = instanceId;
	}
	public Integer getGroupId() {
		return groupId;
	}
	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}
	public Integer getJobId() {
		return jobId;
	}
	public void setJobId(Integer jobId) {
		this.jobId = jobId;
	}
	public String getJobCode() {
		return jobCode;
	}
	public void setJobCode(String jobCode) {
		this.jobCode = jobCode;
	}
	public String getExecutionClassName() {
		return executionClassName;
	}
	public void setExecutionClassName(String executionClassName) {
		this.executionClassName = executionClassName;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public boolean isAllowConcurrentExec() {
		return allowConcurrentExec;
	}

	public void setAllowConcurrentExec(boolean allowConcurrentExec) {
		this.allowConcurrentExec = allowConcurrentExec;
	}

	public Long getRepateAfter() {
		return repateAfter;
	}

	public void setRepateAfter(Long repateAfter) {
		this.repateAfter = repateAfter;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
}
