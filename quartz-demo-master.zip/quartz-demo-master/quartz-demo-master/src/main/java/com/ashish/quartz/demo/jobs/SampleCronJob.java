package com.ashish.quartz.demo.jobs;

import lombok.extern.slf4j.Slf4j;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;

import com.ashish.quartz.demo.QuartzDemoApplication;
import com.ashish.quartz.demo.service.SchedulerService;
import com.ashish.quartz.demo.service.impl.SchedulerServiceImpl;

import java.util.stream.IntStream;

@Slf4j
@DisallowConcurrentExecution
public class SampleCronJob extends QuartzJobBean {
    @Override
    protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
        QuartzDemoApplication.logger.info("SampleCronJob Start................");
        SchedulerService service = new SchedulerServiceImpl();
        service.createTriggerEntryForInstance(context.getMergedJobDataMap());
        IntStream.range(0, 10).forEach(i -> {
            QuartzDemoApplication.logger.info("Counting - {}", i);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                QuartzDemoApplication.logger.error(e.getMessage(), e);
            }
        });
        QuartzDemoApplication.logger.info("SampleCronJob End................");
    }
}
