package com.ashish.quartz.demo.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.Session;

import com.ashish.quartz.demo.to.PendingScheduleTriggerExt;
import com.ashish.quartz.demo.to.SchedulerInfoTO;
import com.ashish.quartz.enitiy.ScheduleGroupInstanceDetail;
import com.ashish.quartz.enitiy.ScheduleJob;
import com.ashish.quartz.enitiy.ScheduleJobTrigger;

public interface SchedulerDAO {
	
	 	void getAllSchedulers();
	 	
	 	void getAllActiveSchedulers();
	 	
	 	void getSchedulerByName();
	 	
	   // void insertSchedulerJob(SchedulerJobInfo jobInfo);
	    
	    void saveOrUpdateScheduleJobInstance(ScheduleGroupInstanceDetail detail);
	    
	    void saveOrUpdateScheduleGroupTriggerDetails(ScheduleJobTrigger trigger);

	   // void updateScheduleJob(SchedulerJobInfo jobInfo);

		List<PendingScheduleTriggerExt> getAllPendingJobs(Session session);

		void markAllUnfinshedInstatncesTrigger(Session session);

		void createTriggerEntryForInstance(Integer instanceId, Integer jobId, Date triggerFireDateTime,
				Integer createdBy, Date createdDate,int status, Session session);

		ScheduleGroupInstanceDetail getSchedulegroupInstanceDetailsByInstanceID(int instanceId,Session session);
		
		 ScheduleJob getScheduleJobByJobID(Integer jobId,Session session);

		Long saveOrUpdateScheduleGroupInstanceDetails(ScheduleJobTrigger sjt, Session session);

		ScheduleJobTrigger getScheduleJobTriggerByTriggerId(Long triggerId, Session session);

		boolean getInstanceStatusByInstanceId(int instanceId, Session session);

		List<SchedulerInfoTO> getAllScheduerInfo(Session session);
		
		
}
