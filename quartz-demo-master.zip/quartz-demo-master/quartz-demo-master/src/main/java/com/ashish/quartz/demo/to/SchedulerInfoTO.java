package com.ashish.quartz.demo.to;

import java.util.Date;

public class SchedulerInfoTO {
	private int instanceID;
	private String status;
	private boolean isRunning;
	private int triggerCount;
	private String jobCode;
	private String jobDesc;
	private String groupCode;
	private String type;
	private String createdBy;
	private Date createdDate;
	private int repateAfterEverySec;
	public SchedulerInfoTO() {
		// TODO Auto-generated constructor stub
	}

	public SchedulerInfoTO(int instanceID, String status, boolean isRunning, int triggerCount, String jobCode,
			String jobDesc, String groupCode, String type, String createdBy) {
		super();
		this.instanceID = instanceID;
		this.status = status;
		this.isRunning = isRunning;
		this.triggerCount = triggerCount;
		this.jobCode = jobCode;
		this.jobDesc = jobDesc;
		this.groupCode = groupCode;
		this.type = type;
		this.createdBy = createdBy;
	}

	public int getInstanceID() {
		return instanceID;
	}

	public void setInstanceID(int instanceID) {
		this.instanceID = instanceID;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public boolean isRunning() {
		return isRunning;
	}

	public void setRunning(boolean isRunning) {
		this.isRunning = isRunning;
	}

	public int getTriggerCount() {
		return triggerCount;
	}

	public void setTriggerCount(int triggerCount) {
		this.triggerCount = triggerCount;
	}

	public String getJobCode() {
		return jobCode;
	}

	public void setJobCode(String jobCode) {
		this.jobCode = jobCode;
	}

	public String getJobDesc() {
		return jobDesc;
	}

	public void setJobDesc(String jobDesc) {
		this.jobDesc = jobDesc;
	}

	public String getGroupCode() {
		return groupCode;
	}

	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public int getRepateAfterEverySec() {
		return repateAfterEverySec;
	}

	public void setRepateAfterEverySec(int repateAfterEverySec) {
		this.repateAfterEverySec = repateAfterEverySec;
	}
	
	
	
}
