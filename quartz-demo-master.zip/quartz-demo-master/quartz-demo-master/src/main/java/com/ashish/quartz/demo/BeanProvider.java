package com.ashish.quartz.demo;


import org.springframework.context.ApplicationContext;

public class BeanProvider {
	private static ApplicationContext  applicationContext;
	
	public static <T> T getBean(Class<T> clazz) {
		return applicationContext.getBean(clazz);
	}
	
	public static Object getBean(String clazz) {
		return applicationContext.getBean(clazz);
	}
	
	public static void setApplicationConext(ApplicationContext  applicationContext) {
		BeanProvider.applicationContext = applicationContext;
	}
}
