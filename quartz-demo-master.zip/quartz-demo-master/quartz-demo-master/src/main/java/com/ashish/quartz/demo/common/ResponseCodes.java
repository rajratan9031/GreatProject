package com.ashish.quartz.demo.common;

public interface ResponseCodes {
	int SUCCESS_CODE = 200;
	int EXCEPTION_CODE = 500;
	int NO_RESULT_FOUND = 201;
}
